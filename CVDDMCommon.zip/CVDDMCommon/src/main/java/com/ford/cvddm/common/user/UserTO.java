/**
 * 
 */
package com.ford.cvddm.common.user;

/**
 * @author NGUPTA18
 *
 */
public class UserTO {

	
	private String cdsID;
    private String fordGlobalID;
    private String firstName;
    private String lastName;
    private String fullName;
    private String fordDisplayName;
    private String mail;
    
	public String getCdsID() {
		return cdsID;
	}
	public void setCdsID(String cdsID) {
		this.cdsID = cdsID;
	}
	public String getFordGlobalID() {
		return fordGlobalID;
	}
	public void setFordGlobalID(String fordGlobalID) {
		this.fordGlobalID = fordGlobalID;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getFordDisplayName() {
		return fordDisplayName;
	}
	public void setFordDisplayName(String fordDisplayName) {
		this.fordDisplayName = fordDisplayName;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
}






