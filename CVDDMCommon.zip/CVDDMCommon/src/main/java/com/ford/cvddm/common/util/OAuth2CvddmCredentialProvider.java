/**
 * 
 */
package com.ford.cvddm.common.util;

import com.ford.it.util.oauth2.OAuth2Constants;
import com.ford.it.util.oauth2.internal.OAuth2Credential;

/**
 * This is Customized OAuth Credential Provider class to get OAuth Credentials
 * defined in configuration xml.Use this when we have to consume 
 * services/api/product which are Hosted in IBM API Connect Portal
 * and CVDDM Application has subscribed to their Product.
 * It is as per Ford Standards for OpenId Authentication and being
 * reviewed by JCOE Team: Colin
 * @author NGUPTA18
 *
 */
public class OAuth2CvddmCredentialProvider {/**
	 * Get the OAuth2 access token

	    /**
	     * Logging Setup
	     */
	    private static final String CLASS_NAME =
	    		OAuth2CvddmCredentialProvider.class.getName();

	    /**
	     * Logging Setup
	     */
	    private static final com.ford.it.logging.ILogger log =
	        com.ford.it.logging.LogFactory.getInstance().getLogger(CLASS_NAME);

	    private  String  oAuthTokenText="getOauth2TokenText";
	    
	    private  String oAuthBearerToken ="getOauth2BearerToken";
	    
	    private String oAuthCookie = "getOauth2Cookie";
	    
	    private String defaultConfig = "default";

	    /**
	     * A single instance of this class
	     */
	    private static OAuth2CvddmCredentialProvider instance =
	        new OAuth2CvddmCredentialProvider();

	    /**
	     * Return the OAuth2CredentialProvider instance
	     */
	    public static OAuth2CvddmCredentialProvider getInstance() {
	        return instance;
	    }

	    private OAuth2CvddmCredentialProvider() {
	    }

	    /**
	     * Get the OAuth2 token text.
	     */
	    public String getOauth2TokenText() {
	        final String METHOD_NAME = oAuthTokenText;
	        log.entering(CLASS_NAME, METHOD_NAME, defaultConfig);
	        log.exiting(CLASS_NAME, METHOD_NAME);
	        return getOauth2TokenText(defaultConfig);
	    }

	    /**
	     * Get the bearer token based for default configuration.
	     */
	    public String getOauth2BearerToken() {
	        final String METHOD_NAME = oAuthBearerToken;
	        log.entering(CLASS_NAME, METHOD_NAME, defaultConfig);
	        log.exiting(CLASS_NAME, METHOD_NAME);
	        return getOauth2BearerToken(defaultConfig);
	    }

	    /**
	     * Get the cookie text based for default configuration.
	     */
	    public String getOauth2Cookie() {
	        final String METHOD_NAME = oAuthCookie;
	        log.entering(CLASS_NAME, METHOD_NAME, defaultConfig);
	        log.exiting(CLASS_NAME, METHOD_NAME);
	        return getOauth2Cookie(defaultConfig);
	    }

	    /**
	     * Get the token text for a property manager configuration
	     */
	    public String getOauth2TokenText(final String configName) {
	        final String METHOD_NAME = oAuthTokenText;
	        log.entering(CLASS_NAME, METHOD_NAME, configName);

	        final OAuth2Credential oAuth2Credential = OAuth2CvddmUtil.initializeOAuth2Credential(configName);

	        OAuth2CvddmUtil.getAndPopulateOAuth2AccessToken(oAuth2Credential);

	        log.exiting(CLASS_NAME, METHOD_NAME, oAuth2Credential.getAccessToken());

	        return oAuth2Credential.getAccessToken();
	    }

	    /**
	     * Get the bearer token for custom configuration
	     */
	    public String getOauth2BearerToken(final String configName) {
	        final String METHOD_NAME = oAuthBearerToken;
	        log.entering(CLASS_NAME, METHOD_NAME, configName);

	        final String bearerToken = getBearerToken(getOauth2TokenText(configName));

	        log.exiting(CLASS_NAME, METHOD_NAME, bearerToken);

	        return bearerToken;

	    }

	    /**
	     * Get the cookie text for a property manager configuration
	     */
	    public String getOauth2Cookie(final String configName) {
	        final String METHOD_NAME = oAuthCookie;
	        log.entering(CLASS_NAME, METHOD_NAME, configName);

	        final String cookie = getADFSCookie(getOauth2TokenText(configName));

	        log.exiting(CLASS_NAME, METHOD_NAME, cookie);

	        return cookie;
	    }

	    /**
	     * Get the token text for app id, app secret and oauth token url, as well as a resource
	     * (required for ADFS v4).
	     */
	    public String getOauth2TokenText(final String appId, final String appSecret, final String oauthTokenUrl,
	        final String resource) {
	        final String METHOD_NAME = oAuthTokenText;
	        log.entering(CLASS_NAME, METHOD_NAME, appId, appSecret, oauthTokenUrl, resource);

	        final OAuth2Credential oAuth2Credential =
	            OAuth2CvddmUtil.initializeOAuth2Credential(appId, appSecret, oauthTokenUrl, null, resource);

	        OAuth2CvddmUtil.getAndPopulateOAuth2AccessToken(oAuth2Credential);

	        log.exiting(CLASS_NAME, METHOD_NAME, oAuth2Credential.getAccessToken());

	        return oAuth2Credential.getAccessToken();
	    }

	    /**
	     * Get the bearer token for app id, app secret and oauth token url, as well as a resource
	     * (required for ADFS v4).
	     */
	    public String getOauth2BearerToken(final String appId, final String appSecret, final String oauthTokenUrl,
	        final String resource) {
	        final String METHOD_NAME = oAuthBearerToken;
	        log.entering(CLASS_NAME, METHOD_NAME, appId, appSecret, oauthTokenUrl, resource);

	        final String bearerToken = getBearerToken(getOauth2TokenText(appId, appSecret, oauthTokenUrl, resource));

	        log.exiting(CLASS_NAME, METHOD_NAME, bearerToken);

	        return bearerToken;
	    }

	    /**
	     * Get the Cookie text for app id, app secret and oauth token url, as well as a resource
	     * (required for ADFS v4).
	     */
	    public String getOauth2Cookie(final String appId, final String appSecret, final String oauthTokenUrl,
	        final String resource) {
	        final String METHOD_NAME = "getOauth2Cookie";
	        log.entering(CLASS_NAME, METHOD_NAME, appId, appSecret, oauthTokenUrl, resource);

	        final String bearerToken = getADFSCookie(getOauth2TokenText(appId, appSecret, oauthTokenUrl, resource));

	        log.exiting(CLASS_NAME, METHOD_NAME, bearerToken);

	        return bearerToken;
	    }

	    /**
	     * Get the Token text for given app id, app secret and oauth token url.
	     */
	    public String getOauth2TokenText(final String appId, final String appSecret, final String oauthTokenUrl) {
	        final String METHOD_NAME = "getOauth2TokenText";
	        log.entering(CLASS_NAME, METHOD_NAME, appId, appSecret, oauthTokenUrl);

	        final OAuth2Credential oAuth2Credential =
	        		OAuth2CvddmUtil.initializeOAuth2Credential(appId, appSecret, oauthTokenUrl);

	        OAuth2CvddmUtil.getAndPopulateOAuth2AccessToken(oAuth2Credential);

	        log.exiting(CLASS_NAME, METHOD_NAME, oAuth2Credential.getAccessToken());

	        return oAuth2Credential.getAccessToken();

	    }

	    /**
	     * Get the bearer token for app id, app secret and oauth token url.
	     */
	    public String getOauth2BearerToken(final String appId, final String appSecret, final String oauthTokenUrl) {
	        final String METHOD_NAME = "getOauth2BearerToken";
	        log.entering(CLASS_NAME, METHOD_NAME, appId, appSecret, oauthTokenUrl);

	        final String bearerToken = getBearerToken(getOauth2TokenText(appId, appSecret, oauthTokenUrl));

	        log.exiting(CLASS_NAME, METHOD_NAME, bearerToken);

	        return bearerToken;

	    }

	    /**
	     * Get the cookietext for given app id, app secret and oauth token url.
	     */
	    public String getOauth2Cookie(final String appId, final String appSecret, final String oauthTokenUrl) {
	        final String METHOD_NAME = oAuthCookie;
	        log.entering(CLASS_NAME, METHOD_NAME, appId, appSecret, oauthTokenUrl);

	        final String cookie = getADFSCookie(getOauth2TokenText(appId, appSecret, oauthTokenUrl));

	        log.exiting(CLASS_NAME, METHOD_NAME, cookie);

	        return cookie;

	    }


	    private String getBearerToken(final String oAuth2TokenText) {

	        return OAuth2Constants.BEARER + " " + oAuth2TokenText;
	    }

	    private String getADFSCookie(final String oAuth2TokenText) {
	        return "ADFS-credential=" + oAuth2TokenText;
	    }
}
