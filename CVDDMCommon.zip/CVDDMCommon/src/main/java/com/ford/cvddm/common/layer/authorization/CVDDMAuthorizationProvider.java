//****************************************************************
//* Copyright (c) 2015 Ford Motor Company. All Rights Reserved.
//****************************************************************
package com.ford.cvddm.common.layer.authorization;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;


import com.ford.aps.Subject;
import com.ford.cvddm.common.layer.CVDDMRequestContext;
import com.ford.it.context.RequestContext;
import com.ford.it.logging.ILogger;
import com.ford.it.security.plugins.aps.APSAuthorizationProvider;
import com.ford.it.security.plugins.aps.APSPluginException;
import com.ford.it.logging.LogFactory;

/**
 * Simple
 */
@Named
@ApplicationScoped
public class CVDDMAuthorizationProvider extends APSAuthorizationProvider {
    // TODO this would be the authorization provider your app would use. Extend the
    // appropriate provider (APS, Simple, EAA, or custom).
    /**
     * Default serialization id.
     */
    private static final long serialVersionUID = 1L;
    
    private static final String CLASS_NAME =
    		CVDDMAuthorizationProvider.class.getName();
    
    /**
     * Logging setup
     */
    private static final ILogger log = LogFactory.getInstance().getLogger(
            CLASS_NAME);
}
