package com.ford.cvddm.common.service;

import java.util.ResourceBundle;
/**
 * <p>The application context provides a mechanism
 * of giving context information to an application.</p>
 * <p>The current implementation wraps a ResourceBundle.</p>
 * Creation date: (10/3/01 4:48:59 PM)
 * @author: Richard Hom
 */
public class ApplicationContext {
	private java.util.ResourceBundle rb;
	/**
	 * Constructor for the application context.
	 * @param propertyFileName java.lang.String
	 */
	public ApplicationContext(String propertyFileName) {
		super();
		this.rb = ResourceBundle.getBundle(propertyFileName);
	}
	/**
	 * Takes key as parameter and returns its value 
	 * Creation date: (10/3/01 5:48:33 PM)
	 * @return java.lang.String
	 * @param keyStr java.lang.String
	 */
	public String get(String keyStr) {
		return getResourceBundle().getString(keyStr);
	}
	/**
	 * Accessor for resource bundle.
	 * Creation date: (10/3/01 5:46:48 PM)
	 * @return java.util.ResourceBundle
	 */
	protected ResourceBundle getResourceBundle() {
		return rb;
	}
}