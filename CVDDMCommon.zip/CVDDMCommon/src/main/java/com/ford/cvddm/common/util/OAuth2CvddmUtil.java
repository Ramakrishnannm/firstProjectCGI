/**
 * 
 */
package com.ford.cvddm.common.util;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.it.exception.FordExceptionAttributes;
import com.ford.it.exception.FordSelfLoggingRuntimeException;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.Level;
import com.ford.it.logging.LogFactory;
import com.ford.it.properties.PropertyManager;
import com.ford.it.util.oauth2.OAuth2Constants;
import com.ford.it.util.oauth2.internal.OAuth2Credential;


/**
 * This is Customized OAuth2Util class to get Access Token
 * for services/api/product which are Hosted in IBM API Connect Portal.
 * and CVDDM Application has subscribed to their Product.
 * It is as per Ford Standards for OpenId Authentication and being
 * reviewed by JCOE Team: Colin.
 * @author NGUPTA18
 *
 */
public class OAuth2CvddmUtil {
    private static final String CLASS_NAME =
    		OAuth2CvddmUtil.class.getName();

        private static final ILogger log = LogFactory.getInstance().getLogger(
            CLASS_NAME);

        /**
         * Credential Cache
         */
        private static Map<String, OAuth2Credential> credentialCache = new HashMap<String, OAuth2Credential>();

        /**
         * No instantiation of utility class
         *
         */
        private OAuth2CvddmUtil() {
        }

        public static OAuth2Credential initializeOAuth2Credential(final String configName) {
            final PropertyManager pm = PropertyManager.getInstance();
            final String configNamePath = OAuth2Constants.OAUTH2_CREDENTIALS_CONFIG + "." + configName + ".";

            return initializeOAuth2Credential(pm.getString(configNamePath + OAuth2Constants.APP_ID, null),
                pm.getString(configNamePath + OAuth2Constants.APP_SECRET, null),
                pm.getString(configNamePath + OAuth2Constants.OAUTH_TOKEN_URL, null), configName,
                pm.getString(configNamePath + OAuth2Constants.RESOURCE, null));
        }

        public static OAuth2Credential initializeOAuth2Credential(final String appId, final String appSecret,
            final String oauthTokenUrl) {
            return initializeOAuth2Credential(appId, appSecret, oauthTokenUrl, null, null);
        }

        public static OAuth2Credential initializeOAuth2Credential(final String appId, final String appSecret,
            final String oauthTokenUrl, final String configName, final String resource) {
            final String METHOD_NAME = "initializeOAuth2Credential";
            log.entering(CLASS_NAME, METHOD_NAME);
            final OAuth2Credential oAuth2Credential = new OAuth2Credential(appId, appSecret, oauthTokenUrl);
            oAuth2Credential.setConfigName(configName);
            oAuth2Credential.setResource(resource);

            if (log.isLoggable(Level.FINER))
                log.logp(Level.FINER, CLASS_NAME, METHOD_NAME, oAuth2Credential.toString());
            log.exiting(CLASS_NAME, METHOD_NAME);
            return oAuth2Credential;
        }

        private static boolean checkOAuth2CredentialFields(final OAuth2Credential oAuth2Credential) {
            final String METHOD_NAME = "checkOAuth2CredentialFields";
            log.entering(CLASS_NAME, METHOD_NAME);
            if (null == oAuth2Credential
                || null == oAuth2Credential.getAppId() || null == oAuth2Credential.getAppSecret()
                || null == oAuth2Credential.getOauthTokenUrl()) {

                log.exiting(CLASS_NAME, METHOD_NAME);
                return false;
            }
            log.exiting(CLASS_NAME, METHOD_NAME);
            return true;
        }

        public static void getAndPopulateOAuth2AccessToken(final OAuth2Credential oAuth2Credential) {
            final String METHOD_NAME = "getOAuth2AccessToken";
            log.entering(CLASS_NAME, METHOD_NAME, oAuth2Credential);

            if (!checkOAuth2CredentialFields(oAuth2Credential)) {
                log.logp(Level.WARNING, CLASS_NAME, METHOD_NAME,
                    "Please verify the oauth configuration file and have all the required fields: app_id, app_secret and oauth_token_url");
                log.exiting(CLASS_NAME, METHOD_NAME);
                return;
            }

            OAuth2Credential cachedCredential = null;
            if (isCacheEnabled()) {
                cachedCredential = getOAuth2CredentialFromCache(oAuth2Credential.getConfigName());
            }
            if (null != cachedCredential) {
                // cached Credential found
                copyCredential(cachedCredential, oAuth2Credential);
                log.logp(Level.FINER, CLASS_NAME, METHOD_NAME, "<< get from Cache: " + oAuth2Credential.getAccessToken());
                return;
            }
            try {
                HttpsURLConnection connection;
                connection = requestAccessToken(oAuth2Credential);

                final int responseStatusCode = connection.getResponseCode();

                if (responseStatusCode == 200) {
                    parseOauthCredentialFromJson(connection, oAuth2Credential);
                    if (isCacheEnabled()) {
                        credentialCache.put(oAuth2Credential.getConfigName(), oAuth2Credential);
                        log.logp(Level.FINE, CLASS_NAME, METHOD_NAME,
                            "Put into cache:[" + oAuth2Credential.getConfigName() + "]");
                    }


                } else {
                    log.logp(Level.WARNING, CLASS_NAME, METHOD_NAME,
                        "Failed to get access token. The http response status code from " + oAuth2Credential.getOauthTokenUrl()
                            + " was " + responseStatusCode);
                }
            } catch (final Exception ex) {
            	log.severe(CvddmUtil.getStackTraceContent(ex));
                throw new FordSelfLoggingRuntimeException(
                    new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
                    "Unable to establish connection to OAuth2 Provider server", ex);

            }

            log.exiting(CLASS_NAME, METHOD_NAME, oAuth2Credential);
        }

        /**
         * Construct a method to request client credential grant token from
         * GVMS API Connect oauth2 provider
         */
        private static HttpsURLConnection requestAccessToken(final OAuth2Credential oAuth2Credential) throws IOException {
            final String METHOD_NAME = "requestAccessToken";
            log.entering(CLASS_NAME, METHOD_NAME, oAuth2Credential);
            final String grantTypeString = "grant_type=client_credentials";
            String resource = null;
            if (null != oAuth2Credential.getResource())
                resource = "resource=" + oAuth2Credential.getResource(); // provider's resource ID

            String body = grantTypeString + "&client_id="+ oAuth2Credential.getAppId();
            body +="&client_secret="+ oAuth2Credential.getAppSecret();
            body+="&code=&redirect_uri=&username=&password=";
            body +="&scope=uaa.resource";
            body +="&refresh_token=";
            if (null != resource)
                body += "&" + resource;   
        
            	

            URL url = new URL(oAuth2Credential.getOauthTokenUrl());
            HttpsURLConnection connection = (HttpsURLConnection)url.openConnection();
            connection.setConnectTimeout(5 * 1000); // 5 second to connect
            connection.setReadTimeout(10 * 1000); // 10 seconds to read a response
            connection.setRequestMethod(CVDDMConstant.POST_METHOD);

            final byte[] authentication =
                (oAuth2Credential.getAppId() + ":" + oAuth2Credential.getAppSecret()).getBytes(StandardCharsets.UTF_8);
            final String encodedAuth = javax.xml.bind.DatatypeConverter.printBase64Binary(authentication);
            connection.setRequestProperty("Authorization", "Basic " + encodedAuth);

            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            connection.setRequestProperty("charset", "utf-8");
            connection.setRequestProperty("Content-Length", Integer.toString(body.length()));

            connection.setDoOutput(true);

            connection.connect();
            final DataOutputStream writer = new DataOutputStream(connection.getOutputStream());

            writer.writeBytes(body);
            writer.flush();
            writer.close();

            log.exiting(CLASS_NAME, METHOD_NAME, connection);
            return connection;

        }

        private static void parseOauthCredentialFromJson(final HttpsURLConnection connection,
            final OAuth2Credential oAuth2Credential) throws IOException {
            final String METHOD_NAME = "parseOauthCredentialFromJson";
            log.entering(CLASS_NAME, METHOD_NAME);

            final ObjectMapper objectMapper = new ObjectMapper();
      

           final JsonNode jsonMap = objectMapper.readTree(connection.getInputStream());
            

            if (!jsonMap.isObject()) {
                log.logp(Level.FINER, CLASS_NAME, METHOD_NAME,
                    "The response from request access token is not a Json object.");
                log.exiting(CLASS_NAME, METHOD_NAME);
                return;
            }

            oAuth2Credential.setAccessToken(jsonMap.get(OAuth2Constants.ACCESS_TOKEN).asText());

            if (null != jsonMap.get(OAuth2Constants.TOKEN_TYPE))
                oAuth2Credential.setTokenType(jsonMap.get(OAuth2Constants.TOKEN_TYPE).asText());

            if (null != jsonMap.get(OAuth2Constants.EXPIRES_IN))
                oAuth2Credential.setExpiresIn(jsonMap.get(OAuth2Constants.EXPIRES_IN).asText());
            else
                oAuth2Credential.setExpiresIn("0");

            if (null != jsonMap.get(OAuth2Constants.SCOPE))
                oAuth2Credential.setScope(jsonMap.get(OAuth2Constants.SCOPE).asText());

            if (null != jsonMap.get(OAuth2Constants.JTI))
                oAuth2Credential.setJti(jsonMap.get(OAuth2Constants.JTI).asText());

            final long expiresAt =
                System.currentTimeMillis() + (Integer.parseInt(oAuth2Credential.getExpiresIn())) * 1000;
            oAuth2Credential.setExpiresAt(expiresAt);

            log.logp(Level.FINER, CLASS_NAME, METHOD_NAME,
                "AccessToken[" + oAuth2Credential.getAccessToken() + "] TokenType[" + oAuth2Credential.getTokenType()
                    + "] Scope["
                    + oAuth2Credential.getScope() + "] ExpiresIn[" + oAuth2Credential.getExpiresIn() + "] Jti["
                    + oAuth2Credential.getJti() + "] ExpiresAt[" + oAuth2Credential.getExpiresAt() + "]");
            log.exiting(CLASS_NAME, METHOD_NAME);
        }

        private static OAuth2Credential getOAuth2CredentialFromCache(final String configName) {
            if (null == configName) {
                return null;
            } else {
                final OAuth2Credential oAuth2Credential = credentialCache.get(configName);
                if ((null != oAuth2Credential) && (null != oAuth2Credential.getAccessToken())) {
                    if(isTokenExpired(oAuth2Credential)) {
                        return null;
                    }
                }
                return oAuth2Credential;
            }
        }

        private static boolean isTokenExpired(final OAuth2Credential oAuth2Credential) {
            final String METHOD_NAME = "isTokenExpired";
            log.logp(Level.FINER, CLASS_NAME, METHOD_NAME,
                "Current time [" + System.currentTimeMillis() + "] Expired at[" + oAuth2Credential.getExpiresAt() + "]");
            return System.currentTimeMillis() > oAuth2Credential.getExpiresAt();
        }

        private static void copyCredential(final OAuth2Credential src, final OAuth2Credential dst) {
            dst.setAccessToken(src.getAccessToken());
            dst.setTokenType(src.getTokenType());
            dst.setExpiresIn(src.getExpiresIn());
            dst.setScope(src.getScope());
            dst.setJti(src.getJti());
            dst.setExpiresAt(src.getExpiresAt());
        }

        private static boolean isCacheEnabled() {
            final String CACHE_ENABLE_FLAG = "com_ford_it_oauth2_cache_enabled";
            final String cacheEnable = System.getenv(CACHE_ENABLE_FLAG);
            if (null != cacheEnable && cacheEnable.trim().equalsIgnoreCase("false")) {
                return false;
            }
            return true;
        }

}
