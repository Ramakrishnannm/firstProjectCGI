package com.ford.cvddm.common.layer;

import com.ford.it.context.RequestContext;
import com.ford.it.context.SubContext;

public class CVDDMRequestContext implements SubContext {
    /**
     * environment
     */
    private String environment;

    /**
     * @see com.ford.it.context.SubContext#close()
     */
    @Override
    public void close() {
        this.environment = null;
    }

    /**
     * @see com.ford.it.context.SubContext#init()
     */
    @Override
    public void init() {
        // empty block
    }

    /**
     * @return The local instance of the cvddmRequestContext class
     */
    public static CVDDMRequestContext getInstance() {
        final CVDDMRequestContext ctx =
                RequestContext.getLocalInstance().getSubContext(
                        CVDDMRequestContext.class);
        return ctx;
    }

    
    public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

}
