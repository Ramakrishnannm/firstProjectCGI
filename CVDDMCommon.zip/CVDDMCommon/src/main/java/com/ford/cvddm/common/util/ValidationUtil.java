package com.ford.cvddm.common.util;

import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;
import com.ford.it.util.TextUtil;

import java.util.Calendar;
import java.util.Date;


import org.apache.commons.validator.routines.EmailValidator;

/**
 * 
 * 
 * @author MJEYARAJ
 *
 */
public class ValidationUtil {

	private static final String CLASS_NAME = ValidationUtil.class.getName();
	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	/**
	 * Private class constructor.
	 */
	private ValidationUtil() {

		super();
	}

	/**
	 * Utility to validate PartIISpec
	 * 
	 * @param inputPartIISpec
	 * @return
	 */
	public static boolean validatePartIISpec(String inputPartIISpec) {

		final String METHOD_NAME = "validateInputPartIISpec";
		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			if (TextUtil.isBlankOrNull(inputPartIISpec)) {
				return false;
			}

			String[] splittedP2S = inputPartIISpec.split(CVDDMConstant.INPUT_PARTIISPEC_SPLITTER);

			if (CvddmUtil.isArrayEmpty(splittedP2S)) {
				return false;
			}

			if (splittedP2S.length != 3) {
				return false;
			}
			if ((splittedP2S[0].length() != 6) || !splittedP2S[0].matches(CVDDMConstant.ALPHA_NUMERIC_MATCH)) {
				return false;
			}
			if ((splittedP2S[1].length() != 6) || !splittedP2S[0].matches(CVDDMConstant.ALPHA_NUMERIC_MATCH)) {
				return false;
			}
			if (!((splittedP2S[2].length() == 2) || (splittedP2S[2].length() == 3))
					|| !splittedP2S[2].matches(CVDDMConstant.ALPHA_NUMERIC_MATCH)) {
				return false;
			}

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			return false;
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

		return true;
	}

	/**
	 * Utility to validate VIN number
	 * 
	 * @param inputVIN
	 * @return
	 */
	public static boolean validateVinNumber(String inputVIN) {

		final String METHOD_NAME = "validateVinNumber";
		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			if (TextUtil.isBlankOrNull(inputVIN)
					|| inputVIN.length() != Integer.valueOf(CvddmUtil.getPropertiesValue(
							CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY, CVDDMConstant.VALID_VIN_LENGTH))
					|| !inputVIN.matches(CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
							CVDDMConstant.VALID_VIN_FORMAT))) {
				return false;
			}

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			return false;
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

		return true;
	}

	/** Start Change: User Story : US1061675 ***/
	/**
	 * Method Name: isValidEmailAddress
	 * 
	 * @Description: This method validates User Provided Email Id using
	 *               1.org.apache.commons.validator.routines.EmailValidator which
	 *               provides email address validation according to RFC 822
	 *               standards and 2. Regular Exp.
	 * @param String
	 *            emailAddress
	 * @return boolean
	 */

	public static boolean isValidEmailAddress(final String emailAddress) {
		boolean validEmailAddress = false;

		EmailValidator validator = EmailValidator.getInstance();

		String emailPattern = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

		if (TextUtil.isNotBlankOrNull(emailAddress)) {

			validEmailAddress = validator.isValid(emailAddress);

			log.info("Apache Email Check Response  " + validEmailAddress);

			if (validEmailAddress) {
				// Level Two check
				validEmailAddress = emailAddress.matches(emailPattern);
				log.info("Expression Email Check Response  " + validEmailAddress);
			}
		}
		return validEmailAddress;
	}
	
	/**
	 * Method Name: isDateGreaterthanCurrentDate
	 * 
	 * @Description: This method validates User Provided Date is greater than Current Date
	 * @param Date userDate
	 * @return boolean
	 */
	
	public static boolean isDateGreaterthanCurrentDate(final Date userDate) {
        
		final String METHOD_NAME = "isDateGreaterthanCurrentDate";
        log.entering(CLASS_NAME, METHOD_NAME);

        if (CvddmUtil.isObjectEmpty(userDate) || userDate.toString().length() == 0) {
            return true;
        }

        final Date checkDate = userDate;

        final Calendar cal = Calendar.getInstance();
        cal.setTime(checkDate);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        checkDate.setTime(cal.getTimeInMillis());

        cal.setTimeInMillis(System.currentTimeMillis());
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);

        if (checkDate.getTime() < cal.getTimeInMillis())
            return false;

        log.exiting(CLASS_NAME, METHOD_NAME);
        return true;

    }
	/** End Change: User Story : US1061675 ***/
}
