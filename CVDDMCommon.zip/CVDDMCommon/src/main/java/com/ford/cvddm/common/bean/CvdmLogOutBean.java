package com.ford.cvddm.common.bean;

import java.io.Serializable;

import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.ford.cvddm.common.util.CvddmUtil;
import javax.servlet.http.Cookie;


@Named
@RequestScoped
public class CvdmLogOutBean implements Serializable  {

    private static final long serialVersionUID = 1L;
    private static final String CLASS_NAME = CvdmLogOutBean.class.getName();


    private static final com.ford.it.logging.ILogger log = com.ford.it.logging.LogFactory
            .getInstance().getLogger(CLASS_NAME);
    


    /**
     * Method Name: processLogout
     * @Description:This method would LogOut the User and redirect to LogOut Page.
     * @param None
     * @return void
     */
    
    public void processLogout() {
    	try {
    		final String METHOD_NAME = "processLogout()";
    		log.entering(CLASS_NAME, METHOD_NAME);
    		FacesContext context = FacesContext.getCurrentInstance();
    		final HttpServletRequest request = (HttpServletRequest)context.getExternalContext().getRequest(); 
    		final HttpServletResponse response = (HttpServletResponse)context.getExternalContext().getResponse();
    		
    		removeLTPATokensFromRequest(request, response);
    		request.getSession(false).invalidate();
    		context.getExternalContext().invalidateSession();
    		request.logout();
    		log.exiting(CLASS_NAME, METHOD_NAME);
    		context.getExternalContext().redirect("/logout.faces?faces-redirect=true");
    	}
    	catch (Exception e) {log.severe(CvddmUtil.getStackTraceContent(e));}
    }
    /**
     * Method Name: removeLTPATokensFromRequest
     * @Description:This method would remove LTPA Tokens from Request.
     * @param final HttpServletRequest request,
               final HttpServletResponse response
     * @return void
     */
    private void removeLTPATokensFromRequest(final HttpServletRequest request,
            final HttpServletResponse response) {
        final Cookie[] cookies = request.getCookies();
        for (final Cookie cookie : cookies) {
            if (isLTPACookie(cookie)) {
                clearCookieValues(cookie);
                response.addCookie(cookie);
            }
        }
    }
   
   
    /**
     * Method Name: isLTPACookie
     * @Description:This method checks whether particular Cookie in LTPA Token or not.
     * @param final Cookie cookie
     * @return boolean
     */
    private boolean isLTPACookie(final Cookie cookie) {
        return "LtpaToken2".equalsIgnoreCase(cookie.getName())
               || "LtpaToken".equalsIgnoreCase(cookie.getName());
    }
    /**
     * Method Name: clearCookieValues
     * @Description:This method would clear Cookies Value.
     * @param final Cookie cookie
     * @return void
     */
    private void clearCookieValues(final Cookie cookie) {
        cookie.setMaxAge(0);
        cookie.setValue("");
        cookie.setPath("/");
    }
	public void processSessionOut() {
	   
	    processLogout();
	}


}
