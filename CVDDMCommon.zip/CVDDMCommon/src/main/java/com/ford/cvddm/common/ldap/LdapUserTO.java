/**
 * 
 */
package com.ford.cvddm.common.ldap;

/**
 * @since US1121586
 * @author NGUPTA18
 *  This class contains some attributes of LDAP for particular User.
 *
 */
public class LdapUserTO {
	
	private String cdsID;
    private String fordGlobalID;
    private String firstName;
    private String lastName;
    private String fullName;
    private String fordDisplayName;
    private String mail;
    
    public String getCdsID() {
        return this.cdsID;
    }

    public LdapUserTO setCdsID(final String cdsID) {

        this.cdsID = cdsID;
        return this;
    }

    public String getFordGlobalID() {
        return this.fordGlobalID;
    }

    public LdapUserTO setFordGlobalID(final String fordGlobalID) {

        this.fordGlobalID = fordGlobalID;
        return this;
    }

    public String getFirstName() {
        return this.firstName;
    }

    public LdapUserTO setFirstName(final String firstName) {

        this.firstName = firstName;
        return this;
    }

    public String getLastName() {
        return this.lastName;
    }

    public LdapUserTO setLastName(final String lastName) {

        this.lastName = lastName;
        return this;
    }

    public String getFullName() {
        return this.fullName;
    }

    public LdapUserTO setFullName(final String fullName) {

        this.fullName = fullName;
        return this;
    }

    public String getFordDisplayName() {
        return this.fordDisplayName;
    }

    public LdapUserTO setFordDisplayName(final String fordDisplayName) {

        this.fordDisplayName = fordDisplayName;
        return this;
    }

    public String getMail() {
        return this.mail;
    }

    public LdapUserTO setMail(final String mail) {

        this.mail = mail;
        return this;
    }

}
