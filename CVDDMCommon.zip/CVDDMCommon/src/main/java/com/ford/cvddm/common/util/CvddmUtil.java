package com.ford.cvddm.common.util;
import javax.faces.application.ConfigurableNavigationHandler;
import javax.faces.application.ViewHandler;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.view.facelets.FaceletException;
import javax.servlet.http.HttpServletRequest;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.TimeZone;
import java.util.TreeMap;

import com.ford.cvddm.common.user.UserTO;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.it.context.RequestContext;
import com.ford.it.context.UserAttributes;
import com.ford.it.email.Email;
import com.ford.it.email.Message;
import com.ford.it.email.Recipient;
import com.ford.it.exception.FordExceptionAttributes;
import com.ford.it.exception.FordSelfLoggingRuntimeException;
import com.ford.it.jsfcore.util.JcLoggingUtil;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.Level;
import com.ford.it.logging.LogFactory;
import com.ford.it.util.TextUtil;



/* 
Class Name: CvddmUtil
@Description: This class contains CVDDM Application related Common Utility Methods.
@author NGUPTA18
 */

public class CvddmUtil {



	private static final String CLASS_NAME =
			CvddmUtil.class.getName();
	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	private static String senderEmailId = null;

	/**
	 * Private class constructor.
	 */

	private CvddmUtil() {

		super();
		loadProperties();

	}

	/**
	 * Method Name: loadProperties()
	 * @Description:This method retrieves would read Properties from cvddmApplication.xml .
	 * @param None
	 * @return String
	 */

	public static void loadProperties() {

		final String METHOD_NAME = "loadProperties";
		log.entering(CLASS_NAME, METHOD_NAME);

		if(TextUtil.isBlankOrNull(senderEmailId)) {

			senderEmailId = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
					CVDDMConstant.CVDDM_SENDER_EMAIL_ID);
		} 
		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * Method Name: getLoggedInUserCDSID
	 * @Description:This method retrieves Logged In User's CDS ID.
	 * @param None
	 * @return String
	 */

	public static String getLoggedInUserCDSID() {


		final String METHOD_NAME = "getLoggedInUserCDSID";
		log.entering(CLASS_NAME, METHOD_NAME);

		String cdsId = "";

		FacesContext fc = FacesContext.getCurrentInstance();

		if(!isObjectEmpty(fc)) {

			ExternalContext exCont = fc.getExternalContext();

			if(!isObjectEmpty(exCont)) {

				HttpServletRequest req = (HttpServletRequest) fc.getExternalContext().getRequest();

				if(!isObjectEmpty(req)) {

					cdsId = req.getUserPrincipal().getName();

				}
			}
		}
		if(TextUtil.isNotBlankOrNull(cdsId)) {
			cdsId = cdsId.toUpperCase();    
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
		return cdsId;
	}
	/**
	 * Method Name: isObjectEmpty
	 * @Description:This method checks whether passed Object is null or blank.
	 * @param Object obj
	 * @return boolean
	 */
	public static boolean isObjectEmpty(Object obj){

		boolean isObjectEmpty = true;
		if(obj!=null && obj !="") {
			isObjectEmpty= false;
		}
		return isObjectEmpty;
	}

	/**
	 * Method Name: formatUserEmail
	 * @Description:Create a user email that is compatible with APS. If the userId pass in
	 * contains an "@" this method assumes it is already in e-mail format.
	 * Otherwise this method will append @ford.com to the end of the user-id to
	 * create a valid Ford email address.
	 *
	 * @param userID the userID to consider turning into an e-mail string
	 * @return String the userID represented as an e-mail
	 */
	public static String formatUserEmail(final String userID) {
		final String METHOD_NAME = "formatUserEmail";
		log.entering(CLASS_NAME, METHOD_NAME);

		String userEmail;


		final String FORD_EMAIL_SUFFIX = "@ford.com";

		if (userID.contains("@")) {
			userEmail = userID;
		} else {
			userEmail = userID + FORD_EMAIL_SUFFIX;
		}

		log.exiting(CLASS_NAME, METHOD_NAME, userEmail);

		return userEmail;
	}



	/**
	 * @Description: This method return Date in TimeZone as passed Argument.
	 * @param String timeZone
	 * @return Date
	 */

	public static Date getTimeZoneCurrentDate(String timeZone) {

		Date timeZoneDate = null;
		try {

			Calendar cal = Calendar.getInstance();  //Create date

			TimeZone tz = TimeZone.getTimeZone(timeZone);  //Create timezone

			cal.setTimeZone(tz); 
			timeZoneDate = cal.getTime();
		}
		catch (Exception ex) {
			log.severe(CvddmUtil.getStackTraceContent(ex));
		}
		return timeZoneDate;
	}
	/**Start Change :User Story: US943267***/
	/**
	 * Method Name: getPropertiesValue
	 * @Description:This method would retrieve Validation Messages/Properties values 
	 *               Defined in ValidationMessages.properties or Application Properties by passing 
	 *               Message Key Name and Bundle Name (configured in faces-config.xml).
	 * @param String resourceBundle ,String msgKey
	 * @return String valMsg
	 */

	public static String getPropertiesValue(String resourceBundle ,String msgKey) {

		String valMsg = null;
		final String METHOD_NAME = "getPropertiesValue";

		log.entering(CLASS_NAME, METHOD_NAME);

		ResourceBundle bundle;

		try {
			FacesContext context = FacesContext.getCurrentInstance();
			bundle = context.getApplication().getResourceBundle(context, resourceBundle);

			if(!isObjectEmpty(bundle)) {

				valMsg = bundle.getString(msgKey);
			}
			else {
				valMsg = msgKey + CVDDMConstant.BUNDLE_KEY_NOT_FOUND_MSG;
			}

		} catch (Exception e) {
			valMsg = CVDDMConstant.BUNDLE_KEY_NOT_FOUND_MSG;
			log.severe(CvddmUtil.getStackTraceContent(e));
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
		return valMsg;
	}
	/**End Change :User Story: US943267***/

	/**
	 * US1021877 - Method to load the properties file
	 * 
	 * @param resourceBundle
	 * @return
	 */
	public static ResourceBundle getPropertiesFile(String resourceBundle) {

		final String METHOD_NAME = "getPropertiesFile";

		log.entering(CLASS_NAME, METHOD_NAME);

		ResourceBundle bundle = null;

		try {
			FacesContext context = FacesContext.getCurrentInstance();
			bundle = context.getApplication().getResourceBundle(context, resourceBundle);

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
		return bundle;
	}

	/** Start Change :User Story: US889958 ***/

	/** 
	 * Method Name: sortByKey
	   @Description: This method would sort HashMap on basis of Key.
	   @param : Map<String, String> inputMap
	   @return  TreeMap<String, String>
	 */

	public static Map<String, String> sortByKey(Map<String, String> inputMap) 
	{ 
		// TreeMap to store values of HashMap 
		TreeMap<String, String> sortedMap = new TreeMap<String, String>(); 

		// Copy all data from hashMap into TreeMap 
		sortedMap.putAll(inputMap);   

		return sortedMap;
	}

	/** End Change :User Story: US889958 ***/

	/** Start Change :User Story: US941763 ****/
	/**
	 * Method Name: isArrayEmpty
	 * @Description:This method checks whether passed Array is null or empty.
	 * @param Object array
	 * @return boolean
	 */
	public static boolean isArrayEmpty(Object [] obj){

		boolean isArrayEmpty = true;
		if(obj!=null && obj.length != 0) {
			isArrayEmpty= false;
		}
		return isArrayEmpty;	
	}
	/** End Change :User Story: US941763 ****/

	/** Start Change :User Story: US890085 ****/
	/**
	 * Method Name: getStackTraceContent
	 * @Description:This method would fetch Exception StackTrace content as String.
	 * @param Exception ex
	 * @return String exceptionAsString
	 */
	public static String getStackTraceContent(Exception ex){

		Writer sw = new StringWriter();
		ex.printStackTrace(new PrintWriter(sw));
		String exceptionAsString = sw.toString();
		if(TextUtil.isBlankOrNull(exceptionAsString)) {

			exceptionAsString = "Couldn't retrieve Exception Details.";
		}
		return exceptionAsString;
	}
	/** End Change :User Story: US890085 ****/

	/**
	 * Method Name: navigateToReqPage
	 * 
	 * @Description: This method would redirect to JSF Page link provided in
	 *  by the User within cvddmcore:downTime Tags
	 * @param final UIComponent uiDowntime
	 * @return void
	 */

	public static void navigateToReqPage(final String pageContextPath, final FacesContext facesContext) {

		final String METHOD_NAME = "navigateToReqPage";

		final ConfigurableNavigationHandler navigationHandler =
				(ConfigurableNavigationHandler)facesContext.getApplication()
				.getNavigationHandler();

		final Level level = JcLoggingUtil.getErrorPageDetailLoggingLevel();
		if (null != level) {
			log.logp(level, CLASS_NAME, METHOD_NAME,
					"Return to pageContextPath[" + pageContextPath + "].");
		}

		final ViewHandler viewHandler = facesContext.getApplication().getViewHandler();
		final String errorPageViewId = viewHandler.deriveViewId(facesContext, pageContextPath);
		if (null == errorPageViewId) {
			throw new FaceletException("No pageContextPath page ["
					+ pageContextPath + "] found.");
		}
		navigationHandler.performNavigation(pageContextPath);
	}
	/*** Start Change :User Story: US945528**/
	/**
	 * Method Name: sendMaintEmail()
	 * @Description:This method would format and send Maintenance Activity related Email to all the Email Id's passed in Input Map.
	 * @param Map<String,String> inputMap
	 * @return void
	 */
	public static void sendMaintEmail(Map<String,String> inputMap) {
		
		final String METHOD_NAME = "sendMaintEmail";
		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			Recipient recipients = null;

			StringBuilder htmlContent= new StringBuilder();

			String emailDtls = inputMap.get(CVDDMConstant.EMAIL_IDS_DETAILS);

			String tempFromDt = inputMap.get(CVDDMConstant.EMAIL_FROM_DATE_STR);

			String tempToDt= inputMap.get(CVDDMConstant.EMAIL_TO_DATE_STR);

			String tempDesc= inputMap.get(CVDDMConstant.EMAIL_MAINT_DESC);

			String tempScreenName = inputMap.get(CVDDMConstant.EMAIL_MAINT_SCREEN_NAME);


			String senderEmail = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
					CVDDMConstant.CVDDM_SENDER_EMAIL_ID);

			recipients = new Recipient(senderEmail);
			recipients.setBccRecipients(emailDtls);

			String tempContentPart = CvddmUtil.getPropertiesValue(CVDDMConstant.EMAIL_TEMPLATE,
					CVDDMConstant.MAINTENANCE_EMAIL_CONTENT_PART_1);

			tempContentPart = tempContentPart.replaceAll(CVDDMConstant.MAINTDESC, tempDesc);

			tempContentPart = tempContentPart.replaceAll(CVDDMConstant.FRMDATEHOLDER, tempFromDt);

			tempContentPart = tempContentPart.replaceAll(CVDDMConstant.TODATEHOLDER, tempToDt);

			log.info("tempContentPart content part is "+tempContentPart);

			htmlContent.append(CvddmUtil.getPropertiesValue(CVDDMConstant.EMAIL_TEMPLATE,
					CVDDMConstant.EMAIL_GREETING));
			htmlContent.append(CVDDMConstant.BREAK_HTML);
			htmlContent.append(CVDDMConstant.BREAK_HTML);
			htmlContent.append(tempContentPart);
			htmlContent.append(CVDDMConstant.BREAK_HTML);
			htmlContent.append(CVDDMConstant.BREAK_HTML);
			htmlContent.append(CvddmUtil.getPropertiesValue(CVDDMConstant.EMAIL_TEMPLATE,
					CVDDMConstant.MAINTENANCE_EMAIL_CONTENT_PART_2));
			htmlContent.append(CVDDMConstant.BREAK_HTML);
			htmlContent.append(CVDDMConstant.BREAK_HTML);
			htmlContent.append(CvddmUtil.getPropertiesValue(CVDDMConstant.EMAIL_TEMPLATE,
					CVDDMConstant.EMAIL_SIGNNATURE_PART_1));
			htmlContent.append(CVDDMConstant.BREAK_HTML);
			htmlContent.append(CvddmUtil.getPropertiesValue(CVDDMConstant.EMAIL_TEMPLATE,
					CVDDMConstant.EMAIL_SIGNNATURE_PART_2));
			htmlContent.append(CVDDMConstant.BREAK_HTML);
			htmlContent.append(CVDDMConstant.BREAK_HTML);
			htmlContent.append(CVDDMConstant.FONT_RED_HTML_START_TAG+CvddmUtil.getPropertiesValue(CVDDMConstant.EMAIL_TEMPLATE,
					CVDDMConstant.EMAIL_DISCLAIMER)+CVDDMConstant.FONT_HTML_END_TAG);

			log.info("htmlContent formed is " + htmlContent);

			Message messageObj = new Message();
			messageObj.setSubject(CvddmUtil.getPropertiesValue(CVDDMConstant.EMAIL_TEMPLATE,
					CVDDMConstant.MAINTENANCE_EMAIL_SUBJECT).replaceAll(CVDDMConstant.SCRNHOLDER, tempScreenName));
			

			messageObj.setHtmlPart(htmlContent.toString());

			final com.ford.it.email.Email emailObj = new Email();
			emailObj.send(recipients, senderEmail, messageObj);	

			log.info("Email sent.");

		}
		catch (Exception e){  	
			log.severe(CvddmUtil.getStackTraceContent(e));
		}
	}
	/*** End Change :User Story: US945528**/
	
	/*** Start Change :User Story: US1121586**/
	/**
	 * Method Name: getUserAttributesValue
	 * @Description:This method fetch Logged in User Attributes value for passed principal name.
	 *  Refer to UserAttributes Class for list of Principal if any missing add in CVDDMConstant.java
	 * @param String principalName
	 * @return String
	 */
	
	
	public static String getUserAttributesValue(String principalName) {
		
		final String METHOD_NAME = "getUserAttributesValue";
		log.entering(CLASS_NAME, METHOD_NAME);
		
		String attributeValue = null;
		
		try {
			
			UserAttributes  usrAttr  = RequestContext.getLocalInstance().getUserAttributes();
			
			if(TextUtil.isNotBlankOrNull(principalName)) {
				
				attributeValue = usrAttr.getPrincipalValue(principalName);
			}
			
		}
		catch (Exception e){  	
			log.severe(CvddmUtil.getStackTraceContent(e));
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
		
		return attributeValue;
	}
	
	/**
	 * Method Name: findDuplicateEmailIds
	 * 
	 * @Description: This method would find Email  Id's.
	 * @param :List<UserTO> emailNotificationLst
	 * @return Set<String>
	 **/

	public static  Set<String> findDuplicateEmailIds(List<UserTO> emailNotificationLst) {

		final Set<String> setToReturn = new HashSet<String>();
		final Set<String> uniqueSet = new HashSet<String>();

		Iterator <UserTO> listIterator = emailNotificationLst.listIterator();

		while(listIterator.hasNext()) {

			UserTO tempObj = listIterator.next();

			if (!uniqueSet.add(tempObj.getMail().trim())) {
				setToReturn.add(tempObj.getMail());
			}
		}
		return setToReturn;
	}
	
	/*** End Change :User Story: US1121586**/
	/*** Start Change : User Story : US1078610 *****/
	/**
	 * Method Name: getLastYearDatePlusOneDay
	 * 
	 * @Description: This method would return Date as per
	 *           Today's date is 08/26/2019
	 *            It would return Date as 08/27/2018 as per UTC Timezone
	 * @param :none
	 * @return Date
	 */
	public static Date getLastYearDatePlusOneDay() {
		
		Calendar calendar = Calendar.getInstance();
		TimeZone tz = TimeZone.getTimeZone(CVDDMConstant.TIMEZONE_UTC); 
		calendar.setTimeZone(tz);
		calendar.add(Calendar.YEAR, -1);
		calendar.add(Calendar.DAY_OF_MONTH, 1);	
		return calendar.getTime();
	}
	
	/**
	 * Method Name: getTodaysDate
	 * 
	 * @Description: This method would return Today's Date in UTC Timezone
	 * @param :none
	 * @return Date
	 */
	
    public static Date getTodaysDate() {
		
    	Calendar calendar = Calendar.getInstance();
		TimeZone tz = TimeZone.getTimeZone(CVDDMConstant.TIMEZONE_UTC);
		calendar.setTimeZone(tz);
		return calendar.getTime();
	}
	
	/*** End Change : User Story : US1078610 *****/
    
    /*** Start Change :User Story: US1064801 **/
    
    /**
	 * Method Name: removeZero
	 * @Description: Java program to remove leading/preceding zeros from a given string
	 * @param :String str
	 * @return String
	 */
    
    public static String removeZero(String str) 
    { 
        // Count leading zeros 
        int i = 0; 
        while (i < str.length() && str.charAt(i) == '0') 
            i++; 
  
        // Convert str into StringBuilder as Strings 
        // are immutable. 
        StringBuilder sb = new StringBuilder(str); 
  
        // The  StringBuffer replace function removes 
        // i characters from given index (0 here) 
        sb.replace(0, i, ""); 
  
        return sb.toString();  // return in String 
    }
    
    /*** End Change :User Story: US1064801 **/
    
    /*** Start Change :User Story: US945639 **/
    
    /**
	 * Method Name: sendExceptionEmail()
	 * @Description:This method would format and send Email to CVDDM Team whenever there is any Exception/System Error 
	 * Occurred in System.
	 * @param  final FordExceptionAttributes fordExceptionAttributes,
            final String message, final Throwable cause
	 * @return void
	 */
	public static void sendExceptionEmail( final FordExceptionAttributes fordExceptionAttributes,
            final String message, final Throwable cause) {
		
		final String METHOD_NAME = "sendExceptionEmail";
		log.entering(CLASS_NAME, METHOD_NAME);
		
		FordSelfLoggingRuntimeException exception = new FordSelfLoggingRuntimeException(fordExceptionAttributes, message, cause);

		try {

			Recipient recipients = null;

			StringBuilder htmlContent= new StringBuilder();

			String senderEmail = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
					CVDDMConstant.CVDDM_SENDER_EMAIL_ID);

			recipients = new Recipient(senderEmail);
			recipients.setBccRecipients(senderEmail);
			
			htmlContent.append(CvddmUtil.getPropertiesValue(CVDDMConstant.EMAIL_TEMPLATE,
					CVDDMConstant.EMAIL_GREETING_FOR_CVDDM_ADMIN));
			
			htmlContent.append(CVDDMConstant.BREAK_HTML);
			htmlContent.append(CVDDMConstant.BREAK_HTML);
			
			htmlContent.append(CvddmUtil.getPropertiesValue(CVDDMConstant.EMAIL_TEMPLATE,
					CVDDMConstant.EXCEPTION_EMAIL_CONTENT_GOODAY_MSG));
			
			htmlContent.append(CVDDMConstant.BREAK_HTML);
			htmlContent.append(CVDDMConstant.BREAK_HTML);
			
			htmlContent.append(CvddmUtil.getPropertiesValue(CVDDMConstant.EMAIL_TEMPLATE,
					CVDDMConstant.EXCEPTION_EMAIL_CONTENT_DATE_TIME)+" "+ exception.getLogTimeStamp());
			
			htmlContent.append(CVDDMConstant.BREAK_HTML);
			htmlContent.append(CVDDMConstant.BREAK_HTML);
			
			htmlContent.append(CvddmUtil.getPropertiesValue(CVDDMConstant.EMAIL_TEMPLATE,
					CVDDMConstant.EXCEPTION_EMAIL_CONTENT_USER)+" "+
					CvddmUtil.getUserAttributesValue(UserAttributes.FULL_NAME_PRINCIPAL_CLASS_NM)
					+"( "+CvddmUtil.getLoggedInUserCDSID()+" )");

			htmlContent.append(CVDDMConstant.BREAK_HTML);
			htmlContent.append(CVDDMConstant.BREAK_HTML);
			
			htmlContent.append(CvddmUtil.getPropertiesValue(CVDDMConstant.EMAIL_TEMPLATE,
					CVDDMConstant.EXCEPTION_EMAIL_CONTENT_EXCEPETION_CODE) +" "+ exception.getLogReferenceCode());
			htmlContent.append(CVDDMConstant.BREAK_HTML);
			htmlContent.append(CVDDMConstant.BREAK_HTML);
			
			htmlContent.append(CvddmUtil.getPropertiesValue(CVDDMConstant.EMAIL_TEMPLATE,
					CVDDMConstant.EXCEPTION_EMAIL_CONTENT_DESC));
			htmlContent.append(CVDDMConstant.BREAK_HTML);
			htmlContent.append(CVDDMConstant.BREAK_HTML);
			
			htmlContent.append(CVDDMConstant.FONT_RED_HTML_START_TAG+message.substring(0, 2000)+CVDDMConstant.FONT_HTML_END_TAG);
			
			htmlContent.append(CVDDMConstant.BREAK_HTML);
			htmlContent.append(CVDDMConstant.BREAK_HTML);
			
			htmlContent.append(CvddmUtil.getPropertiesValue(CVDDMConstant.EMAIL_TEMPLATE,
					CVDDMConstant.EMAIL_SIGNNATURE_PART_1));
			
			htmlContent.append(CVDDMConstant.BREAK_HTML);
			htmlContent.append(CVDDMConstant.BREAK_HTML);
			
			htmlContent.append(CvddmUtil.getPropertiesValue(CVDDMConstant.EMAIL_TEMPLATE,
					CVDDMConstant.EMAIL_SIGNNATURE_PART_2));
			
			htmlContent.append(CVDDMConstant.BREAK_HTML);
			htmlContent.append(CVDDMConstant.BREAK_HTML);
			htmlContent.append(CVDDMConstant.FONT_RED_HTML_START_TAG+CvddmUtil.getPropertiesValue(CVDDMConstant.EMAIL_TEMPLATE,
					CVDDMConstant.EMAIL_DISCLAIMER)+CVDDMConstant.FONT_HTML_END_TAG);

			log.info("htmlContent formed is " + htmlContent);

			Message messageObj = new Message();
			messageObj.setSubject(CvddmUtil.getPropertiesValue(CVDDMConstant.EMAIL_TEMPLATE,
					CVDDMConstant.EXCEPTION_EMAIL_SUBJECT));
			

			messageObj.setHtmlPart(htmlContent.toString());

			final com.ford.it.email.Email emailObj = new Email();
			emailObj.send(recipients, senderEmail, messageObj);	

			log.info("Email sent.");

		}
		catch (Exception e){  	
			log.severe(CvddmUtil.getStackTraceContent(e));
		}
	}
    /*** End Change :User Story: US945639 **/
	/*** Start Change :User Story: US1064102 -- Config did selection screen **/
	public static String getUTCTimeInMilliSecs(String myDate) {

		SimpleDateFormat sdf = new SimpleDateFormat(CVDDMConstant.UTC_TIME_FORMAT_FOR_AWS);
		sdf.setTimeZone(TimeZone.getTimeZone(CVDDMConstant.UTC_TIME_ZONE));

		Date date = null;
		try {
			date = sdf.parse(myDate);
		} catch (ParseException e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		long millis;
		if (null != date) {
			millis = date.getTime();
			return millis + "";
		} else {
			return "";
		}
	}
	/*** End Change :User Story: US1064102 -- Config did selection screen **/
	
}
