package com.ford.cvddm.constant;

/**
 * This class contains constants used by the demonstration classes.
 *
 * @since v1.0
 */
public class CVDDMConstant {

	/** The Class Name used for Logging */
	private static final String CLASS_NAME = CVDDMConstant.class.getName();

	public static final String CVDDM_SENDER_EMAIL_ID = "CVDDM_SENDER_EMAIL_ID";

	/** Used to store the Authorization Provider in the Request */
	public static final String AUTHORIZATION_PROVIDER = CLASS_NAME + ".AUTHORIZATION_PROVIDER";

	/** Persistence unit constant for CVDDM DEV DB */
	public static final String CVDDM_DEV_PERSISTENCE_UNIT = "cvddmdev-persistence-unit";

	/** Data Set up Environments */

	public static final String ENV_QA1 = "QA1";
	public static final String ENV_QA2 = "QA2";

	public static final String APP_RVCM = "RVCM";
	public static final String APP_GIVIS = "GIVIS";
	public static final String APP_GVMS = "GVMS";

	/**
	 * Private Constructor - This class should not be instantiated.
	 */

	private CVDDMConstant() {
		// Empty
	}

	/*
	 * ====================================================================== Web
	 * Service Constants
	 * ======================================================================
	 */
	/**
	 * GVMS : Vehicle Module Info Service configuration name for the Web Service
	 * Consumer AS
	 */
	public static final String VEHICLE_MODULE_INFO_SERVICE_CONFIG_QA1 = "VehicleModuleInfoServiceQA1";
	public static final String VEHICLE_MODULE_INFO_SERVICE_CONFIG_QA2 = "VehicleModuleInfoServiceQA2";
	public static final String GVMS_PRODUCT_OAUTH_CONFIG_QA1 = "gvmsProductInfoQA1";
	public static final String GVMS_PRODUCT_OAUTH_CONFIG_QA2 = "gvmsProductInfoQA2";
	public static final String LOCALE_US = "EN-US";
	public static final String STRING_ALL = "ALL";
	public static final String NODE_TYPE = "NODE_TYPE";
	public static final String VIN_NUMBER = "VIN_NUMBER";
	public static final String ENV_TYPE = "ENV_TYPE";
	public static final String VEHICLE_REQ_OBJ = "VEHICLE_REQ_OBJ";
	/**
	 * GVMS : Vehicle Module Info Service configuration name for the Web Service
	 * Consumer AS
	 */
	/**
	 * GVMS : Module State Service configuration name for the Web Service Consumer
	 * AS
	 */
	public static final String MODULE_STATE_SERVICE_CONFIG_QA1 = "ModuleStateServiceQA1";
	public static final String MODULE_STATE_SERVICE_CONFIG_QA2 = "ModuleStateServiceQA2";

	/**
	 * GVMS : Module State Service configuration name for the Web Service Consumer
	 * AS
	 */

	/** ValidationMessage.Properties Key Name in faces-config.xml ****/

	/** Start Change :User Story: US943267 ***/
	public static final String BUNDLE_APPLICATION_RESOURCE_KEY = "bundle";
	public static final String BUNDLE_VALIDATION_MSG_KEY = "valMsg";
	public static final String BUNDLE_KEY_NOT_FOUND_MSG = "Resource Bundle or Message Key Not Found.";
	public static final String BUNDLE_APPLICATION_CONFIG_KEY = "appConfigProp";
	/** End Change :User Story: US943267 ***/

	/** Start Change :User Story: US889958 ***/
	public static final String TO_DATE_FROM_DATE_MSG = "TO_DATE_FROM_DATE_MSG";

	public static final String FROM_DATE_CURRENT_DATE_MSG = "FROM_DATE_CURRENT_DATE_MSG";

	public static final String MAINT_CRT_SUCCESS_MSG = "MAINT_CRT_SUCCESS_MSG";

	public static final String MAINT_CRT_FAIL_MSG = "MAINT_CRT_FAIL_MSG";

	public static final String MAINT_TYPE_DWN_VALID = "MAINT_TYPE_DWN_VALID";

	public static final String VALIDATION_ERR = "Validation error";

	public static final String MAINT_FOR_SCRN_DWNTIME_REQ = "MAINT_FOR_SCRN_DWNTIME_REQ";

	public static final String MAINT_TYPE_DWNTIME_CD = "MAINT_TYPE_DWNTIME_CD";

	public static final String STRING_Y = "Y";

	public static final String STRING_N = "N";

	public static final String TIMEZONE_UTC = "UTC";

	public static final String CVDDM_SCREEN_ID_PK = "CVDDM_SCREEN_ID_PK";

	public static final String MAINT_TYPE_CD_PK = "MAINT_TYPE_CD_PK";

	public static final String MAINT_RCRD_DE_OBJ = "MAINT_RCRD_DE_OBJ";

	public static final String POST_METHOD = "POST";
	/** End Change :User Story: US889958 ***/

	/** Start Change :User Story: US941763 ****/
	public static final String COMMON_MENU_SCRN_CD = "COMMON_MENU_SCRN_CD";
	public static final String LIST_MENU_SCRN_CD = "LIST_MENU_SCRN_CD";
	public static final String COMMON_MENUS = "Common Menus";
	public static final String LIST_MENUS = "List of Menus";
	public static final String LIST_SUB_MENUS = "List of Sub Menus";
	/** End Change :User Story: US941763 ****/

	/** Start Change :User Story: US941659 ****/
	public static final String MAINT_TYPE_SITE_INVALID = "MAINT_TYPE_SITE_INVALID";
	public static final String MAINT_TYPE_ALERT_CD = "MAINT_TYPE_ALERT_CD";
	public static final String MAINT_TYPE_BANNER_CD = "MAINT_TYPE_BANNER_CD";
	/** End Change :User Story: US941659 ****/

	/*** Start Change: User Story : US941734 ***/
	public static final String CVDDM_APP_NAME = "CVDDM";
	public static final String APS_GET_ALL_USER_FOR_APP = "retrieveRoleAssignments";
	/*** End Change: User Story : US941734 ***/

	/*** Start Change: User Story : US941845 ***/
	public static final String APS_GET_ROLES_FR_RESOURCE = "appResourcePolicyRole";
	public static final String DEFAULT_RESOURCE_NAME = "MyDashboard";
	public static final String EMPTY_STRING = "";
	public static final String SEMI_COLON = ";";
	/*** End Change: User Story : US941845 ***/

	/*** Start Change: User Story : US986092 ***/
	public static final String APS_GET_USERS_FR_ROLE = "entitlementGroup";
	public static final String DEFAULT_ROLE_NAME = "Data Requester";
	public static final String ERROR_IN_EMAIL_ID_FETCH = "ERROR_IN_EMAIL_ID_FETCH";
	/*** End Change: User Story : US986092 ***/

	/*** Start Change: US898252 IVSU_CVDDM_Interoperability ***/
	public static final String IVSU_HTTP_POSTER_PROXY_IP = "IVSU_HTTP_POSTER_PROXY_IP";
	public static final String IVSU_HTTP_POSTER_PROXY_PORT = "IVSU_HTTP_POSTER_PROXY_PORT";
	public static final String IVSU_HTTP_POSTER_JSON_CONTENT_TYPE = "IVSU_HTTP_POSTER_JSON_CONTENT_TYPE";
	public static final String IVSU_END_POINT_PARTIISPEC = "IVSU_END_POINT_PARTIISPEC";
	public static final String IVSU_END_POINT_TO_VALIDATE_IVS_FEED = "IVSU_END_POINT_TO_VALIDATE_IVS_FEED";
	public static final String IVSU_END_POINT_TO_RETRIVE_IVS_FEED = "IVSU_END_POINT_TO_RETRIVE_IVS_FEED";
	/*** End Change: US898252 IVSU_CVDDM_Interoperability ***/

	/*** Start Change: User Story : US1020052 ***/
	public static final String TCU_CD = "754";
	public static final String SYNC_CD = "7D0";
	public static final String BLEM_CD = "731";
	public static final String ECG_CD = "716";
	public static final String ALL_MODULE_CD = "ALL";
	public static final String LBL_TCU = "TCU";
	public static final String LBL_SYNC = "SYNC";
	public static final String LBL_BLEM = "BLEM";
	public static final String LBL_ECG = "ECG";
	public static final String CONSUMER_ROLE = "CONSUMER";
	public static final String ROLE_SOURCE = "OTA";
	public static final String ROLE_RVCM_DESC_ID = "RVCM";
	public static final String CURRENTLITE_REQ_OBJ = "CURRENTLITE_REQ_OBJ";
	public static final String QA1_GVMS_GET_CURRENT_LITE_URL = "QA1_GVMS_GET_CURRENT_LITE_URL";
	public static final String QA2_GVMS_GET_CURRENT_LITE_URL = "QA2_GVMS_GET_CURRENT_LITE_URL";
	public static final String CONTENT_TYPE = "application/json";
	/*** End Change: User Story : US1020052 ***/

	/** Start Change: User Story : US890091 ***/

	public static final String DOWNTIME_PAGE_MSG = "DOWNTIME_PAGE_MSG";

	/** End Change: User Story : US890091 ***/

	/*** Start Change: User Story : US947738 ***/

	public static final String LBL_APIM = "APIM";

	public static final String LBL_RFA = "RFA";

	public static final String MODULE_STATE_ROLE_DESC = "Ford Dealer Code";

	public static final String MODULE_STATE_ROLE_ID = "DLR-GPH001";

	public static final String IS_TCU_PRESENT = "IS_TCU_PRESENT";

	public static final String IS_SYNC_PRESENT = "IS_SYNC_PRESENT";

	public static final String IS_BLEM_PRESENT = "IS_BLEM_PRESENT";

	public static final String IS_ECG_PRESENT = "IS_ECG_PRESENT";

	public static final String TCU_PART_NUMBERS = "TCU_PART_NUMBERS";

	public static final String SYNC_PART_NUMBERS = "SYNC_PART_NUMBERS";

	public static final String BLEM_PART_NUMBERS = "BLEM_PART_NUMBERS";

	public static final String ECG_PART_NUMBERS = "ECG_PART_NUMBERS";

	public static final String TCU_NETWORK_RATE = "TCU_NETWORK_RATE";

	public static final String SYNC_NETWORK_RATE = "SYNC_NETWORK_RATE";

	public static final String BLEM_NETWORK_RATE = "BLEM_NETWORK_RATE";

	public static final String ECG_NETWORK_RATE = "ECG_NETWORK_RATE";

	public static final String SPEC_CATEGORY_VAL = "GGDS";

	public static final String NONE = "NONE";

	public static final String CD_F10A = "F10A";
	public static final String CD_F110 = "F110";
	public static final String CD_F111 = "F111";
	public static final String CD_F113 = "F113";
	public static final String CD_F188 = "F188";
	public static final String CD_F18C = "F18C";
	public static final String CD_8033 = "8033";
	public static final String CD_F16B = "F16B";
	public static final String CD_F124 = "F124";
	public static final String CD_8060 = "8060";
	public static final String CD_F141 = "F141";
	public static final String CD_F120 = "F120";
	public static final String CD_DE00 = "DE00";
	public static final String CD_DE01 = "DE01";
	public static final String CD_DE02 = "DE02";
	public static final String CD_DE03 = "DE03";

	public static final String DESC_F10A = "ECU Configuration";
	public static final String DESC_F110 = "Part II Specification";
	public static final String DESC_F111 = "Core Assembly";
	public static final String DESC_F113 = "Assembly";
	public static final String DESC_F188 = "Strategy";
	public static final String DESC_F18C = "Serial Number";
	public static final String DESC_8033 = "Image";
	public static final String DESC_F16B = "F16B"; // Need from Team.
	public static final String DESC_F124 = "Calibration";
	public static final String DESC_8060 = "Application";
	public static final String DESC_F141 = "Serial Number";
	public static final String DESC_F120 = "Strategy";
	public static final String DESC_DE00 = "Direct Configuraation DID DE00";
	public static final String DESC_DE01 = "Direct Configuraation DID DE01";
	public static final String DESC_DE02 = "Direct Configuraation DID DE02";
	public static final String DESC_DE03 = "Direct Configuraation DID DE03";

	/*** End Change: User Story : US947738 ***/

	/*** Start Change: User Story : US1016146 ***/
	public static final String QA1_RVCM_TCU_VALIDATION_ENDPOINT = "QA1_RVCM_TCU_VALIDATION_ENDPOINT";
	public static final String QA2_RVCM_TCU_VALIDATION_ENDPOINT = "QA2_RVCM_TCU_VALIDATION_ENDPOINT";
	public static final String QA1_RVCM_ACCESS_TOKEN = "QA1_RVCM_ACCESS_TOKEN";
	public static final String QA2_RVCM_ACCESS_TOKEN = "QA2_RVCM_ACCESS_TOKEN";
	public static final String RVCM_APP_ID = "RVCM_APP_ID";
	public static final String RVCM_JSON_DATA_FOR_754 = "RVCM_JSON_DATA_FOR_754";
	/*** End Change: User Story : US1016146 ***/

	/*** Start Change: US1021877 ***/
	public static final String GIVIS_GET_PARTNUMBERS_ENDPOINT = "GIVIS_GET_PARTNUMBERS_ENDPOINT";
	/*** End Change: US1021877 ***/

	/*** Start Change: US1021790 ***/
	public static final String GIVIS_GET_AWS_MODIFIED_DATE_ENDPOINT = "GIVIS_GET_AWS_MODIFIED_DATE_ENDPOINT";
	/*** End Change: US1021790 ***/

	/*** Start Change: US1016146 ***/
	public static final String RVCM_TCU_VALIDATION = "rvcmTcuValidationQA2";

	/*** End Change: US1016146 ***/

	/*** Start Change: US1016146 ***/
	public static final String IVSU_OAUTH_CREDENTIALS = "iVSURestCredentials";

	/*** End Change: US1016146 ***/

	/*** Start Change: User Story : US890091 ***/

	/**
	 * The family for any components created in Cvddm Core.
	 */
	public static final String CVDDM_COMPONENT_FAMILY = "cvddmcore";

	/*** End Change: User Story : US890091 ***/

	/*** Start Change: User Story : US987948 ***/

	/***
	 * Add Screen Menu Code for each Screen from PCVDM01_SCREEN_INFO except Across
	 * Site Screen. Whenever there is a New Screen Added, it should have Entry over
	 * here as well as in ApplicationConfiguration.properties
	 ***/

	public static final String ALL_MENU_SCRN_CD = "ALL_MENU_SCRN_CD";
	public static final String ALL_SUB_MENU_SCRN_CD = "ALL_SUB_MENU_SCRN_CD";
	public static final String MY_DASHBOARD_SCRN_CD = "MY_DASHBOARD_SCRN_CD";
	public static final String TEST_DATA_SET_UP_SCRN_CD = "TEST_DATA_SET_UP_SCRN_CD";
	public static final String TEST_DEVICE_SCHEDULER_SCRN_CD = "TEST_DEVICE_SCHEDULER_SCRN_CD";
	public static final String ADMIN_SCRN_CD = "ADMIN_SCRN_CD";
	public static final String REPORTS_SCRN_CD = "REPORTS_SCRN_CD";
	public static final String MAINT_CONTROLLER_SCRN_CD = "MAINT_CONTROLLER_SCRN_CD";
	public static final String FULL_STOP = ". ";
	public static final String HASH_SYMBOL = " # ";
	public static final String ALERT_MSG = "ALERT_MSG";
	public static final String AND_SYMBOL = " & ";
	public static final String COMMA_SYMBOL = " , ";

	/*** End Change: User Story : US987948 ***/
	/*** Start Change: User Story : US890086 ***/
	public static final String BANNER_MSG = "BANNER_MSG";
	/*** End Change: User Story : US890086 ***/

	/*** Start Change: User Story : US1016144 ***/
	public static final String DATA_VALIDATION_SCRN_CD = "DATA_VALIDATION_SCRN_CD";
	public static final String GVMS_DATA_VALIDATION_SCRN_CD = "GVMS_DATA_VALIDATION_SCRN_CD";
	public static final String GVMS_SUCCESS_STATUS_CD = "0";
	public static final String GVMS_SOURCE = "GVMS";
	public static final String PART2_SPEC_MISSING_MSG = "PART2_SPEC_MISSING_MSG";
	public static final String VALID_VIN_LENGTH = "VALID_VIN_LENGTH";
	public static final String INVALID_VIN_FORMAT_MSG = "INVALID_VIN_FORMAT_MSG";
	public static final String VALID_VIN_FORMAT = "VALID_VIN_FORMAT";
	public static final String STRING_E = "E";
	/*** End Change: User Story : US1016144 ***/

	/*** Start Change: User Story : US1021877 ***/
	public static final String NODES_ACRONYMS_PROPERTIES = "nodesAcronymsProp";
	/*** End Change: User Story : US1021877 ***/

	/*** Start Change: User Story : US1028146 ***/
	public static final String HTTP_PROXY_FOR_AZURE = "HTTP_PROXY_FOR_AZURE";
	public static final String HTTPS_PROXY_FOR_AZURE = "HTTPS_PROXY_FOR_AZURE";
	/*** End Change: User Story : US1028146 ***/

	/*** Start Change: User Story : US1021877 ***/
	public static final String PART_NUMBER_VAL_MSG = "PART_NUMBER_VAL_MSG";
	public static final String NODE_VAL_MSG = "NODE_VAL_MSG";
	public static final String NO_VAL_DATA_MSG = "NO_VAL_DATA_MSG";
	public static final String ERR_LOADING_ENV = "ERR_LOADING_ENV";
	/*** End Change: User Story : US1021877 ***/

	/*** Start Change: User Story : US1016146 ***/
	public static final String ERR_LOADING_APP = "ERR_LOADING_APP";
	public static final String NO_ECU_VAL_DATA_MSG = "NO_ECU_VAL_DATA_MSG";
	public static final String VIN_NOT_FOUND_IN_IVSU = "VIN_NOT_FOUND_IN_IVSU";
	public static final String ALPHA_NUMERIC_MATCH = "[a-zA-Z0-9]*";
	public static final String VALID_VIN_MSG = "VALID_VIN_MSG";
	/*** End Change: User Story : US1016146 ***/

	/*** Start Change: User Story : US987948 ***/
	public static final String IVS_PARTNUMBER_VALIDATION_SCRN_CD = "IVS_PARTNUMBER_VALIDATION_SCRN_CD";
	public static final String RVCM_TCU_VALIDATION_SCRN_CD = "RVCM_TCU_VALIDATION_SCRN_CD";
	public static final String GIVIS_VIN_VALIDATION_SCRN_CD = "GIVIS_VIN_VALIDATION_SCRN_CD";
	public static final String PARTIISPEC_VALIDATION_SCRN_CD = "PARTIISPEC_VALIDATION_SCRN_CD";
	/*** End Change: User Story : US987948 ***/

	/*** Start Change: User Story : US1021790 ***/
	public static final String AWS_ACCESS_KEY = "AWS_ACCESS_KEY";
	public static final String AWS_SECRET_KEY = "AWS_SECRET_KEY";
	public static final String AWS_END_POINT = "AWS_END_POINT";
	public static final String AWS_BUCKET_NAME = "AWS_BUCKET_NAME";
	/*** End Change: User Story : US1021790 ***/

	/*** Start Change: User Story : US1021790 ***/
	public static final String NO_P2S_DATA_MSG = "NO_P2S_DATA_MSG";
	public static final String VALID_P2S_MSG = "VALID_P2S_MSG";
	public static final String UTC_TIME_FORMAT_FOR_AWS = "yyyy-MM-dd HH:mm:ss";
	public static final String UTC_TIME_ZONE = "UTC";
	public static final String PARTIISPEC_DID_TAG_NAME = "DID";
	public static final String PARTIISPEC_FEATURE_HEADER_ID = "ID";
	public static final String PARTIISPEC_FEATURE_HEADER_NAME = "NAME";
	public static final String PARTIISPEC_DID_REPLACE = "did_";
	public static final String INPUT_PARTIISPEC_SPLITTER = "-";
	public static final String PARTIISPEC_AWS_FILE_FORMAT = ".MDX";
	public static final String INVALID_MDX_FILE = "INVALID_MDX_FILE";
	/*** End Change: User Story : US1021790 ***/

	/*** Start Change: User Story : US1022136 ***/
	public static final String GIVIS_COOKIE = "GIVIS_COOKIE";

	/*** End Change: User Story : US1022136 ***/

	/*** Start Change : User Story US1048618 ***/
	public static final String FEEDBACK_CRT_SUCCESS_MSG = "FEEDBACK_CRT_SUCCESS_MSG";
	public static final String FEEDBACK_CRT_FAIL_MSG = "FEEDBACK_CRT_FAIL_MSG";
	public static final String FEEDBACK_RCRD_DE_OBJ = "FEEDBACK_RCRD_DE_OBJ";
	public static final String FEEDBACK_PAGE_ACRS_SITE = "Across Site";
	public static final String FEEDBACK_PAGE_ALL_MENU = "All Menus";
	public static final String FEEDBACK_PAGE_ALL_SUB_MENUS = "All Sub Menus";

	/*** End Change : User Story US1048618 ***/

	/*** Start Change: User Story : US890083 ***/

	public static final String VAL_MSG_MAINT_RCRD_SEL = "VAL_MSG_MAINT_RCRD_SEL";
	public static final String DATE_PATTERN_AM_PM = "MM/dd/yyyy hh:mm a";
	/*** End Change: User Story : US890083 ***/

	/*** Start Change: User Story : US1022136 ***/
	public static final String GIVIS_VEHICLE_MODULE_INFO_SERVICE_CONFIG_QA1 = "GivisVehicleModuleInfoServiceQA1";
	public static final String GIVIS_VEHICLE_MODULE_INFO_SERVICE_CONFIG_QA2 = "GivisVehicleModuleInfoServiceQA2";
	public static final String GIVIS_DATA_VALIDATION_SCRN_CD = "GIVIS_DATA_VALIDATION_SCRN_CD";
	public static final String XML_CONTENT_TYPE = "text/xml; charset=UTF-8";
	/*** Start Change: User Story : US1022136 ***/

	/*** Start Change: User Story : US1076334 ***/
	public static final String MULTIVIN_VALID_MSG = "MULTIVIN_VALID_MSG";
	public static final String NO_OF_VINS_ALLOWED = "NO_OF_VINS_ALLOWED";
	public static final String NO_OF_VINS_VALID_MSG = "NO_OF_VINS_VALID_MSG";
	public static final String ATLEAST_ONE_VIN_MSG = "ATLEAST_ONE_VIN_MSG";
	public static final String ENV_REQUIRED_MSG = "ENV_REQUIRED_MSG";
	public static final String VIN_VALUE_NOT_AVAIL = "VIN_VALUE_NOT_AVAIL";
	public static final String DUPLICATE_VIN = "DUPLICATE_VIN";
	public static final String VIN_NAME = "VIN: ";

	/*** End Change: User Story : US1076334 ***/
	/*** Start Change: User Story : US941215 ***/
	public static final String PARAM_MAINT_RCRD_ID = "selMaintRecord";
	public static final String ERROR_UPDATE_RCRD_MSG = "ERROR_UPDATE_RCRD_MSG";
	public static final String NOTVALID_ACTIVE_RCRD_MSG = "NOTVALID_ACTIVE_RCRD_MSG";
	public static final String TO_DATE_CURRENT_DATE_MSG = "TO_DATE_CURRENT_DATE_MSG";
	public static final String RCRD_UPDT_SUCCESS_MSG = "RCRD_UPDT_SUCCESS_MSG";
	public static final String RCRD_UPDT_FAIL_MSG = "RCRD_UPDT_FAIL_MSG";
	public static final String UPDT_MAINT_NAVIGATION = "/maintenance/updateMaintenanceRecord.faces";
	public static final String CRT_MAINT_NAVIGATION = "/maintenance/createCvddmMaintenance.faces?faces-redirect=true";
	public static final String TO_DATE_FROM_DATE_CRRT_MSG = "TO_DATE_FROM_DATE_CRRT_MSG";
	/*** End Change: User Story : US941215 ***/
	/*** Start Change :User Story: US945528 **/
	public static final String EMAIL_IDS_DETAILS = "EMAIL_IDS_DETAILS";
	public static final String EMAIL_FROM_DATE_STR = "EMAIL_FROM_DATE_STR";
	public static final String EMAIL_TO_DATE_STR = "EMAIL_TO_DATE_STR";
	public static final String EMAIL_MAINT_DESC = "EMAIL_MAINT_DESC";
	public static final String EMAIL_MAINT_SCREENCD = "EMAIL_MAINT_SCREENCD";
	public static final String EMAIL_MAINT_SCREEN_NAME = "EMAIL_MAINT_SCREEN_NAME";

	public static final String MAINTDESC = "MAINTDESC";
	public static final String FRMDATEHOLDER = "FRMDATEHOLDER";
	public static final String TODATEHOLDER = "TODATEHOLDER";

	public static final String VIN_NOT_AVAIL = "Vin not Available";

	public static final String SCRNHOLDER = "SCRNHOLDER";

	public static final String BREAK_HTML = "<br/>";

	public static final String MAINTENANCE_EMAIL_SUBJECT = "MAINTENANCE_EMAIL_SUBJECT";
	public static final String EMAIL_GREETING = "EMAIL_GREETING";
	public static final String MAINTENANCE_EMAIL_CONTENT_PART_1 = "MAINTENANCE_EMAIL_CONTENT_PART_1";
	public static final String MAINTENANCE_EMAIL_CONTENT_PART_2 = "MAINTENANCE_EMAIL_CONTENT_PART_2";
	public static final String EMAIL_SIGNNATURE_PART_1 = "EMAIL_SIGNNATURE_PART_1";
	public static final String EMAIL_SIGNNATURE_PART_2 = "EMAIL_SIGNNATURE_PART_2";
	public static final String EMAIL_DISCLAIMER = "EMAIL_DISCLAIMER";
	public static final String COMMA = ",";
	public static final String TRUE = "true";
	public static final String SYS_PROPERTY_PARTIALSEND = "com.ford.itcore.email.partialsend";
	/*** End Change :User Story: US945528 ***/

	/*** Start Change: User Story : US1048243 ***/
	public static final String PARTIISPEC_ID = "(Part II Specification)-(F110)-";
	/*** End Change: User Story : US1048243 ***/

	/***
	 * Start Change: User Story : US1023636 Part II Specification DID - Feature
	 * details
	 ***/
	public static final String SUB_FIELD = "SUB_FIELD";
	public static final String ID = "ID";
	public static final String NAME = "NAME";
	public static final String MOST_SIG_BIT = "MOST_SIG_BIT";
	public static final String LEAST_SIG_BIT = "LEAST_SIG_BIT";
	public static final String DATA_DEFINITION = "DATA_DEFINITION";
	public static final String ENUMERATED_PARAMETERS = "ENUMERATED_PARAMETERS";
	public static final String ENUM_MEMBER = "ENUM_MEMBER";
	public static final String ENUM_VALUE = "ENUM_VALUE";
	public static final String DESCRIPTION = "DESCRIPTION";

	/***
	 * End Change: User Story : US1023636 Part II Specification DID - Feature
	 * details
	 ***/
	/*** Start Change: User Story : US1016229 ***/
	public static final String GIVIS_SUCCESS_STATUS_CD = "0";
	public static final String GIVIS_SOURCE = "GIVIS";
	public static final String VIN_NOT_FOUND_IN_GIVIS = "No Vehicle Data Available as VIN not found in IVIS.";
	public static final String UNHANDLED_EXCEPTIONS = "Soap Fault Exceptions";

	/*** End Change: User Story : US1016229 ***/

	/*** Start Change: User Story : US1121586 ***/
	/* Principal Attribute missing in UserAttributes can be defined over here */
	/*
	 * Attribute to store FordManagerCdsidPrincipal class name.
	 */
	public static final String FORD_MANAGER_CDSID_PRINCIPAL_CLASS_NM = "com.ford.websphere.auth.FordManagerCdsidPrincipal";

	/*** END Change: User Story : US1121586 ***/

	/*** Start Change: User Story : US1061675 ***/
	public static final String PART_NUMBER_PAGE_PATH = "PART_NUMBER_PAGE_PATH";
	public static final String HOME_PAGE_PATH = "HOME_PAGE_PATH";
	public static final String NO_OF_ADDN_EMAIL_ALLOWED = "NO_OF_ADDN_EMAIL_ALLOWED";
	public static final String NO_OF_EMAIL_ALLOWED_MSG = "NO_OF_EMAIL_ALLOWED_MSG";
	public static final String EMAIL_PANEL = "emailPanel";
	public static final String PLACEHOLDER_EMAIL_MSG = "PLACEHOLDER_EMAIL_MSG";
	public static final String PRODUCT_TEAM_PAGE_PATH = "PRODUCT_TEAM_PAGE_PATH";
	public static final String STRING_ZERO = "0";
	public static final String REQUIRED_MSG = "REQUIRED_MSG";
	public static final String DATE_NOT_PAST_MSG = "DATE_NOT_PAST_MSG";
	public static final String DATE_GREATER_THAN_MSG = "DATE_GREATER_THAN_MSG";
	public static final String PRODUCT_TEAM_NOT_AVAIL = "PRODUCT_TEAM_NOT_AVAIL";
	public static final String PRODUCT_LINE_NOT_AVAIL = "PRODUCT_LINE_NOT_AVAIL";
	public static final String DATA_SET_UP_SCRN_CD = "DATA_SET_UP_SCRN_CD";
	public static final String LABEL_PRD_GRP = "label.testdatasetup.productgroup";
	public static final String LABEL_PRD_LINE = "label.testdatasetup.productline";
	public static final String LABEL_PRD_TEAM = "label.testdatasetup.productteam";
	public static final String LABEL_TEST_START_DATE = "label.testdatasetup.testingstartdate";
	public static final String LABEL_TEST_END_DATE = "label.testdatasetup.testingenddate";
	public static final String LABEL_TEST_REQ_DATE = "label.testdatasetup.testdatareq";
	public static final String LABEL_TEST_CODE_DATE = "label.testdatasetup.codedropdate";
	public static final String LABEL_TEST_TEST_TYPE = "label.testdatasetup.testingtype";
	public static final String LABEL_TEST_SUBJECT = "label.testdatasetup.subject";
	public static final String JSF_ID_TEST_SUBJECT = "addProductTeamForm:testingSubjectId";
	public static final String JSF_ID_TEST_TYPES = "addProductTeamForm:testingTypesId";
	public static final String JSF_ID_TEST_PRD_GRP = "addProductTeamForm:productGroupsId";
	public static final String JSF_ID_TEST_PRD_LINE = "addProductTeamForm:productLinesId";
	public static final String JSF_ID_TEST_PRD_TEAM = "addProductTeamForm:productTeamsId";
	public static final String JSF_ID_TEST_END_DATE = "addProductTeamForm:testingEndDateId";
	public static final String JSF_ID_TEST_START_DATE = "addProductTeamForm:testingStartDateId";
	public static final String JSF_ID_TEST_REQ_DATE = "addProductTeamForm:testDataReqDateId";

	/*** End Change: User Story : US1061675 ***/

	/*** Start Change: User Story : US1078610 ***/
	public static final String SUCCESS = "Success";
	public static final String MMM_D_YYYY_AM_PM = "MMM d, yyyy hh:mm a";
	public static final String JSF_ID_HIST_TO_DATE = "gvmsVinHistoryForm:toDate";
	public static final String JSF_ID_HIST_VIN_NUMBER = "gvmsVinHistoryForm:vinNumberId";
	public static final String EMPTY_FILTER_CRITERIA = "EMPTY_FILTER_CRITERIA";
	public static final String LABEL_HIST_TO_DATE = "label.history.toDate";
	public static final String LABEL_HIST_FROM_DATE = "label.history.fromDate";
	public static final String GVMS_HISTORY_PAGE_PATH = "GVMS_HISTORY_PAGE_PATH";
	public static final String GVMS_VIN_VALIDATION_PAGE_PATH = "GVMS_VIN_VALIDATION_PAGE_PATH";
	/*** End Change: User Story : US1078610 ***/

	/*** Start Change: User Story : US1121586 ***/
	public static final String INVALID_EMAIL_MESSAGE = "INVALID_EMAIL_MESSAGE";
	public static final String EMAIL_PLACEHOLDER = "EMAILPLACEHOLDER";
	public static final String STRING_IS = "is";
	public static final String STRING_ARE = "are";
	public static final String STRING_EMAIL_ID = "Email Id";
	public static final String DUPLICATE_EMAIL_ID = "DUPLICATE_EMAIL_ID";
	public static final String EMAIL_ID_NOT_AVAIL = "EMAIL_ID_NOT_AVAIL";
	public static final String FDS_LDAP_USER_ID = "fdsUserId";
	public static final String FDS_LDAP_USER_PASSKEY = "fdsUserPassword";
	public static final String FDS_LDAP_CRENDENTIALS = "fdsLdapCredentials";
	/*** End Change: User Story : US1121586 ***/

	/*** Start Change :User Story: US1064801 **/
	public static final String VIN_REQ_PAGE_PATH = "VIN_REQ_PAGE_PATH";
	public static final String FEATURE_DID_PAGE_PATH = "FEATURE_DID_PAGE_PATH";
	public static final String REVIEW_PAGE_PATH = "REVIEW_PAGE_PATH";
	public static final String LABEL_VIN_REQ_PRIORITY = "label.priority";
	public static final String JSF_ID_VIN_REQ_PRIORITY = "addVinDetailsForm:priorityId";
	public static final String LABEL_VIN_REQ_REGION = "label.region";
	public static final String JSF_ID_VIN_REQ_REGION = "addVinDetailsForm:regionId";
	public static final String LABEL_VIN_REQ_MOCKUPVIN = "label.mockupVin";
	public static final String JSF_ID_VIN_REQ_MOCKUPVIN = "addVinDetailsForm:mockupvinId";
	public static final String LABEL_VIN_REQ_NOOFVINS = "label.mockupvin.noofvins";
	public static final String JSF_ID_VIN_REQ_NOOFVINS = "addVinDetailsForm:vinsRequiredTd";
	public static final String LABEL_VIN_REQ_PRDVEHICLE = "label.mockupvin.proddropdown";
	public static final String JSF_ID_VIN_REQ_PRDVEHICLE = "addVinDetailsForm:prodVehicleDetails";
	public static final String NO_OF_MOCK_VINS_ALLOWED = "NO_OF_MOCK_VINS_ALLOWED";
	public static final String NO_OF_MOCK_VINS_ALLOWED_MSG = "NO_OF_MOCK_VINS_ALLOWED_MSG";
	public static final String ECU_REQUIRED_MSG = "ECU_REQUIRED_MSG";
	public static final String JSF_ID_VIN_REQ_NOOFVINS_TYPE2 = "vinsRequiredTd";
	public static final String JSF_ID_VIN_REQ_VINPANEL_TYPE2 = "vinPanel";
	public static final String JSF_ID_VIN_REQ_ECUMODULE_TYPE2 = "modTempObjId";
	public static final String JSF_ID_VIN_REQ_USER_VINS_DT = "vinsDatatableId";
	public static final String JSF_ID_VIN_REQ_PRDVEHICLE_TYPE2 = "prodVehicleDetails";
	public static final String HYPHEN_SYMBOL = " - ";
	public static final String STATUS_NEW = "NEW";
	public static final String NODES_WHICH_NEED_VIRTUAL_DEVICE_QUESTION = "NODES_WHICH_NEED_VIRTUAL_DEVICE_QUESTION";
	public static final String COLON_SYMBOL = ":";
	public static final String LABEL_VIRTUAL_DEVICE_REQ = "label.virtual_part";
	public static final String NOT_SELECTED = "  not selected";
	public static final String NOT_SELECTED_FOR_ALL = "  not selected for all Vin(s)";
	public static final String ATLEAST_ONE_VIN_FOR_DATA_SET_UP = "ATLEAST_ONE_VIN_FOR_DATA_SET_UP";
	public static final String USER_VIN_VALID_MSG = "USER_VIN_VALID_MSG";
	public static final String LABEL_ESN = "label.esn";
	public static final String NO_OF_VIN_FORMAT = "NO_OF_VIN_FORMAT";
	public static final String NO_OF_VIN_FORMAT_MSG = "NO_OF_VIN_FORMAT_MSG";
	public static final String SINGLE_ZERO = "0";
	public static final String DOUBLE_ZERO = "00";
	public static final String NOT_VALID = " is not valid";
	public static final String ESN_NAME = "ESN: ";
	public static final String DUPLICATE_ESN = "DUPLICATE_ESN";
	public static final String USER_ESN_VALID_MSG ="USER_ESN_VALID_MSG";
	/*** End Change :User Story: US1064801 **/

	/*** Start Change :User Story: US945639 **/
	public static final String EMAIL_TEMPLATE = "emailTemplate";
	public static final String EMAIL_GREETING_FOR_CVDDM_ADMIN = "EMAIL_GREETING_FOR_CVDDM_ADMIN";
	public static final String EXCEPTION_EMAIL_SUBJECT = "EXCEPTION_EMAIL_SUBJECT";
	public static final String EXCEPTION_EMAIL_CONTENT_GOODAY_MSG = "EXCEPTION_EMAIL_CONTENT_GOODAY_MSG";
	public static final String EXCEPTION_EMAIL_CONTENT_DATE_TIME = "EXCEPTION_EMAIL_CONTENT_DATE_TIME";
	public static final String EXCEPTION_EMAIL_CONTENT_USER = "EXCEPTION_EMAIL_CONTENT_USER";
	public static final String EXCEPTION_EMAIL_CONTENT_EXCEPETION_CODE = "EXCEPTION_EMAIL_CONTENT_EXCEPETION_CODE";
	public static final String EXCEPTION_EMAIL_CONTENT_DESC = "EXCEPTION_EMAIL_CONTENT_DESC";
	public static final String FONT_RED_HTML_START_TAG = "<b><font color='red'>";
	public static final String  FONT_HTML_END_TAG = "</font></b>";

	/*** End Change :User Story: US945639 **/
	/*** Start Change :User Story: US1147659 **/
	public static final String SUBMIT_ACTION = "SUBMIT";
	public static final String CONTINUE_ACTION = "CONTINUE";
	public static final String OK_ACTION = "OK";
	public static final String MOCKUP_VIN_PANEL_ID  = "mockupVinPanel";
	public static final String NOT_ENOUGH_VINS_MSG ="NOT_ENOUGH_VINS_MSG";
	public static final String NOT_ENOUGH_ESNS_MSG ="NOT_ENOUGH_ESNS_MSG";
	public static final String VIN_REQ_OK_MSG="VIN_REQ_OK_MSG";
	/*** End Change :User Story: US1147659 **/

	/*** Start Change: User Story : US1107518 ***/
	public static final String IVSU_END_POINT_TO_VALIDATE_IVS_FEED_QA2 = "IVSU_END_POINT_TO_VALIDATE_IVS_FEED_QA2";
	public static final String IVSU_OAUTH_CREDENTIALS_QA2 = "iVSURestCredentialsQA2";
	/*** End Change: User Story : US1107518 ***/

	/*** Start Change: User Story : US1100581 ***/
	public static final String GIVIS_MODULE_STATE_SERVICE_CONFIG_QA1 = "GivisModuleStateServiceQA1";
	public static final String GIVIS_MODULE_STATE_SERVICE_CONFIG_QA2 = "GivisModuleStateServiceQA2";
	/*** End Change: User Story : US1100581 ***/

	/*** Start Change: User Story : US1100595 ***/
	public static final String GIVIS_EOL_CONFIG = "GivisEOLTransferService";
	/*** End Change: User Story : US1100595 ***/

	/*** Start Change : User Story : US1068105 */
	public static final String CSV_CRT_SUCCESS_MSG = "CSV_CRT_SUCCESS_MSG";
	public static final String CSV_CRT_FAIL_MSG = "CSV_CRT_FAIL_MSG";
	public static final String CSV_FAIL_MSG = "CSV_FAIL_MSG";
	public static final String ESN_CSV_CRT_SUCCESS_MSG = "ESN_CSV_CRT_SUCCESS_MSG";
	public static final String PARTMATRIX_CSV_CRT_SUCCESS_MSG = "PARTMATRIX_CSV_CRT_SUCCESS_MSG";

	public static final String VIN_REPO_CSVNAME = "VIN_Repo.csv";
	public static final String ESN_REPO_CSVNAME = "ESN_Repo.csv";

	public static final String PARTMATRX_REPO_CSVNAME = "Part+Matrix+reference.csv";

	/**** End Change : User Story : US1068105 */

	/*** Start Change : User Story : US1108103 */
	public static final String HISTORY_UTILITY_ENVIRONMENT_ID = "HISTORY_UTILITY_ENVIRONMENT";
	public static final String HISTORY_UTILITY_APPLICATION_ID = "HISTORY_UTILITY_APPLICATION_ID";
	public static final String HISTORY_UTILITY_VIN = "HISTORY_UTILITY_VIN";
	public static final String HISTORY_UTILITY_PARTIISPEC = "HISTORY_UTILITY_PARTIISPEC";
	public static final String HISTORY_UTILITY_WEBSERVICE_STATUS = "HISTORY_UTILITY_WEBSERVICE_STATUS";
	public static final String HISTORY_UTILITY_WEBSERVICE_ERROR = "HISTORY_UTILITY_WEBSERVICE_ERROR";

	public static final String HISTORY_UTILITY_ENV_QA1 = "HISTORY_UTILITY_ENV_QA1";
	public static final String HISTORY_UTILITY_ENV_QA2 = "HISTORY_UTILITY_ENV_QA2";

	public static final String HISTORY_UTILITY_APP_RVCM = "HISTORY_UTILITY_APP_RVCM";
	public static final String HISTORY_UTILITY_APP_GIVIS = "HISTORY_UTILITY_APP_GIVIS";
	public static final String HISTORY_UTILITY_APP_GVMS = "HISTORY_UTILITY_APP_GVMS";
	public static final String HISTORY_UTILITY_APP_IVS = "HISTORY_UTILITY_APP_IVS";
	public static final String HISTORY_UTILITY_APP_IVSU = "HISTORY_UTILITY_APP_IVSU";

	public static final String NO_PARTIISPEC_VAL_DATA_MSG = "NO_PARTIISPEC_VAL_DATA_MSG";

	/*** End Change: User Story : US1108103 ***/

	/*** Start Change : User Story : US1121805 */
	public static final String IVS_FEED_FLAG = "P";
	/*** End Change: User Story : US1121805 ***/

	/*** Start Change : User Story : US1021777 */
	public static final String GIVIS_JSF_ID_HIST_TO_DATE = "givisVinHistoryForm:toDate";
	public static final String GIVIS_HISTORY_PAGE_PATH = "GIVIS_HISTORY_PAGE_PATH";
	public static final String GIVIS_VIN_VALIDATION_PAGE_PATH = "GIVIS_VIN_VALIDATION_PAGE_PATH";
	public static final String GIVIS_JSF_ID_HIST_VIN_NUMBER = "givisVinHistoryForm:vinNumberId";
	/*** End Change: User Story : US1021777 ***/

	/*** Start Change : User Story : US1078611 */
	public static final String RVCM_JSF_ID_HIST_TO_DATE = "rvcmVinHistoryForm:toDate";
	public static final String RVCM_HISTORY_PAGE_PATH = "RVCM_HISTORY_PAGE_PATH";
	public static final String RVCM_VIN_VALIDATION_PAGE_PATH = "RVCM_VIN_VALIDATION_PAGE_PATH";
	public static final String RVCM_JSF_ID_HIST_VIN_NUMBER = "rvcmVinHistoryForm:vinNumberId";
	/*** End Change: User Story : US1078611 ***/
	/*** Start Change: User Story : US1107537 */
	public static final String PARTIISPEC_HISTORY_PAGE_PATH = "PARTIISPEC_HISTORY_PAGE_PATH";
	public static final String PARTIISPEC_VALIDATION_PAGE_PATH = "PARTIISPEC_VALIDATION_PAGE_PATH";
	public static final String HISTORY_UTILITY_APP_AWS = "HISTORY_UTILITY_APP_AWS";
	public static final String PARTIISPEC_NAME = "PARTIISPEC: ";
	public static final String PARTIISPEC_JSF_ID_HIST_VIN_NUMBER = "rvcmVinHistoryForm:vinNumberId";
	public static final String JSF_ID_CONFIG_DID_RESPMSG = "addConfigDidFeaturesForm:uirptt";
	public static final String VAL_MSG_APN_SLCT_CONFIG_DID = "val.msg.apn.did.config";
	/*** End Change: User Story : US1107537 ***/

	/*** Start Change : User Story : US1063866 */
	public static final String FREQUENTLY_SELECTED_MODULE_TCU = "754-TCU";
	public static final String FREQUENTLY_SELECTED_MODULE_SYNC = "7D0-APIM-SYNC";
	public static final String FREQUENTLY_SELECTED_MODULE_BLEM = "731-RFA-BLEM";
	public static final String FREQUENTLY_SELECTED_MODULE_ECG = "716-GWM-ECG";
	public static final String JSF_ID_APN_ENV = "addPartNumberForm:env";
	public static final String JSF_ID_APN_DSBLE_MSG = "addPartNumberForm:dsableMsg";
	public static final String DISABLE_INFO = "Please click CLEAR to EDIT the INPUT Part Number details";	
	public static final String JSF_ID_APN_PARTNUM = "addPartNumberForm:pnr";
	public static final String JSF_ID_APN_MODULE = "addPartNumberForm:grid";
	public static final String JSF_ID_APN_RESPMSG = "addPartNumberForm:uirpt";
	public static final String JSF_ID_APN_SPNMSG = "addPartNumberForm:msgdpn";
	public static final String LABEL_APN_ENV = "label.ivsval.env";
	public static final String LABEL_APN_PARTNUM = "label.ivsval.pn";
	public static final String LABEL_APN_MODULE = "label.ivsval.ems";
	public static final String VAL_MSG_APN_SLCT_PARTNBR = "val.msg.apn.spn";
	public static final String VAL_MSG_APN_SLCT_PARTNBR_ALL = "val.msg.apn.spn.all";
	public static final String PMR_NAVIGATION = "val.msg.apn.spn";
	/*** End Change : User Story : US1063866 */
}