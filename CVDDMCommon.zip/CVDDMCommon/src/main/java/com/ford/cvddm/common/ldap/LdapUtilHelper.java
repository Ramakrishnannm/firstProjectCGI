/**
 * 
 */
package com.ford.cvddm.common.ldap;

import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.it.ldap.LDAPLookup;
import com.ford.it.ldap.LDAPLookupException;
import com.ford.it.ldap.LDAPLookupFactory;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;
import com.ford.it.properties.PropertyManager;
import javax.naming.NamingEnumeration;
import javax.naming.directory.Attribute;
import javax.naming.directory.SearchResult;

/**
 * @since US1121586
 * @author NGUPTA18
 * This class contains Util Methods for Querying Ford Directory Services (LDAP)
 * and return LDAP User Data.
 *
 */
public class LdapUtilHelper {

	/** The Class Name used for Logging */
	private static final String CLASS_NAME = LdapUtilHelper.class.getName();

	/** The Logger instance used for Logging */
	private static final ILogger log =
			LogFactory.getInstance().getLogger(CLASS_NAME);

	private static final String[] SEARCH_ATTRIBUTES = {"uid", "fordGID", "givenName", "sn", "cn", "fordDisplayName", "mail"};

	/**
	 * Private class constructor.
	 */

	private LdapUtilHelper() {

		super();
	}

	/**
	 * Method Name: getLdapUserUsingCDSId
	 * @Description:This method would Query Ford Directory Service using passed CDS Id
	 * and return User details from LDAP as defined in SEARCH_ATTRIBUTES. 
	 * @param final String cdsID
	 * @return LdapUserTO
	 */

	public static LdapUserTO getLdapUserUsingCDSId(final String cdsID) {

        final String METHOD_NAME = "getLdapUserUsingCDSId";
		
		log.entering(CLASS_NAME, METHOD_NAME);
		
		final PropertyManager pm = PropertyManager.getInstance();

		final String configNamePath = LDAPLookupFactory.OVERRIDE_PROPERTY_GROUP_NAME + "." + CVDDMConstant.FDS_LDAP_CRENDENTIALS + ".";


		final String userId = pm.getString(configNamePath + CVDDMConstant.FDS_LDAP_USER_ID, null);


		final String password = pm.getString(configNamePath + CVDDMConstant.FDS_LDAP_USER_PASSKEY, null);


		LDAPLookup ldapLookObj = null;
		LdapUserTO ldapUserTO = null;

		try {

			final LDAPLookupFactory ldapFactory = LDAPLookupFactory.getInstance();
			ldapLookObj = ldapFactory.createLDAPLookup(LDAPLookupFactory.LDAP_DIR_FDS, userId, password);

			ldapLookObj.setAttributes(SEARCH_ATTRIBUTES);

			ldapLookObj.setSearchCriteria("(|(uid=" + cdsID + ")(fordDisplayName=" + cdsID + "))");

			final NamingEnumeration<SearchResult> results = ldapLookObj.search();

			ldapUserTO = populateLdapUserTO(results);

		} catch (final LDAPLookupException loe) {
			
			log.severe(CvddmUtil.getStackTraceContent(loe));

		} finally {
			//Close the connection to the LDAP directory that was established
			// at construction of the LDAPLookup object
			if (ldapLookObj != null) {
				ldapLookObj.closeConnection();
			}
			log.exiting(CLASS_NAME, METHOD_NAME);
		}

		return ldapUserTO;
	}

	/**
	 * Method Name: getLdapUserUsingEmailId
	 * @Description:This method would Query Ford Directory Service using passed Email Id
	 * and return User details from LDAP as defined in SEARCH_ATTRIBUTES. 
	 * @param final String emailID
	 * @return LdapUserTO
	 */

	public static LdapUserTO getLdapUserUsingEmailId(final String emailID) {

		final String METHOD_NAME = "getLdapUserUsingEmailId";

		log.entering(CLASS_NAME, METHOD_NAME);

		final PropertyManager pm = PropertyManager.getInstance();

		final String configNamePath = LDAPLookupFactory.OVERRIDE_PROPERTY_GROUP_NAME + "." + CVDDMConstant.FDS_LDAP_CRENDENTIALS + ".";


		final String userId = pm.getString(configNamePath + CVDDMConstant.FDS_LDAP_USER_ID, null);


		final String password = pm.getString(configNamePath + CVDDMConstant.FDS_LDAP_USER_PASSKEY, null);


		LDAPLookup ldapLookObj = null;
		LdapUserTO ldapUserTO = null;

		try {

			final LDAPLookupFactory ldapFactory = LDAPLookupFactory.getInstance();

			ldapLookObj = ldapFactory.createLDAPLookup(LDAPLookupFactory.LDAP_DIR_FDS, userId, password);

			ldapLookObj.setAttributes(SEARCH_ATTRIBUTES);

			ldapLookObj.setSearchCriteria("(mail=" + emailID + ")");

			final NamingEnumeration<SearchResult> results = ldapLookObj.search();

			ldapUserTO = populateLdapUserTO(results);

		} catch (final LDAPLookupException loe) {
			log.severe(CvddmUtil.getStackTraceContent(loe));

		}catch (final Exception exp) {
			log.severe(CvddmUtil.getStackTraceContent(exp));

		} 
		finally {
			//Close the connection to the LDAP directory that was established
			// at construction of the LDAPLookup object
			if (ldapLookObj != null) {
				ldapLookObj.closeConnection();
			}
			log.exiting(CLASS_NAME, METHOD_NAME);
		}
		return ldapUserTO;
	}

	/**
	 * Method Name: populateLdapUserTO()
	 * @Description:This method would populate LdapUserTO object with values from
	 * fetched from FDS. 
	 * @param final NamingEnumeration<SearchResult> results
	 * @return LdapUserTO
	 */

	private static LdapUserTO populateLdapUserTO(
			final NamingEnumeration<SearchResult> results) {
		
		final String METHOD_NAME = "populateLdapUserTO";
		log.entering(CLASS_NAME, METHOD_NAME);

		LdapUserTO ldapUserTO = null;
		
		try {
		
		if (!CvddmUtil.isObjectEmpty(results) && results.hasMore()) {
			
				ldapUserTO = new LdapUserTO();
				// Loop through all of the records returned from the search
				while (results.hasMore()) {
					// Get the next record returned from the search
					final SearchResult resultRecord = results.next();

					// Get an enumeration of all the attributes returned for
					// the current record
					final NamingEnumeration<? extends Attribute> attributes =
							resultRecord.getAttributes().getAll();

					// Loop through the attributes and process each attribute
					while (attributes.hasMore()) {
						final Attribute attr = attributes.next();
						final String attrID = attr.getID();

						// Get an enumeration of all the values returned for
						// the current attribute
						final NamingEnumeration<?> values = attr.getAll();

						// Loop through and process each value for the current
						// attribute
						while ((!CvddmUtil.isObjectEmpty(values)) && values.hasMore()) {

							// Get the value for the key
							final String nextValue =
									((String)values.next()).trim();
							
							log.info("nextValues are >>"+nextValue);

							if (SEARCH_ATTRIBUTES[0].equalsIgnoreCase(attrID)) {
								ldapUserTO.setCdsID(nextValue);
							} else if (SEARCH_ATTRIBUTES[1].equalsIgnoreCase(attrID)) {
								ldapUserTO.setFordGlobalID(nextValue);
							} else if (SEARCH_ATTRIBUTES[2].equalsIgnoreCase(attrID)) {
								ldapUserTO.setFirstName(nextValue);
							} else if (SEARCH_ATTRIBUTES[3].equalsIgnoreCase(attrID)) {
								ldapUserTO.setLastName(nextValue);
							} else if (SEARCH_ATTRIBUTES[4].equalsIgnoreCase(attrID)) {
								ldapUserTO.setFullName(nextValue);
							} else if (SEARCH_ATTRIBUTES[5].equalsIgnoreCase(attrID)) {
								ldapUserTO.setFordDisplayName(nextValue);
							} else if (SEARCH_ATTRIBUTES[6].equalsIgnoreCase(attrID)) {
								ldapUserTO.setMail(nextValue);
							}

						}
					}
				}

			}
		} catch (final Exception ex) {

				log.severe(CvddmUtil.getStackTraceContent(ex));
				ldapUserTO = null;
			}
		 log.exiting(CLASS_NAME, METHOD_NAME);
		 return ldapUserTO;
		}

}
