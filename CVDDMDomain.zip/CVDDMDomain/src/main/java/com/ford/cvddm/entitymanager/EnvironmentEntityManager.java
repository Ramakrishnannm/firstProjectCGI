package com.ford.cvddm.entitymanager;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.ford.cvddm.base.CvddmBaseEntityManager;
import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.domain.env.de.CvddmEnvironmentDE;
import com.ford.it.jpa.helper.FJpaEntityManagerFactoryCacheHelper;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;

/**
 * @Description: This Class contains all DAO specific methods related to
 *               Environment Functionality.
 * @author MJEYARAJ
 *
 */
@ApplicationScoped
public class EnvironmentEntityManager extends CvddmBaseEntityManager {

	private static final String CLASS_NAME = EnvironmentEntityManager.class.getName();
	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	private EntityManager entityManager = null;

	/**
	 * Method Name: fetchAllRecords
	 * 
	 * @Description:This method would fetch all Environmant Records from PCVDM06_ENV
	 *                   database table.
	 * 
	 * @param none
	 * @return List<CvddmEnvironmentDE>
	 */
	@SuppressWarnings("unchecked")
	public List<CvddmEnvironmentDE> fetchAllRecords() {

		final String METHOD_NAME = "fetchAllRecords";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<CvddmEnvironmentDE> cvddmEnvRcrdList = null;

		try {

			entityManager = createEntityManager();

			Query query = entityManager.createNamedQuery("CvddmEnvironmentDE.fetchAll");

			cvddmEnvRcrdList = query.getResultList();
		}

		catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return cvddmEnvRcrdList;
	}

	/**
	 * Method Name: fetchEnvObject
	 * 
	 * @Description:This method would fetch Environmant Object from PCVDM06_ENV
	 *                   database table.
	 * 
	 * @param none
	 * @return List<CvddmEnvironmentDE>
	 */
	@SuppressWarnings("unchecked")
	public CvddmEnvironmentDE fetchEnvObject(String env) {

		final String METHOD_NAME = "fetchEnvObject";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<CvddmEnvironmentDE> cvddmEnvRcrdList = null;

		CvddmEnvironmentDE envObj = new CvddmEnvironmentDE();

		try {

			entityManager = createEntityManager();

			Query query = entityManager.createNamedQuery("CvddmEnvironmentDE.fetchEnvObject");
			query.setParameter(1, env);

			if (!query.getResultList().isEmpty()) {

				cvddmEnvRcrdList = query.getResultList();
			}

			if (!CvddmUtil.isObjectEmpty(cvddmEnvRcrdList) && !cvddmEnvRcrdList.isEmpty()) {

				envObj = cvddmEnvRcrdList.get(0);

			}
		}

		catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return envObj;
	}

}