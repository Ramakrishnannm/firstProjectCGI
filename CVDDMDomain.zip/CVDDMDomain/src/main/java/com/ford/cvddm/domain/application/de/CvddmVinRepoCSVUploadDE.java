package com.ford.cvddm.domain.application.de;

import java.io.Serializable;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.QueryHint;
import javax.persistence.Table;

import com.ford.cvddm.base.CVDDMBaseAuditDE;
import com.google.common.base.Objects;

/**
 * The persistent class for the PCVDM19_VIN_REPO database table.
 * 
 */
@Entity
@Table(name = "PCVDM19_VIN_REPO")
@AttributeOverrides({ @AttributeOverride(name = "createUser", column = @Column(name = "CVDM19_CREATE_USER_C")),
		@AttributeOverride(name = "createTime", column = @Column(name = "CVDM19_CREATE_S")),
		@AttributeOverride(name = "updateUser", column = @Column(name = "CVDM19_LAST_UPDT_USER_C")),
		@AttributeOverride(name = "updateTime", column = @Column(name = "CVDM19_LAST_UPDT_S")) })

@NamedQueries({
    @NamedQuery(name="CvddmVinRepoCSVUploadDE.findAll", query="SELECT c FROM CvddmVinRepoCSVUploadDE c where c.status=?1"),
    @NamedQuery(name="CvddmVinRepoCSVUploadDE.getAvailableDtls", query="SELECT c FROM CvddmVinRepoCSVUploadDE c where c.status=?1",
    hints = @QueryHint(name = "javax.persistence.cache.retrieveMode", value = "BYPASS")),
    @NamedQuery(name="CvddmVinRepoCSVUploadDE.getMockVinDtlsfrmRepo", query="SELECT c FROM CvddmVinRepoCSVUploadDE c  where c.programCode=?1"
    		+ " and c.modelYear=?2 and c.vehicleName=?3 and c.status=?4",
    		 hints = @QueryHint(name = "javax.persistence.cache.retrieveMode", value = "BYPASS"))})
public class CvddmVinRepoCSVUploadDE extends CVDDMBaseAuditDE implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "CVDM19_VIN_K", unique = true, nullable = false)
	private Long cvddmCSVRcrdId;

	public Long getCvddmCSVRcrdId() {
		return cvddmCSVRcrdId;
	}

	public void setCvddmCSVRcrdId(Long cvddmCSVRcrdId) {
		this.cvddmCSVRcrdId = cvddmCSVRcrdId;
	}

	public String getVin() {
		return vin;
	}

	public void setVin(String vin) {
		this.vin = vin;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getVehicleName() {
		return vehicleName;
	}

	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Column(name = "CVDM19_VIN_R", unique = true, nullable = false)
	private String vin;

	@Column(name = "CVDM19_BRAND_N", nullable = false)
	private String make;

	@Column(name = "CVDM19_VEHICLE_N", nullable = false)
	private String vehicleName;
	@Column(name = "CVDM19_STATUS_C", nullable = false)
	private String status;

	@Column(name = "CVDM19_PGM_C", nullable = false)
	private String programCode;
	@Column(name = "CVDM19_MDL_YR_R", nullable = false)
	private String modelYear;

	public String getProgramCode() {
		return programCode;
	}

	public void setProgramCode(String programCode) {
		this.programCode = programCode;
	}

	public String getModelYear() {
		return modelYear;
	}

	public void setModelYear(String modelYear) {
		this.modelYear = modelYear;
	}
	
	@Override
	public int hashCode() {
		return Objects.hashCode(this.cvddmCSVRcrdId);
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		final CvddmVinRepoCSVUploadDE other = (CvddmVinRepoCSVUploadDE)obj;
		return Objects.equal(this.cvddmCSVRcrdId, other.cvddmCSVRcrdId);
	}

}