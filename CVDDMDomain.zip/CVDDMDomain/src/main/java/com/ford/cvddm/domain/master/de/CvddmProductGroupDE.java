package com.ford.cvddm.domain.master.de;

import java.io.Serializable;
import javax.persistence.*;

import com.ford.cvddm.base.CVDDMBaseAuditDE;
import com.google.common.base.Objects;


/**
 * The persistent class for the PCVDM10_PRDCT_GRP database table.
 * 
 */
@Entity
@Table(name="PCVDM10_PRDCT_GRP")

@AttributeOverrides({ @AttributeOverride(name = "createUser", column = @Column(name = "CVDM10_CREATE_USER_C")),
	@AttributeOverride(name = "createTime", column = @Column(name = "CVDM10_CREATE_S")),
	@AttributeOverride(name = "updateUser", column = @Column(name = "CVDM10_LAST_UPDT_USER_C")),
	@AttributeOverride(name = "updateTime", column = @Column(name = "CVDM10_LAST_UPDT_S")) })

@NamedQueries({
    @NamedQuery(name="CvddmProductGroupDE.findAll", query="SELECT c FROM CvddmProductGroupDE c"),
    @NamedQuery(name="CvddmProductGroupDE.getProductGroupById",
    query = "select n from CvddmProductGroupDE n WHERE n.cvdmPrdctGrpId=?1 and n.cvdmActiveFlag=?1 ", hints = @QueryHint(
            		name = "javax.persistence.cache.retrieveMode",
                    value = "BYPASS")),
    @NamedQuery(name = "CvddmProductGroupDE.getActiveRecords",
        query = "select n from CvddmProductGroupDE n WHERE n.cvdmActiveFlag=?1 ", hints = @QueryHint(
        		name = "javax.persistence.cache.retrieveMode",
                value = "BYPASS"))})



public class CvddmProductGroupDE extends CVDDMBaseAuditDE implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="CVDM10_PRDCT_GRP_K")
	private long cvdmPrdctGrpId;

	@Column(name="CVDM10_ACTIVE_F")
	private String cvdmActiveFlag;

	@Column(name="CVDM10_PRDCT_GRP_N")
	private String cvdmPrdctGrpDesc;


	public long getCvdmPrdctGrpId() {
		return this.cvdmPrdctGrpId;
	}

	public void setCvdmPrdctGrpId(long cvdmPrdctGrpId) {
		this.cvdmPrdctGrpId = cvdmPrdctGrpId;
	}

	public String getCvdmActiveFlag() {
		return this.cvdmActiveFlag;
	}

	public void setCvdmActiveFlag(String cvdmActiveFlag) {
		this.cvdmActiveFlag = cvdmActiveFlag;
	}

	public String getCvdmPrdctGrpDesc() {
		return this.cvdmPrdctGrpDesc;
	}

	public void setCvdmPrdctGrpDesc(String cvdmPrdctGrpDesc) {
		this.cvdmPrdctGrpDesc = cvdmPrdctGrpDesc;
	}
	
	@Override
	public int hashCode() {
		return Objects.hashCode(this.cvdmPrdctGrpId);
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		final CvddmProductGroupDE other = (CvddmProductGroupDE) obj;
		return Objects.equal(this.cvdmPrdctGrpId, other.cvdmPrdctGrpId);
	}

}