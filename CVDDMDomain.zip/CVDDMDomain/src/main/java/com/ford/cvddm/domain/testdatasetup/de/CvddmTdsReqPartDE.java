package com.ford.cvddm.domain.testdatasetup.de;

import java.io.Serializable;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.google.common.base.Objects;

/**
 * The persistent class for the PCVDM26_TDS_REQ_PART database table.
 * 
 */
@Entity
@Table(name = "PCVDM26_TDS_REQ_PART")
@AttributeOverrides({ @AttributeOverride(name = "createUser", column = @Column(name = "CVDM26_CREATE_USER_C")),
		@AttributeOverride(name = "createTime", column = @Column(name = "CVDM26_CREATE_S")),
		@AttributeOverride(name = "updateUser", column = @Column(name = "CVDM26_LAST_UPDT_USER_C")),
		@AttributeOverride(name = "updateTime", column = @Column(name = "CVDM26_LAST_UPDT_S")) })
@NamedQuery(name = "CvddmTdsReqPartDE.findAll", query = "SELECT c FROM CvddmTdsReqPartDE c")
public class CvddmTdsReqPartDE extends com.ford.cvddm.base.CVDDMBaseAuditDE implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "CVDM16_TDS_REQ_MOD_K", referencedColumnName = "CVDM16_TDS_REQ_MOD_K")
	private CvddmTdsReqModDE cvddmTdsReqModDE;

	@Column(name = "CVDM26_PART_LINEAGE_D")
	private int partLineageData;

	@Column(name = "CVDM26_ASSY_PART_R")
	private String assembly;

	@Column(name = "CVDM26_ASSY_PART_X")
	private String assemblyDescription;

	@Column(name = "CVDM26_HW_PART_R")
	private String hardwarePartNumber;

	@Column(name = "CVDM26_HW_PART_X")
	private String hardwareDescription;

	@Column(name = "CVDM26_SW_PARTS_X")
	private String softwareParts;

	@Column(name = "CVDM26_APPLICATION_X")
	private String applications;

	@Column(name = "CVDM26_SRVC_XML_D")
	private int serviceXMLType;

	@Column(name = "CVDM26_RPLCMNT_MOD_IN_OP_F")
	private String replacementModuleIsInOperation;

	@Column(name = "CVDM26_PGM_IN_SRVC_F")
	private String programInService;

	public CvddmTdsReqModDE getCvddmTdsReqModDE() {
		return cvddmTdsReqModDE;
	}

	public void setCvddmTdsReqModDE(CvddmTdsReqModDE cvddmTdsReqModDE) {
		this.cvddmTdsReqModDE = cvddmTdsReqModDE;
	}

	public int getPartLineageData() {
		return partLineageData;
	}

	public void setPartLineageData(int partLineageData) {
		this.partLineageData = partLineageData;
	}

	public String getAssembly() {
		return assembly;
	}

	public void setAssembly(String assembly) {
		this.assembly = assembly;
	}

	public String getAssemblyDescription() {
		return assemblyDescription;
	}

	public void setAssemblyDescription(String assemblyDescription) {
		this.assemblyDescription = assemblyDescription;
	}

	public String getHardwarePartNumber() {
		return hardwarePartNumber;
	}

	public void setHardwarePartNumber(String hardwarePartNumber) {
		this.hardwarePartNumber = hardwarePartNumber;
	}

	public String getHardwareDescription() {
		return hardwareDescription;
	}

	public void setHardwareDescription(String hardwareDescription) {
		this.hardwareDescription = hardwareDescription;
	}

	public String getSoftwareParts() {
		return softwareParts;
	}

	public void setSoftwareParts(String softwareParts) {
		this.softwareParts = softwareParts;
	}

	public String getApplications() {
		return applications;
	}

	public void setApplications(String applications) {
		this.applications = applications;
	}

	public int getServiceXMLType() {
		return serviceXMLType;
	}

	public void setServiceXMLType(int serviceXMLType) {
		this.serviceXMLType = serviceXMLType;
	}

	public String getReplacementModuleIsInOperation() {
		return replacementModuleIsInOperation;
	}

	public void setReplacementModuleIsInOperation(String replacementModuleIsInOperation) {
		this.replacementModuleIsInOperation = replacementModuleIsInOperation;
	}

	public String getProgramInService() {
		return programInService;
	}

	public void setProgramInService(String programInService) {
		this.programInService = programInService;
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(this.cvddmTdsReqModDE.getCvdmTdsReqModId());
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		final CvddmTdsReqPartDE other = (CvddmTdsReqPartDE) obj;
		return Objects.equal(this.cvddmTdsReqModDE.getCvdmTdsReqModId(), other.cvddmTdsReqModDE.getCvdmTdsReqModId());
	}

}