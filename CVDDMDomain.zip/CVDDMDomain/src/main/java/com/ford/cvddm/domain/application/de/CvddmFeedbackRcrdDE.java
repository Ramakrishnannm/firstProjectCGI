package com.ford.cvddm.domain.application.de;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.ford.cvddm.base.CVDDMBaseAuditDE;
import com.ford.cvddm.domain.master.de.CvddmScreenInfoDE;

/**
 * The persistent class for the PCVDM09_FDBK database table.
 * 
 */
@Entity
@Table(name = "PCVDM09_FDBK")
@AttributeOverrides({ @AttributeOverride(name = "createUser", column = @Column(name = "CVDM09_CREATE_USER_C")),
		@AttributeOverride(name = "createTime", column = @Column(name = "CVDM09_CREATE_S")),
		@AttributeOverride(name = "updateUser", column = @Column(name = "CVDM09_LAST_UPDT_USER_C")),
		@AttributeOverride(name = "updateTime", column = @Column(name = "CVDM09_LAST_UPDT_S")) })
public class CvddmFeedbackRcrdDE extends CVDDMBaseAuditDE implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "CVDM09_FDBK_K", unique = true, nullable = false)
	private int cvddmFeedbackRcrdId;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "CVDM01_SCREEN_D", referencedColumnName = "CVDM01_SCREEN_D")
	private CvddmScreenInfoDE cvddmScreenInfoDE;

	@Column(name = "CVDM09_FDBK_X", nullable = false, length = 1000)
	private String cvddmFeedbackDesc;

	@Column(name = "CVDM09_SGSTN_X", nullable = false, length = 1000)
	private String cvddmFeedbackSuggestion;

	@Column(name = "CVDM09_FDBK_RATING_R", unique = true, nullable = false)
	private Integer rating;

	@Column(name = "CVDM09_FDBK_S", nullable = false)
	private Timestamp cvddmFeedbackFromDt;

	@Column(name = "CVDM09_FDBK_USER_C", nullable = false)
	private String feedBackUserName;

	public String getFeedBackUserName() {
		return feedBackUserName;
	}

	public void setFeedBackUserName(String feedBackUserName) {
		this.feedBackUserName = feedBackUserName;
	}

	public Timestamp getCvddmFeedbackFromDt() {
		return cvddmFeedbackFromDt;
	}

	public void setCvddmFeedbackFromDt(Timestamp cvddmFeedbackFromDt) {
		this.cvddmFeedbackFromDt = cvddmFeedbackFromDt;
	}

	public CvddmScreenInfoDE getCvddmScreenInfoDE() {
		return cvddmScreenInfoDE;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((cvddmFeedbackDesc == null) ? 0 : cvddmFeedbackDesc.hashCode());
		result = prime * result + cvddmFeedbackRcrdId;
		result = prime * result + ((cvddmFeedbackSuggestion == null) ? 0 : cvddmFeedbackSuggestion.hashCode());
		result = prime * result + ((cvddmScreenInfoDE == null) ? 0 : cvddmScreenInfoDE.hashCode());
		result = prime * result + rating;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CvddmFeedbackRcrdDE other = (CvddmFeedbackRcrdDE) obj;
		if (cvddmFeedbackDesc == null) {
			if (other.cvddmFeedbackDesc != null)
				return false;
		} else if (!cvddmFeedbackDesc.equals(other.cvddmFeedbackDesc))
			return false;
		if (cvddmFeedbackRcrdId != other.cvddmFeedbackRcrdId)
			return false;
		if (cvddmFeedbackSuggestion == null) {
			if (other.cvddmFeedbackSuggestion != null)
				return false;
		} else if (!cvddmFeedbackSuggestion.equals(other.cvddmFeedbackSuggestion))
			return false;
		if (cvddmScreenInfoDE == null) {
			if (other.cvddmScreenInfoDE != null)
				return false;
		} else if (!cvddmScreenInfoDE.equals(other.cvddmScreenInfoDE))
			return false;
		if (rating != other.rating)
			return false;
		return true;
	}

	public void setCvddmScreenInfoDE(CvddmScreenInfoDE cvddmScreenInfoDE) {
		this.cvddmScreenInfoDE = cvddmScreenInfoDE;
	}

	public int getCvddmFeedbackRcrdId() {
		return cvddmFeedbackRcrdId;
	}

	public void setCvddmFeedbackRcrdId(int cvddmFeedbackRcrdId) {
		this.cvddmFeedbackRcrdId = cvddmFeedbackRcrdId;
	}

	public String getCvddmFeedbackDesc() {
		return cvddmFeedbackDesc;
	}

	public void setCvddmFeedbackDesc(String cvddmFeedbackDesc) {
		this.cvddmFeedbackDesc = cvddmFeedbackDesc;
	}

	public String getCvddmFeedbackSuggestion() {
		return cvddmFeedbackSuggestion;
	}

	public void setCvddmFeedbackSuggestion(String cvddmFeedbackSuggestion) {
		this.cvddmFeedbackSuggestion = cvddmFeedbackSuggestion;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

}