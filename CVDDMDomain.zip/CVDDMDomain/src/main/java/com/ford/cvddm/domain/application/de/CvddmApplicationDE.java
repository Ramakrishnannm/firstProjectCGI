package com.ford.cvddm.domain.application.de;

import java.io.Serializable;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.QueryHint;
import javax.persistence.Table;

import com.ford.cvddm.base.CVDDMBaseAuditDE;
import com.google.common.base.Objects;

/**
 * The persistent class for the PCVDM07_APP database table.
 *
 */
@Entity
@Table(name = "PCVDM07_APP")
@AttributeOverrides({ @AttributeOverride(name = "createUser", column = @Column(name = "CVDM07_CREATE_USER_C")),
		@AttributeOverride(name = "createTime", column = @Column(name = "CVDM07_CREATE_S")),
		@AttributeOverride(name = "updateUser", column = @Column(name = "CVDM07_LAST_UPDT_USER_C")),
		@AttributeOverride(name = "updateTime", column = @Column(name = "CVDM07_LAST_UPDT_S")) })

@NamedQueries({
		@NamedQuery(name = "CvddmApplicationDE.fetchAll", query = "select n from CvddmApplicationDE n", hints = @QueryHint(name = "javax.persistence.cache.retrieveMode", value = "BYPASS")) })

public class CvddmApplicationDE extends CVDDMBaseAuditDE implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "CVDM07_APP_D", unique = true, nullable = false)
	private int appId;

	@Column(name = "CVDM07_APP_N", nullable = false, length = 1)
	private String appName;

	@Column(name = "CVDM07_APP_X", nullable = false)
	private String appDesc;

	public int getAppId() {
		return appId;
	}

	public void setAppId(int appId) {
		this.appId = appId;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getAppDesc() {
		return appDesc;
	}

	public void setAppDesc(String appDesc) {
		this.appDesc = appDesc;
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(this.appId);
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		final CvddmApplicationDE other = (CvddmApplicationDE) obj;
		return Objects.equal(this.appId, other.appId);
	}

}
