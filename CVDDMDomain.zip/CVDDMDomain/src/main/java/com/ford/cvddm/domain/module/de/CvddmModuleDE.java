package com.ford.cvddm.domain.module.de;

import java.io.Serializable;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.QueryHint;
import javax.persistence.Table;
import com.ford.cvddm.base.CVDDMBaseAuditDE;
import com.google.common.base.Objects;

/**
 * The persistent class for the PCVDM15_MODULE_TYPE database table.
 *
 */
@Entity
@Table(name = "PCVDM15_MOD_TYPE")
@AttributeOverrides({ @AttributeOverride(name = "createUser", column = @Column(name = "CVDM15_CREATE_USER_C")),
		@AttributeOverride(name = "createTime", column = @Column(name = "CVDM15_CREATE_S")),
		@AttributeOverride(name = "updateUser", column = @Column(name = "CVDM15_LAST_UPDT_USER_C")),
		@AttributeOverride(name = "updateTime", column = @Column(name = "CVDM15_LAST_UPDT_S")) })

@NamedQueries({
		@NamedQuery(name = "CvddmModuleDE.fetchAll", query = "select n from CvddmModuleDE n", hints = @QueryHint(name = "javax.persistence.cache.retrieveMode", value = "BYPASS")),
		@NamedQuery(name = "CvddmModuleDE.fetchModuleRcd", query = "select n from CvddmModuleDE n where n.module = ?1", hints = @QueryHint(name = "javax.persistence.cache.retrieveMode", value = "BYPASS")),
		@NamedQuery(name = "CvddmModuleDE.fetchActiveRcds", query = "select n from CvddmModuleDE n where n.activeFlag = 'Y'", hints = @QueryHint(name = "javax.persistence.cache.retrieveMode", value = "BYPASS")) })
public class CvddmModuleDE extends CVDDMBaseAuditDE implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "CVDM15_MOD_K", unique = true, nullable = false)
	private String moduleId;

	@Column(name = "CVDM15_MOD_C", nullable = false)
	private String module;

	@Column(name = "CVDM15_MOD_N", nullable = false)
	private String moduleName;

	@Column(name = "CVDM15_MOD_X")
	private String moduleDesc;

	@Column(name = "CVDM15_ACTIVE_F", nullable = false, length = 1)
	private String activeFlag;

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public String getModuleId() {
		return moduleId;
	}

	public void setModuleId(String moduleId) {
		this.moduleId = moduleId;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public String getModuleDesc() {
		return moduleDesc;
	}

	public void setModuleDesc(String moduleDesc) {
		this.moduleDesc = moduleDesc;
	}

	public String getActiveFlag() {
		return activeFlag;
	}

	public void setActiveFlag(String activeFlag) {
		this.activeFlag = activeFlag;
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(this.moduleId);
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		final CvddmModuleDE other = (CvddmModuleDE) obj;
		return Objects.equal(this.moduleId, other.moduleId);
	}

}
