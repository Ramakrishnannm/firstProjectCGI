package com.ford.cvddm.domain.master.de;

import java.io.Serializable;
import javax.persistence.*;

import com.google.common.base.Objects;



/**
 * The persistent class for the PCVDM13_TEST_TYPE database table.
 * 
 */
@Entity
@Table(name="PCVDM13_TEST_TYPE")
@AttributeOverrides({ @AttributeOverride(name = "createUser", column = @Column(name = "CVDM13_CREATE_USER_C")),
	@AttributeOverride(name = "createTime", column = @Column(name = "CVDM13_CREATE_S")),
	@AttributeOverride(name = "updateUser", column = @Column(name = "CVDM13_LAST_UPDT_USER_C")),
	@AttributeOverride(name = "updateTime", column = @Column(name = "CVDM13_LAST_UPDT_S")) })
@NamedQueries({
@NamedQuery(name="CvddmTestingTypeDE.getTestingTypeById", 
            query="SELECT c FROM CvddmTestingTypeDE c where c.cvdmTestTypeID=?1 and c.cvdmActiveFlag=?2",hints = @QueryHint(
			name = "javax.persistence.cache.retrieveMode",
	        value = "BYPASS")),
@NamedQuery(name="CvddmTestingTypeDE.getActiveRecords", query="SELECT c FROM CvddmTestingTypeDE c where c.cvdmActiveFlag=?1",hints = @QueryHint(
		name = "javax.persistence.cache.retrieveMode",
        value = "BYPASS"))})

public class CvddmTestingTypeDE extends com.ford.cvddm.base.CVDDMBaseAuditDE implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="CVDM13_TEST_TYPE_K")
	private long cvdmTestTypeID;

	@Column(name="CVDM13_ACTIVE_F")
	private String cvdmActiveFlag;

	@Column(name="CVDM13_TEST_TYPE_N")
	private String cvdmTestTypeDesc;


	public long getCvdmTestTypeID() {
		return this.cvdmTestTypeID;
	}

	public void setCvdmTestTypeID(long cvdmTestTypeID) {
		this.cvdmTestTypeID = cvdmTestTypeID;
	}

	public String getCvdmActiveFlag() {
		return this.cvdmActiveFlag;
	}

	public void setCvdmActiveFlag(String cvdmActiveFlag) {
		this.cvdmActiveFlag = cvdmActiveFlag;
	}

	public String getCvdmTestTypeDesc() {
		return this.cvdmTestTypeDesc;
	}

	public void setCvdmTestTypeDesc(String cvdmTestTypeDesc) {
		this.cvdmTestTypeDesc = cvdmTestTypeDesc;
	}
	
	@Override
	public int hashCode() {
		return Objects.hashCode(this.cvdmTestTypeID);
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		final CvddmTestingTypeDE other = (CvddmTestingTypeDE) obj;
		return Objects.equal(this.cvdmTestTypeID, other.cvdmTestTypeID);
	}

}