package com.ford.cvddm.domain.application.de;

import java.io.Serializable;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.QueryHint;
import javax.persistence.Table;

import com.ford.cvddm.base.CVDDMBaseAuditDE;

/**
 * The persistent class for the PCVDM21_PART_MATRIX database table.
 * 
 */
@Entity
@Table(name = "PCVDM21_PART_MATRIX")
@AttributeOverrides({ @AttributeOverride(name = "createUser", column = @Column(name = "CVDM21_CREATE_USER_C")),
		@AttributeOverride(name = "createTime", column = @Column(name = "CVDM21_CREATE_S")),
		@AttributeOverride(name = "updateUser", column = @Column(name = "CVDM21_LAST_UPDT_USER_C")),
		@AttributeOverride(name = "updateTime", column = @Column(name = "CVDM21_LAST_UPDT_S")) })

@NamedQueries({
		@NamedQuery(name = "CvddmPartMatrixReferenceCSVUploadDE.fetchAll", query = "select n from CvddmPartMatrixReferenceCSVUploadDE n", hints = @QueryHint(name = "javax.persistence.cache.retrieveMode", value = "BYPASS")) })
public class CvddmPartMatrixReferenceCSVUploadDE extends CVDDMBaseAuditDE implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name = "CVDM21_PART_K", unique = true, nullable = false)
	private Long cvddmPartMatrxRcrdId;

	@Column(name = "CVDM17_REGION_C", nullable = false)
	private String region;

	@Column(name = "CVDM21_SW_VER_X", nullable = false)
	private String softwareReleaseVersion;

	@Column(name = "CVDM21_FB_X", nullable = false)
	private String featureBundle;

	@Column(name = "CVDM21_NODE_ADRS_C", nullable = false)
	private String node;

	@Column(name = "CVDM21_PART_R", nullable = false)
	private String assemblyPartIIspec;

	@Column(name = "CVDM21_PGM_C", nullable = false)
	private String programCode;

	@Column(name = "CVDM21_MDL_YR_R", nullable = false)
	private String modelYear;

	@Column(name = "CVDM21_SORT_ORDER_R")
	private int sortingOrder;

	public Long getCvddmPartMatrxRcrdId() {
		return cvddmPartMatrxRcrdId;
	}

	public void setCvddmPartMatrxRcrdId(Long cvddmPartMatrxRcrdId) {
		this.cvddmPartMatrxRcrdId = cvddmPartMatrxRcrdId;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getSoftwareReleaseVersion() {
		return softwareReleaseVersion;
	}

	public void setSoftwareReleaseVersion(String softwareReleaseVersion) {
		this.softwareReleaseVersion = softwareReleaseVersion;
	}

	public String getFeatureBundle() {
		return featureBundle;
	}

	public void setFeatureBundle(String featureBundle) {
		this.featureBundle = featureBundle;
	}

	public String getNode() {
		return node;
	}

	public void setNode(String node) {
		this.node = node;
	}

	public String getAssemblyPartIIspec() {
		return assemblyPartIIspec;
	}

	public void setAssemblyPartIIspec(String assembly) {
		this.assemblyPartIIspec = assembly;
	}

	public String getProgramCode() {
		return programCode;
	}

	public void setProgramCode(String programCodeLeadVehicles) {
		this.programCode = programCodeLeadVehicles;
	}

	public String getModelYear() {
		return modelYear;
	}

	public void setModelYear(String modelYear) {
		this.modelYear = modelYear;
	}

	public int getSortingOrder() {
		return sortingOrder;
	}

	public void setSortingOrder(int sortingOrder) {
		this.sortingOrder = sortingOrder;
	}

}