/**
 * 
 */
package com.ford.cvddm.base;


import javax.enterprise.context.ApplicationScoped;
import javax.persistence.EntityManager;

import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.it.jpa.helper.FJpaEntityManagerFactoryCacheHelper;


/**
 * @author NGUPTA18
 * Description: Base Class for CVDDM Entity Manager.
 *
 */
@ApplicationScoped
public abstract class CvddmBaseEntityManager {


	public  EntityManager createEntityManager() {

		return FJpaEntityManagerFactoryCacheHelper
				.createEntityManager(
						CVDDMConstant.CVDDM_DEV_PERSISTENCE_UNIT);
	}

}
