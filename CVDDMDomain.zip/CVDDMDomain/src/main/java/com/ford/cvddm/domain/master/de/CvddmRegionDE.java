package com.ford.cvddm.domain.master.de;

import java.io.Serializable;
import javax.persistence.*;

import com.ford.cvddm.base.CVDDMBaseAuditDE;
import com.google.common.base.Objects;



/**
 * US1064801
 * @author NGUPTA18
 * The persistent class for the PCVDM17_REGION database table.
 * 
 */
@Entity
@Table(name="PCVDM17_REGION")
@AttributeOverrides({ @AttributeOverride(name = "createUser", column = @Column(name = "CVDM17_CREATE_USER_C")),
	@AttributeOverride(name = "createTime", column = @Column(name = "CVDM17_CREATE_S")),
	@AttributeOverride(name = "updateUser", column = @Column(name = "CVDM17_LAST_UPDT_USER_C")),
	@AttributeOverride(name = "updateTime", column = @Column(name = "CVDM17_LAST_UPDT_S")) })
@NamedQueries({
    @NamedQuery(name="CvddmRegionDE.findAll", query="SELECT c FROM CvddmRegionDE c"),
    @NamedQuery(name="CvddmRegionDE.getRegionById", 
    query="SELECT c FROM CvddmRegionDE c where c.cvdmRegionId=?1 and c.cvdmActiveFlag=?2",hints = @QueryHint(
	name = "javax.persistence.cache.retrieveMode",
    value = "BYPASS")),
    @NamedQuery(name = "CvddmRegionDE.getActiveRecords",
        query = "select n from CvddmRegionDE n WHERE n.cvdmActiveFlag=?1 ", hints = @QueryHint(
        		name = "javax.persistence.cache.retrieveMode",
                value = "BYPASS"))})
public class CvddmRegionDE extends CVDDMBaseAuditDE implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="CVDM17_REGION_K")
	private long cvdmRegionId;
	
	@Column(name="CVDM17_REGION_C")
	private String cvdmRegionCd;

	@Column(name="CVDM17_ACTIVE_F")
	private String cvdmActiveFlag;

	@Column(name="CVDM17_REGION_N")
	private String cvdmRegionDesc;
	
	public long getCvdmRegionId() {
		return this.cvdmRegionId;
	}

	public void setCvdmRegionId(long cvdmRegionId) {
		this.cvdmRegionId = cvdmRegionId;
	}

	public String getCvdmRegionCd() {
		return this.cvdmRegionCd;
	}

	public void setCvdmRegionCd(String cvdmRegionCd) {
		this.cvdmRegionCd = cvdmRegionCd;
	}

	public String getCvdmActiveFlag() {
		return this.cvdmActiveFlag;
	}

	public void setCvdmActiveFlag(String cvdmActiveFlag) {
		this.cvdmActiveFlag = cvdmActiveFlag;
	}

	public String getCvdmRegionDesc() {
		return this.cvdmRegionDesc;
	}

	public void setCvdmRegionDesc(String cvdmRegionDesc) {
		this.cvdmRegionDesc = cvdmRegionDesc;
	}
	
	@Override
	public int hashCode() {
		return Objects.hashCode(this.cvdmRegionId);
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		final CvddmRegionDE other = (CvddmRegionDE) obj;
		return Objects.equal(this.cvdmRegionId, other.cvdmRegionId);
	}

}