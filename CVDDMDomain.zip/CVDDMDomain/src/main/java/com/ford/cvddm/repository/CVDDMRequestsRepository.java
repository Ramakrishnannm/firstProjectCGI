package com.ford.cvddm.repository;

import java.util.List;

import javax.enterprise.context.Dependent;
import javax.persistence.QueryHint;

import org.apache.deltaspike.data.api.Query;
import org.apache.deltaspike.data.api.QueryResult;
import org.apache.deltaspike.data.api.Repository;
import org.eclipse.persistence.config.HintValues;
import org.eclipse.persistence.config.QueryHints;

import com.ford.cvddm.de.CVDDMRequestsDE;
import com.ford.it.jpa.ds.repository.FJpaBaseEntityRepository;

/**
 * Repository for {@link BookingViewDE}
 *
 * @since v1.0
 */
@Dependent
@Repository
public abstract class CVDDMRequestsRepository
        extends FJpaBaseEntityRepository<CVDDMRequestsDE, String> {
    /**
     * Query to find bookings by the customer.emailAddress.
     *
     * @param customerEmailAddress
     * @return List of {@link CVDDMRequestsDE}
     */
    @Query(hints = {@QueryHint(name = "javax.persistence.cache.retrieveMode",
        value = "BYPASS")})
    public abstract List<CVDDMRequestsDE> findByRequestId(
            final String requestId);
    
    public abstract CVDDMRequestsDE findByRequestIdAndUuid(String requestId, String uuid);
    
    
    /**
     * Added hints to always ignore the cache and refresh the data from the database and READ
     * ONLY.
     *
     * @see org.apache.deltaspike.data.api.EntityRepository#findAll()
     */
    @Override
    @Query(hints = {
                    @QueryHint(name = QueryHints.READ_ONLY, value = HintValues.TRUE),
                    @QueryHint(name = "javax.persistence.cache.retrieveMode", value = "BYPASS"),
                    @QueryHint(name = "eclipselink.refresh", value = "TRUE")})
    public abstract List<CVDDMRequestsDE> findAll();
    
    
    /**
     * Returns a set of all agents as a {@link QueryResult} object
     *
     * @return a set of all agents as a {@link QueryResult} object
     */
    @Query(named = "queryAllRequests")
    public abstract QueryResult<CVDDMRequestsDE> findAllCVDDMRequestss();

}
