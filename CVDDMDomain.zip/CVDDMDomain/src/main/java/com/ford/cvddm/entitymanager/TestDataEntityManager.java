/**
 * 
 */
package com.ford.cvddm.entitymanager;

import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.ford.cvddm.base.CvddmBaseEntityManager;
import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.domain.master.de.CvddmProductGroupDE;
import com.ford.cvddm.domain.master.de.CvddmProductLineDE;
import com.ford.cvddm.domain.master.de.CvddmProductTeamDE;
import com.ford.cvddm.domain.master.de.CvddmTestingTypeDE;
import com.ford.cvddm.domain.testdatasetup.de.CvddmConfigDidSelectionDE;
import com.ford.cvddm.domain.testdatasetup.de.CvddmTdsReqModDE;
import com.ford.cvddm.domain.testdatasetup.de.CvddmTdsReqPartDE;
import com.ford.cvddm.domain.testdatasetup.de.CvddmTestDataReqDE;
import com.ford.it.jpa.helper.FJpaEntityManagerFactoryCacheHelper;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;

/**
 * @author NGUPTA18
 * @Description: This Class contains all DAO specific methods related to
 *               Test Data Set Up Functionality.
 *
 */
@ApplicationScoped
public class TestDataEntityManager extends CvddmBaseEntityManager {


	private static final String CLASS_NAME = TestDataEntityManager.class.getName();
	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	private EntityManager entityManager = null;


	/**
	 * Method Name: getActiveProductGroups
	 * 
	 * @Description:This method would fetch all  Active Product Groups from 
	 *                   PCVDM10_PRDCT_GRP database table.
	 * @param none
	 * @return List<CvddmProductGroupDE>
	 */
	@SuppressWarnings("unchecked")
	public List<CvddmProductGroupDE> getActiveProductGroups() {

		final String METHOD_NAME = "getActiveProductGroups";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<CvddmProductGroupDE> productGroupDEs = null;

		try {

			entityManager = createEntityManager();

			Query query = entityManager.createNamedQuery("CvddmProductGroupDE.getActiveRecords");

			query.setParameter(1, CVDDMConstant.STRING_Y);

			productGroupDEs = query.getResultList();
		}

		catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return productGroupDEs;
	}

	/**
	 * Method Name: getActiveProductLines
	 * 
	 * @Description:This method would fetch all  Active Product Lines from 
	 *                   PCVDM11_PRDCT_LINE database table on basis of passed Product Group Id
	 * @param String prdGrpId
	 * @return List<CvddmProductLineDE>
	 */
	@SuppressWarnings("unchecked")
	public List<CvddmProductLineDE> getActiveProductLines(String prdGrpId) {

		final String METHOD_NAME = "getActiveProductLines";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<CvddmProductLineDE> productLineDEs = null;

		try {

			entityManager = createEntityManager();

			Query query = entityManager.createNamedQuery("CvddmProductLineDE.getActiveRecordsForProductGrp");

			query.setParameter(1, CVDDMConstant.STRING_Y);
			query.setParameter(2, Long.parseLong(prdGrpId));

			productLineDEs = query.getResultList();
		}

		catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return productLineDEs;
	}

	/**
	 * Method Name: getActiveProductTeams
	 * 
	 * @Description:This method would fetch all  Active Product Teams from 
	 *                   PCVDM12_PRDCT_TEAM database table on basis of passed Product Line Id
	 * @param String prdLineId
	 * @return List<CvddmProductTeamDE>
	 */
	@SuppressWarnings("unchecked")
	public List<CvddmProductTeamDE> getActiveProductTeams(String prdLineId) {

		final String METHOD_NAME = "getActiveProductTeams";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<CvddmProductTeamDE> productTeamDEs = null;

		try {

			entityManager = createEntityManager();

			Query query = entityManager.createNamedQuery("CvddmProductTeamDE.getActiveRecordsForProductLine");

			query.setParameter(1, CVDDMConstant.STRING_Y);
			query.setParameter(2, Long.parseLong(prdLineId));

			productTeamDEs = query.getResultList();
		}

		catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return productTeamDEs;
	}

	/**
	 * Method Name: getActiveTestingTypes
	 * 
	 * @Description:This method would fetch all  Active Testing Types from 
	 *                   PCVDM13_TEST_TYPE database table.
	 * @param none
	 * @return List<CvddmTestingTypeDE>
	 */
	@SuppressWarnings("unchecked")
	public List<CvddmTestingTypeDE> getActiveTestingTypes() {

		final String METHOD_NAME = "getActiveTestingTypes";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<CvddmTestingTypeDE> testingTypeDEs = null;

		try {

			entityManager = createEntityManager();

			Query query = entityManager.createNamedQuery("CvddmTestingTypeDE.getActiveRecords");

			query.setParameter(1, CVDDMConstant.STRING_Y);

			testingTypeDEs = query.getResultList();
		}

		catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return testingTypeDEs;
	}

	/*** Start Change :User Story: US1147659 **/

	/**
	 * Method Name: fetchProductGroupById
	 * 
	 * @Description:This method would fetchActive Product Group from 
	 *                   PCVDM10_PRDCT_GRP database table depending on
	 *                   the PK passed.
	 * @param String productGrpId
	 * @return CvddmProductGroupDE
	 */
	@SuppressWarnings("unchecked")
	public CvddmProductGroupDE fetchProductGroupById(String productGrpId) {

		final String METHOD_NAME = "fetchProductGroupById";
		log.entering(CLASS_NAME, METHOD_NAME);

		CvddmProductGroupDE productGroupDE = null;
		
		List<CvddmProductGroupDE> productGroupDELst = new ArrayList<CvddmProductGroupDE>();

		try {

			entityManager = createEntityManager();

			Query query = entityManager.createNamedQuery("CvddmProductGroupDE.getProductGroupById");

			Long uniqueId  = Long.parseLong(productGrpId);

			query.setParameter(1, uniqueId);
			query.setParameter(2, CVDDMConstant.STRING_Y);
			
			productGroupDELst = query.getResultList();
			
            if(!productGroupDELst.isEmpty()) {
				
            	productGroupDE = productGroupDELst.get(0);
			}
		}

		catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return productGroupDE;
	}
	/**
	 * Method Name: fetchProductLineById
	 * 
	 * @Description:This method would fetch Active Product Line from 
	 *                   PCVDM11_PRDCT_LINE database table depending on
	 *                   the PK passed.
	 * @param String productLineId
	 * @return CvddmProductLineDE
	 */
	@SuppressWarnings("unchecked")
	public CvddmProductLineDE fetchProductLineById(String productLineId) {

		final String METHOD_NAME = "fetchProductLineById";
		log.entering(CLASS_NAME, METHOD_NAME);

		CvddmProductLineDE productLineDE = null;
		
		List<CvddmProductLineDE> productLineDELst = new ArrayList<CvddmProductLineDE>();

		try {

			entityManager = createEntityManager();

			Query query = entityManager.createNamedQuery("CvddmProductLineDE.getProductLineById");

			Long uniqueId = Long.parseLong(productLineId);

			query.setParameter(1, uniqueId);
			query.setParameter(2, CVDDMConstant.STRING_Y);
			
			productLineDELst = query.getResultList();
			
            if(!productLineDELst.isEmpty()) {
				
            	productLineDE = productLineDELst.get(0);
			}

		}

		catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return productLineDE;
	}

	/**
	 * Method Name: fetchProducTeamById
	 * 
	 * @Description:This method would fetch Active Product Team from 
	 *                   PCVDM12_PRDCT_TEAM database table depending on
	 *                   the PK passed.
	 * @param String productTeamId
	 * @return CvddmProductTeamDE
	 */
	@SuppressWarnings("unchecked")
	public CvddmProductTeamDE fetchProducTeamById(String productTeamId) {

		final String METHOD_NAME = "fetchProducTeamById";
		log.entering(CLASS_NAME, METHOD_NAME);

		CvddmProductTeamDE productTeamDE = null;
		
		List<CvddmProductTeamDE> productTeamDELst = new ArrayList<CvddmProductTeamDE>();

		try {

			entityManager = createEntityManager();

			Query query = entityManager.createNamedQuery("CvddmProductTeamDE.getProductTeamById");

			Long uniqueId = Long.parseLong(productTeamId);

			query.setParameter(1, uniqueId);
			query.setParameter(2, CVDDMConstant.STRING_Y);
			
			productTeamDELst = query.getResultList();
			
			if(!productTeamDELst.isEmpty()) {
				
				productTeamDE = productTeamDELst.get(0);
			}
		}

		catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return productTeamDE;
	}

	/**
	 * Method Name: fetchTestingTypeById
	 * 
	 * @Description:This method would fetch Active Product Team from 
	 *                   PCVDM13_TEST_TYPE database table depending on
	 *                   the PK passed.
	 * @param SString testingId
	 * @return CvddmTestingTypeDE
	 */
	@SuppressWarnings("unchecked")
	public CvddmTestingTypeDE fetchTestingTypeById(String testingId) {

		final String METHOD_NAME = "fetchTestingTypeById";
		log.entering(CLASS_NAME, METHOD_NAME);

		CvddmTestingTypeDE testingTypeDE = null;
		
		List<CvddmTestingTypeDE> testingTypeDELst = new ArrayList<CvddmTestingTypeDE>();

		try {

			entityManager = createEntityManager();

			Query query = entityManager.createNamedQuery("CvddmTestingTypeDE.getTestingTypeById");

			Long uniqueId = Long.parseLong(testingId);

			query.setParameter(1, uniqueId);
			query.setParameter(2, CVDDMConstant.STRING_Y);
			
			testingTypeDELst = query.getResultList();
			
			if(!testingTypeDELst.isEmpty()) {
				
				testingTypeDE = testingTypeDELst.get(0);
			}
		}

		catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return testingTypeDE;
	}
	/**
	 * Method Name: saveCvddmTestDataReqDEData
	 * 
	 * @Description:This method would persist data into 
	 *                   PCVDM14_TDS_REQ database table
	 * @param CvddmTestDataReqDE dataReqDE
	 * @return CvddmTestDataReqDE
	 */

	public CvddmTestDataReqDE saveCvddmTestDataReqDEData(CvddmTestDataReqDE dataReqDE) {


		final String METHOD_NAME = "saveCvddmTestDataReqDEData";
		log.entering(CLASS_NAME, METHOD_NAME);

		CvddmTestDataReqDE cvddmTestDataReqDE = null;

		try {
			
			entityManager = createEntityManager();

			entityManager.getTransaction().begin();
			cvddmTestDataReqDE = entityManager.merge(dataReqDE);
			entityManager.getTransaction().commit();

		}
		catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			entityManager.getTransaction().rollback();
		}
		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);

			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}
		return cvddmTestDataReqDE;
	}
	
	/**
	 * Method Name: saveCvddmTdsReqModDEData
	 * 
	 * @Description:This method would persist data into 
	 *                   PCVDM16_TDS_REQ_MOD database table
	 * @param CvddmTdsReqModDE dataReqDE
	 * @return CvddmTdsReqModDE
	 */
	
	public CvddmTdsReqModDE saveCvddmTdsReqModDEData(CvddmTdsReqModDE dataReqDE) {


		final String METHOD_NAME = "saveCvddmTdsReqModDEData";
		log.entering(CLASS_NAME, METHOD_NAME);

		CvddmTdsReqModDE tdsReqModDE = null;

		try {
			
			entityManager = createEntityManager();

			entityManager.getTransaction().begin();
			tdsReqModDE = entityManager.merge(dataReqDE);
			entityManager.getTransaction().commit();

		}
		catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			entityManager.getTransaction().rollback();
		}
		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}
		return tdsReqModDE;
	}
	/**
	 * Method Name: saveCvddmTdsReqPartDEData
	 * 
	 * @Description:This method would persist data into 
	 *                   PCVDM26_TDS_REQ_PART database table
	 * @param CvddmTdsReqPartDE dataReqDE
	 * @return CvddmTdsReqPartDE
	 */
	
	public CvddmTdsReqPartDE saveCvddmTdsReqPartDEData(CvddmTdsReqPartDE dataReqDE) {


		final String METHOD_NAME = "saveCvddmTdsReqPartDEData";
		log.entering(CLASS_NAME, METHOD_NAME);

		CvddmTdsReqPartDE tdsReqPartDE = null;

		try {
			
			entityManager = createEntityManager();

			entityManager.getTransaction().begin();
			tdsReqPartDE = entityManager.merge(dataReqDE);
			entityManager.getTransaction().commit();

		}
		catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			entityManager.getTransaction().rollback();
		}
		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}
		return tdsReqPartDE;
	}
	/**
	 * Method Name: saveCvddmConfigDidSelectionDEData
	 * 
	 * @Description:This method would persist data into 
	 *                   PCVDM26_TDS_REQ_PART database table
	 * @param CvddmConfigDidSelectionDE dataReqDE
	 * @return CvddmConfigDidSelectionDE
	 */
	
	public CvddmConfigDidSelectionDE saveCvddmConfigDidSelectionDEData(CvddmConfigDidSelectionDE dataReqDE) {


		final String METHOD_NAME = "saveCvddmConfigDidSelectionDEData";
		log.entering(CLASS_NAME, METHOD_NAME);

		CvddmConfigDidSelectionDE didSelectionDE = null;

		try {
			
			entityManager = createEntityManager();

			entityManager.getTransaction().begin();
			didSelectionDE = entityManager.merge(dataReqDE);
			entityManager.getTransaction().commit();

		}
		catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			entityManager.getTransaction().rollback();
		}
		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}
		return didSelectionDE;
	}
	/*** End Change :User Story: US1147659 **/

}
