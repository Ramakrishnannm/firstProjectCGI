package com.ford.cvddm.domain.master.de;

import java.io.Serializable;
import javax.persistence.*;

import com.google.common.base.Objects;



/**
 * The persistent class for the PCVDM12_PRDCT_TEAM database table.
 * 
 */
@Entity
@Table(name="PCVDM12_PRDCT_TEAM")
@AttributeOverrides({ @AttributeOverride(name = "createUser", column = @Column(name = "CVDM12_CREATE_USER_C")),
	@AttributeOverride(name = "createTime", column = @Column(name = "CVDM12_CREATE_S")),
	@AttributeOverride(name = "updateUser", column = @Column(name = "CVDM12_LAST_UPDT_USER_C")),
	@AttributeOverride(name = "updateTime", column = @Column(name = "CVDM12_LAST_UPDT_S")) })

@NamedQueries({
    @NamedQuery(name="CvddmProductTeamDE.findAll", query="SELECT c FROM CvddmProductTeamDE c"),
    @NamedQuery(name="CvddmProductTeamDE.getProductTeamById",
    query = "select n from CvddmProductTeamDE n WHERE n.cvdmPrdctTeamId=?1 and n.cvdmActiveFlag=?2 ", hints = @QueryHint(
            		name = "javax.persistence.cache.retrieveMode",
                    value = "BYPASS")),
    @NamedQuery(name = "CvddmProductTeamDE.getActiveRecordsForProductLine",
        query = "select n from CvddmProductTeamDE n WHERE n.cvdmActiveFlag=?1 and n.cvddmProductLineDE.cvdmPrdctLineId=?2 ", hints = @QueryHint(
        		name = "javax.persistence.cache.retrieveMode",
                value = "BYPASS"))})

public class CvddmProductTeamDE extends com.ford.cvddm.base.CVDDMBaseAuditDE implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="CVDM12_PRDCT_TEAM_K")
	private long cvdmPrdctTeamId;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "CVDM11_PRDCT_LINE_K", referencedColumnName = "CVDM11_PRDCT_LINE_K")
	private CvddmProductLineDE cvddmProductLineDE;

	@Column(name="CVDM12_ACTIVE_F")
	private String cvdmActiveFlag;

	@Column(name="CVDM12_PRDCT_TEAM_N")
	private String cvdmPrdctTeamDesc;
	
	public long getCvdmPrdctTeamId() {
		return cvdmPrdctTeamId;
	}

	public void setCvdmPrdctTeamId(long cvdmPrdctTeamId) {
		this.cvdmPrdctTeamId = cvdmPrdctTeamId;
	}

	public CvddmProductLineDE getCvddmProductLineDE() {
		return cvddmProductLineDE;
	}

	public void setCvddmProductLineDE(CvddmProductLineDE cvddmProductLineDE) {
		this.cvddmProductLineDE = cvddmProductLineDE;
	}

	public String getCvdmActiveFlag() {
		return this.cvdmActiveFlag;
	}

	public void setCvdmActiveFlag(String cvdmActiveFlag) {
		this.cvdmActiveFlag = cvdmActiveFlag;
	}

	public String getCvdmPrdctTeamDesc() {
		return this.cvdmPrdctTeamDesc;
	}

	public void setCvdmPrdctTeamDesc(String cvdmPrdctTeamDesc) {
		this.cvdmPrdctTeamDesc = cvdmPrdctTeamDesc;
	}
	
	@Override
	public int hashCode() {
		return Objects.hashCode(this.cvdmPrdctTeamId);
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		final CvddmProductTeamDE other = (CvddmProductTeamDE) obj;
		return Objects.equal(this.cvdmPrdctTeamId, other.cvdmPrdctTeamId);
	}

}