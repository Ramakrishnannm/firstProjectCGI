package com.ford.cvddm.entitymanager;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.enterprise.context.ApplicationScoped;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.ford.cvddm.base.CvddmBaseEntityManager;
import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.domain.maintenance.de.CvddmMaintRcrdDE;
import com.ford.cvddm.domain.master.de.CvddmMaintTypeDE;
import com.ford.cvddm.domain.master.de.CvddmScreenInfoDE;
import com.ford.it.jpa.helper.FJpaEntityManagerFactoryCacheHelper;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;

/**
 * @Description: This Class contains all DAO specific methods related to
 *               Maintenance Functionality.
 * @author NGUPTA18
 *
 */
@ApplicationScoped
public class MaintenanceEntityManager extends CvddmBaseEntityManager {

	private static final String CLASS_NAME = MaintenanceEntityManager.class.getName();
	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	private EntityManager entityManager = null;

	/**
	 * Method Name: saveCvddmMaintRcrd
	 * 
	 * @Description:This method would create a New Maintenance Record in
	 *                   PCVDM05_MAINT_REQ database table.
	 * @param Map
	 *            <String, Object> inputMap
	 * @return void
	 */
	public CvddmMaintRcrdDE saveCvddmMaintRcrd(Map<String, Object> inputDataMap) {

		final String METHOD_NAME = "saveCvddmMaintRcrd";
		log.entering(CLASS_NAME, METHOD_NAME);

		CvddmMaintRcrdDE cvddmMaintRcrdDE = null;

		try {
			entityManager = createEntityManager();

			cvddmMaintRcrdDE = (CvddmMaintRcrdDE) inputDataMap.get(CVDDMConstant.MAINT_RCRD_DE_OBJ);

			if (!CvddmUtil.isObjectEmpty(cvddmMaintRcrdDE)) {

				int cvddmScreenId = Integer.parseInt(inputDataMap.get(CVDDMConstant.CVDDM_SCREEN_ID_PK).toString());

				CvddmScreenInfoDE cvddmScreenInfoDE = entityManager.find(CvddmScreenInfoDE.class, cvddmScreenId);

				if (!CvddmUtil.isObjectEmpty(cvddmScreenInfoDE)) {
					cvddmMaintRcrdDE.setCvddmScreenInfoDE(cvddmScreenInfoDE);
				}

				int maintType = Integer.parseInt(inputDataMap.get(CVDDMConstant.MAINT_TYPE_CD_PK).toString());

				CvddmMaintTypeDE cvddmMaintType = entityManager.find(CvddmMaintTypeDE.class, maintType);

				if (!CvddmUtil.isObjectEmpty(cvddmMaintType)) {
					cvddmMaintRcrdDE.setCvddmMaintTypeDE(cvddmMaintType);
				}

				entityManager.getTransaction().begin();
				cvddmMaintRcrdDE = entityManager.merge(cvddmMaintRcrdDE);
				entityManager.getTransaction().commit();

			}

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
		} finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return cvddmMaintRcrdDE;

	}

	/**
	 * Method Name: retrieveMaintTypes
	 * 
	 * @Description:This method would fetch Active Maintenance Types. from
	 *                   PCVDM04_MAINT_TYPE database table.
	 * @param none
	 * @return List<CvddmMaintTypeDE>
	 */
	@SuppressWarnings("unchecked")
	public List<CvddmMaintTypeDE> retrieveActiveMaintTypes() {

		final String METHOD_NAME = "retrieveActiveMaintTypes";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<CvddmMaintTypeDE> cvddmMaintTypeLst = null;

		try {

			entityManager = createEntityManager();

			Query query = entityManager.createNamedQuery("CvddmMaintTypeDE.getActiveRecords");

			query.setParameter(1, CVDDMConstant.STRING_Y);

			cvddmMaintTypeLst = query.getResultList();
		}

		catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return cvddmMaintTypeLst;
	}

	/**
	 * Method Name: fetchAllRecords
	 * 
	 * @Description:This method would fetch all Maintenance Record. from
	 *                   PCVDM05_MAINT_REQ database table.
	 * 
	 * @param none
	 * @return List<CvddmMaintRcrdDE>
	 */
	@SuppressWarnings("unchecked")
	public List<CvddmMaintRcrdDE> fetchAllRecords() {

		final String METHOD_NAME = "fetchAllRecords";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<CvddmMaintRcrdDE> cvddmMaintRcrdList = null;

		try {

			entityManager = createEntityManager();

			Query query = entityManager.createNamedQuery("CvddmMaintRcrdDE.fetchAll");

			cvddmMaintRcrdList = query.getResultList();
		}

		catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return cvddmMaintRcrdList;
	}

	/**
	 * Method Name: retrieveAllScreens
	 * 
	 * @Description:This method would fetch all CVDDM Menu/Sub Menus. from
	 *                   PCVDM01_SCREEN_INFO database table.
	 * @param none
	 * @return List<CvddmScreenInfoDE>
	 */
	@SuppressWarnings("unchecked")
	public List<CvddmScreenInfoDE> retrieveAllScreens() {

		final String METHOD_NAME = "retrieveAllScreens";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<CvddmScreenInfoDE> cvddmScreenInfoDELst = null;

		try {

			entityManager = createEntityManager();
			Query query = entityManager.createNamedQuery("CvddmScreenInfoDE.findAll");
			cvddmScreenInfoDELst = query.getResultList();
			
		} catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		} finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return cvddmScreenInfoDELst;
	}

	/**
	 * Added hints to always ignore the cache and refresh the data from the database
	 * and READ ONLY. This method would fetch Active CvddmMaintRcrdDE Records on
	 * basis Active/Inactive Flag which would be used for Soft Delete Functionality.
	 */

	@SuppressWarnings("unchecked")
	public List<CvddmMaintRcrdDE> retrieveMaintRcrds() {

		final String METHOD_NAME = "retrieveMaintRcrds";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<CvddmMaintRcrdDE> cvddmMaintRcrdDELst = null;

		try {

			entityManager = createEntityManager();

			Query query = entityManager.createNamedQuery("CvddmMaintRcrdDE.getActiveRecords");


			query.setParameter(1, CVDDMConstant.STRING_Y);

			cvddmMaintRcrdDELst = query.getResultList();
		}

		catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}
		return cvddmMaintRcrdDELst;
	}

	/*** Start Change: User Story : US890091 ***/
	/**
	 * Method Name: getDownTimeRecord
	 * 
	 * @Description:This method would get the Active Maintenance Record from
	 *                   PCVDM05_MAINT_REQ database table for Across Site and
	 *                   Downtime when Current Date is greater than equal to From
	 *                   Date&Time and Less Than Equal to To Date&Time *
	 * @param none
	 * @return CvddmMaintRcrdDE
	 */
	@SuppressWarnings("unchecked")
	public CvddmMaintRcrdDE getDownTimeRecord() {

		final String METHOD_NAME = "getDownTimeRecord";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<CvddmMaintRcrdDE> cvddmMaintRcrdList = new ArrayList<CvddmMaintRcrdDE>();

		Long cvddmScreenId = null;

		String cvdmMaintTypeCd = CVDDMConstant.EMPTY_STRING;

		CvddmMaintRcrdDE cvddmMaintRcrdDE = new CvddmMaintRcrdDE();

		try {

			entityManager = createEntityManager();

			Query query = entityManager.createNamedQuery("CvddmMaintRcrdDE.getDownTimeRecord");

			Timestamp currenDtTime = new Timestamp(
					CvddmUtil.getTimeZoneCurrentDate(CVDDMConstant.TIMEZONE_UTC).getTime());

			String strcvddmScreenId = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
					CVDDMConstant.MAINT_FOR_SCRN_DWNTIME_REQ);

			cvddmScreenId = Long.parseLong(strcvddmScreenId);

			cvdmMaintTypeCd = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
					CVDDMConstant.MAINT_TYPE_DWNTIME_CD);

			int cvdmMaintTypeCdInt = Integer.parseInt(cvdmMaintTypeCd);

			query.setParameter(1, currenDtTime);
			query.setParameter(2, currenDtTime);
			query.setParameter(3, cvddmScreenId);
			query.setParameter(4, cvdmMaintTypeCdInt);
			query.setParameter(5, CVDDMConstant.STRING_Y);

			if (!query.getResultList().isEmpty()) {

				cvddmMaintRcrdList = query.getResultList();
			}

			if (!CvddmUtil.isObjectEmpty(cvddmMaintRcrdList) && !cvddmMaintRcrdList.isEmpty()) {

				cvddmMaintRcrdDE = cvddmMaintRcrdList.get(0);
			}
		} catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}
		return cvddmMaintRcrdDE;
	}

	/*** End Change: User Story : US890091 ***/

	/*** Start Change: User Story : US987948 ***/
	/**
	 * Method Name: getAlertRecord
	 * 
	 * @Description: This method would get the Active Alert Maintenance Record from
	 *               PCVDM05_MAINT_REQ database table for Menus when Current Date is
	 *               greater than equal to From Date&Time and Less Than Equal to To
	 *               Date&Time *
	 * @param String
	 *            cvddmScreenCd
	 * @return CvddmMaintRcrdDE
	 */
	@SuppressWarnings("unchecked")
	public CvddmMaintRcrdDE getAlertRecord(String cvddmScreenCd) {

		final String METHOD_NAME = "getAlertRecord";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<CvddmMaintRcrdDE> cvddmMaintRcrdList = new ArrayList<CvddmMaintRcrdDE>();

		Long cvddmScreenId = null;

		String cvdmMaintTypeCd = CVDDMConstant.EMPTY_STRING;

		CvddmMaintRcrdDE cvddmMaintRcrdDE = new CvddmMaintRcrdDE();

		try {

			entityManager = createEntityManager();

			Query query = entityManager.createNamedQuery("CvddmMaintRcrdDE.getAlertRecord");

			Timestamp currenDtTime = new Timestamp(
					CvddmUtil.getTimeZoneCurrentDate(CVDDMConstant.TIMEZONE_UTC).getTime());

			cvddmScreenId = Long.parseLong(cvddmScreenCd);

			cvdmMaintTypeCd = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
					CVDDMConstant.MAINT_TYPE_ALERT_CD);

			int cvdmMaintTypeCdInt = Integer.parseInt(cvdmMaintTypeCd);

			query.setParameter(1, currenDtTime);
			query.setParameter(2, currenDtTime);
			query.setParameter(3, cvddmScreenId);
			query.setParameter(4, cvdmMaintTypeCdInt);
			query.setParameter(5, CVDDMConstant.STRING_Y);

			if (!query.getResultList().isEmpty()) {

				cvddmMaintRcrdList = query.getResultList();
			}

			if (!CvddmUtil.isObjectEmpty(cvddmMaintRcrdList) && !cvddmMaintRcrdList.isEmpty()) {

				cvddmMaintRcrdDE = cvddmMaintRcrdList.get(0);

			}
		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
		} finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return cvddmMaintRcrdDE;
	}

	/*** End Change: User Story : US987948 ***/

	/*** Start Change: User Story : US890086 ***/
	/**
	 * Method Name: getBannerRecord
	 * 
	 * @Description: This method would get the Active Banner Maintenance Record from
	 *               PCVDM05_MAINT_REQ database table for Menus when Current Date is
	 *               greater than equal to From Date&Time and Less Than Equal to To
	 *               Date&Time *
	 * @param String
	 *            cvddmScreenCd
	 * @return CvddmMaintRcrdDE
	 */
	@SuppressWarnings("unchecked")
	public CvddmMaintRcrdDE getBannerRecord(String cvddmScreenCd) {

		final String METHOD_NAME = "getBannerRecord";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<CvddmMaintRcrdDE> cvddmMaintRcrdList = new ArrayList<CvddmMaintRcrdDE>();

		Long cvddmScreenId = null;

		String cvdmMaintTypeCd = CVDDMConstant.EMPTY_STRING;

		CvddmMaintRcrdDE cvddmMaintRcrdDE = new CvddmMaintRcrdDE();

		try {

			entityManager = createEntityManager();

			Query query = entityManager.createNamedQuery("CvddmMaintRcrdDE.getBannerRecord");

			Timestamp currenDtTime = new Timestamp(
					CvddmUtil.getTimeZoneCurrentDate(CVDDMConstant.TIMEZONE_UTC).getTime());

			cvddmScreenId = Long.parseLong(cvddmScreenCd);

			cvdmMaintTypeCd = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
					CVDDMConstant.MAINT_TYPE_BANNER_CD);

			int cvdmMaintTypeCdInt = Integer.parseInt(cvdmMaintTypeCd);

			query.setParameter(1, currenDtTime);
			query.setParameter(2, currenDtTime);
			query.setParameter(3, cvddmScreenId);
			query.setParameter(4, cvdmMaintTypeCdInt);
			query.setParameter(5, CVDDMConstant.STRING_Y);

			if (!query.getResultList().isEmpty()) {

				cvddmMaintRcrdList = query.getResultList();
			}

			if (!CvddmUtil.isObjectEmpty(cvddmMaintRcrdList) && !cvddmMaintRcrdList.isEmpty()) {

				cvddmMaintRcrdDE = cvddmMaintRcrdList.get(0);

			}
		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
		} finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return cvddmMaintRcrdDE;
	}

	/*** End Change: User Story : US890086 ***/
	/***  Start Change: User Story : US890083 ***/
	/**
	 * Method Name: softDeleteRrcd
	 * 
	 * @Description: This method would Soft Delete Maintenance Record from PCVDM05_MAINT_REQ by 
	 *               updating Active Flag to N. 
	 * @param CvddmMaintRcrdDE cvddmMaintRcrdDE
	 * @return none
	 */
	
	public void softDeleteRrcd(CvddmMaintRcrdDE cvddmMaintRcrdDE) {

		final String METHOD_NAME = "softDeleteRrcd";
		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			entityManager = createEntityManager();
			entityManager.getTransaction().begin();
			entityManager.merge(cvddmMaintRcrdDE);
			entityManager.getTransaction().commit();
		}
		catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
		} finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}
	}
    /***  End Change: User Story : US890083 ***/
	
	/*** Start Change: User Story : US941215 ***/
    /**
	 * Method Name: fetchRcrdforUpdate
	 * @Description:This method would fetch  Maintenance Record on basis of passed Primary Key Value.
	 * @param String cvdmMaintRcrdId
	 * @return CvddmMaintRcrdDE
	 */
	@SuppressWarnings("unchecked")
	public CvddmMaintRcrdDE fetchRcrdforUpdate(String selMaintRcrdId) {

		final String METHOD_NAME = "fetchRcrdforUpdate";
		log.entering(CLASS_NAME, METHOD_NAME);


		CvddmMaintRcrdDE cvddmMaintRcrdDE = null;
		
		List<CvddmMaintRcrdDE> cvddmMaintRcrdList = new ArrayList<CvddmMaintRcrdDE>();
		
		try {

			entityManager = createEntityManager();
			
			Timestamp currenDtTime = new Timestamp(
					CvddmUtil.getTimeZoneCurrentDate(CVDDMConstant.TIMEZONE_UTC).getTime());
			
			Query query = entityManager.createNamedQuery("CvddmMaintRcrdDE.fetchRcrdforUpdate");
			
			int cvdmMaintRcrdId = Integer.parseInt(selMaintRcrdId);

			query.setParameter(1, cvdmMaintRcrdId);
			query.setParameter(2, currenDtTime);
			
			if (!query.getResultList().isEmpty()) {

				cvddmMaintRcrdList = query.getResultList();
			}

			if (!CvddmUtil.isObjectEmpty(cvddmMaintRcrdList) && !cvddmMaintRcrdList.isEmpty()) {

				cvddmMaintRcrdDE = cvddmMaintRcrdList.get(0);

			}
		}
		catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
		} finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}
		
		return cvddmMaintRcrdDE;

	}

	/**
	 * Method Name: updtCvddmMaintRcrd
	 * @Description:This method would update Maintenance Record in PCVDM05_MAINT_REQ database table.
	 * @param none
	 * @return none
	 */
	
	public void updtCvddmMaintRcrd(CvddmMaintRcrdDE cvddmMaintRcrdDE) {

		final String METHOD_NAME = "updtCvddmMaintRcrd";
		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			entityManager = createEntityManager();
			entityManager.getTransaction().begin();
			entityManager.merge(cvddmMaintRcrdDE);
			entityManager.getTransaction().commit();
		}
		catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
		} finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}
	}
	/*** End Change: User Story : US941215 ***/

}