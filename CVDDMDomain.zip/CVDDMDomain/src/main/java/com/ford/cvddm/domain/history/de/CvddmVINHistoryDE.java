package com.ford.cvddm.domain.history.de;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.QueryHint;
import javax.persistence.Table;

import com.ford.cvddm.base.CVDDMBaseAuditDE;
import com.ford.cvddm.domain.application.de.CvddmApplicationDE;
import com.ford.cvddm.domain.env.de.CvddmEnvironmentDE;
import com.google.common.base.Objects;

/**
 * This DE class is for - US1108103 The persistent class for the
 * PCVDM08_VEH_DATA_VLDTN_REQ database table.
 *
 */
@Entity
@Table(name = "PCVDM08_VEH_DATA_VLDTN_REQ")
@AttributeOverrides({ @AttributeOverride(name = "createUser", column = @Column(name = "CVDM08_CREATE_USER_C")),
		@AttributeOverride(name = "createTime", column = @Column(name = "CVDM08_CREATE_S")),
		@AttributeOverride(name = "updateUser", column = @Column(name = "CVDM08_LAST_UPDT_USER_C")),
		@AttributeOverride(name = "updateTime", column = @Column(name = "CVDM08_LAST_UPDT_S")) })

@NamedQueries({
		@NamedQuery(name = "CvddmVINHistoryDE.fetchAll", query = "select n from CvddmVINHistoryDE n", hints = @QueryHint(name = "javax.persistence.cache.retrieveMode", value = "BYPASS")),
		@NamedQuery(name = "CvddmVINHistoryDE.getValidationHistoryRcrds", query = "select n from CvddmVINHistoryDE n where n.cvddmApplicationDE.appId=?1"
				+ " and n.requestUser=?2  and n.requestedDateAndTime >=?3 and n.requestedDateAndTime <=?4", 
				    hints = @QueryHint(name = "javax.persistence.cache.retrieveMode", value = "BYPASS")) })

public class CvddmVINHistoryDE extends CVDDMBaseAuditDE implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "CVDM08_VLDTN_REQ_K", unique = true, nullable = false)
	private int requestId;

	@Column(name = "CVDM08_REQ_USER_C", nullable = false, length = 1)
	private String requestUser;

	@Column(name = "CVDM08_REQ_S", nullable = false)
	private Timestamp requestedDateAndTime;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "CVDM06_ENV_D", referencedColumnName = "CVDM06_ENV_D")
	private CvddmEnvironmentDE cvddmEnvironmentDE;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "CVDM07_APP_D", referencedColumnName = "CVDM07_APP_D")
	private CvddmApplicationDE cvddmApplicationDE;

	@Column(name = "CVDM08_VIN_R", nullable = false, length = 1)
	private String vINNumber;

	@Column(name = "CVDM08_WEBSRVC_STAT_C", nullable = false)
	private String webserviceStatus;

	@Column(name = "CVDM08_WEBSRVC_ERR_X", nullable = false, length = 1)
	private String webserviceError;

	public int getRequestId() {
		return requestId;
	}

	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}

	public String getRequestUser() {
		return requestUser;
	}

	public void setRequestUser(String requestUser) {
		this.requestUser = requestUser;
	}

	public Timestamp getRequestedDateAndTime() {
		return requestedDateAndTime;
	}

	public void setRequestedDateAndTime(Timestamp requestedDateAndTime) {
		this.requestedDateAndTime = requestedDateAndTime;
	}

	public CvddmEnvironmentDE getCvddmEnvironmentDE() {
		return cvddmEnvironmentDE;
	}

	public void setCvddmEnvironmentDE(CvddmEnvironmentDE cvddmEnvironmentDE) {
		this.cvddmEnvironmentDE = cvddmEnvironmentDE;
	}

	public CvddmApplicationDE getCvddmApplicationDE() {
		return cvddmApplicationDE;
	}

	public void setCvddmApplicationDE(CvddmApplicationDE cvddmApplicationDE) {
		this.cvddmApplicationDE = cvddmApplicationDE;
	}

	public String getvINNumber() {
		return vINNumber;
	}

	public void setvINNumber(String vINNumber) {
		this.vINNumber = vINNumber;
	}

	public String getWebserviceStatus() {
		return webserviceStatus;
	}

	public void setWebserviceStatus(String webserviceStatus) {
		this.webserviceStatus = webserviceStatus;
	}

	public String getWebserviceError() {
		return webserviceError;
	}

	public void setWebserviceError(String webserviceError) {
		this.webserviceError = webserviceError;
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(this.requestId);
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		final CvddmVINHistoryDE other = (CvddmVINHistoryDE) obj;
		return Objects.equal(this.requestId, other.requestId);
	}

}
