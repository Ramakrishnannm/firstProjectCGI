package com.ford.cvddm.entitymanager;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import com.ford.cvddm.base.CvddmBaseEntityManager;
import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.domain.application.de.CvddmApplicationDE;
import com.ford.cvddm.domain.env.de.CvddmEnvironmentDE;
import com.ford.cvddm.domain.history.de.CvddmPartIISpecHistoryDE;
import com.ford.cvddm.domain.history.de.CvddmVINHistoryDE;
import com.ford.it.jpa.helper.FJpaEntityManagerFactoryCacheHelper;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;
import com.ford.it.util.TextUtil;

/**
 * 
 * This class is for - US1108103
 * 
 * @Description: This Class contains all DAO specific methods related to History
 *               Functionality.
 * @author MJEYARAJ
 *
 */
@ApplicationScoped
public class HistoryEntityManager extends CvddmBaseEntityManager {

	private static final String CLASS_NAME = HistoryEntityManager.class.getName();
	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	private EntityManager entityManager = null;

	/**
	 * 
	 * This method would create a New VIN History Record in
	 * PCVDM08_VEH_DATA_VLDTN_REQ database table.
	 * 
	 * @param requestUser
	 * @param requestedDateAndTime
	 * @param enviroinmentId
	 * @param applicationId
	 * @param vINNumber
	 * @param webserviceStatus
	 * @param webserviceError
	 * @return
	 */
	public CvddmVINHistoryDE saveVINHistoryRcrd(String requestUser, Timestamp requestedDateAndTime, String envUtilityId,
			String appUtilityId, String vINNumber, String webserviceStatus, String webserviceError) {

		final String METHOD_NAME = "saveVINHistoryRcrd";
		log.entering(CLASS_NAME, METHOD_NAME);

		CvddmVINHistoryDE vINHistory = new CvddmVINHistoryDE();

		try {
			entityManager = createEntityManager();

			vINHistory.setRequestUser(requestUser);
			vINHistory.setRequestedDateAndTime(requestedDateAndTime);
			vINHistory.setvINNumber(vINNumber);
			vINHistory.setWebserviceStatus(webserviceStatus);
			vINHistory.setWebserviceError(webserviceError);

			CvddmEnvironmentDE cvddmEnvironmentDE = entityManager.find(CvddmEnvironmentDE.class,
					Integer.parseInt(envUtilityId));

			if (!CvddmUtil.isObjectEmpty(cvddmEnvironmentDE)) {
				vINHistory.setCvddmEnvironmentDE(cvddmEnvironmentDE);
			} else {
				return null;
			}

			CvddmApplicationDE CvddmApplicationDE = entityManager.find(CvddmApplicationDE.class,
					Integer.parseInt(appUtilityId));

			if (!CvddmUtil.isObjectEmpty(CvddmApplicationDE)) {
				vINHistory.setCvddmApplicationDE(CvddmApplicationDE);
			} else {
				return null;
			}

			entityManager.getTransaction().begin();
			entityManager.persist(vINHistory);
			entityManager.getTransaction().commit();

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			return null;
		} finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return new CvddmVINHistoryDE();

	}

	/*** Start Change : User Story : US1078610 *****/

	/**
	 * Method Name: getValidationHistoryRcrds
	 * 
	 * @Description:This method would fetch all VIN History from
	 *                   PCVDM08_VEH_DATA_VLDTN_REQ database table for input app id.
	 * @param String
	 *            appId
	 * @return List<CvddmVINHistoryDE>
	 */
	@SuppressWarnings("unchecked")
	public List<CvddmVINHistoryDE> getValidationHistoryRcrds(String appId) {

		final String METHOD_NAME = "getValidationHistoryRcrds";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<CvddmVINHistoryDE> vinHistoryDEs = null;

		try {

			entityManager = createEntityManager();

			Query query = entityManager.createNamedQuery("CvddmVINHistoryDE.getValidationHistoryRcrds");

			/***
			 * Date Range of Query is Current Date - Minus One Year + One Day to Today's
			 * Date e.g If today's date is 08/26/2019 System should pull data from
			 * 08/27/2018 to 08/26/2019 Only.
			 **/

			Timestamp startDate = new Timestamp(CvddmUtil.getLastYearDatePlusOneDay().getTime());

			Timestamp endDate = new Timestamp(CvddmUtil.getTodaysDate().getTime());

			query.setParameter(1, Integer.parseInt(appId));
			query.setParameter(2, CvddmUtil.getLoggedInUserCDSID());
			query.setParameter(3, startDate);
			query.setParameter(4, endDate);

			vinHistoryDEs = query.getResultList();
		}

		catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return vinHistoryDEs;
	}
	
	@SuppressWarnings("unchecked")
	public List<CvddmPartIISpecHistoryDE> getValidationPartIISpecHistoryRcrds(String appId) {

		final String METHOD_NAME = "getValidationHistoryRcrds";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<CvddmPartIISpecHistoryDE> vinHistoryDEs = null;

		try {

			entityManager = createEntityManager();

			Query query = entityManager.createNamedQuery("CvddmPartIISpecHistoryDE.getValidationHistoryRcrds");

			/***
			 * Date Range of Query is Current Date - Minus One Year + One Day to Today's
			 * Date e.g If today's date is 08/26/2019 System should pull data from
			 * 08/27/2018 to 08/26/2019 Only.
			 **/

			Timestamp startDate = new Timestamp(CvddmUtil.getLastYearDatePlusOneDay().getTime());

			Timestamp endDate = new Timestamp(CvddmUtil.getTodaysDate().getTime());

			query.setParameter(1, Integer.parseInt(appId));
						vinHistoryDEs = query.getResultList();
		}

		catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return vinHistoryDEs;
	}

	/**
	 * Method Name: getValidationHistoryRcrdsByDate
	 * 
	 * @Description:This method would fetch all VIN History from
	 *                   PCVDM08_VEH_DATA_VLDTN_REQ database table for input appId,
	 *                   Timestamp fromDate, Timestamp toDate.
	 * @param String
	 *            String appId,Timestamp fromDate, Timestamp toDate
	 * @return List<CvddmVINHistoryDE>
	 */
	@SuppressWarnings("unchecked")
	public List<CvddmVINHistoryDE> getValidationHistoryRcrdsByDate(String appId, Timestamp fromDate, Timestamp toDate) {

		final String METHOD_NAME = "getValidationHistoryRcrdsByDate";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<CvddmVINHistoryDE> vinHistoryDEs = null;

		try {

			entityManager = createEntityManager();

			Query query = entityManager.createNamedQuery("CvddmVINHistoryDE.getValidationHistoryRcrds");

			query.setParameter(1, Integer.parseInt(appId));
			query.setParameter(2, CvddmUtil.getLoggedInUserCDSID());
			query.setParameter(3, fromDate);
			query.setParameter(4, toDate);

			vinHistoryDEs = query.getResultList();
		}

		catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return vinHistoryDEs;
	}
	
	/**
	 * Method Name: getValidationHistoryPartIISpecRcrdsByOptions
	 * 
	 * @Description:This method would fetch all VIN History from
	 *                   PCVDM22_PART_DATA_VLDTN_REQ database table for input appId,
	 *                   Timestamp fromDate, Timestamp toDate, VIN or Env
	 * @param String String appId,Timestamp fromDate, Timestamp toDate
	 * @return List<CvddmVINHistoryDE>
	 */
	@SuppressWarnings("unchecked")
	public List<CvddmPartIISpecHistoryDE> getValidationHistoryPartIISpecRcrdsByOptions(String appId,Timestamp fromDate, Timestamp toDate,String partIIspec,String env) {

		final String METHOD_NAME = "getValidationHistoryRcrdsByOptions";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<CvddmPartIISpecHistoryDE> vinHistoryDEs = null;

		try {

			entityManager = createEntityManager();

			CriteriaBuilder builder = entityManager.getCriteriaBuilder();

			CriteriaQuery<CvddmPartIISpecHistoryDE> criteria = builder.createQuery(CvddmPartIISpecHistoryDE.class);

			Root<CvddmPartIISpecHistoryDE> root = criteria.from(CvddmPartIISpecHistoryDE.class);

			List<Predicate> predicates = new ArrayList<Predicate>();


			predicates.add(builder.equal(root.get("cvddmApplicationDE").get("appId"),Integer.parseInt(appId))) ;
			
			predicates.add(builder.equal(root.get("requestUser"), CvddmUtil.getLoggedInUserCDSID()));

			if(TextUtil.isNotBlankOrNull(partIIspec)) {
				
				predicates.add(builder.equal(root.get("partIISpec"), partIIspec));

			}
			if(TextUtil.isNotBlankOrNull(env)) {

				Integer envInt  = Integer.valueOf(env);
				
				predicates.add( builder.equal(root.get("cvddmEnvironmentDE").get("envId"), envInt));

			}

			if(!CvddmUtil.isObjectEmpty(fromDate)) {

				predicates.add(builder.greaterThanOrEqualTo(root.get("requestedDateAndTime"), fromDate));
			}

			if(!CvddmUtil.isObjectEmpty(toDate)) {
				predicates.add(builder.lessThanOrEqualTo(root.get("requestedDateAndTime"), toDate));
			}
	
			criteria.where(builder.and(predicates.toArray(new Predicate[predicates.size()])));

			Query query = entityManager.createQuery(criteria);

			vinHistoryDEs = query.getResultList();
		}

		catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}
		return vinHistoryDEs;
	}

	/**
	 * Method Name: getValidationHistoryRcrdsByOptions
	 * 
	 * @Description:This method would fetch all VIN History from
	 *                   PCVDM08_VEH_DATA_VLDTN_REQ database table for input appId,
	 *                   Timestamp fromDate, Timestamp toDate, VIN or Env
	 * @param String String appId,Timestamp fromDate, Timestamp toDate
	 * @return List<CvddmVINHistoryDE>
	 */
	@SuppressWarnings("unchecked")
	public List<CvddmVINHistoryDE> getValidationHistoryRcrdsByOptions(String appId,Timestamp fromDate, Timestamp toDate,String vinNumber,String env) {

		final String METHOD_NAME = "getValidationHistoryRcrdsByOptions";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<CvddmVINHistoryDE> vinHistoryDEs = null;

		try {

			entityManager = createEntityManager();

			CriteriaBuilder builder = entityManager.getCriteriaBuilder();

			CriteriaQuery<CvddmVINHistoryDE> criteria = builder.createQuery(CvddmVINHistoryDE.class);

			Root<CvddmVINHistoryDE> root = criteria.from(CvddmVINHistoryDE.class);

			List<Predicate> predicates = new ArrayList<Predicate>();


			predicates.add(builder.equal(root.get("cvddmApplicationDE").get("appId"),Integer.parseInt(appId))) ;
			
			predicates.add(builder.equal(root.get("requestUser"), CvddmUtil.getLoggedInUserCDSID()));

			if(TextUtil.isNotBlankOrNull(vinNumber)) {
				
				predicates.add(builder.equal(root.get("vINNumber"), vinNumber));

			}
			if(TextUtil.isNotBlankOrNull(env)) {

				Integer envInt  = Integer.valueOf(env);
				
				predicates.add( builder.equal(root.get("cvddmEnvironmentDE").get("envId"), envInt));

			}

			if(!CvddmUtil.isObjectEmpty(fromDate)) {

				predicates.add(builder.greaterThanOrEqualTo(root.get("requestedDateAndTime"), fromDate));
			}

			if(!CvddmUtil.isObjectEmpty(toDate)) {
				predicates.add(builder.lessThanOrEqualTo(root.get("requestedDateAndTime"), toDate));
			}
	
			criteria.where(builder.and(predicates.toArray(new Predicate[predicates.size()])));

			Query query = entityManager.createQuery(criteria);

			vinHistoryDEs = query.getResultList();
		}

		catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}
		return vinHistoryDEs;
	}

	
	/*** End Change : User Story : US1078610 *****/

	/**
	 * 
	 * This method would create a New PartIISpec History Record in
	 * PCVDM22_PART_DATA_VLDTN_REQ database table.
	 * 
	 * @param requestUser
	 * @param requestedDateAndTime
	 * @param enviroinmentId
	 * @param applicationId
	 * @param partIISpec
	 * @param webserviceStatus
	 * @param webserviceError
	 * @return
	 */
	public CvddmPartIISpecHistoryDE savePartIISpecHistoryRcrd(String requestUser, Timestamp requestedDateAndTime,
			String envUtilityId, String appUtilityId, String partIISpec, String webserviceStatus,
			String webserviceError) {

		final String METHOD_NAME = "savePartIISpecHistoryRcrd";
		log.entering(CLASS_NAME, METHOD_NAME);

		CvddmPartIISpecHistoryDE cvddmPartIISpecHistory = new CvddmPartIISpecHistoryDE();

		try {
			entityManager = createEntityManager();

			cvddmPartIISpecHistory.setRequestUser(requestUser);
			cvddmPartIISpecHistory.setRequestedDateAndTime(requestedDateAndTime);
			cvddmPartIISpecHistory.setPartIISpec(partIISpec);
			cvddmPartIISpecHistory.setWebserviceStatus(webserviceStatus);
			cvddmPartIISpecHistory.setWebserviceError(webserviceError);

			CvddmEnvironmentDE cvddmEnvironmentDE = entityManager.find(CvddmEnvironmentDE.class,
					Integer.parseInt(envUtilityId));

			if (!CvddmUtil.isObjectEmpty(cvddmEnvironmentDE)) {
				cvddmPartIISpecHistory.setCvddmEnvironmentDE(cvddmEnvironmentDE);
			} else {
				return null;
			}

			CvddmApplicationDE CvddmApplicationDE = entityManager.find(CvddmApplicationDE.class,
					Integer.parseInt(appUtilityId));

			if (!CvddmUtil.isObjectEmpty(CvddmApplicationDE)) {
				cvddmPartIISpecHistory.setCvddmApplicationDE(CvddmApplicationDE);
			} else {
				return null;
			}

			entityManager.getTransaction().begin();
			entityManager.persist(cvddmPartIISpecHistory);
			entityManager.getTransaction().commit();

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			return null;
		} finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return new CvddmPartIISpecHistoryDE();

	}

	public List<CvddmPartIISpecHistoryDE> getValidationPartIIspecHistoryRcrds(String appId) {
		final String METHOD_NAME = "getValidationPartIIspecHistoryRcrds";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<CvddmPartIISpecHistoryDE> vinHistoryDEs = null;

		try {

			entityManager = createEntityManager();

			Query query = entityManager.createNamedQuery("CvddmPartIISpecHistoryDE.getValidationHistoryRcrds");

			/***
			 * Date Range of Query is Current Date - Minus One Year + One Day to Today's
			 * Date e.g If today's date is 08/26/2019 System should pull data from
			 * 08/27/2018 to 08/26/2019 Only.
			 **/

			Timestamp startDate = new Timestamp(CvddmUtil.getLastYearDatePlusOneDay().getTime());

			Timestamp endDate = new Timestamp(CvddmUtil.getTodaysDate().getTime());

			query.setParameter(1, Integer.parseInt(appId));

			vinHistoryDEs = query.getResultList();
		}

		catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return vinHistoryDEs;
	}

	public List<CvddmPartIISpecHistoryDE> getValidationPartIISpecHistoryRcrdsByDate(String appId, Timestamp fromDate,
			Timestamp toDate) {
		final String METHOD_NAME = "getValidationHistoryRcrdsByDate";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<CvddmPartIISpecHistoryDE> vinHistoryDEs = null;

		try {

			entityManager = createEntityManager();

			Query query = entityManager.createNamedQuery("CvddmPartIISpecHistoryDE.getValidationHistoryRcrds");

			query.setParameter(1, Integer.parseInt(appId));
			vinHistoryDEs = query.getResultList();
		}

		catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return vinHistoryDEs;
	}

}