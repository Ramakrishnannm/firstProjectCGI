package com.ford.cvddm.domain.testdatasetup.de;

import java.io.Serializable;
import javax.persistence.*;

import com.ford.cvddm.domain.master.de.CvddmRegionDE;
import com.google.common.base.Objects;


/**
 * The persistent class for the PCVDM18_TDS_REQ_VIN database table.
 * 
 */
@Entity
@Table(name="PCVDM18_TDS_REQ_VIN")
@AttributeOverrides({ @AttributeOverride(name = "createUser", column = @Column(name = "CVDM18_CREATE_USER_C")),
	@AttributeOverride(name = "createTime", column = @Column(name = "CVDM18_CREATE_S")),
	@AttributeOverride(name = "updateUser", column = @Column(name = "CVDM18_LAST_UPDT_USER_C")),
	@AttributeOverride(name = "updateTime", column = @Column(name = "CVDM18_LAST_UPDT_S")) })
@NamedQuery(name="CvddmTdsReqVinDE.findAll", query="SELECT c FROM CvddmTdsReqVinDE c")
public class CvddmTdsReqVinDE extends com.ford.cvddm.base.CVDDMBaseAuditDE implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="CVDM18_TDS_REQ_VIN_K")
	private long cvdmTdsReqVinId;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "CVDM14_TDS_REQ_K", referencedColumnName = "CVDM14_TDS_REQ_K")
	private CvddmTestDataReqDE cvddmTestDataReqDE;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "CVDM17_REGION_K", referencedColumnName = "CVDM17_REGION_K")
	private CvddmRegionDE cvddmRegionDE;

	@Column(name="CVDM18_VIN_ENTER_F")
	private String cvdmisVirtualVin;

	@Column(name="CVDM18_VIN_R")
	private String cvdmVinNumber;

	public CvddmTestDataReqDE getCvddmTestDataReqDE() {
		return cvddmTestDataReqDE;
	}

	public void setCvddmTestDataReqDE(CvddmTestDataReqDE cvddmTestDataReqDE) {
		this.cvddmTestDataReqDE = cvddmTestDataReqDE;
	}

	public CvddmRegionDE getCvddmRegionDE() {
		return cvddmRegionDE;
	}

	public void setCvddmRegionDE(CvddmRegionDE cvddmRegionDE) {
		this.cvddmRegionDE = cvddmRegionDE;
	}

	public long getCvdmTdsReqVinId() {
		return this.cvdmTdsReqVinId;
	}

	public void setCvdmTdsReqVinId(long cvdmTdsReqVinId) {
		this.cvdmTdsReqVinId = cvdmTdsReqVinId;
	}


	public String getCvdmisVirtualVin() {
		return this.cvdmisVirtualVin;
	}

	public void setCvdmisVirtualVin(String cvdmisVirtualVin) {
		this.cvdmisVirtualVin = cvdmisVirtualVin;
	}

	public String getCvdmVinNumber() {
		return this.cvdmVinNumber;
	}

	public void setCvdmVinNumber(String cvdmVinNumber) {
		this.cvdmVinNumber = cvdmVinNumber;
	}
	
	@Override
	public int hashCode() {
		return Objects.hashCode(this.cvdmTdsReqVinId);
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		final CvddmTdsReqVinDE other = (CvddmTdsReqVinDE) obj;
		return Objects.equal(this.cvdmTdsReqVinId, other.cvdmTdsReqVinId);
	}

}