package com.ford.cvddm.entitymanager;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.enterprise.context.ApplicationScoped;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.ford.cvddm.base.CvddmBaseEntityManager;
import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.domain.application.de.CvddmFeedbackRcrdDE;
import com.ford.cvddm.domain.master.de.CvddmScreenInfoDE;
import com.ford.it.jpa.helper.FJpaEntityManagerFactoryCacheHelper;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;

/**
 * @Description: This Class contains all DAO specific methods related to
 *               Feedback Functionality.
 * @author RPADI
 *
 */
@ApplicationScoped
public class FeedbackEntityManager extends CvddmBaseEntityManager {

	private static final String CLASS_NAME = FeedbackEntityManager.class.getName();
	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	private EntityManager entityManager = null;

	/**
	 * Method Name: saveCvddmFeedbackRcrd
	 * 
	 * @Description:This method would create a New Feedback Record in PCVDM09_FDBK
	 *                   database table.
	 * @param Map
	 *            <String, Object> inputMap
	 * 
	 */

	public CvddmFeedbackRcrdDE saveCvddmFeedbackRcrd(Map<String, Object> inputDataMap) {

		final String METHOD_NAME = "saveCvddmFeedbackRcrd";
		log.entering(CLASS_NAME, METHOD_NAME);

		CvddmFeedbackRcrdDE cvddmFeedbackRcrdDE = null;

		try {
			entityManager = createEntityManager();

			cvddmFeedbackRcrdDE = (CvddmFeedbackRcrdDE) inputDataMap.get(CVDDMConstant.FEEDBACK_RCRD_DE_OBJ);

			if (!CvddmUtil.isObjectEmpty(cvddmFeedbackRcrdDE)) {

				int cvddmScreenId = Integer.parseInt(inputDataMap.get(CVDDMConstant.CVDDM_SCREEN_ID_PK).toString());

				CvddmScreenInfoDE cvddmScreenInfoDE = entityManager.find(CvddmScreenInfoDE.class, cvddmScreenId);

				if (!CvddmUtil.isObjectEmpty(cvddmScreenInfoDE)) {
					cvddmFeedbackRcrdDE.setCvddmScreenInfoDE(cvddmScreenInfoDE);
				}
				Date serverCurrentDate = CvddmUtil.getTimeZoneCurrentDate(CVDDMConstant.TIMEZONE_UTC);

				cvddmFeedbackRcrdDE.setCvddmFeedbackFromDt(new Timestamp(serverCurrentDate.getTime()));

				String loggedInUser = CvddmUtil.getLoggedInUserCDSID();

				cvddmFeedbackRcrdDE.setFeedBackUserName(loggedInUser);
				entityManager.getTransaction().begin();
				entityManager.persist(cvddmFeedbackRcrdDE);
				entityManager.getTransaction().commit();

			}

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
		} finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return cvddmFeedbackRcrdDE;

	}

	/**
	 * Method Name: retrieveAllScreens
	 * 
	 * @Description:This method would fetch all page names from PCVDM01_SCREEN_INFO
	 *                   database table.
	 * @param none
	 * @return List<CvddmScreenInfoDE>
	 */
	@SuppressWarnings("unchecked")
	public List<CvddmScreenInfoDE> retrieveAllScreens() {

		final String METHOD_NAME = "retrieveAllScreens";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<CvddmScreenInfoDE> cvddmScreenInfoDELst = null;

		try {

			entityManager = createEntityManager();
			Query query = entityManager.createNamedQuery("CvddmScreenInfoDE.findAll");
			cvddmScreenInfoDELst = query.getResultList();

		} catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		} finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return cvddmScreenInfoDELst;
	}
	
	/**
	 * Method Name: retrieveSelectedScreenNameId
	 * 
	 * @Description:This method would fetch selected page name from PCVDM01_SCREEN_INFO
	 *                   database table.
	 * @param pageNamee
	 * @return String
	 */
	
	@SuppressWarnings("unchecked")
	public String retrieveSelectedScreenNameId(String pageNamee) {

		final String METHOD_NAME = "retrieveSelectedScreenNameId";
		log.entering(CLASS_NAME, METHOD_NAME);

		String pageName = null;

		try {

			entityManager = createEntityManager();
			Query query = entityManager.createNamedQuery("CvddmScreenInfoDE.getSelectedPageId");
			query.setParameter(1, pageNamee);
			pageName = query.getSingleResult().toString();

		} catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		} finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return pageName;
	}

}