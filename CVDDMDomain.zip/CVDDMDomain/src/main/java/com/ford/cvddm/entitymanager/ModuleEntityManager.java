package com.ford.cvddm.entitymanager;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.ford.cvddm.base.CvddmBaseEntityManager;
import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.domain.module.de.CvddmModuleDE;
import com.ford.it.jpa.helper.FJpaEntityManagerFactoryCacheHelper;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;

/**
 * @Description: This Class contains all DAO specific methods related to Module
 *               Functionality.
 * @author MJEYARAJ
 *
 */
@ApplicationScoped
public class ModuleEntityManager extends CvddmBaseEntityManager {

	private static final String CLASS_NAME = ModuleEntityManager.class.getName();
	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	private EntityManager entityManager = null;

	/**
	 * Method Name: fetchAllRecords
	 * 
	 * @Description:This method would fetch all module Records from
	 *                   PCVDM15_MODULE_TYPE database table.
	 * 
	 * @param none
	 * @return List<CvddmModuleDE>
	 */
	@SuppressWarnings("unchecked")
	public List<CvddmModuleDE> fetchAllRecords() {

		final String METHOD_NAME = "fetchAllRecords";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<CvddmModuleDE> cvddmModRcrdList = null;

		try {

			entityManager = createEntityManager();

			Query query = entityManager.createNamedQuery("CvddmModuleDE.fetchAll");

			cvddmModRcrdList = query.getResultList();
		}

		catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return cvddmModRcrdList;
	}

	/**
	 * Method Name: fetchModuleRecord
	 * 
	 * @Description:This method would fetch module Record from PCVDM15_MODULE_TYPE
	 *                   database table.
	 * 
	 * @param none
	 * @return CvddmModuleDE
	 */
	@SuppressWarnings("unchecked")
	public CvddmModuleDE fetchModuleRecord(String module) {

		final String METHOD_NAME = "fetchModuleRecord";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<CvddmModuleDE> cvddmModRcrdList = null;

		CvddmModuleDE moduleRcrd = new CvddmModuleDE();

		try {

			entityManager = createEntityManager();

			Query query = entityManager.createNamedQuery("CvddmModuleDE.fetchModuleRcd");
			query.setParameter(1, module);

			if (!query.getResultList().isEmpty()) {

				cvddmModRcrdList = query.getResultList();
			}

			if (!CvddmUtil.isObjectEmpty(cvddmModRcrdList) && !cvddmModRcrdList.isEmpty()) {

				moduleRcrd = cvddmModRcrdList.get(0);

			}
		}

		catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return moduleRcrd;
	}

	/**
	 * Method Name: fetchAllRecords
	 * 
	 * @Description:This method would fetch all Module active Records from
	 *                   PCVDM15_MODULE_TYPE database table.
	 * 
	 * @param none
	 * @return List<CvddmModuleDE>
	 */
	@SuppressWarnings("unchecked")
	public List<CvddmModuleDE> fetchActiveRecords() {

		final String METHOD_NAME = "fetchActiveRecords";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<CvddmModuleDE> cvddmModRcrdList = null;

		try {

			entityManager = createEntityManager();

			Query query = entityManager.createNamedQuery("CvddmModuleDE.fetchActiveRcds");

			cvddmModRcrdList = query.getResultList();
		}

		catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return cvddmModRcrdList;
	}

}