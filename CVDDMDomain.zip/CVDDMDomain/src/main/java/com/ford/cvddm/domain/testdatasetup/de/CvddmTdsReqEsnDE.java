package com.ford.cvddm.domain.testdatasetup.de;

import java.io.Serializable;
import javax.persistence.*;

import com.ford.cvddm.domain.module.de.CvddmModuleDE;
import com.google.common.base.Objects;



/**
 * The persistent class for the PCVDM25_TDS_REQ_ESN database table.
 * 
 */
@Entity
@Table(name="PCVDM25_TDS_REQ_ESN")
@AttributeOverrides({ @AttributeOverride(name = "createUser", column = @Column(name = "CVDM25_CREATE_USER_C")),
	@AttributeOverride(name = "createTime", column = @Column(name = "CVDM25_CREATE_S")),
	@AttributeOverride(name = "updateUser", column = @Column(name = "CVDM25_LAST_UPDT_USER_C")),
	@AttributeOverride(name = "updateTime", column = @Column(name = "CVDM25_LAST_UPDT_S")) })
@NamedQuery(name="CvddmTdsReqEsnDE.findAll", query="SELECT c FROM CvddmTdsReqEsnDE c")
public class CvddmTdsReqEsnDE extends com.ford.cvddm.base.CVDDMBaseAuditDE implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="CVDM25_TDS_REQ_ESN_K", unique=true, nullable=false)
	private long cvdmTdsReqEsnId;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "CVDM14_TDS_REQ_K", referencedColumnName = "CVDM14_TDS_REQ_K")
	private CvddmTestDataReqDE cvddmTestDataReqDE;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "CVDM15_MOD_K", referencedColumnName = "CVDM15_MOD_K")
	private CvddmModuleDE cvddmModuleDE;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "CVDM18_VIN_R", referencedColumnName = "CVDM18_VIN_R")
	private CvddmTdsReqVinDE tdsReqVinDE;

	@Column(name="CVDM25_ESN_R", nullable=false, length=8)
	private String cvdmEsnNumber;

	@Column(name="CVDM25_ESN_TYPE_F", nullable=false, length=1)
	private String cvdmEsnType;


	public long getCvdmTdsReqEsnId() {
		return this.cvdmTdsReqEsnId;
	}

	public void setCvdmTdsReqEsnId(long cvdmTdsReqEsnId) {
		this.cvdmTdsReqEsnId = cvdmTdsReqEsnId;
	}

	public CvddmTestDataReqDE getCvddmTestDataReqDE() {
		return cvddmTestDataReqDE;
	}

	public void setCvddmTestDataReqDE(CvddmTestDataReqDE cvddmTestDataReqDE) {
		this.cvddmTestDataReqDE = cvddmTestDataReqDE;
	}

	public CvddmModuleDE getCvddmModuleDE() {
		return cvddmModuleDE;
	}

	public void setCvddmModuleDE(CvddmModuleDE cvddmModuleDE) {
		this.cvddmModuleDE = cvddmModuleDE;
	}

	public CvddmTdsReqVinDE getTdsReqVinDE() {
		return tdsReqVinDE;
	}

	public void setTdsReqVinDE(CvddmTdsReqVinDE tdsReqVinDE) {
		this.tdsReqVinDE = tdsReqVinDE;
	}

	public String getCvdmEsnNumber() {
		return this.cvdmEsnNumber;
	}

	public void setCvdmEsnNumber(String cvdmEsnNumber) {
		this.cvdmEsnNumber = cvdmEsnNumber;
	}

	public String getCvdmEsnType() {
		return this.cvdmEsnType;
	}

	public void setCvdmEsnType(String cvdmEsnType) {
		this.cvdmEsnType = cvdmEsnType;
	}
	
	@Override
	public int hashCode() {
		return Objects.hashCode(this.cvdmTdsReqEsnId);
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		final CvddmTdsReqEsnDE other = (CvddmTdsReqEsnDE) obj;
		return Objects.equal(this.cvdmTdsReqEsnId, other.cvdmTdsReqEsnId);
	}

}