package com.ford.cvddm.domain.master.de;

import java.io.Serializable;
import javax.persistence.*;

import com.google.common.base.Objects;

/**
 * The persistent class for the PCVDM01_SCREEN_INFO database table.
 * 
 */
@Entity
@Table(name = "PCVDM01_SCREEN_INFO")
@AttributeOverrides({ @AttributeOverride(name = "createUser", column = @Column(name = "CVDM01_CREATE_USER_C")),
		@AttributeOverride(name = "createTime", column = @Column(name = "CVDM01_CREATE_S")),
		@AttributeOverride(name = "updateUser", column = @Column(name = "CVDM01_LAST_UPDT_USER_C")),
		@AttributeOverride(name = "updateTime", column = @Column(name = "CVDM01_LAST_UPDT_S")) })
@NamedQueries({
		@NamedQuery(name = "CvddmScreenInfoDE.findAll", query = "SELECT c FROM CvddmScreenInfoDE c", hints = @QueryHint(name = "javax.persistence.cache.retrieveMode", value = "BYPASS")),
		@NamedQuery(name = "CvddmScreenInfoDE.getSelectedPageId", query = "select n.cvddmScreenId from CvddmScreenInfoDE n WHERE n.cvdmScreenName =?1 ", hints = @QueryHint(name = "javax.persistence.cache.retrieveMode", value = "BYPASS")) })
public class CvddmScreenInfoDE extends com.ford.cvddm.base.CVDDMBaseAuditDE implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "CVDM01_SCREEN_D", insertable = false)
	private int cvddmScreenId;

	@Column(name = "CVDM01_SCREEN_N")
	private String cvdmScreenName;

	@Column(name = "CVDM01_SCREEN_U", updatable = false)
	private String cvdmScreenURL;

	public int getCvddmScreenId() {
		return this.cvddmScreenId;
	}

	public void setCvddmScreenId(int cvddmScreenId) {
		this.cvddmScreenId = cvddmScreenId;
	}

	public String getCvdmScreenName() {
		return this.cvdmScreenName;
	}

	public void setCvdmScreenName(String cvdmScreenName) {
		this.cvdmScreenName = cvdmScreenName;
	}

	public String getCvdmScreenURL() {
		return this.cvdmScreenURL;
	}

	public void setCvdmScreenURL(String cvdmScreenURL) {
		this.cvdmScreenURL = cvdmScreenURL;
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(this.cvddmScreenId);
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		final CvddmScreenInfoDE other = (CvddmScreenInfoDE) obj;
		return Objects.equal(this.cvddmScreenId, other.cvddmScreenId);
	}

	@Override
	public String toString() {
		return "CvddmScreenInfoDE [cvddmScreenId=" + cvddmScreenId + ", cvdmScreenName=" + cvdmScreenName
				+ ", cvdmScreenURL=" + cvdmScreenURL + "]";
	}

}