package com.ford.cvddm.entitymanager;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.ford.cvddm.base.CvddmBaseEntityManager;
import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.domain.application.de.CvddmPartMatrixReferenceCSVUploadDE;
import com.ford.it.jpa.helper.FJpaEntityManagerFactoryCacheHelper;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;

/**
 * @Description: This Class contains all DAO specific methods related to Part
 *               Matrix Functionality.
 * @author MJEYARAJ
 *
 */
@ApplicationScoped
public class PartMatrixEntityManager extends CvddmBaseEntityManager {

	private static final String CLASS_NAME = PartMatrixEntityManager.class.getName();
	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	private EntityManager entityManager = null;

	/**
	 * Method Name: fetchAllRecords
	 * 
	 * @Description:This method would fetch all application Records from
	 *                   PCVDM21_PART_MATRIX database table.
	 * 
	 * @param none
	 * @return List<CvddmApplicationDE>
	 */
	@SuppressWarnings("unchecked")
	public List<CvddmPartMatrixReferenceCSVUploadDE> fetchAllRecords() {

		final String METHOD_NAME = "fetchAllRecords";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<CvddmPartMatrixReferenceCSVUploadDE> cvddmPartMatrixList = null;

		try {

			entityManager = createEntityManager();

			Query query = entityManager.createNamedQuery("CvddmPartMatrixReferenceCSVUploadDE.fetchAll");

			cvddmPartMatrixList = query.getResultList();
		}

		catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return cvddmPartMatrixList;
	}

}