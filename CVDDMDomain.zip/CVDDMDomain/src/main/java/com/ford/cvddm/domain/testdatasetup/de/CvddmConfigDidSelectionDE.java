package com.ford.cvddm.domain.testdatasetup.de;

import java.io.Serializable;
import javax.persistence.*;

import com.google.common.base.Objects;

/**
 * The persistent class for the PCVDM24_TDS_REQ_CFG_DID database table.
 * 
 */
@Entity
@Table(name = "PCVDM24_TDS_REQ_CFG_DID")
@AttributeOverrides({ @AttributeOverride(name = "createUser", column = @Column(name = "CVDM24_CREATE_USER_C")),
		@AttributeOverride(name = "createTime", column = @Column(name = "CVDM24_CREATE_S")),
		@AttributeOverride(name = "updateUser", column = @Column(name = "CVDM24_LAST_UPDT_USER_C")),
		@AttributeOverride(name = "updateTime", column = @Column(name = "CVDM24_LAST_UPDT_S")) })
@NamedQuery(name = "CvddmConfigDidSelectionDE.findAll", query = "SELECT c FROM CvddmConfigDidSelectionDE c")
public class CvddmConfigDidSelectionDE extends com.ford.cvddm.base.CVDDMBaseAuditDE implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "CVDM24_TDS_REQ_CFG_DID_K", unique = true, nullable = false)
	private long cvdmTdsReqConfigDidId;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "CVDM16_TDS_REQ_MOD_K", referencedColumnName = "CVDM16_TDS_REQ_MOD_K")
	private CvddmTdsReqModDE cvddmTdsReqModDE;
	@Column(name = "CVDM24_CFG_DID_N", nullable = false)
	private String cvdmConfigDidName;

	@Column(name = "CVDM24_CFG_VALUE_X", nullable = false)
	private String cvdmConfigDidValue;

	@Column(name = "CVDM24_CFG_DID_D", nullable = false, length = 8)
	private String cvdmConfigDidId;

	public long getCvdmTdsReqConfigDidId() {
		return cvdmTdsReqConfigDidId;
	}

	public void setCvdmTdsReqConfigDidId(long cvdmTdsReqConfigDidId) {
		this.cvdmTdsReqConfigDidId = cvdmTdsReqConfigDidId;
	}

	public CvddmTdsReqModDE getCvddmTdsReqModDE() {
		return cvddmTdsReqModDE;
	}

	public void setCvddmTdsReqModDE(CvddmTdsReqModDE cvddmTdsReqModDE) {
		this.cvddmTdsReqModDE = cvddmTdsReqModDE;
	}

	public String getCvdmConfigDidId() {
		return cvdmConfigDidId;
	}

	public void setCvdmConfigDidId(String cvdmConfigDidId) {
		this.cvdmConfigDidId = cvdmConfigDidId;
	}

	public String getCvdmConfigDidName() {
		return cvdmConfigDidName;
	}

	public void setCvdmConfigDidName(String cvdmConfigDidName) {
		this.cvdmConfigDidName = cvdmConfigDidName;
	}

	public String getCvdmConfigDidValue() {
		return cvdmConfigDidValue;
	}

	public void setCvdmConfigDidValue(String cvdmConfigDidValue) {
		this.cvdmConfigDidValue = cvdmConfigDidValue;
	}
	
	@Override
	public int hashCode() {
		return Objects.hashCode(this.cvdmTdsReqConfigDidId);
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		final CvddmConfigDidSelectionDE other = (CvddmConfigDidSelectionDE) obj;
		return Objects.equal(this.cvdmTdsReqConfigDidId, other.cvdmTdsReqConfigDidId);
	}

	

}