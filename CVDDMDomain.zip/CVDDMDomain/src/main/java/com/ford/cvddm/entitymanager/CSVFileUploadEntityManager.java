package com.ford.cvddm.entitymanager;

import java.util.Iterator;
import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.persistence.EntityManager;
import javax.persistence.FlushModeType;
import javax.persistence.Query;

import org.apache.deltaspike.jpa.api.transaction.Transactional;

import com.ford.cvddm.base.CvddmBaseEntityManager;
import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.domain.application.de.CvddmESNCSVUploadDE;
import com.ford.cvddm.domain.application.de.CvddmPartMatrixReferenceCSVUploadDE;
import com.ford.cvddm.domain.application.de.CvddmVinRepoCSVUploadDE;
import com.ford.it.jpa.helper.FJpaEntityManagerFactoryCacheHelper;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;

/**
 * @Description: This Class contains all DAO specific methods related to CSV
 *               file upload Functionality.
 * @author RPADI
 *
 */
@ApplicationScoped
public class CSVFileUploadEntityManager extends CvddmBaseEntityManager {

	private static final String CLASS_NAME = CSVFileUploadEntityManager.class.getName();
	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	private EntityManager entityManager = null;

	/**
	 * Method Name: saveCvddmCSVRcrds
	 *
	 * This method is used to create the vinrepo csv records into DB
	 * 
	 */
	@Transactional
	public boolean saveCvddmCSVRcrds(List<CvddmVinRepoCSVUploadDE> cvddmCSVUploadDE) {

		final String METHOD_NAME = "saveCvddmCSVRcrd";
		log.entering(CLASS_NAME, METHOD_NAME);

		try {
			entityManager = createEntityManager();
			entityManager.setFlushMode(FlushModeType.COMMIT);

			final int listSize = cvddmCSVUploadDE.size();
			entityManager.getTransaction().begin();
			for (int i = 0; i < listSize; i++) {

				final CvddmVinRepoCSVUploadDE object = cvddmCSVUploadDE.get(i);
				entityManager.persist(object);
				if (i % 1000 == 0 && i > 0) {
					entityManager.flush();
					entityManager.clear();

				}

			}
			entityManager.getTransaction().commit();

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			return false;
		} finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}
		return true;
	}

	/**
	 * Method Name: saveESNCSVRcrds
	 *
	 * This method is used to create the esnrepo csv records into DB
	 * 
	 */

	public boolean saveESNCSVRcrds(List<CvddmESNCSVUploadDE> eSNCSVUploadDE) {

		final String METHOD_NAME = "saveESNCSVRcrds";
		log.entering(CLASS_NAME, METHOD_NAME);

		try {
			entityManager = createEntityManager();
			entityManager.setFlushMode(FlushModeType.COMMIT);

			final int listSize = eSNCSVUploadDE.size();
			entityManager.getTransaction().begin();
			for (int i = 0; i < listSize; i++) {

				final CvddmESNCSVUploadDE object = eSNCSVUploadDE.get(i);
				entityManager.persist(object);
				if (i % 1000 == 0 && i > 0) {
					entityManager.flush();
					entityManager.clear();

				}

			}
			entityManager.getTransaction().commit();

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			return false;
		} finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}
		return true;
	}

	/**
	 * Method Name: savePartMatrxCSVRcrds
	 *
	 * This method is used to create the savePartMatrxCSVRcrds csv records into DB
	 * 
	 */
	public boolean savePartMatrxCSVRcrds(List<CvddmPartMatrixReferenceCSVUploadDE> partMatrixReferenceCSVUploadDE) {

		final String METHOD_NAME = "savePartMatrxCSVRcrds";
		log.entering(CLASS_NAME, METHOD_NAME);

		try {
			entityManager = createEntityManager();
			entityManager.setFlushMode(FlushModeType.COMMIT);

			final int listSize = partMatrixReferenceCSVUploadDE.size();
			entityManager.getTransaction().begin();
			for (int i = 0; i < listSize; i++) {

				final CvddmPartMatrixReferenceCSVUploadDE object = partMatrixReferenceCSVUploadDE.get(i);
				entityManager.persist(object);
				if (i % 1000 == 0 && i > 0) {
					entityManager.flush();
					entityManager.clear();

				}

			}
			entityManager.getTransaction().commit();

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			return false;
		} finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}
		return true;
	}

	/*** Start Change :User Story: US1064801**/

	/**
	 * Method Name: getMockVinDtlsfrmRepo
	 * 
	 * @Description:This method would fetch MockUpVIN from PCVDM19_VIN_REPO table depending on passed
	 * parameters.
	 * @param String progCode,String modelYear,String vehicleName,String noofVins
	 * @return List<CvddmVinRepoCSVUploadDE> 
	 */
	@SuppressWarnings("unchecked")
	public List<CvddmVinRepoCSVUploadDE>  getMockVinDtlsfrmRepo(String progCode,String modelYear,String vehicleName,String noofVins) {

		final String METHOD_NAME = "getMockVinDtlsfrmRepo";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<CvddmVinRepoCSVUploadDE> repoVINDEs = null;

		try {

			entityManager = createEntityManager();
			
			Query query = entityManager.createNamedQuery("CvddmVinRepoCSVUploadDE.getMockVinDtlsfrmRepo");
			query.setParameter(1, progCode);
			query.setParameter(2, modelYear);
			query.setParameter(3, vehicleName);
			query.setParameter(4, CVDDMConstant.STATUS_NEW);
			
			Integer limit = Integer.valueOf(noofVins);

			repoVINDEs = query.setMaxResults(limit).getResultList();
		}

		catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return repoVINDEs;
	}
	
	/**
	 * Method Name: getProdVehicleDetails
	 * 
	 * @Description:This method would get details of Program Code,Model year and Vehicle name PCVDM19_VIN_REPO table
	 * @param none
	 * @return List<CvddmVinRepoCSVUploadDE> 
	 */
	@SuppressWarnings("unchecked")
	public List<CvddmVinRepoCSVUploadDE>  getProdVehicleDetails() {

		final String METHOD_NAME = "getProdVehicleDetails";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<CvddmVinRepoCSVUploadDE> repoVINDEs = null;

		try {

			entityManager = createEntityManager();
			
			Query query = entityManager.createNamedQuery("CvddmVinRepoCSVUploadDE.getAvailableDtls");
			query.setParameter(1, CVDDMConstant.STATUS_NEW);

			repoVINDEs = query.getResultList();
		}

		catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return repoVINDEs;
	}
	
	/**
	 * Method Name: updateVINRepoTable
	 * 
	 * @Description:This method would update PCVDM19_VIN_REPO table for particular Request
	 * @param List<CvddmVinRepoCSVUploadDE>
	 * @return boolean
	 */
	public boolean updateVINRepoTable(List<CvddmVinRepoCSVUploadDE> mockupVinDetails) {

		final String METHOD_NAME = "updateVINRepoTable";
		log.entering(CLASS_NAME, METHOD_NAME);

		boolean isUpdateSucces = true;


		try {

			entityManager = createEntityManager();

			Iterator <CvddmVinRepoCSVUploadDE> vinRepoItr = mockupVinDetails.iterator();

			while(vinRepoItr.hasNext()) {

				CvddmVinRepoCSVUploadDE  tempObj = vinRepoItr.next();

				entityManager.getTransaction().begin();
				entityManager.merge(tempObj);
				entityManager.getTransaction().commit();

			}
		}

		catch (Exception e) {
			isUpdateSucces = false;
			entityManager.getTransaction().rollback();
			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return isUpdateSucces;
	}


	/*** End Change :User Story: US1064801**/
	/*** Start Change :User Story: US1147659**/
	
	/**
	 * Method Name: getAvailableESNRecords
	 * 
	 * @Description:This method would get available ESN's from PCVDM20_ESN_REPO table
	 * @param String noofESNs
	 * @return List<CvddmESNCSVUploadDE> 
	 * 
	 */
	
	@SuppressWarnings("unchecked")
	public List<CvddmESNCSVUploadDE> getAvailableESNRecords(String noofESNs) {

		final String METHOD_NAME = "getAvailableESNRecords";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<CvddmESNCSVUploadDE> esncsvUploadDEs = null;

		try {

			entityManager = createEntityManager();
			
			Query query = entityManager.createNamedQuery("CvddmESNCSVUploadDE.getAvailableESNRecords");
			query.setParameter(1, CVDDMConstant.STATUS_NEW);
			
			Integer limit = Integer.valueOf(noofESNs);

			esncsvUploadDEs = query.setMaxResults(limit).getResultList();
		}

		catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return esncsvUploadDEs;
	}
	
	/**
	 * Method Name: updateESNRepoTable
	 * 
	 * @Description:This method would update PCVDM20_ESN_REPO table for particular Request
	 * @param List<CvddmESNCSVUploadDE>
	 * @return boolean
	 */
	public boolean updateESNRepoTable(List<CvddmESNCSVUploadDE> mockupESNDetails) {

		final String METHOD_NAME = "updateVINRepoTable";
		log.entering(CLASS_NAME, METHOD_NAME);

		boolean isUpdateSucces = true;


		try {

			entityManager = createEntityManager();

			Iterator <CvddmESNCSVUploadDE> esnRepoItr = mockupESNDetails.iterator();

			while(esnRepoItr.hasNext()) {

				CvddmESNCSVUploadDE  tempObj = esnRepoItr.next();

				entityManager.getTransaction().begin();
				entityManager.merge(tempObj);
				entityManager.getTransaction().commit();

			}
		}

		catch (Exception e) {
			isUpdateSucces = false;
			entityManager.getTransaction().rollback();
			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return isUpdateSucces;
	}

	
	/*** End Change :User Story: US1147659**/
}