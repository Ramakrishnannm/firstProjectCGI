package com.ford.cvddm.domain.master.de;

import java.io.Serializable;
import javax.persistence.*;

import com.google.common.base.Objects;


/**
 * The persistent class for the PCVDM04_MAINT_TYPE database table.
 * 
 */
@Entity
@Table(name="PCVDM04_MAINT_TYPE")
@AttributeOverrides({ @AttributeOverride(name = "createUser", column = @Column(name = "CVDM04_CREATE_USER_C")),
	@AttributeOverride(name = "createTime", column = @Column(name = "CVDM04_CREATE_S")),
	@AttributeOverride(name = "updateUser", column = @Column(name = "CVDM04_LAST_UPDT_USER_C")),
	@AttributeOverride(name = "updateTime", column = @Column(name = "CVDM04_LAST_UPDT_S")) })

@NamedQueries({
    @NamedQuery(name="CvddmMaintTypeDE.findAll", query="SELECT c FROM CvddmMaintTypeDE c"),
    @NamedQuery(name = "CvddmMaintTypeDE.getActiveRecords",
        query = "select n from CvddmMaintTypeDE n WHERE n.cvdmActiveFlag=?1 ", hints = @QueryHint(
        		name = "javax.persistence.cache.retrieveMode",
                value = "BYPASS"))})


public class CvddmMaintTypeDE extends com.ford.cvddm.base.CVDDMBaseAuditDE implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY) 
	@Column(name="CVDM04_MAINT_TYPE_C", unique=true, nullable=false, length=5)
	private int cvdmMaintTypeCd;

	@Column(name="CVDM04_ACTIVE_F", nullable=false, length=1)
	private String cvdmActiveFlag;

	@Column(name="CVDM04_MAINT_TYPE_N", nullable=false, length=40)
	private String cvdmMaintTypeDesc;



	public int getCvdmMaintTypeCd() {
		return this.cvdmMaintTypeCd;
	}

	public void setCvdmMaintTypeCd(int cvdmMaintTypeCd) {
		this.cvdmMaintTypeCd = cvdmMaintTypeCd;
	}

	public String getCvdmActiveFlag() {
		return this.cvdmActiveFlag;
	}

	public void setCvdmActiveFlag(String cvdmActiveFlag) {
		this.cvdmActiveFlag = cvdmActiveFlag;
	}

	public String getCvdmMaintTypeDesc() {
		return this.cvdmMaintTypeDesc;
	}

	public void setCvdmMaintTypeDesc(String cvdmMaintTypeDesc) {
		this.cvdmMaintTypeDesc = cvdmMaintTypeDesc;
	}
	
	@Override
	public int hashCode() {
		return Objects.hashCode(this.cvdmMaintTypeCd);
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		final CvddmMaintTypeDE other = (CvddmMaintTypeDE)obj;
		return Objects.equal(this.cvdmMaintTypeCd, other.cvdmMaintTypeCd);
	}

}