package com.ford.cvddm.domain.maintenance.de;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.*;

import com.ford.cvddm.base.CVDDMBaseAuditDE;
import com.ford.cvddm.domain.master.de.CvddmMaintTypeDE;
import com.ford.cvddm.domain.master.de.CvddmScreenInfoDE;
import com.google.common.base.Objects;

import java.util.Date;

/**
 * The persistent class for the PCVDM05_MAINT_REQ database table.
 * 
 */
@Entity
@Table(name = "PCVDM05_MAINT_REQ")
@AttributeOverrides({ @AttributeOverride(name = "createUser", column = @Column(name = "CVDM05_CREATE_USER_C")),
		@AttributeOverride(name = "createTime", column = @Column(name = "CVDM05_CREATE_S")),
		@AttributeOverride(name = "updateUser", column = @Column(name = "CVDM05_LAST_UPDT_USER_C")),
		@AttributeOverride(name = "updateTime", column = @Column(name = "CVDM05_LAST_UPDT_S")) })

@NamedQueries({
		@NamedQuery(name = "CvddmMaintRcrdDE.fetchAll", query = "select n from CvddmMaintRcrdDE n", hints = @QueryHint(name = "javax.persistence.cache.retrieveMode", value = "BYPASS")),
		@NamedQuery(name = "CvddmMaintRcrdDE.getDownTimeRecord", query = "select d from CvddmMaintRcrdDE d WHERE d.cvdmMaintToDt >=?1 and d.cvdmMaintFromDt <=?2 "
				+ " and d.cvddmScreenInfoDE.cvddmScreenId =?3" + " and d.cvddmMaintTypeDE.cvdmMaintTypeCd =?4"
				+ " and d.cvdmActiveFlag =?5"
				+ " order by d.cvdmMaintFromDt desc ", hints = @QueryHint(name = "javax.persistence.cache.retrieveMode", value = "BYPASS")),
		@NamedQuery(name = "CvddmMaintRcrdDE.getAlertRecord", query = "select d from CvddmMaintRcrdDE d WHERE d.cvdmMaintToDt >=?1 and d.cvdmMaintFromDt <=?2 "
				+ " and d.cvddmScreenInfoDE.cvddmScreenId =?3" + " and d.cvddmMaintTypeDE.cvdmMaintTypeCd =?4"
				+ " and d.cvdmActiveFlag =?5"
				+ " order by d.cvdmMaintFromDt desc ", hints = @QueryHint(name = "javax.persistence.cache.retrieveMode", value = "BYPASS")),
		@NamedQuery(name = "CvddmMaintRcrdDE.getBannerRecord", query = "select d from CvddmMaintRcrdDE d WHERE d.cvdmMaintToDt >=?1 and d.cvdmMaintFromDt <=?2 "
				+ " and d.cvddmScreenInfoDE.cvddmScreenId =?3" + " and d.cvddmMaintTypeDE.cvdmMaintTypeCd =?4"
				+ " and d.cvdmActiveFlag =?5"
				+ " order by d.cvdmMaintFromDt desc ", hints = @QueryHint(name = "javax.persistence.cache.retrieveMode", value = "BYPASS")),
		@NamedQuery(name = "CvddmMaintRcrdDE.fetchRcrdforUpdate", query = "select d from CvddmMaintRcrdDE d WHERE d.cvdmMaintRcrdId =?1 and d.cvdmMaintToDt >=?2  ", hints = @QueryHint(name = "javax.persistence.cache.retrieveMode", value = "BYPASS")),
		@NamedQuery(name = "CvddmMaintRcrdDE.getActiveRecords", query = "select n from CvddmMaintRcrdDE n WHERE n.cvdmActiveFlag =?1 ", hints = @QueryHint(name = "javax.persistence.cache.retrieveMode", value = "BYPASS")) })

public class CvddmMaintRcrdDE extends CVDDMBaseAuditDE implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "CVDM05_MAINT_REQ_K", unique = true, nullable = false)
	private int cvdmMaintRcrdId;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "CVDM01_SCREEN_D", referencedColumnName = "CVDM01_SCREEN_D")
	private CvddmScreenInfoDE cvddmScreenInfoDE;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "CVDM04_MAINT_TYPE_C", referencedColumnName = "CVDM04_MAINT_TYPE_C")
	private CvddmMaintTypeDE cvddmMaintTypeDE;

	@Column(name = "CVDM05_EMAIL_NOTIFY_F", nullable = false, length = 1)
	private String cvdmEmailNotify;

	@Column(name = "CVDM05_MAINT_FROM_S", nullable = false)
	private Timestamp cvdmMaintFromDt;

	@Column(name = "CVDM05_MAINT_TITLE_X", nullable = false, length = 100)
	private String cvdmMaintTitle;

	@Column(name = "CVDM05_MAINT_TO_S", nullable = false)
	private Timestamp cvdmMaintToDt;

	@Column(name = "CVDM05_MAINT_X", nullable = false, length = 1000)
	private String cvdmMaintDesc;

	@Column(name = "CVDM05_ACTIVE_F", nullable = false, length = 1)
	private String cvdmActiveFlag;

	@Column(name = "CVDM05_REQ_USER_C", nullable = false)
	private String cvdmMaintCreatedUser;

	@Column(name = "CVDM05_REQ_S", nullable = false)
	private Timestamp cvdmMaintCreatedTime;

	public String getCvdmMaintCreatedUser() {
		return cvdmMaintCreatedUser;
	}

	public void setCvdmMaintCreatedUser(String cvdmMaintCreatedUser) {
		this.cvdmMaintCreatedUser = cvdmMaintCreatedUser;
	}

	public Timestamp getCvdmMaintCreatedTime() {
		return cvdmMaintCreatedTime;
	}

	public void setCvdmMaintCreatedTime(Timestamp cvdmMaintCreatedTime) {
		this.cvdmMaintCreatedTime = cvdmMaintCreatedTime;
	}

	public int getCvdmMaintRcrdId() {
		return this.cvdmMaintRcrdId;
	}

	public void setCvdmMaintRcrdId(int cvdmMaintRcrdId) {
		this.cvdmMaintRcrdId = cvdmMaintRcrdId;
	}

	public String getCvdmEmailNotify() {
		return this.cvdmEmailNotify;
	}

	public void setCvdmEmailNotify(String cvdmEmailNotify) {
		this.cvdmEmailNotify = cvdmEmailNotify;
	}

	public Date getCvdmMaintFromDt() {
		return this.cvdmMaintFromDt;
	}

	public void setCvdmMaintFromDt(Timestamp cvdmMaintFromDt) {
		this.cvdmMaintFromDt = cvdmMaintFromDt;
	}

	public String getCvdmMaintTitle() {
		return this.cvdmMaintTitle;
	}

	public void setCvdmMaintTitle(String cvdmMaintTitle) {
		this.cvdmMaintTitle = cvdmMaintTitle;
	}

	public Date getCvdmMaintToDt() {
		return this.cvdmMaintToDt;
	}

	public void setCvdmMaintToDt(Timestamp cvdmMaintToDt) {
		this.cvdmMaintToDt = cvdmMaintToDt;
	}

	public String getCvdmMaintDesc() {
		return this.cvdmMaintDesc;
	}

	public void setCvdmMaintDesc(String cvdmMaintDesc) {
		this.cvdmMaintDesc = cvdmMaintDesc;
	}

	public String getCvdmActiveFlag() {
		return cvdmActiveFlag;
	}

	public void setCvdmActiveFlag(String cvdmActiveFlag) {
		this.cvdmActiveFlag = cvdmActiveFlag;
	}

	public CvddmScreenInfoDE getCvddmScreenInfoDE() {
		return cvddmScreenInfoDE;
	}

	public void setCvddmScreenInfoDE(CvddmScreenInfoDE cvddmScreenInfoDE) {
		this.cvddmScreenInfoDE = cvddmScreenInfoDE;
	}

	public CvddmMaintTypeDE getCvddmMaintTypeDE() {
		return cvddmMaintTypeDE;
	}

	public void setCvddmMaintTypeDE(CvddmMaintTypeDE cvddmMaintTypeDE) {
		this.cvddmMaintTypeDE = cvddmMaintTypeDE;
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(this.cvdmMaintRcrdId);
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		final CvddmMaintRcrdDE other = (CvddmMaintRcrdDE) obj;
		return Objects.equal(this.cvdmMaintRcrdId, other.cvdmMaintRcrdId);
	}

}