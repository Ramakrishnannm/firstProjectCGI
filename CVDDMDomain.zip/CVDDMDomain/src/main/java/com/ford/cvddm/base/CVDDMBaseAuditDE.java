//****************************************************************
//* Copyright (c) 2014 Ford Motor Company. All Rights Reserved.
//****************************************************************
package com.ford.cvddm.base;

import javax.persistence.MappedSuperclass;

import org.eclipse.persistence.annotations.OptimisticLocking;
import org.eclipse.persistence.annotations.OptimisticLockingType;

import com.ford.it.jpa.base.FJpaBaseAuditDE;

/**
 * A project specific base class for entities requiring audit columns See
 * {@link FJpaBaseAuditDE}.
 *
 * @since v1.0
 */
@MappedSuperclass
@OptimisticLocking(type = OptimisticLockingType.VERSION_COLUMN, cascade = true)
public abstract class CVDDMBaseAuditDE extends FJpaBaseAuditDE {

	private static final long serialVersionUID = 1L;

}
