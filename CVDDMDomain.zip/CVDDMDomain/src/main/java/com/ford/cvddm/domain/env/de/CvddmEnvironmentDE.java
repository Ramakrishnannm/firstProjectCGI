package com.ford.cvddm.domain.env.de;

import java.io.Serializable;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.QueryHint;
import javax.persistence.Table;

import com.ford.cvddm.base.CVDDMBaseAuditDE;
import com.google.common.base.Objects;

/**
 * The persistent class for the PCVDM06_ENV database table.
 *
 */
@Entity
@Table(name = "PCVDM06_ENV")
@AttributeOverrides({ @AttributeOverride(name = "createUser", column = @Column(name = "CVDM06_CREATE_USER_C")),
		@AttributeOverride(name = "createTime", column = @Column(name = "CVDM06_CREATE_S")),
		@AttributeOverride(name = "updateUser", column = @Column(name = "CVDM06_LAST_UPDT_USER_C")),
		@AttributeOverride(name = "updateTime", column = @Column(name = "CVDM06_LAST_UPDT_S")) })

@NamedQueries({
		@NamedQuery(name = "CvddmEnvironmentDE.fetchAll", query = "select n from CvddmEnvironmentDE n", hints = @QueryHint(name = "javax.persistence.cache.retrieveMode", value = "BYPASS")),
		@NamedQuery(name = "CvddmEnvironmentDE.fetchEnvObject", query = "select n from CvddmEnvironmentDE n where n.envName = ?1", hints = @QueryHint(name = "javax.persistence.cache.retrieveMode", value = "BYPASS")) })

public class CvddmEnvironmentDE extends CVDDMBaseAuditDE implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "CVDM06_ENV_D", unique = true, nullable = false)
	private int envId;

	@Column(name = "CVDM06_ENV_N", nullable = false, length = 1)
	private String envName;

	@Column(name = "CVDM06_ENV_X", nullable = false)
	private String envDesc;

	public int getEnvId() {
		return envId;
	}

	public void setEnvId(int envId) {
		this.envId = envId;
	}

	public String getEnvName() {
		return envName;
	}

	public void setEnvName(String envName) {
		this.envName = envName;
	}

	public String getEnvDesc() {
		return envDesc;
	}

	public void setEnvDesc(String envDesc) {
		this.envDesc = envDesc;
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(this.envId);
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		final CvddmEnvironmentDE other = (CvddmEnvironmentDE) obj;
		return Objects.equal(this.envId, other.envId);
	}

}
