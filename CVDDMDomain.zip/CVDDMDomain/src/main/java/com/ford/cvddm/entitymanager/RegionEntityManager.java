/**
 * 
 */
package com.ford.cvddm.entitymanager;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.ford.cvddm.base.CvddmBaseEntityManager;
import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.domain.master.de.CvddmRegionDE;
import com.ford.it.jpa.helper.FJpaEntityManagerFactoryCacheHelper;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;

/**
 * @author NGUPTA18
 * @Description: This Class contains all DAO specific methods related to
 *               Regions
 *
 */
@ApplicationScoped
public class RegionEntityManager extends CvddmBaseEntityManager {
	
	private static final String CLASS_NAME = RegionEntityManager.class.getName();
	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	private EntityManager entityManager = null;
	
	
	/**
	 * Method Name: getActiveProductGroups
	 * 
	 * @Description:This method would fetch all  Active Regions from 
	 *                   PCVDM17_REGION database table.
	 * @param none
	 * @return List<CvddmRegionsDE>
	 */
	@SuppressWarnings("unchecked")
	public List<CvddmRegionDE> getActiveRegions() {

		final String METHOD_NAME = "getActiveRegions";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<CvddmRegionDE> cvddmRegionsDEs = null;

		try {

			entityManager = createEntityManager();

			Query query = entityManager.createNamedQuery("CvddmRegionDE.getActiveRecords");

			query.setParameter(1, CVDDMConstant.STRING_Y);


			cvddmRegionsDEs = query.getResultList();
		}

		catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return cvddmRegionsDEs;
	}
	/*** Start Change :User Story: US1147659 **/
	/**
	 * Method Name: fetchRegionById
	 * 
	 * @Description:This method would fetch Active Product Team from 
	 *                   PCVDM17_REGION database table depending on
	 *                   the PK passed.
	 * @param String regionId
	 * @return CvddmRegionDE
	 */
	public CvddmRegionDE fetchRegionById(String regionId) {

		final String METHOD_NAME = "fetchRegionById";
		log.entering(CLASS_NAME, METHOD_NAME);

		CvddmRegionDE regionDE = null;

		try {

			entityManager = createEntityManager();

			Query query = entityManager.createNamedQuery("CvddmRegionDE.getRegionById");
			
			Long uniqueId = Long.parseLong(regionId);

			query.setParameter(1, uniqueId);
			query.setParameter(2, CVDDMConstant.STRING_Y);

			regionDE = (CvddmRegionDE) query.getResultList();
		}

		catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return regionDE;
	}
	
	/*** End Change :User Story: US1147659 **/

}
