package com.ford.cvddm.connection;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.ford.it.properties.PropertyGroup;
import com.ford.it.properties.PropertyManager;

public class SingletonDBConnection {
	private static SingletonDBConnection singleInstance;
	private static DataSource dataSource;
	private static Connection dbConnect;

	private SingletonDBConnection() {
/*		DataSource dataSource = null;
		try {

			InitialContext initialContext = new InitialContext();

			dataSource = (DataSource) initialContext.lookup("jdbc/AImsDatasource");

			try {
				dbConnect = dataSource.getConnection("FDPRXVT", "vtdev207");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (NamingException e) {
			e.printStackTrace();
		}
*/	}

	public static SingletonDBConnection getInstance() {
		if (singleInstance == null) {
			synchronized (SingletonDBConnection.class) {
				if (singleInstance == null) {
					singleInstance = new SingletonDBConnection();
				}
			}
		}

		return singleInstance;
	}

	public static Connection getConnection() throws NamingException {
		try {
			InitialContext initialContext = new InitialContext();

	        final PropertyManager pm = PropertyManager.getInstance();

            PropertyGroup pGroup = pm.getGroup("AimsDatabaseCredentials");
	            
			dataSource = (DataSource) initialContext.lookup("jdbc/AimsDatasource");
			dbConnect = dataSource.getConnection(pGroup.getString("userId"), pGroup.getString("password"));
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		if (dbConnect == null) {
			try {
				Context initContext = new InitialContext();
				Context envContext = (Context) initContext.lookup("java:/comp/env");
				dataSource = (DataSource) envContext.lookup("jdbc/AimsDatasource");

				try {
					dbConnect = dataSource.getConnection();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} catch (NamingException e) {
				e.printStackTrace();
			}
		}

		return dbConnect;
	}
	
}