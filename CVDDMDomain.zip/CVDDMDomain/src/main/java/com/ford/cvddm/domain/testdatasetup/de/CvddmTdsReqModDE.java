package com.ford.cvddm.domain.testdatasetup.de;

import java.io.Serializable;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.ford.cvddm.domain.module.de.CvddmModuleDE;
import com.google.common.base.Objects;

/**
 * The persistent class for the PCVDM16_TDS_REQ_MOD database table.
 * 
 */
@Entity
@Table(name = "PCVDM16_TDS_REQ_MOD")
@AttributeOverrides({ @AttributeOverride(name = "createUser", column = @Column(name = "CVDM16_CREATE_USER_C")),
		@AttributeOverride(name = "createTime", column = @Column(name = "CVDM16_CREATE_S")),
		@AttributeOverride(name = "updateUser", column = @Column(name = "CVDM16_LAST_UPDT_USER_C")),
		@AttributeOverride(name = "updateTime", column = @Column(name = "CVDM16_LAST_UPDT_S")) })
@NamedQuery(name = "CvddmTdsReqModDE.findAll", query = "SELECT c FROM CvddmTdsReqModDE c")
public class CvddmTdsReqModDE extends com.ford.cvddm.base.CVDDMBaseAuditDE implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "CVDM16_TDS_REQ_MOD_K", unique = true, nullable = false)
	private long cvdmTdsReqModId;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "CVDM14_TDS_REQ_K", referencedColumnName = "CVDM14_TDS_REQ_K")
	private CvddmTestDataReqDE cvddmTestDataReqDE;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "CVDM15_MOD_K", referencedColumnName = "CVDM15_MOD_K")
	private CvddmModuleDE cvddmModuleDE;

	public long getCvdmTdsReqModId() {
		return cvdmTdsReqModId;
	}

	public void setCvdmTdsReqModId(long cvdmTdsReqModId) {
		this.cvdmTdsReqModId = cvdmTdsReqModId;
	}

	public CvddmTestDataReqDE getCvddmTestDataReqDE() {
		return cvddmTestDataReqDE;
	}

	public void setCvddmTestDataReqDE(CvddmTestDataReqDE cvddmTestDataReqDE) {
		this.cvddmTestDataReqDE = cvddmTestDataReqDE;
	}

	public CvddmModuleDE getCvddmModuleDE() {
		return cvddmModuleDE;
	}

	public void setCvddmModuleDE(CvddmModuleDE cvddmModuleDE) {
		this.cvddmModuleDE = cvddmModuleDE;
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(this.cvdmTdsReqModId);
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		final CvddmTdsReqModDE other = (CvddmTdsReqModDE) obj;
		return Objects.equal(this.cvdmTdsReqModId, other.cvdmTdsReqModId);
	}

}