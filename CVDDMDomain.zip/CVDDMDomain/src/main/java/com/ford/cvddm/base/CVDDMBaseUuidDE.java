//****************************************************************
//* Copyright (c) 2014 Ford Motor Company. All Rights Reserved.
//****************************************************************
package com.ford.cvddm.base;

import javax.persistence.MappedSuperclass;

import com.ford.it.jpa.base.FJpaBaseUuidDE;

/**
 *
 * A project specific base class for entities requiring audit columns and UUID as their
 * identity column value
 * See {@link FJpaBaseUuidDE}.
 *
 * @param <E>
 *
 * @since v1.0
 */
@MappedSuperclass
public abstract class CVDDMBaseUuidDE<E extends CVDDMBaseUuidDE<E>> extends FJpaBaseUuidDE {

    private static final long serialVersionUID = 1L;

}