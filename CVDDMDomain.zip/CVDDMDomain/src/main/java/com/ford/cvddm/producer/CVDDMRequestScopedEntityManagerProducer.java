package com.ford.cvddm.producer;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.inject.Default;
import javax.enterprise.inject.Disposes;
import javax.enterprise.inject.Produces;
import javax.persistence.EntityManager;

import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.it.jpa.helper.FJpaEntityManagerFactoryCacheHelper;

/**
 * The standard Ford entity manager producer. This provider distributes a request scoped
 * JPA entity manager which will work with other Ford JPA framework components such as
 * repositories.
 *
 */
@ApplicationScoped
public class CVDDMRequestScopedEntityManagerProducer {

    @Produces
    @RequestScoped
    @Default
    public EntityManager createEntityManager() {

        return FJpaEntityManagerFactoryCacheHelper
                .createEntityManager(
                CVDDMConstant.CVDDM_DEV_PERSISTENCE_UNIT);
    }

    public void closeDefaultEm(
        @Disposes final EntityManager em) {
        if (em != null)
            em.close();
    }
}