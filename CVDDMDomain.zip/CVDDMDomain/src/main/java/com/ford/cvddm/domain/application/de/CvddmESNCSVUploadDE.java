package com.ford.cvddm.domain.application.de;

import java.io.Serializable;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.QueryHint;
import javax.persistence.Table;

import com.ford.cvddm.base.CVDDMBaseAuditDE;
import com.google.common.base.Objects;

/**
 * The persistent class for the PCVDM20_ESN_REPO database table.
 * 
 */
@Entity
@Table(name = "PCVDM20_ESN_REPO")
@AttributeOverrides({ @AttributeOverride(name = "createUser", column = @Column(name = "CVDM20_CREATE_USER_C")),
		@AttributeOverride(name = "createTime", column = @Column(name = "CVDM20_CREATE_S")),
		@AttributeOverride(name = "updateUser", column = @Column(name = "CVDM20_LAST_UPDT_USER_C")),
		@AttributeOverride(name = "updateTime", column = @Column(name = "CVDM20_LAST_UPDT_S")) })
@NamedQueries({
    @NamedQuery(name="CvddmESNCSVUploadDE.findAll", query="SELECT c FROM CvddmESNCSVUploadDE c"),
    @NamedQuery(name="CvddmESNCSVUploadDE.getAvailableESNRecords", query="SELECT c FROM CvddmESNCSVUploadDE c where c.status=?1",
    hints = @QueryHint(name = "javax.persistence.cache.retrieveMode", value = "BYPASS"))})

public class CvddmESNCSVUploadDE extends CVDDMBaseAuditDE implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "CVDM20_ESN_K", unique = true, nullable = false)
	private Long cvddmEsnRcrdId;
	
	@Column(name = "CVDM20_ESN_R", nullable = false)
	private String eSN;
	@Column(name = "CVDM20_PS_KEY_X", nullable = false)
	private String pSKey;
	@Column(name = "CVDM20_MQTT_PWD_X", nullable = false)
	private String mqttPassword;
	@Column(name = "CVDM20_IMEI_R", nullable = false)
	private String iMEI;
	@Column(name = "CVDM20_ICCID_D", nullable = false)
	private String iCCID;
	@Column(name = "CVDM20_STATUS_C", nullable = false)
	private String status;

	public Long getCvddmEsnRcrdId() {
		return cvddmEsnRcrdId;
	}

	public void setCvddmEsnRcrdId(Long cvddmEsnRcrdId) {
		this.cvddmEsnRcrdId = cvddmEsnRcrdId;
	}

	public String geteSN() {
		return eSN;
	}

	public void seteSN(String eSN) {
		this.eSN = eSN;
	}

	public String getpSKey() {
		return pSKey;
	}

	public void setpSKey(String pSKey) {
		this.pSKey = pSKey;
	}

	public String getMqttPassword() {
		return mqttPassword;
	}

	public void setMqttPassword(String mqttPassword) {
		this.mqttPassword = mqttPassword;
	}

	public String getiMEI() {
		return iMEI;
	}

	public void setiMEI(String iMEI) {
		this.iMEI = iMEI;
	}

	public String getiCCID() {
		return iCCID;
	}

	public void setiCCID(String iCCID) {
		this.iCCID = iCCID;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	@Override
	public int hashCode() {
		return Objects.hashCode(this.cvddmEsnRcrdId);
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		final CvddmESNCSVUploadDE other = (CvddmESNCSVUploadDE) obj;
		return Objects.equal(this.cvddmEsnRcrdId, other.cvddmEsnRcrdId);
	}
}