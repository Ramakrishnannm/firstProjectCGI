package com.ford.cvddm.domain.testdatasetup.de;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.ford.cvddm.base.CVDDMBaseAuditDE;
import com.google.common.base.Objects;


/**
 * The persistent class for the PCVDM23_TDS_REQ_CMNT database table.
 * 
 */
@Entity
@Table(name="PCVDM23_TDS_REQ_CMNT")
@AttributeOverrides({ @AttributeOverride(name = "createUser", column = @Column(name = "CVDM23_CREATE_USER_C")),
	@AttributeOverride(name = "createTime", column = @Column(name = "CVDM23_CREATE_S")),
	@AttributeOverride(name = "updateUser", column = @Column(name = "CVDM23_LAST_UPDT_USER_C")),
	@AttributeOverride(name = "updateTime", column = @Column(name = "CVDM23_LAST_UPDT_S")) })
@NamedQuery(name="CvddmTdsReqCmntDE.findAll", query="SELECT c FROM CvddmTdsReqCmntDE c")

public class CvddmTdsReqCmntDE extends CVDDMBaseAuditDE implements Serializable {
	
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="CVDM23_TDS_REQ_CMNT_K")
	private long cvdmTdsReqCmntId;
	

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "CVDM14_TDS_REQ_K", referencedColumnName = "CVDM14_TDS_REQ_K")
	private CvddmTestDataReqDE cvddmTestDataReqDE;
	
	@Column(name="CVDM23_CMNT_USER_C", nullable=false, length=8)
	private String cvdmCmntUser;
	
	@Column(name="CVDM23_CMNT_X")
	private String cvdmCmntDesc;
	
	@Column(name = "CVDM23_CMNT_S", nullable = false)
	private Timestamp cvdmCmntCreationTime;
	
	public long getCvdmTdsReqCmntId() {
		return cvdmTdsReqCmntId;
	}

	public void setCvdmTdsReqCmntId(long cvdmTdsReqCmntId) {
		this.cvdmTdsReqCmntId = cvdmTdsReqCmntId;
	}

	public CvddmTestDataReqDE getCvddmTestDataReqDE() {
		return cvddmTestDataReqDE;
	}

	public void setCvddmTestDataReqDE(CvddmTestDataReqDE cvddmTestDataReqDE) {
		this.cvddmTestDataReqDE = cvddmTestDataReqDE;
	}

	public String getCvdmCmntUser() {
		return cvdmCmntUser;
	}

	public void setCvdmCmntUser(String cvdmCmntUser) {
		this.cvdmCmntUser = cvdmCmntUser;
	}

	public String getCvdmCmntDesc() {
		return cvdmCmntDesc;
	}

	public void setCvdmCmntDesc(String cvdmCmntDesc) {
		this.cvdmCmntDesc = cvdmCmntDesc;
	}

	public Timestamp getCvdmCmntCreationTime() {
		return cvdmCmntCreationTime;
	}

	public void setCvdmCmntCreationTime(Timestamp cvdmCmntCreationTime) {
		this.cvdmCmntCreationTime = cvdmCmntCreationTime;
	}
	
	@Override
	public int hashCode() {
		return Objects.hashCode(this.cvdmTdsReqCmntId);
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		final CvddmTdsReqCmntDE other = (CvddmTdsReqCmntDE) obj;
		return Objects.equal(this.cvdmTdsReqCmntId, other.cvdmTdsReqCmntId);
	}

}
