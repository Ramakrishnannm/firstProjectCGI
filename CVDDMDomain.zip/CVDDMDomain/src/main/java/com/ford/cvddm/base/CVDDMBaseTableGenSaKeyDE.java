package com.ford.cvddm.base;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.TableGenerator;

import com.ford.it.jpa.base.FJpaBaseAuditDE;
import com.google.common.base.Objects;

/**
 *
 * A project specific base class for entities requiring audit columns and Sakey as their
 * ID column
 * see {@link FJpaBaseAuditDE}
 *
 * @since v1.0
 */
@MappedSuperclass
public abstract class CVDDMBaseTableGenSaKeyDE extends FJpaBaseAuditDE {

    private static final long serialVersionUID = 1L;

    @Id
    @TableGenerator(name = "saKeyGenerator", table = "IFJPA76_SAKEY_GEN",
        pkColumnName = "TBLGEN",
        pkColumnValue = "TEST_SA_KEY_SEQ", initialValue = 10)
    @GeneratedValue(strategy = GenerationType.TABLE, generator = "saKeyGenerator")
    @Column(length = 36, insertable = true, updatable = false, name = "KEY_SAKEY",
        nullable = false)
    private Long saKey;

    public Long getSaKey() {
        return this.saKey;
    }

    public void setSaKey(final Long saKey) {
        this.saKey = saKey;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(this.saKey);
    }

    @Override
    public boolean equals(final Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;

        final CVDDMBaseTableGenSaKeyDE other = (CVDDMBaseTableGenSaKeyDE)obj;
        return Objects.equal(this.saKey, other.saKey);
    }
}
