package com.ford.cvddm.entitymanager;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.ford.cvddm.base.CvddmBaseEntityManager;
import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.domain.application.de.CvddmApplicationDE;
import com.ford.it.jpa.helper.FJpaEntityManagerFactoryCacheHelper;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;

/**
 * @Description: This Class contains all DAO specific methods related to
 *               Application Functionality.
 * @author MJEYARAJ
 *
 */
@ApplicationScoped
public class ApplicationEntityManager extends CvddmBaseEntityManager {

	private static final String CLASS_NAME = ApplicationEntityManager.class.getName();
	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	private EntityManager entityManager = null;

	/**
	 * Method Name: fetchAllRecords
	 * 
	 * @Description:This method would fetch all application Records from PCVDM07_APP
	 *                   database table.
	 * 
	 * @param none
	 * @return List<CvddmApplicationDE>
	 */
	@SuppressWarnings("unchecked")
	public List<CvddmApplicationDE> fetchAllRecords() {

		final String METHOD_NAME = "fetchAllRecords";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<CvddmApplicationDE> cvddmAppRcrdList = null;

		try {

			entityManager = createEntityManager();

			Query query = entityManager.createNamedQuery("CvddmApplicationDE.fetchAll");

			cvddmAppRcrdList = query.getResultList();
		}

		catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
			FJpaEntityManagerFactoryCacheHelper.closeEntityManager(entityManager);
		}

		return cvddmAppRcrdList;
	}

}