package com.ford.cvddm.domain.testdatasetup.de;

import java.io.Serializable;
import javax.persistence.*;

import com.ford.cvddm.domain.env.de.CvddmEnvironmentDE;
import com.ford.cvddm.domain.master.de.CvddmProductTeamDE;
import com.ford.cvddm.domain.master.de.CvddmTestingTypeDE;
import com.google.common.base.Objects;
import java.sql.Timestamp;


/**
 * The persistent class for the PCVDM14_TDS_REQ database table.
 * 
 */
@Entity
@Table(name="PCVDM14_TDS_REQ")
@AttributeOverrides({ @AttributeOverride(name = "createUser", column = @Column(name = "CVDM14_CREATE_USER_C")),
	@AttributeOverride(name = "createTime", column = @Column(name = "CVDM14_CREATE_S")),
	@AttributeOverride(name = "updateUser", column = @Column(name = "CVDM14_LAST_UPDT_USER_C")),
	@AttributeOverride(name = "updateTime", column = @Column(name = "CVDM14_LAST_UPDT_S")) })
@NamedQuery(name="CvddmTestDataReqDE.findAll", query="SELECT c FROM CvddmTestDataReqDE c")

public class CvddmTestDataReqDE extends com.ford.cvddm.base.CVDDMBaseAuditDE implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="CVDM14_TDS_REQ_K")
	private int cvdmTdsReqId;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "CVDM06_ENV_D", referencedColumnName = "CVDM06_ENV_D")
	private CvddmEnvironmentDE cvddmEnvironmentDE;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "CVDM12_PRDCT_TEAM_K", referencedColumnName = "CVDM12_PRDCT_TEAM_K")
	private CvddmProductTeamDE cvddmProductTeamDE;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "CVDM13_TEST_TYPE_K", referencedColumnName = "CVDM13_TEST_TYPE_K")
	private CvddmTestingTypeDE cvddmTestingTypeDE;
	
	@Column(name="CVDM14_REQ_USER_C")
	private String requestUserCdsId;
	
	@Column(name="CVDM14_REQ_USER_N")
	private String requesterDisplayName;
	
	@Column(name="CVDM14_REQ_MGR_USER_C")
	private String requestManagerCdsId;
	
	@Column(name="CVDM14_REQ_S")
	private Timestamp requestDateTime;

	@Column(name="CVDM14_CODE_DROP_Y")
	private Timestamp cvdmCodeDropDate;
	
	@Column(name="CVDM14_TEST_DATA_REQRD_Y")
	private Timestamp cvdmTestDataRequiredOn;


	@Column(name="CVDM14_TEST_END_Y")
	private Timestamp cvdmTestingEndDate;


	@Column(name="CVDM14_TEST_START_Y")
	private Timestamp cvdmTestingStartDate;
	
	@Column(name="CVDM14_SUBJECT_X")
	private String cvdmSubject;


	@Column(name="CVDM14_EMAIL_X")
	private String cvdmEmailNotificationList;

	@Column(name="CVDM14_MDL_YR_R")
	private Long cvdmModelYear;

	@Column(name="CVDM14_PGM_C")
	private String cvdmPgmCode;

	@Column(name="CVDM14_PRIORITY_C")
	private String cvdmPriority;
	
	@Column(name="CVDM14_VEH_N")
	private String cvdmVehicleName;


	public int getCvdmTdsReqId() {
		return this.cvdmTdsReqId;
	}

	public void setCvdmTdsReqId(int cvdmTdsReqId) {
		this.cvdmTdsReqId = cvdmTdsReqId;
	}

	public Timestamp getCvdmCodeDropDate() {
		return this.cvdmCodeDropDate;
	}

	public void setCvdmCodeDropDate(Timestamp cvdmCodeDropDate) {
		this.cvdmCodeDropDate = cvdmCodeDropDate;
	}

	public String getCvdmEmailNotificationList() {
		return this.cvdmEmailNotificationList;
	}

	public void setCvdmEmailNotificationList(String cvdmEmailNotificationList) {
		this.cvdmEmailNotificationList = cvdmEmailNotificationList;
	}

	public Long getCvdmModelYear() {
		return this.cvdmModelYear;
	}

	public void setCvdmModelYear(Long cvdmModelYear) {
		this.cvdmModelYear = cvdmModelYear;
	}

	public String getCvdmPgmCode() {
		return this.cvdmPgmCode;
	}

	public void setCvdmPgmCode(String cvdmPgmCode) {
		this.cvdmPgmCode = cvdmPgmCode;
	}

	public String getCvdmPriority() {
		return this.cvdmPriority;
	}

	public void setCvdmPriority(String cvdmPriority) {
		this.cvdmPriority = cvdmPriority;
	}


	public String getCvdmSubject() {
		return this.cvdmSubject;
	}

	public void setCvdmSubject(String cvdmSubject) {
		this.cvdmSubject = cvdmSubject;
	}

	public Timestamp getCvdmTestDataRequiredOn() {
		return this.cvdmTestDataRequiredOn;
	}

	public void setCvdmTestDataRequiredOn(Timestamp cvdmTestDataRequiredOn) {
		this.cvdmTestDataRequiredOn = cvdmTestDataRequiredOn;
	}

	public Timestamp getCvdmTestingEndDate() {
		return this.cvdmTestingEndDate;
	}

	public void setCvdmTestingEndDate(Timestamp cvdmTestingEndDate) {
		this.cvdmTestingEndDate = cvdmTestingEndDate;
	}

	public Timestamp getCvdmTestingStartDate() {
		return this.cvdmTestingStartDate;
	}

	public void setCvdmTestingStartDate(Timestamp cvdmTestingStartDate) {
		this.cvdmTestingStartDate = cvdmTestingStartDate;
	}
	
	public CvddmEnvironmentDE getCvddmEnvironmentDE() {
		return cvddmEnvironmentDE;
	}

	public void setCvddmEnvironmentDE(CvddmEnvironmentDE cvddmEnvironmentDE) {
		this.cvddmEnvironmentDE = cvddmEnvironmentDE;
	}

	public CvddmProductTeamDE getCvddmProductTeamDE() {
		return cvddmProductTeamDE;
	}

	public void setCvddmProductTeamDE(CvddmProductTeamDE cvddmProductTeamDE) {
		this.cvddmProductTeamDE = cvddmProductTeamDE;
	}

	public CvddmTestingTypeDE getCvddmTestingTypeDE() {
		return cvddmTestingTypeDE;
	}

	public void setCvddmTestingTypeDE(CvddmTestingTypeDE cvddmTestingTypeDE) {
		this.cvddmTestingTypeDE = cvddmTestingTypeDE;
	}
	
	public String getRequestUserCdsId() {
		return requestUserCdsId;
	}

	public void setRequestUserCdsId(String requestUserCdsId) {
		this.requestUserCdsId = requestUserCdsId;
	}

	public String getRequesterDisplayName() {
		return requesterDisplayName;
	}

	public void setRequesterDisplayName(String requesterDisplayName) {
		this.requesterDisplayName = requesterDisplayName;
	}

	public String getRequestManagerCdsId() {
		return requestManagerCdsId;
	}

	public void setRequestManagerCdsId(String requestManagerCdsId) {
		this.requestManagerCdsId = requestManagerCdsId;
	}

	public Timestamp getRequestDateTime() {
		return requestDateTime;
	}

	public void setRequestDateTime(Timestamp requestDateTime) {
		this.requestDateTime = requestDateTime;
	}

	public String getCvdmVehicleName() {
		return cvdmVehicleName;
	}

	public void setCvdmVehicleName(String cvdmVehicleName) {
		this.cvdmVehicleName = cvdmVehicleName;
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(this.cvdmTdsReqId);
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		final CvddmTestDataReqDE other = (CvddmTestDataReqDE) obj;
		return Objects.equal(this.cvdmTdsReqId, other.cvdmTdsReqId);
	}
}