package com.ford.cvddm.de;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.QueryHint;
import javax.persistence.Table;

import com.ford.cvddm.base.CVDDMBaseAuditDE;

@Entity
@Table(name = "CVDDM_REQUESTS_TEST")
@AttributeOverrides({ @AttributeOverride(name = "createUser", column = @Column(name = "CREATE_USER")),
		@AttributeOverride(name = "createTime", column = @Column(name = "CREATE_TIME")),
		@AttributeOverride(name = "updateUser", column = @Column(name = "UPDATE_USER")),
		@AttributeOverride(name = "updateTime", column = @Column(name = "UPDATE_TIME")) })
@NamedQueries({
		@NamedQuery(name = "queryAllRequests", query = "select cvddmReqs from CVDDMRequestsDE cvddmReqs", hints = {
				@QueryHint(name = "javax.persistence.cache.retrieveMode", value = "BYPASS"),
				@QueryHint(name = "eclipselink.refresh", value = "TRUE") }) })
public class CVDDMRequestsDE extends CVDDMBaseAuditDE {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue()
	@Column(name = "REQUEST_ID")
	private String requestId;

	@Column(name = "PROGRAM_CODE")
	private String programCode;

	@Column(name = "MODEL_YEAR")
	private long modelYear;

	@Column(name = "ENVIROINMENT")
	private String enviroinment;

	@Column(name = "REQUESTED_BY")
	private String requestedBy;

	@Column(name = "STATUS")
	private String requestStatus;

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getProgramCode() {
		return programCode;
	}

	public void setProgramCode(String programCode) {
		this.programCode = programCode;
	}

	public long getModelYear() {
		return modelYear;
	}

	public void setModelYear(long modelYear) {
		this.modelYear = modelYear;
	}

	public String getEnviroinment() {
		return enviroinment;
	}

	public void setEnviroinment(String enviroinment) {
		this.enviroinment = enviroinment;
	}

	public String getRequestedBy() {
		return requestedBy;
	}

	public void setRequestedBy(String requestedBy) {
		this.requestedBy = requestedBy;
	}

	public String getRequestStatus() {
		return requestStatus;
	}

	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((enviroinment == null) ? 0 : enviroinment.hashCode());
		result = prime * result + (int) (modelYear ^ (modelYear >>> 32));
		result = prime * result + ((programCode == null) ? 0 : programCode.hashCode());
		result = prime * result + ((requestId == null) ? 0 : requestId.hashCode());
		result = prime * result + ((requestStatus == null) ? 0 : requestStatus.hashCode());
		result = prime * result + ((requestedBy == null) ? 0 : requestedBy.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CVDDMRequestsDE other = (CVDDMRequestsDE) obj;
		if (enviroinment == null) {
			if (other.enviroinment != null)
				return false;
		} else if (!enviroinment.equals(other.enviroinment))
			return false;
		if (modelYear != other.modelYear)
			return false;
		if (programCode == null) {
			if (other.programCode != null)
				return false;
		} else if (!programCode.equals(other.programCode))
			return false;
		if (requestId == null) {
			if (other.requestId != null)
				return false;
		} else if (!requestId.equals(other.requestId))
			return false;
		if (requestStatus == null) {
			if (other.requestStatus != null)
				return false;
		} else if (!requestStatus.equals(other.requestStatus))
			return false;
		if (requestedBy == null) {
			if (other.requestedBy != null)
				return false;
		} else if (!requestedBy.equals(other.requestedBy))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "CVDDMRequestsDE [requestId=" + requestId + ", programCode=" + programCode + ", modelYear=" + modelYear
				+ ", enviroinment=" + enviroinment + ", requestedBy=" + requestedBy + ", requestStatus=" + requestStatus
				+ "]";
	}

}