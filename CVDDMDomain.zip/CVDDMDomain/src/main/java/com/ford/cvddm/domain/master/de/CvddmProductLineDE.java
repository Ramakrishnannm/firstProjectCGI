package com.ford.cvddm.domain.master.de;

import java.io.Serializable;
import javax.persistence.*;

import com.google.common.base.Objects;



/**
 * The persistent class for the PCVDM11_PRDCT_LINE database table.
 * 
 */
@Entity
@Table(name="PCVDM11_PRDCT_LINE")
@AttributeOverrides({ @AttributeOverride(name = "createUser", column = @Column(name = "CVDM11_CREATE_USER_C")),
	@AttributeOverride(name = "createTime", column = @Column(name = "CVDM11_CREATE_S")),
	@AttributeOverride(name = "updateUser", column = @Column(name = "CVDM11_LAST_UPDT_USER_C")),
	@AttributeOverride(name = "updateTime", column = @Column(name = "CVDM11_LAST_UPDT_S")) })

@NamedQueries({
    @NamedQuery(name="CvddmProductLineDE.findAll", query="SELECT c FROM CvddmProductLineDE c"),
    @NamedQuery(name="CvddmProductLineDE.getProductLineById",
    query = "select n from CvddmProductLineDE n WHERE n.cvdmPrdctLineId=?1 and n.cvdmActiveFlag=?1 ", hints = @QueryHint(
            		name = "javax.persistence.cache.retrieveMode",
                    value = "BYPASS")),
    @NamedQuery(name = "CvddmProductLineDE.getActiveRecordsForProductGrp",
        query = "select n from CvddmProductLineDE n WHERE n.cvdmActiveFlag=?1 and n.cvddmProductGroupDE.cvdmPrdctGrpId=?2 ", hints = @QueryHint(
        		name = "javax.persistence.cache.retrieveMode",
                value = "BYPASS"))})


public class CvddmProductLineDE extends com.ford.cvddm.base.CVDDMBaseAuditDE implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="CVDM11_PRDCT_LINE_K")
	private long cvdmPrdctLineId;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "CVDM10_PRDCT_GRP_K", referencedColumnName = "CVDM10_PRDCT_GRP_K")
	private CvddmProductGroupDE cvddmProductGroupDE;

	@Column(name="CVDM11_ACTIVE_F")
	private String cvdmActiveFlag;

	@Column(name="CVDM11_PRDCT_LINE_N")
	private String cvdmPrdctLineDesc;
	

	public long getCvdmPrdctLineId() {
		return this.cvdmPrdctLineId;
	}

	public void setCvdmPrdctLineId(long cvdmPrdctLineId) {
		this.cvdmPrdctLineId = cvdmPrdctLineId;
	}

	public CvddmProductGroupDE getCvddmProductGroupDE() {
		return cvddmProductGroupDE;
	}

	public void setCvddmProductGroupDE(CvddmProductGroupDE cvddmProductGroupDE) {
		this.cvddmProductGroupDE = cvddmProductGroupDE;
	}

	public String getCvdmActiveFlag() {
		return this.cvdmActiveFlag;
	}

	public void setCvdmActiveFlag(String cvdmActiveFlag) {
		this.cvdmActiveFlag = cvdmActiveFlag;
	}

	public String getCvdmPrdctLineDesc() {
		return this.cvdmPrdctLineDesc;
	}

	public void setCvdmPrdctLineDesc(String cvdmPrdctLineDesc) {
		this.cvdmPrdctLineDesc = cvdmPrdctLineDesc;
	}
	
	@Override
	public int hashCode() {
		return Objects.hashCode(this.cvdmPrdctLineId);
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		final CvddmProductLineDE other = (CvddmProductLineDE) obj;
		return Objects.equal(this.cvdmPrdctLineId, other.cvdmPrdctLineId);
	}

}