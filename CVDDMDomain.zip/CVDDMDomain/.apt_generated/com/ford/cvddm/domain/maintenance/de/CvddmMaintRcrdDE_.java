package com.ford.cvddm.domain.maintenance.de;

import com.ford.cvddm.domain.master.de.CvddmMaintTypeDE;
import com.ford.cvddm.domain.master.de.CvddmScreenInfoDE;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="EclipseLink-2.4.2.v20130514-rNA", date="2019-05-24T13:10:23")
@StaticMetamodel(CvddmMaintRcrdDE.class)
public class CvddmMaintRcrdDE_ { 

    public static volatile SingularAttribute<CvddmMaintRcrdDE, Timestamp> cvdmMaintFromDt;
    public static volatile SingularAttribute<CvddmMaintRcrdDE, CvddmScreenInfoDE> cvddmScreenInfoDE;
    public static volatile SingularAttribute<CvddmMaintRcrdDE, CvddmMaintTypeDE> cvddmMaintTypeDE;
    public static volatile SingularAttribute<CvddmMaintRcrdDE, Timestamp> cvdmMaintToDt;
    public static volatile SingularAttribute<CvddmMaintRcrdDE, String> cvdmMaintTitle;
    public static volatile SingularAttribute<CvddmMaintRcrdDE, String> cvdmMaintDesc;
    public static volatile SingularAttribute<CvddmMaintRcrdDE, Integer> cvdmMaintRcrdId;
    public static volatile SingularAttribute<CvddmMaintRcrdDE, String> cvdmEmailNotify;

}