package com.ford.cvddm.domain.master.de;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="EclipseLink-2.4.2.v20130514-rNA", date="2019-05-24T13:10:23")
@StaticMetamodel(CvddmScreenInfoDE.class)
public class CvddmScreenInfoDE_ { 

    public static volatile SingularAttribute<CvddmScreenInfoDE, String> cvdmScreenURL;
    public static volatile SingularAttribute<CvddmScreenInfoDE, Long> cvddmScreenId;
    public static volatile SingularAttribute<CvddmScreenInfoDE, String> cvdmScreenName;

}