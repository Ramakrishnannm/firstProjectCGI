package com.ford.cvddm.domain.master.de;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="EclipseLink-2.4.2.v20130514-rNA", date="2019-05-24T13:10:23")
@StaticMetamodel(CvddmMaintTypeDE.class)
public class CvddmMaintTypeDE_ { 

    public static volatile SingularAttribute<CvddmMaintTypeDE, String> cvdmActiveFlag;
    public static volatile SingularAttribute<CvddmMaintTypeDE, String> cvdmMaintTypeDesc;
    public static volatile SingularAttribute<CvddmMaintTypeDE, String> cvdmMaintTypeCd;

}