package com.ford.cvddm.de;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="EclipseLink-2.4.2.v20130514-rNA", date="2019-05-17T13:59:39")
@StaticMetamodel(CVDDMRequestsDE.class)
public class CVDDMRequestsDE_ { 

    public static volatile SingularAttribute<CVDDMRequestsDE, String> requestedBy;
    public static volatile SingularAttribute<CVDDMRequestsDE, String> enviroinment;
    public static volatile SingularAttribute<CVDDMRequestsDE, String> programCode;
    public static volatile SingularAttribute<CVDDMRequestsDE, String> requestId;
    public static volatile SingularAttribute<CVDDMRequestsDE, Long> modelYear;
    public static volatile SingularAttribute<CVDDMRequestsDE, String> requestStatus;

}