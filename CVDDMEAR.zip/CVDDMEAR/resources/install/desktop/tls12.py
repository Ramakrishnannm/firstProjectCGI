########################################
# DO NOT EDIT ANYTHING BELOW THIS LINE #
########################################

PROCESS_SSL = 'TRUE'

from Settings import Settings as Config
if Config.isDesktop():
               KS_SCOPE = 'Node'
else:
               KS_SCOPE = 'Cell'
               
# Create a custom repertoire for TLSv1.2 protocol, without affecting other apps in shared
SSL_CONFIG_PARAMS = [
               [
                              ['configalias',    SSL_CONFIG_ALIAS],
                              ['keystorename',   '%sDefaultKeyStore' % KS_SCOPE],
                              ['truststorename', '%sDefaultTrustStore' % KS_SCOPE],
                              # SSL handshake protocol
                              ['sslProtocol',    'TLSv1.2']
               ]
]

SSL_ENDPOINT_PARAMS = [
               [
                              ['endpointname', 'PivotalCloudFoundry'],
                              ['dns', PCF_ENDPOINT_DNS],
                              ['port', 443],
                              ['protocol', '*'],
                              ['configalias', SSL_CONFIG_ALIAS]
               ]
]

import Log, WAS
from Settings import Settings as Config
from WAS import updateObjectProperties

def createConfig( self ):
               Log.debug( '>>SSL.createConfig' )

               from common import findPropertyValue
               global AdminTask, Config
               
               if Config.isDesktop():
                              template = '(cell):%sCell:(node):%sNode'
                              serverName = Config.getNameForActiveClusterMember()
                              keyStoreScopeName   = template % (serverName, serverName)
                              trustStoreScopeName = keyStoreScopeName
               else:                      
                              # override cluster, use cell management scope
                              template = '(cell):%s'
                              keyStoreScopeName   = template % Config.CELL
                              trustStoreScopeName = keyStoreScopeName

               for item in Config.SSL_CONFIG_PARAMS:

                              sslCfgAlias = findPropertyValue( item, 'configalias' )
                              sslCfgAlias = Config.APPLICATION_NAME + '_' + sslCfgAlias
                              Log.debug( '  sslCfgAlias       = ' + sslCfgAlias )

                              trustStoreName = findPropertyValue( item, 'truststorename' )
                              # don't prepend app name
                              # trustStoreName = Config.APPLICATION_NAME + '_' + trustStoreName
                              Log.debug( '  trustStoreName    = ' + trustStoreName )

                              keyStoreName = findPropertyValue( item, 'keystorename' )
                              # don't prepend app name
                              # keyStoreName = Config.APPLICATION_NAME + '_' + keyStoreName
                              Log.debug( '  keyStoreName      = ' + keyStoreName )

                              attrs  = '-alias ' + sslCfgAlias
                              attrs += ' -scopeName ' + keyStoreScopeName
                              attrs += ' -trustStoreName ' + trustStoreName
                              attrs += ' -trustStoreScopeName ' + trustStoreScopeName
                              attrs += ' -keyStoreName ' + keyStoreName
                              attrs += ' -keyStoreScopeName ' + keyStoreScopeName

                              Log.log( 'Creating SSLConfig ' + sslCfgAlias )
                              Log.debug( 'AdminTask.createSSLConfig ' + attrs )
                              sslConfig = AdminTask.createSSLConfig( attrs )

                              setting = AdminConfig.showAttribute( sslConfig, 'setting' )
                              updateObjectProperties( setting, 'SecureSocketLayer', item )

               Log.debug( '<<SSL.createConfig' )
               
               
def removeConfig( self ):
               Log.debug( '>>SSL.removeConfig' )

               import sys
               global AdminTask, Config
               
               if Config.isDesktop():
                              serverName = Config.getNameForActiveClusterMember()
                              scopeName = '(cell):' + serverName + 'Cell:(node):' + serverName + 'Node'
               else:
                              # override management scope
                              scopeName = '(cell):%s' % Config.CELL
               
               try:
                              configs = AdminTask.listSSLConfigs( '-displayObjectName false -scopeName ' + scopeName ).splitlines()
               except:
                              configs = None

               if configs:
                              Log.debug( '   configs = ' + str(configs) )

                              sslConfigList = []
                              for configItems in configs:
                                             nameArgs = configItems.split( ' ' )
                                             name = nameArgs[1]
                                             if name.startswith( Config.APPLICATION_NAME + '_' ):
                                                            sslConfigList.append( name )

                              Log.debug( '   sslConfigList = ' + str(sslConfigList) )
                              if len(sslConfigList) > 0:
                                             for item in sslConfigList:
                                                            Log.debug( '   alias = ' + item)
                                                            try:
                                                                           output = AdminTask.deleteSSLConfig( '-alias ' + item + ' -scopeName ' + scopeName )
                                                                           Log.log( '   deleted SSLConfig ' + item )
                                                            except:
                                                                           _type_, output, _tbck_ = sys.exc_info()
                                                            Log.log( str(output) )

               Log.debug( '<<SSL.removeConfig' )
               
# method overrides
WAS.SSL.createConfig = createConfig
WAS.SSL.removeConfig = removeConfig