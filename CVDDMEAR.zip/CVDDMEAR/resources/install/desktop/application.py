################################################################################
##                         IMPORT BASE PY FILE
## Import other settings from applicationbase.py 
## See the resources/install/common folder for this file.
## Note for the desktop we need to fully qualify this file. 
################################################################################
from Settings import Settings as Config
execfile('C:/Projects/GIT/CVDDM/CVDDMEAR/resources/install/common/applicationbase.py' )
execfile('C:/Projects/GIT/CVDDM/CVDDMEAR/resources/install/desktop/dynapropcfgSymlink.py' )

##############################################################################
##                           SYSTEM_PROPERTIES
##  Append additional properties specific to this environment
##############################################################################
SYSTEM_PROPERTIES.append(["faces.PROJECT_STAGE", "Development"])
SYSTEM_PROPERTIES.append(["user.timezone", "UTC"])
SYSTEM_PROPERTIES.append(["com.ibm.ws.jsf.call.publishevent.with.sourceclass", "true"])

################################################################################
##     CVDDM DB (DEV) -- NOT used and is listed here just for an example
##  The necessary core settings are established in applicationbase.py
##  These settings are just added to definitions started in the base py.
################################################################################
#SQLServer_DB_CVDDM.append(["databaseName", "XXXXX"])
#SQLServer_DB_CVDDM.append(["serverName", "XXXXX"])
#SQLServer_DB_CVDDM.append(["portNumber", XXXXX])

################################################################################
##   DynaProp Database (DEV) -- NOT used and is listed here just for an example
##  The necessary core settings are established in applicationbase.py
##  These settings are just added to definitions started in the base py.
################################################################################
#SQLServer_DB_DynaProp.append(["databaseName", "XXXXX"])
#SQLServer_DB_DynaProp.append(["serverName", "XXXXX"])
#SQLServer_DB_DynaProp.append(["portNumber", XXXXX])

################################################################################
## DataMaintenance Database (DEV) -- NOT used and is listed here just for an example
##  The necessary core settings are established in applicationbase.py
##  These settings are just added to definitions started in the base py.
################################################################################
#SQLServer_DB_DataMaintenance.append(["databaseName", "XXXXX"])
#SQLServer_DB_DataMaintenance.append(["serverName", "XXXXX"])
#SQLServer_DB_DataMaintenance.append(["portNumber", XXXXX])

#DATA_SOURCE_DEFINITIONS = [SQLServer_DB_CVDDM]
################################################################################