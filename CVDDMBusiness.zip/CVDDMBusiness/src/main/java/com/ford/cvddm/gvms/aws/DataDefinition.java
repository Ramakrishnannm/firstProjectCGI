package com.ford.cvddm.gvms.aws;

import java.util.List;

public class DataDefinition {
	
	private List<EnumertedParameter> enumertedParameters;

	public List<EnumertedParameter> getEnumertedParameters() {
		return enumertedParameters;
	}

	public void setEnumertedParameters(List<EnumertedParameter> enumertedParameters) {
		this.enumertedParameters = enumertedParameters;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((enumertedParameters == null) ? 0 : enumertedParameters.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DataDefinition other = (DataDefinition) obj;
		if (enumertedParameters == null) {
			if (other.enumertedParameters != null)
				return false;
		} else if (!enumertedParameters.equals(other.enumertedParameters))
			return false;
		return true;
	}

}
