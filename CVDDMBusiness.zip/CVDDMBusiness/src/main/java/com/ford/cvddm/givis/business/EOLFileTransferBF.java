package com.ford.cvddm.givis.business;

import java.io.Serializable;
import java.util.Map;

import javax.enterprise.context.SessionScoped;

import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.outbound.givis.soap.eolxfiletransfer.EOLFileTransferRequest;
import com.ford.cvddm.outbound.givis.soap.eolxfiletransfer.InitiateTransferRequest;
import com.ford.cvddm.outbound.layer.CVDDMConsumerAS;
import com.ford.cvddm.sob.business.layer.CVDDMBaseBF;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;
import com.ford.it.wscore.consumer.as.WscBaseGenericConsumerAS;

@SessionScoped
public class EOLFileTransferBF extends CVDDMBaseBF implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** The Class Name used for Logging */
	private static final String CLASS_NAME = EOLFileTransferBF.class.getName();

	/** The Logger instance used for Logging */
	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	/**
	 * Instance of the Consumer AS needed to interact with the Module StateService
	 */
	private WscBaseGenericConsumerAS cvddmConsumerAS;

	/**
	 * @return Returns the cvddmConsumerAS.
	 */
	public WscBaseGenericConsumerAS getCvddmConsumerAS(String consumerType) {

		this.cvddmConsumerAS = new CVDDMConsumerAS(consumerType);
		return this.cvddmConsumerAS;
	}

	/**
	 * @param CVDDMConsumerAS
	 *            The cvddmConsumerAS to set.
	 */
	public void setCVDDMConsumerAS(final WscBaseGenericConsumerAS cvddmConsumerAS) {
		this.cvddmConsumerAS = cvddmConsumerAS;
	}

	/**
	 * 
	 * 
	 * @param inputMap
	 * @return
	 */
	public boolean pushEOLtoGIVIS(Map<String, Object> inputMap) {

		boolean isDataPushed = false;

		final String METHOD_NAME = "pushEOLtoGIVIS";
		log.entering(CLASS_NAME, METHOD_NAME);

		EOLFileTransferRequest eOLFileTransferRequest = null;

		try {

			eOLFileTransferRequest = new EOLFileTransferRequest();

			if (!CvddmUtil.isObjectEmpty(eOLFileTransferRequest)) {

				getCvddmConsumerAS(CVDDMConstant.GIVIS_EOL_CONFIG).processConsumer("ReceiveEOLFiles",
						eOLFileTransferRequest);

				isDataPushed = true;
			}

		} catch (Exception ex) {
			isDataPushed = false;
			log.severe(CvddmUtil.getStackTraceContent(ex));
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
		return isDataPushed;
	}

	/**
	 * 
	 * 
	 * @param inputMap
	 * @return
	 */
	public boolean initiateEOLTransfer(Map<String, Object> inputMap) {

		boolean isDataPushed = false;

		final String METHOD_NAME = "initiateEOLTransfer";
		log.entering(CLASS_NAME, METHOD_NAME);

		InitiateTransferRequest initiateTransferRequest = null;

		try {

			initiateTransferRequest = new InitiateTransferRequest();

			if (!CvddmUtil.isObjectEmpty(initiateTransferRequest)) {

				getCvddmConsumerAS(CVDDMConstant.GIVIS_EOL_CONFIG).processConsumer("InitiateEOLFileTransfer",
						initiateTransferRequest);

				isDataPushed = true;
			}

		} catch (Exception ex) {
			isDataPushed = false;
			log.severe(CvddmUtil.getStackTraceContent(ex));
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
		return isDataPushed;
	}

}