package com.ford.cvddm.module.business.list;

import java.io.Serializable;
import java.util.List;

import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;

import com.ford.cvddm.domain.module.de.CvddmModuleDE;
import com.ford.cvddm.entitymanager.ModuleEntityManager;
import com.ford.cvddm.sob.business.layer.CVDDMBaseBF;

/**
 * Description : Business Facade Class for Module Functionality.
 * 
 * @author MJEYARAJ
 *
 */
@SessionScoped
public class ListCvddmModuleBF extends CVDDMBaseBF implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private ModuleEntityManager ModuleEntityManager;

	/**
	 * Method Name: fetchAllModRcrds
	 * 
	 * @Description:This method would fetch all Module Records from
	 *                   PCVDM15_MODULE_TYPE database table.
	 * 
	 * @param None
	 * @return List<CvddmModuleDE>
	 */
	public List<CvddmModuleDE> fetchAllModRcrds() {

		return ModuleEntityManager.fetchAllRecords();
	}

	/**
	 * Method Name: fetchAllModActiveRcrds
	 * 
	 * @Description:This method would fetch all Module active Records from
	 *                   PCVDM15_MODULE_TYPE database table.
	 * 
	 * @param None
	 * @return List<CvddmModuleDE>
	 */
	public List<CvddmModuleDE> fetchAllModActiveRcrds() {

		return ModuleEntityManager.fetchActiveRecords();
	}

	/**
	 * Method Name: fetchModRcrd
	 * 
	 * @Description:This method would fetch Module Record from PCVDM15_MODULE_TYPE
	 *                   database table.
	 * 
	 * @param None
	 * @return CvddmModuleDE
	 */
	public CvddmModuleDE fetchModRcrd(String moduleId) {

		return ModuleEntityManager.fetchModuleRecord(moduleId);
	}

}