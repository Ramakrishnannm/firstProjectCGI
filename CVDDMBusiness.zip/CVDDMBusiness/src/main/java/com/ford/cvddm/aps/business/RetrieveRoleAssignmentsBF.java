/**
 * 
 */
package com.ford.cvddm.aps.business;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.outbound.aps.retrieveRoleAssignments.GetUsersForApplicationRequestType;
import com.ford.cvddm.outbound.aps.retrieveRoleAssignments.GetUsersForApplicationResponseType;
import com.ford.cvddm.outbound.aps.retrieveRoleAssignments.UserRoleType;
import com.ford.cvddm.outbound.layer.CVDDMConsumerAS;
import com.ford.cvddm.sob.business.layer.CVDDMBaseBF;
import com.ford.cvddm.sob.business.layer.CVDDMBusinessException;
import com.ford.it.exception.FordExceptionAttributes;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;
import com.ford.it.util.TextUtil;
import com.ford.it.wscore.consumer.as.WscBaseGenericConsumerAS;

/**
 * Description : US941734
 * Business Facade Class for RetrieveRoleAssignments APS SOA Service.
 * Used to fetch all authorized CVDDM User's from APS.
 * @author NGUPTA18
 *
 */
@SessionScoped
public class RetrieveRoleAssignmentsBF extends CVDDMBaseBF implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** The Class Name used for Logging */
	private static final String CLASS_NAME = RetrieveRoleAssignmentsBF.class.getName();

	/** The Logger instance used for Logging */
	private static final ILogger log =
			LogFactory.getInstance().getLogger(CLASS_NAME);

	/**
	 * Instance of the Consumer AS needed to interact with the RetrieveRoleAssignments Service
	 */
	private WscBaseGenericConsumerAS cvddmConsumerAS;

	/**
	 * @return Returns the cvddmConsumerAS.
	 */
	public WscBaseGenericConsumerAS getCvddmConsumerAS(String consumerType) {

		this.cvddmConsumerAS = new CVDDMConsumerAS(consumerType);
		return this.cvddmConsumerAS;
	}

	/**
	 * @param CVDDMConsumerAS The cvddmConsumerAS to set.
	 */
	public void setCVDDMConsumerAS(final WscBaseGenericConsumerAS cvddmConsumerAS) {
		this.cvddmConsumerAS = cvddmConsumerAS;
	}

	/**
	 * Method: getUsersForApplicationResponse
	 * This method retrieves GetUsersForApplicationResponseType Object from
	 * APS RetrieveRoleAssignments Service for CVDDM Application
	 *
	 * @param none
	 * @return GetUsersForApplicationResponseType
	 * @throws CVDDMBusinessException when UsersForApplicationResponse couldn't be fetched from 
	 *  APS RetrieveRoleAssignments Service
	 */

	public GetUsersForApplicationResponseType getUsersForApplicationResponse() {

		final String METHOD_NAME = "getUsersForApplicationResponse";
		log.entering(CLASS_NAME, METHOD_NAME);


		final GetUsersForApplicationRequestType getUserForApp = new  GetUsersForApplicationRequestType();

		getUserForApp.setApplication(CVDDMConstant.CVDDM_APP_NAME);

		GetUsersForApplicationResponseType usersForApplicationResponseType = null;

		try {

			usersForApplicationResponseType = getCvddmConsumerAS(CVDDMConstant.APS_GET_ALL_USER_FOR_APP).processConsumer(
					"GetUsersForApplication", getUserForApp);	
		}

		catch (final Exception ex) {
			log.severe(CvddmUtil.getStackTraceContent(ex));
    		throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(
    				CLASS_NAME, METHOD_NAME).build(), CvddmUtil.getStackTraceContent(ex), ex);
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
		// Return the GetUsersForApplicationResponseType
		return usersForApplicationResponseType;
	}

	/**
	 * Method: getEmailIdsForApplication
	 * This method retrieves CdsId's from GetUsersForApplicationResponseType Object from
	 * and prepare List of Email Id's for all User's as per Ford Standard.
	 * @param none
	 * @return StringBuilder
	 * 
	 */

	public StringBuilder getEmailIdsForApplication() {

		final String METHOD_NAME = "getEmailIdsForApplication";
		log.entering(CLASS_NAME, METHOD_NAME);

		StringBuilder emailIdsBuilder = new StringBuilder();

		GetUsersForApplicationResponseType usersForApplicationResponseType = null;

		try {

			usersForApplicationResponseType = getUsersForApplicationResponse();

			if(!CvddmUtil.isObjectEmpty(usersForApplicationResponseType)
					&& !CvddmUtil.isObjectEmpty(usersForApplicationResponseType.getUserRoles())) {

				List<UserRoleType> userRoleTypeLst = usersForApplicationResponseType.getUserRoles();

				Iterator <UserRoleType> userRoleItr = userRoleTypeLst.listIterator();

				while(userRoleItr.hasNext()) {

					UserRoleType userRoleType =  userRoleItr.next();

					if(!CvddmUtil.isObjectEmpty(userRoleType) 
							&& TextUtil.isNotBlankOrNull(userRoleType.getUser()) ) {

						String userCdsId = userRoleType.getUser();

						log.info("User CDS Id from APS are >>> "+userCdsId);

						String emailId = CvddmUtil.formatUserEmail(userCdsId);

						log.info("Email Ids from User CDS Id are >>> "+emailId);

						emailIdsBuilder.append(emailId);
						
						if(userRoleItr.hasNext()) {	
							emailIdsBuilder.append(CVDDMConstant.COMMA);
						}
					}
				}							
				log.info("Final List of Email Ids >>> "+emailIdsBuilder.toString());
			} 
			if(emailIdsBuilder.length() == 0) { // To Handle Error Scenario.

				emailIdsBuilder.append(CvddmUtil.getPropertiesValue
						(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY, CVDDMConstant.ERROR_IN_EMAIL_ID_FETCH));
			}
		}
		catch(Exception ex) {
			log.severe(CvddmUtil.getStackTraceContent(ex));
    		throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(
    				CLASS_NAME, METHOD_NAME).build(), CvddmUtil.getStackTraceContent(ex), ex);
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
		return emailIdsBuilder;
	}

}
