package com.ford.cvddm.maintenance.business.list;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;

import com.ford.cvddm.domain.maintenance.de.CvddmMaintRcrdDE;
import com.ford.cvddm.domain.master.de.CvddmMaintTypeDE;
import com.ford.cvddm.domain.master.de.CvddmScreenInfoDE;
import com.ford.cvddm.entitymanager.MaintenanceEntityManager;
import com.ford.cvddm.sob.business.layer.CVDDMBaseBF;


/**
 * Description : Business Facade Class for Maintenance Functionality.
 * @author NGUPTA18
 *
 */
@SessionScoped
public class ListCvddmMaintenanceBF extends CVDDMBaseBF implements Serializable  {


	private static final long serialVersionUID = 1L;
	
	@Inject
	private MaintenanceEntityManager maintenanceEntityManager;
	
	

	/**
	 * Method Name: saveCvddmMaintRcrd
	 * @Description:This method would create a New Maintenance Record in PCVDM05_MAINT_REQ database table.
	 * @param  Map <String, Object> inputMap
	 * @return CvddmMaintRcrdDE
	 */
	public CvddmMaintRcrdDE saveCvddmMaintRcrd(Map <String, Object> inputDataMap) {
		
		return maintenanceEntityManager.saveCvddmMaintRcrd(inputDataMap);
	}

	/**
	 * Method Name: retrieveMaintRcrds
	 * @Description:This method would fetch Active Maintenance Records  on
	 * basis Active/Inactive Flag which would be used for Soft Delete Functionality.
	 * from  PCVDM05_MAINT_REQ database table.
	 * @param None
	 * @return  List<CvddmMaintRcrdDE> 
	 */
	public List<CvddmMaintRcrdDE> retrieveMaintRcrds() {

		return maintenanceEntityManager.retrieveMaintRcrds();
	}
	
	/**
	 * Method Name: fetchAllMaintRcrds
	 * @Description:This method would fetch all Maintenance Records
	 * from  PCVDM05_MAINT_REQ database table.
	 * 
	 * @param None
	 * @return  List<CvddmMaintRcrdDE> 
	 */
	public List<CvddmMaintRcrdDE> fetchAllMaintRcrds() {

		return maintenanceEntityManager.fetchAllRecords();
	}

	/***
	 * Method Name: retrieveMaintTypes
	 * @Description:This method would fetch Active Maintenance Types. 
	 * from  PCVDM04_MAINT_TYPE database table.
	 * @param none
	 * @return  List<CvddmMaintTypeDE> 
	 */
	public List<CvddmMaintTypeDE> retrieveActiveMaintTypes() {
		
		return maintenanceEntityManager.retrieveActiveMaintTypes();
	}


	/**
	 * Method Name: retrieveAllScreens
	 * @Description:This method would fetch all CVDDM Menu/Sub Menus. 
	 * from  PCVDM01_SCREEN_INFO database table.
	 * @param none
	 * @return  List<CvddmScreenInfoDE> 
	 */
	public List<CvddmScreenInfoDE> retrieveAllScreens() {
		
		return maintenanceEntityManager.retrieveAllScreens();
	}
	/*** Start Change: User Story : US890091 ***/
	/**
	 * Method Name: getDownTimeRecord
	 * 
	 * @Description: This method would get the Active Maintenance Record from
	 *                   PCVDM05_MAINT_REQ database table
	 *                   for Across Site and Downtime when Current Date is 
	 *                   greater than equal to From Date&Time and Less Than Equal to To Date&Time * 
	 * @param none
	 * @return CvddmMaintRcrdDE
	 */
	public CvddmMaintRcrdDE getDownTimeRecord()  {
		
		maintenanceEntityManager = new MaintenanceEntityManager();
		
		return maintenanceEntityManager.getDownTimeRecord();
	}
	/*** End Change: User Story : US890091 ***/
	
	/***  Start Change: User Story : US987948 ***/
	/**
	 * Method Name: getAlertRecord
	 * 
	 * @Description: This method would get the Active Alert Maintenance Record from
	 *                   PCVDM05_MAINT_REQ database table
	 *                   for Menus when Current Date is 
	 *                   greater than equal to From Date&Time and Less Than Equal to To Date&Time * 
	 * @param String cvddmScreenCd
	 * @return CvddmMaintRcrdDE
	 */
	public CvddmMaintRcrdDE getAlertRecord(String cvddmScreenCd)  {
		
		maintenanceEntityManager = new MaintenanceEntityManager();
		
		return maintenanceEntityManager.getAlertRecord(cvddmScreenCd);
	}
	
	/***  End Change: User Story : US987948 ***/
	
	/***  Start Change: User Story : US890086 ***/
	/**
	 * Method Name: getBannerRecord
	 * 
	 * @Description: This method would get the Active Banner Maintenance Record from
	 *                   PCVDM05_MAINT_REQ database table
	 *                   for Menus when Current Date is 
	 *                   greater than equal to From Date&Time and Less Than Equal to To Date&Time * 
	 * @param String cvddmScreenCd
	 * @return CvddmMaintRcrdDE
	 */
	public CvddmMaintRcrdDE getBannerRecord(String cvddmScreenCd)  {
		
		maintenanceEntityManager = new MaintenanceEntityManager();
		
		return maintenanceEntityManager.getBannerRecord(cvddmScreenCd);
	}
	
	/***  End Change: User Story : US890086 ***/
	/***  Start Change: User Story : US890083 ***/
	/**
	 * Method Name: softDeleteRrcd
	 * 
	 * @Description: This method would Soft Delete Maintenance  Record from PCVDM05_MAINT_REQ by 
	 *               updating Active Flag to N. 
	 * @param CvddmMaintRcrdDE cvddmMaintRcrdDE
	 * @return none
	 */
     public void softDeleteRrcd(CvddmMaintRcrdDE cvddmMaintRcrdDE) {
		
		maintenanceEntityManager = new MaintenanceEntityManager();
		maintenanceEntityManager.softDeleteRrcd(cvddmMaintRcrdDE);
	}
	
	/***  End Change: User Story : US890083 ***/
    /*** Start Change: User Story : US941215 ***/
     /**
 	 * Method Name: fetchRcrdforUpdate
 	 * @Description:This method would fetch  Maintenance Record on basis of passed Primary Key Value.
 	 * @param String cvdmMaintRcrdId
 	 * @return CvddmMaintRcrdDE
 	 */
 	public CvddmMaintRcrdDE fetchRcrdforUpdate(String cvdmMaintRcrdId) {

 		return maintenanceEntityManager.fetchRcrdforUpdate(cvdmMaintRcrdId);
 	}
 	
 	/**
	 * Method Name: updtCvddmMaintRcrd
	 * @Description:This method would update Maintenance Record in PCVDM05_MAINT_REQ database table.
	 * @param  CvddmMaintRcrdDE cvddmMaintRcrdDE
	 * @return none
	 */
	public void updtCvddmMaintRcrd(CvddmMaintRcrdDE cvddmMaintRcrdDE) {
		
		maintenanceEntityManager = new MaintenanceEntityManager();
		maintenanceEntityManager.updtCvddmMaintRcrd(cvddmMaintRcrdDE);
	}
 	/*** End Change: User Story : US941215 ***/

}