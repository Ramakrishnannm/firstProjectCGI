package com.ford.cvddm.bf;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

import com.ford.cvddm.de.CVDDMRequestsDE;
import com.ford.cvddm.repository.CVDDMRequestsRepository;
import com.ford.cvddm.sob.business.layer.CVDDMBaseBF;

@ApplicationScoped
public class CVDDMRequestsBF extends CVDDMBaseBF {

	@Inject
	private CVDDMRequestsRepository cVDDMRequestsRepository;

	/**
	 * @see cVDDMRequestsRepository#removeWithMerge(CVDDMRequestsDE)
	 */
	public void deleteCVDDMRequests(final String CVDDMRequestsUuid) {

		this.cVDDMRequestsRepository.removeWithMerge(this.cVDDMRequestsRepository.findBy(CVDDMRequestsUuid));
	}

	/**
	 * @see cVDDMRequestsRepository#findBy(String)
	 */
	public CVDDMRequestsDE retrieveCVDDMRequests(final String uuid) {
		return this.cVDDMRequestsRepository.findBy(uuid);
	}

	/**
	 * {@link cVDDMRequestsRepository#findAll()}
	 */
	public List<CVDDMRequestsDE> retrieveCVDDMRequestsListReadOnly() {

		return this.cVDDMRequestsRepository.findAll();
	}

	/**
	 * @see cVDDMRequestsRepository#save(CVDDMRequestsDE)
	 */
	public CVDDMRequestsDE saveCVDDMRequests(final CVDDMRequestsDE CVDDMRequestsDE) {

		return this.cVDDMRequestsRepository.save(CVDDMRequestsDE);
	}

	/**
	 * 
	 * @param CVDDMRequestsUuid
	 */
	public void updateCVDDMRequests(CVDDMRequestsDE CVDDMRequest) {
		
		CVDDMRequestsDE cVDDMRequestsDE = new CVDDMRequestsDE();
        String primaryKey = CVDDMRequest.getRequestId();
    	String programCode = CVDDMRequest.getProgramCode();
    	long modelYear = CVDDMRequest.getModelYear();
    	String enviroinment = CVDDMRequest.getEnviroinment();
    	String requestedBy = CVDDMRequest.getRequestedBy();
    	String requestStatus = CVDDMRequest.getRequestStatus();
		cVDDMRequestsDE = this.cVDDMRequestsRepository.findBy(primaryKey);
		cVDDMRequestsDE.setProgramCode(programCode);
		cVDDMRequestsDE.setModelYear(modelYear);
		cVDDMRequestsDE.setEnviroinment(enviroinment);
		cVDDMRequestsDE.setRequestedBy(requestedBy);
		cVDDMRequestsDE.setRequestStatus(requestStatus);

		this.cVDDMRequestsRepository.saveAndFlushAndRefresh(cVDDMRequestsDE);
		System.out.println("Updated3");
	}

}
