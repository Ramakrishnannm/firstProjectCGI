package com.ford.cvddm.gvms.business;

import java.io.InputStream;
import java.io.Serializable;

import javax.enterprise.context.SessionScoped;

import org.apache.commons.io.IOUtils;

import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.outbound.gvms.getCurrentLite.CvddmHttpPoster;
import com.ford.cvddm.outbound.gvms.getCurrentLite.DerivedValues;
import com.ford.cvddm.outbound.gvms.getCurrentLite.DidInfoType;
import com.ford.cvddm.outbound.gvms.getCurrentLite.GetCurrentLite;
import com.ford.cvddm.outbound.gvms.getCurrentLite.GetCurrentLiteRequest;
import com.ford.cvddm.outbound.gvms.getCurrentLite.GetCurrentLiteResponseType;
import com.ford.cvddm.outbound.gvms.getCurrentLite.NodeInfo;
import com.ford.cvddm.sob.business.layer.CVDDMBaseBF;
import com.ford.cvddm.sob.business.layer.CVDDMBusinessException;
import com.ford.it.exception.FordExceptionAttributes;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;
import com.ford.it.util.TextUtil;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Description :US1020052
 * Business Facade Class for GVMS IBM API Connect - GetCurrentLite Rest Service.
 * This would be used to get VIN details from GVMS Application.
 * @author NGUPTA18
 *
 */
@SessionScoped
public class GvmsGetCurrentLiteBF extends CVDDMBaseBF implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** The Class Name used for Logging */
	private static final String CLASS_NAME = GvmsGetCurrentLiteBF.class.getName();

	/** The Logger instance used for Logging */
	private static final ILogger log =
			LogFactory.getInstance().getLogger(CLASS_NAME);


	/**
	 * This method retrieves a GetCurrentLiteResponseType Object from GVMS getCurrentLite Rest Service
	 * @param Map <String, Object> inputMap
	 * @return GetCurrentLiteResponseType
	 * @throws CVDDMBusinessException when GetCurrentLiteResponseType Object Could not be retrieved from GVMS.
	 */

	public GetCurrentLiteResponseType getGetCurrentLiteResponseType(Map <String, Object> inputMap) {

		final String METHOD_NAME = "getGetCurrentLiteResponseType";
		log.entering(CLASS_NAME, METHOD_NAME);

		String env = (String) inputMap.get(CVDDMConstant.ENV_TYPE);

		if(TextUtil.isBlankOrNull(env)) {

			env = CVDDMConstant.ENV_QA1;
		}

		final GetCurrentLiteRequest getCurrentLiteRequestObj  = (GetCurrentLiteRequest) inputMap.get(CVDDMConstant.CURRENTLITE_REQ_OBJ);


		GetCurrentLiteResponseType getCurrentLiteResponseType = null;

		String getCurrentRequestStr = null;
		String getCurrentLiteResponseStr = null;

		InputStream inputStream = null;

		InputStream responseStream = null;

		CvddmHttpPoster cvddmHttposter = null;


		ObjectMapper objectMapper = null;

		try {

			if(!CvddmUtil.isObjectEmpty(getCurrentLiteRequestObj)) {

				cvddmHttposter = new CvddmHttpPoster();

				objectMapper = new ObjectMapper();

				if(CVDDMConstant.ENV_QA1.equalsIgnoreCase(env)) {

					final URL url = new URL(CvddmUtil.getPropertiesValue( 
							CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, CVDDMConstant.QA1_GVMS_GET_CURRENT_LITE_URL));

					cvddmHttposter.setUrl(url);

					cvddmHttposter.addOauth2Credentials(CVDDMConstant.GVMS_PRODUCT_OAUTH_CONFIG_QA1);
				}
				else {

					final URL url = new URL(CvddmUtil.getPropertiesValue( 
							CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, CVDDMConstant.QA2_GVMS_GET_CURRENT_LITE_URL));

					cvddmHttposter.setUrl(url);
					cvddmHttposter.addOauth2Credentials(CVDDMConstant.GVMS_PRODUCT_OAUTH_CONFIG_QA2);
				}

				cvddmHttposter.setContentType(CVDDMConstant.CONTENT_TYPE);
				getCurrentRequestStr = objectMapper.writeValueAsString(getCurrentLiteRequestObj);

				if(!CvddmUtil.isObjectEmpty(getCurrentRequestStr)) {
					inputStream = IOUtils.toInputStream(getCurrentRequestStr,StandardCharsets.UTF_8.toString());
				}

				if(!CvddmUtil.isObjectEmpty(inputStream)) {

					responseStream = cvddmHttposter.post(inputStream);
				}

				if(!CvddmUtil.isObjectEmpty(responseStream)) {

					getCurrentLiteResponseStr = IOUtils.toString(responseStream, StandardCharsets.UTF_8.toString());
				}

				if(!CvddmUtil.isObjectEmpty(getCurrentLiteResponseStr) && TextUtil.isNotBlankOrNull(getCurrentLiteResponseStr)) {
					
					objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);

					getCurrentLiteResponseType = objectMapper.readValue(getCurrentLiteResponseStr,GetCurrentLiteResponseType.class);
				}

			}
		} catch (final Exception ex) {
			log.severe(CvddmUtil.getStackTraceContent(ex));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(
					CLASS_NAME, METHOD_NAME).build(), CvddmUtil.getStackTraceContent(ex), ex);
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

		// Return the GetCurrentLiteResponseType
		return getCurrentLiteResponseType;
	}

	/**
	 * This method retrieves a GetCurrentLiteResponseType Object from GVMS getCurrentLite Rest Service for ALL Nodes
	 * and would be invoked for GVSM VIN Validation User Story Bean Class.
	 * @param Map <String, Object> inputMap
	 * @return GetCurrentLiteResponseType.
	 */


	public GetCurrentLiteResponseType getGetCurrentLiteResponseTypeForALL(Map <String, Object> inputMap) {


		final String METHOD_NAME = "getGetCurrentLiteResponseTypeForALL";
		log.entering(CLASS_NAME, METHOD_NAME);

		GetCurrentLiteResponseType getCurrentLiteResponseObj = null;

		GetCurrentLite getCurrentLiteObj = null;

		GetCurrentLiteRequest getCurrentLiteReqObj = null;

		try {

			if(!CvddmUtil.isObjectEmpty(inputMap) && !inputMap.isEmpty()) {

				getCurrentLiteReqObj = new GetCurrentLiteRequest();

				getCurrentLiteObj = new GetCurrentLite();

				String vinNumber = (String) inputMap.get(CVDDMConstant.VIN_NUMBER);

				getCurrentLiteObj.setVin(vinNumber);

				getCurrentLiteObj.setRole(CVDDMConstant.CONSUMER_ROLE);
				getCurrentLiteObj.setRoleSource(CVDDMConstant.ROLE_SOURCE);
				getCurrentLiteObj.setRoleDesc(CVDDMConstant.ROLE_RVCM_DESC_ID);
				getCurrentLiteObj.setRoleID(CVDDMConstant.ROLE_RVCM_DESC_ID);
				getCurrentLiteObj.setIsPgmyRequired(CVDDMConstant.STRING_Y);
				getCurrentLiteObj.setTraceID(UUID.randomUUID().toString());
				getCurrentLiteObj.setIsNodeInfoRequired(CVDDMConstant.STRING_Y);

				NodeInfo nodeInfoObj = new NodeInfo();
				List<String> nodeAddressList = new ArrayList<String>();
				nodeAddressList.add(CVDDMConstant.ALL_MODULE_CD);

				nodeInfoObj.setNodeAddress(nodeAddressList);


				getCurrentLiteObj.setNodeInfo(nodeInfoObj);

				DerivedValues derValObj = new DerivedValues();

				derValObj.setIsDerivedAssembly(CVDDMConstant.STRING_Y);
				derValObj.setIsPart2Spec(CVDDMConstant.STRING_Y);

				derValObj.setReservedElement(CVDDMConstant.EMPTY_STRING);

				getCurrentLiteObj.setDerivedValues(derValObj);


				DidInfoType didInfoType = new DidInfoType();
				didInfoType.setDidInfoRequired(CVDDMConstant.STRING_Y);

				List <String> didTypeLst = new ArrayList<String>();
				didTypeLst.add(CVDDMConstant.ALL_MODULE_CD);
				didInfoType.setReservedElement(CVDDMConstant.EMPTY_STRING);
				didInfoType.setDidList(null);
				didInfoType.setDidType(didTypeLst);

				getCurrentLiteObj.setDidInfoType(didInfoType);

				getCurrentLiteReqObj.setGetCurrentLite(getCurrentLiteObj);

				String env = (String) inputMap.get(CVDDMConstant.ENV_TYPE);

				if(TextUtil.isBlankOrNull(env)) {

					env = CVDDMConstant.ENV_QA1;
				}

				inputMap.put(CVDDMConstant.ENV_TYPE, env);
				inputMap.put(CVDDMConstant.CURRENTLITE_REQ_OBJ, getCurrentLiteReqObj);

				getCurrentLiteResponseObj = getGetCurrentLiteResponseType(inputMap); 

			}
		}
		catch (final Exception ex) {
			log.severe(CvddmUtil.getStackTraceContent(ex));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(
					CLASS_NAME, METHOD_NAME).build(), CvddmUtil.getStackTraceContent(ex), ex);
		}

		log.exiting(CLASS_NAME, METHOD_NAME);
		return getCurrentLiteResponseObj;

	}

}
