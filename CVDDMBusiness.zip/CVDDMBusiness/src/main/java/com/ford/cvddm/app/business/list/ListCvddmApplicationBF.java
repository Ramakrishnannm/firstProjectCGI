package com.ford.cvddm.app.business.list;

import java.io.Serializable;
import java.util.List;

import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;

import com.ford.cvddm.domain.application.de.CvddmApplicationDE;
import com.ford.cvddm.entitymanager.ApplicationEntityManager;
import com.ford.cvddm.sob.business.layer.CVDDMBaseBF;

/**
 * Description : Business Facade Class for Environment Functionality.
 * 
 * @author MJEYARAJ
 *
 */
@SessionScoped
public class ListCvddmApplicationBF extends CVDDMBaseBF implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private ApplicationEntityManager applicationEntityManager;

	/**
	 * Method Name: fetchAllEnvRcrds
	 * 
	 * @Description:This method would fetch all Application Records from PCVDM07_APP
	 *                   database table.
	 * 
	 * @param None
	 * @return List<CvddmApplicationDE>
	 */
	public List<CvddmApplicationDE> fetchAllAppRcrds() {

		return applicationEntityManager.fetchAllRecords();
	}

}