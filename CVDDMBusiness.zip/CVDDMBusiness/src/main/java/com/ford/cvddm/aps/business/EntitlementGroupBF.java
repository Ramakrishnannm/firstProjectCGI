/**
 * 
 */
package com.ford.cvddm.aps.business;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.enterprise.context.SessionScoped;
import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.outbound.aps.entitlementGroup.EntitlementUsersType;
import com.ford.cvddm.outbound.aps.entitlementGroup.UserDetailType;
import com.ford.cvddm.outbound.layer.CVDDMConsumerAS;
import com.ford.cvddm.sob.business.layer.CVDDMBaseBF;
import com.ford.cvddm.sob.business.layer.CVDDMBusinessException;
import com.ford.it.exception.FordExceptionAttributes;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;
import com.ford.it.util.TextUtil;
import com.ford.it.wscore.consumer.as.WscBaseGenericConsumerAS;

/**
 * Description : US986092 
 * Business Facade Class for EntitlementGroup APS ADFS Protected SOA Service.
 * Used to fetch all authorized CVDDM User's for particular Role from APS.
 * @author NGUPTA18
 *
 */
@SessionScoped
public class EntitlementGroupBF extends CVDDMBaseBF implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** The Class Name used for Logging */
	private static final String CLASS_NAME = EntitlementGroupBF.class.getName();

	/** The Logger instance used for Logging */
	private static final ILogger log =
			LogFactory.getInstance().getLogger(CLASS_NAME);

	/**
	 * Instance of the Consumer AS needed to interact with the EntitlementGroup Service
	 */
	private WscBaseGenericConsumerAS cvddmConsumerAS;

	/**
	 * @return Returns the cvddmConsumerAS.
	 */
	public WscBaseGenericConsumerAS getCvddmConsumerAS(String consumerType) {

		this.cvddmConsumerAS = new CVDDMConsumerAS(consumerType);
		return this.cvddmConsumerAS;
	}

	/**
	 * @param CVDDMConsumerAS The cvddmConsumerAS to set.
	 */
	public void setCVDDMConsumerAS(final WscBaseGenericConsumerAS cvddmConsumerAS) {
		this.cvddmConsumerAS = cvddmConsumerAS;
	}

	/**
	 * Method: getEntitlementUsersType
	 * This method retrieves EntitlementUsersType Object from
	 * APS EntitlementGroup Service for CVDDM Application
	 *
	 * @param String roleName
	 * @return EntitlementUsersType
	 * @throws CVDDMBusinessException when User details couldn't be fetched from 
	 *  APS EntitlementGroup Service
	 */

	public EntitlementUsersType getEntitlementUsersType(String roleName) {

		final String METHOD_NAME = "getEntitlementUsersType";
		log.entering(CLASS_NAME, METHOD_NAME);

		if(TextUtil.isBlankOrNull(roleName)) {

			roleName = CVDDMConstant.DEFAULT_ROLE_NAME;
		}

		EntitlementUsersType entitlementUsersTypeResp = null; // Response Object.

		try {

			entitlementUsersTypeResp = getCvddmConsumerAS(CVDDMConstant.APS_GET_USERS_FR_ROLE).processConsumer(
					"GetUsersForEntitlement", roleName);
		}

		catch (final Exception ex) {
			log.severe(CvddmUtil.getStackTraceContent(ex));
    		throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(
    				CLASS_NAME, METHOD_NAME).build(), CvddmUtil.getStackTraceContent(ex), ex);
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
		// Return the EntitlementUsersType
		return entitlementUsersTypeResp;
	}

	/**
	 * Method: getEmailIdsForRole
	 * This method retrieves CdsId's from EntitlementUsersType Object 
	 * and prepare List of Email Id's for all User's as per Ford Standard.
	 * @param List<String> rolesList
	 * @return StringBuilder
	 * 
	 */

	public StringBuilder getEmailIdsForRole(List<String> rolesList) {

		final String METHOD_NAME = "getEmailIdsForRole";
		log.entering(CLASS_NAME, METHOD_NAME);

		StringBuilder emailIdsBuilder = new StringBuilder();

		try {

			if(!CvddmUtil.isObjectEmpty(rolesList) && !rolesList.isEmpty()) {

				Iterator<String> rolesItr = rolesList.listIterator();

				while(rolesItr.hasNext()) {

					String roleName = rolesItr.next();

					EntitlementUsersType entitlementUsersTypeResp = getEntitlementUsersType(roleName.trim());

					if(!CvddmUtil.isObjectEmpty(entitlementUsersTypeResp)
							&& !CvddmUtil.isObjectEmpty(entitlementUsersTypeResp.getUserDetail())) {

						List<UserDetailType> userDtlLst = entitlementUsersTypeResp.getUserDetail();

						if(!userDtlLst.isEmpty()) {

							StringBuilder tempEmailBuilder = prepEmailIdsFrmUsrDtlType(userDtlLst);

							tempEmailBuilder = removeDuplicateIds(tempEmailBuilder);
							emailIdsBuilder.append(tempEmailBuilder);
							if(rolesItr.hasNext()) {	
								emailIdsBuilder.append(CVDDMConstant.COMMA);
							}
						}
					} 
				}
				log.info("Final List of Email Ids are >>" +emailIdsBuilder.toString());
			} 

			if(emailIdsBuilder.length() == 0) { // To Handle Error Scenario.

				emailIdsBuilder.append(CvddmUtil.getPropertiesValue
						(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY, CVDDMConstant.ERROR_IN_EMAIL_ID_FETCH));
			}
		}
		catch(Exception ex) {
			log.severe(CvddmUtil.getStackTraceContent(ex));
    		throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(
    				CLASS_NAME, METHOD_NAME).build(), CvddmUtil.getStackTraceContent(ex), ex);
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
		return emailIdsBuilder;
	}

	/**
	 * Method: prepEmailIdsFrmUsrDtlType
	 * This method List of Email Id's for all User's as per Ford Standard
	 *  from List<UserDetailType>userDtlLst
	 * @param List<UserDetailType>userDtlLst
	 * @return StringBuilder
	 * 
	 */
	public StringBuilder prepEmailIdsFrmUsrDtlType(List<UserDetailType>userDtlLst) {

		final String METHOD_NAME = "prepEmailIdsFrmUsrDtlType";
		log.entering(CLASS_NAME, METHOD_NAME);

		StringBuilder emailIdsBuilder = new StringBuilder();

		try {

			Iterator <UserDetailType> usrDtlTypeItr = userDtlLst.listIterator();

			while(usrDtlTypeItr.hasNext()) {

				UserDetailType userDetailType =  usrDtlTypeItr.next();

				if(!CvddmUtil.isObjectEmpty(userDetailType) 
						&& TextUtil.isNotBlankOrNull(userDetailType.getUserId()) ) {

					String userCdsId = userDetailType.getUserId();

					log.info("userCdsId  is >>" +userCdsId );

					String emailId = CvddmUtil.formatUserEmail(userCdsId);

					log.info("Email Id is >>" +emailId );

					emailIdsBuilder.append(emailId);

					if(usrDtlTypeItr.hasNext()) {	
						emailIdsBuilder.append(CVDDMConstant.COMMA);
					}
				}
			}
		}
		catch(Exception ex) {
			log.severe(CvddmUtil.getStackTraceContent(ex));
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
		return emailIdsBuilder;
	}

	/**
	 * Method: removeDuplicateIds
	 * This method would remove Duplicate Email Id's from Input String Builder.
	 * @param StringBuilder tempEmailBuilder
	 * @return StringBuilder
	 * 
	 */

	public StringBuilder removeDuplicateIds(StringBuilder tempEmailBuilder) {

		final String METHOD_NAME = "removeDuplicateIds";
		log.entering(CLASS_NAME, METHOD_NAME);

		StringBuilder emailIdsBuilder = new StringBuilder();

		try {

			if(!CvddmUtil.isObjectEmpty(tempEmailBuilder) 
					&& TextUtil.isNotBlankOrNull(tempEmailBuilder.toString())){

				String [] emailIdArray = tempEmailBuilder.toString().split(CVDDMConstant.COMMA);

				Set<String> emailIdSet = new HashSet<String>();

				if(!CvddmUtil.isArrayEmpty(emailIdArray)) {

					for(int i=0; i < emailIdArray.length; i++) {

						emailIdSet.add(emailIdArray[i]);
					}	
				}

				Iterator <String> emailIdItr = emailIdSet.iterator();

				while(emailIdItr.hasNext()) {

					emailIdsBuilder.append(emailIdItr.next());
					
					if(emailIdItr.hasNext()) {	
						emailIdsBuilder.append(CVDDMConstant.COMMA);
					}
				}
			}
		}
		catch(Exception ex) {
			log.severe(CvddmUtil.getStackTraceContent(ex));
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
		return emailIdsBuilder;
	}
}
