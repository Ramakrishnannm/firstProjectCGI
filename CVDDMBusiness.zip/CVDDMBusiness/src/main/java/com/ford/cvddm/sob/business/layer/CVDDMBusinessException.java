package com.ford.cvddm.sob.business.layer;

import com.ford.cvddm.common.layer.exception.CVDDMBaseRuntimeException;
import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.it.exception.FordExceptionAttributes;

/**
 * Exception to be thrown when Business processing problems occur.
 */
public class CVDDMBusinessException extends CVDDMBaseRuntimeException {

    /**
     * Comment for <code>serialVersionUID</code>
     */
    private static final long serialVersionUID = 1L;

    /**
     * Construct a CVDDMBusinessException instance
     *
     * @param fordExceptionAttributes
     * @param message
     */
    public CVDDMBusinessException(
            final FordExceptionAttributes fordExceptionAttributes,
            final String message) {
        super(fordExceptionAttributes, message);

    }

    /**
     * Construct a CVDDMBusinessException instance
     *
     * @param fordExceptionAttributes
     * @param message
     * @param cause
     */
    public CVDDMBusinessException(
            final FordExceptionAttributes fordExceptionAttributes,
            final String message, final Throwable cause) {
        super(fordExceptionAttributes, message, cause);
        
        /*** Start Change :User Story: US945639 **/
    	//CvddmUtil.sendExceptionEmail(fordExceptionAttributes, message, cause);
    	/*** End Change :User Story: US945639 **/

    }
}
