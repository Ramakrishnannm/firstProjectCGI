/**
 * 
 */
package com.ford.cvddm.region.business.list;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;

import com.ford.cvddm.domain.master.de.CvddmRegionDE;
import com.ford.cvddm.entitymanager.RegionEntityManager;
import com.ford.cvddm.sob.business.layer.CVDDMBaseBF;

/**US1064801
 * Description : Business Facade Class for Regions
 * @author NGUPTA18
 *
 */
public class ListCvddmRegionBF extends CVDDMBaseBF implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Inject
	private RegionEntityManager regionEntityManager;
	
	/**
	 * Method Name: getActiveRegions
	 * 
	 * @Description:This method would fetch all  Active Regions from 
	 *                   PCVDM17_REGION database table.
	 * @param none
	 * @return List<CvddmRegionDE>
	 */
	public List<CvddmRegionDE> getActiveRegions(){

		return regionEntityManager.getActiveRegions();
	}
	
	/*** Start Change :User Story: US1147659 **/
	
	/**
	 * Method Name: fetchRegionById
	 * 
	 * @Description:This method would fetch Active Product Team from 
	 *                   PCVDM17_REGION database table depending on
	 *                   the PK passed.
	 * @param String regionId
	 * @return CvddmRegionDE
	 */
	public CvddmRegionDE fetchRegionById(String regionId) {
		
		return regionEntityManager.fetchRegionById(regionId);
	}
	/*** End Change :User Story: US1147659 **/
}
