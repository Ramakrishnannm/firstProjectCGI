package com.ford.cvddm.gvms.aws;

import java.io.InputStream;

import org.apache.commons.io.IOUtils;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.Protocol;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.S3ClientOptions;
import com.amazonaws.services.s3.model.AmazonS3Exception;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.sob.business.layer.CVDDMBusinessException;
import com.ford.it.exception.FordExceptionAttributes;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;

public class PartIISpecFromAWS {

	/** The Class Name used for Logging */
	private static final String CLASS_NAME = PartIISpecFromAWS.class.getName();

	/** The Logger instance used for Logging */
	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	// Connecting AWS
	private static final String S3SIGNER = "S3SignerType";
	private static final boolean PATHSTYLEACCESS = true;

	/**
	 * Connecting AWS and gets MDX file
	 * 
	 * @return
	 */
	public byte[] getPartIISpecFromAWS(String key) {

		final String METHOD_NAME = "getPartIISpecFromAWS";
		log.entering(CLASS_NAME, METHOD_NAME);

		AWSCredentials aWSCredentials = null;
		ClientConfiguration config = null;
		S3ClientOptions options = null;
		AmazonS3 amazons3 = null;

		S3Object amazonS3Object = null;
		InputStream inputStreamAWS = null;
		byte[] bytes = null;

		try {

			aWSCredentials = new BasicAWSCredentials(
					CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
							CVDDMConstant.AWS_ACCESS_KEY),
					CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
							CVDDMConstant.AWS_SECRET_KEY));

			config = new ClientConfiguration();
			config.withProtocol(Protocol.HTTPS);
			config.setSignerOverride(S3SIGNER);

			options = new S3ClientOptions();
			options.setPathStyleAccess(PATHSTYLEACCESS);

			amazons3 = new AmazonS3Client(aWSCredentials, config);
			amazons3.setEndpoint(CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
					CVDDMConstant.AWS_END_POINT));
			amazons3.setS3ClientOptions(options);

			log.info("AWS connection created successfully");

			amazonS3Object = amazons3.getObject(new GetObjectRequest(CvddmUtil.getPropertiesValue(
					CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, CVDDMConstant.AWS_BUCKET_NAME), key));
			inputStreamAWS = amazonS3Object.getObjectContent();
			bytes = IOUtils.toByteArray(inputStreamAWS);
			log.info("AWS connection tested successfully -> Tested output = " + bytes);

		} catch (AmazonS3Exception ie) {
			if (ie.getErrorMessage().contains("The specified key does not exist")) {
				log.severe(CvddmUtil.getStackTraceContent(ie));
				return null;
			} else {
				throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
						CvddmUtil.getStackTraceContent(ie), ie);
			}
		} catch (Exception ie) {

			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(ie), ie);

		}

		log.exiting(CLASS_NAME, METHOD_NAME);

		return bytes;
	}

}
