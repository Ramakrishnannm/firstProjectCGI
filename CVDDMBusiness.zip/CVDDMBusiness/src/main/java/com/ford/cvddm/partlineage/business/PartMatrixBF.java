package com.ford.cvddm.partlineage.business;

import java.io.Serializable;
import java.util.List;

import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;

import com.ford.cvddm.domain.application.de.CvddmPartMatrixReferenceCSVUploadDE;
import com.ford.cvddm.entitymanager.PartMatrixEntityManager;
import com.ford.cvddm.sob.business.layer.CVDDMBaseBF;

/**
 * Description : Business Facade Class for Part Matrix Functionality.
 * 
 * @author MJEYARAJ
 *
 */
@SessionScoped
public class PartMatrixBF extends CVDDMBaseBF implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private PartMatrixEntityManager partMatrixEntityManager;

	/**
	 * Method Name: fetchAllPartMatrixRcrds
	 * 
	 * @Description:This method would fetch all part matrix Records from
	 *                   PCVDM21_PART_MATRIX database table.
	 * 
	 * @param None
	 * @return List<CvddmPartMatrixReferenceCSVUploadDE>
	 */
	public List<CvddmPartMatrixReferenceCSVUploadDE> fetchAllPartMatrixRcrds() {

		return partMatrixEntityManager.fetchAllRecords();
	}

}