package com.ford.cvddm.app.business.list;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;

import com.ford.cvddm.domain.application.de.CvddmFeedbackRcrdDE;
import com.ford.cvddm.domain.master.de.CvddmScreenInfoDE;
import com.ford.cvddm.entitymanager.FeedbackEntityManager;
import com.ford.cvddm.sob.business.layer.CVDDMBaseBF;

/**
 * Description : Business Facade Class for FeedBack Functionality.
 * 
 * RPADI
 *
 */
@SessionScoped
public class ListCvddmFeebackBF extends CVDDMBaseBF implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private FeedbackEntityManager feedbackEntityManager;

	/**
	 * Method Name: retrieveAllScreens
	 * 
	 * @Description:This method would fetch all CVDDM Pages. from
	 *                   PCVDM01_SCREEN_INFO database table.
	 * @param none
	 * @return List<CvddmScreenInfoDE>
	 */
	public List<CvddmScreenInfoDE> retrieveAllScreens() {

		return feedbackEntityManager.retrieveAllScreens();
	}

	/**
	 * Method Name: saveCvddmFeedbackRcrd
	 * 
	 * @Description:This method would create a New FeedBack Record in
	 *                   dbo.PCVDM09_FDBK; database table.
	 * @param Map
	 *            <String, Object> inputMap
	 * @return CvddmMaintRcrdDE
	 */
	public CvddmFeedbackRcrdDE saveCvddmFeedbackRcrd(Map<String, Object> inputDataMap) {

		return feedbackEntityManager.saveCvddmFeedbackRcrd(inputDataMap);
	}

	/**
	 * Method Name: retrieveAllScreens
	 * 
	 * @Description:This method would fetch Selected Screen Name from
	 *                   PCVDM01_SCREEN_INFO database table.
	 * 
	 */
	public String retrieveSelectedScreenNameId(String pageName) {

		return feedbackEntityManager.retrieveSelectedScreenNameId(pageName);
	}

}