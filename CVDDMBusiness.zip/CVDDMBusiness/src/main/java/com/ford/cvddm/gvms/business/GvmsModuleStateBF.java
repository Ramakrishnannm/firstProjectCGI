package com.ford.cvddm.gvms.business;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.enterprise.context.SessionScoped;
import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.outbound.gvms.moduleState.DIDInfoType;
import com.ford.cvddm.outbound.gvms.moduleState.ECUAcronymType;
import com.ford.cvddm.outbound.gvms.moduleState.GatewayType;
import com.ford.cvddm.outbound.gvms.moduleState.HistoricType;
import com.ford.cvddm.outbound.gvms.moduleState.ModuleNameENUMType;
import com.ford.cvddm.outbound.gvms.moduleState.ModuleNodeType;
import com.ford.cvddm.outbound.gvms.moduleState.ModuleODLNetworkType;
import com.ford.cvddm.outbound.gvms.moduleState.ModuleSnapshotType;
import com.ford.cvddm.outbound.gvms.moduleState.ModuleStateRequest;
import com.ford.cvddm.outbound.gvms.moduleState.RoleENUMType;
import com.ford.cvddm.outbound.gvms.moduleState.RoleSourceENUMType;
import com.ford.cvddm.outbound.gvms.moduleState.StateUpdateRoleType;
import com.ford.cvddm.outbound.layer.CVDDMConsumerAS;
import com.ford.cvddm.sob.business.layer.CVDDMBaseBF;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;
import com.ford.it.util.TextUtil;
import com.ford.it.wscore.consumer.as.WscBaseGenericConsumerAS;

/**
 * This concrete class provides business functionality to the Presentation Layer
 *  while 'hiding' the technology specific Application Service instances.
 *  This Class would invoke GVMS IBM API Connect - Module State SOA Service.
 *  User Story : US947738
 * @author NGUPTA18
 *
 */
@SessionScoped
public class GvmsModuleStateBF extends CVDDMBaseBF implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** The Class Name used for Logging */
	private static final String CLASS_NAME = GvmsModuleStateBF.class.getName();

	/** The Logger instance used for Logging */
	private static final ILogger log =
			LogFactory.getInstance().getLogger(CLASS_NAME);

	/**
	 * Instance of the Consumer AS needed to interact with the Module StateService
	 */
	private WscBaseGenericConsumerAS cvddmConsumerAS;

	/**
	 * @return Returns the cvddmConsumerAS.
	 */
	public WscBaseGenericConsumerAS getCvddmConsumerAS(String consumerType) {

		this.cvddmConsumerAS = new CVDDMConsumerAS(consumerType);
		return this.cvddmConsumerAS;
	}

	/**
	 * @param CVDDMConsumerAS The cvddmConsumerAS to set.
	 */
	public void setCVDDMConsumerAS(final WscBaseGenericConsumerAS cvddmConsumerAS) {
		this.cvddmConsumerAS = cvddmConsumerAS;
	}

	/**
	 * This method would push Analyze Log Details to GVMS using Module State SOA Service.
	 * @param Map <String, Object> inputMap
	 * @return boolean
	 */

	public boolean pushAnalyzeLogtoGVMS(Map <String, Object> inputMap) {

		boolean isDataPushed = false;

		final String METHOD_NAME = "pushAnalyzeLogtoGVMS";
		log.entering(CLASS_NAME, METHOD_NAME);

		String env = (String) inputMap.get(CVDDMConstant.ENV_TYPE);


		ModuleStateRequest moduleStateRequest = null;

		try {

			if(TextUtil.isBlankOrNull(env)) {

				env = CVDDMConstant.ENV_QA1;
			}

			moduleStateRequest = populateModuleStateRequest(inputMap);

			if(!CvddmUtil.isObjectEmpty(moduleStateRequest)) {

				if(CVDDMConstant.ENV_QA1.equalsIgnoreCase(env)) {

					getCvddmConsumerAS(CVDDMConstant.MODULE_STATE_SERVICE_CONFIG_QA1).processConsumer(
							"AnalyzeModuleState", moduleStateRequest);
				}
				else {

					getCvddmConsumerAS(CVDDMConstant.MODULE_STATE_SERVICE_CONFIG_QA2).processConsumer(
							"AnalyzeModuleState", moduleStateRequest);
				}

				isDataPushed = true;
			}

		}
		catch(Exception ex) {  		
			isDataPushed = false;
			log.severe(CvddmUtil.getStackTraceContent(ex));
		}
		log.exiting(CLASS_NAME, METHOD_NAME);    	
		return isDataPushed;
	}

	/**
	 * This method would populate ModuleStateRequest Object with details provided by the 
	 * User so as to run Analyze Log.
	 * @param Map <String, Object> inputMap
	 * @return ModuleStateRequest
	 */

	public ModuleStateRequest populateModuleStateRequest(Map <String, Object> inputMap) {

		final String METHOD_NAME = "populateModuleStateRequest";
		log.entering(CLASS_NAME, METHOD_NAME);

		ModuleStateRequest moduleStateRequest = new ModuleStateRequest();

		ModuleSnapshotType  snapshotType = new ModuleSnapshotType();

		boolean isTCUPresent = false;

		boolean isSyncPresent = false;

		boolean isBlemPresent = false;

		boolean isECGPresent = false;
		
		ModuleNodeType moduleNodeType = new ModuleNodeType();
		
		
		List<ModuleNodeType> vinNodeList = snapshotType.getNode();
		
		try {

			if(!CvddmUtil.isObjectEmpty(inputMap) && !inputMap.isEmpty()) {

				
				String vinNumber = (String) inputMap.get(CVDDMConstant.VIN_NUMBER);

				snapshotType.setModuleName(ModuleNameENUMType.ECU);
				
				snapshotType.setVIN(vinNumber);

				StateUpdateRoleType roleType = new StateUpdateRoleType();

				roleType.setRole(RoleENUMType.DEALER);

				roleType.setRoleSource(RoleSourceENUMType.PTS);

				roleType.setRoleDesc(CVDDMConstant.MODULE_STATE_ROLE_DESC);

				roleType.setRoleID(CVDDMConstant.MODULE_STATE_ROLE_ID);

				snapshotType.setRequestRole(roleType);
				
				isTCUPresent = (boolean)inputMap.get(CVDDMConstant.IS_TCU_PRESENT);

				if(isTCUPresent) {
					
					moduleNodeType = prepareModuleNodeType(inputMap);

					vinNodeList.add(moduleNodeType);
				}


				isSyncPresent = (boolean)inputMap.get(CVDDMConstant.IS_SYNC_PRESENT);

				if(isSyncPresent) {
					
					moduleNodeType = prepareModuleNodeType(inputMap);

					vinNodeList.add(moduleNodeType);

				}

				isBlemPresent = (boolean)inputMap.get(CVDDMConstant.IS_BLEM_PRESENT);

				if(isBlemPresent) {
					
					moduleNodeType = prepareModuleNodeType(inputMap);

					vinNodeList.add(moduleNodeType);

				}

				isECGPresent = (boolean)inputMap.get(CVDDMConstant.IS_ECG_PRESENT);

				if(isECGPresent) {

					moduleNodeType = prepareModuleNodeType(inputMap);

					vinNodeList.add(moduleNodeType);

				}
			}
			
			snapshotType.getNode().addAll(vinNodeList);
			moduleStateRequest.setModuleSnapshot(snapshotType);
		}
		
		

		catch(Exception ex) {  		
			log.severe(CvddmUtil.getStackTraceContent(ex));
		}

		log.exiting(CLASS_NAME, METHOD_NAME);
		return moduleStateRequest;
	}
	
	
	/**
	 * This method would populate prepare ModuleNodeType Object with details provided by the 
	 * User for the respective TCU, BLEM, SYNC and ECG Module.
	 * @param Map <String, Object> inputMap
	 * @return ModuleNodeType
	 */
	
	@SuppressWarnings("unchecked")
	public ModuleNodeType prepareModuleNodeType(Map <String, Object> inputMap) {
		
		final String METHOD_NAME = "prepareModuleNodeType";
		log.entering(CLASS_NAME, METHOD_NAME);
		
		ModuleNodeType moduleNodeType =  new ModuleNodeType();
		
		ModuleODLNetworkType  networkType = new ModuleODLNetworkType();

		boolean isTCUPresent = false;

		boolean isSyncPresent = false;

		boolean isBlemPresent = false;

		boolean isECGPresent = false;
		
		Map <String, String> partDetails = new LinkedHashMap<String, String>();
		
		try {
			

			moduleNodeType.setIsFlashed(false);
			
			moduleNodeType.setSpecificationCategory(CVDDMConstant.SPEC_CATEGORY_VAL);
			
			isTCUPresent = (boolean)inputMap.get(CVDDMConstant.IS_TCU_PRESENT);
			isECGPresent = (boolean)inputMap.get(CVDDMConstant.IS_ECG_PRESENT);
			isBlemPresent = (boolean)inputMap.get(CVDDMConstant.IS_BLEM_PRESENT);
			isSyncPresent = (boolean)inputMap.get(CVDDMConstant.IS_SYNC_PRESENT);
			
			if(isTCUPresent) {
				
				partDetails = (Map<String, String>)inputMap.get(CVDDMConstant.TCU_PART_NUMBERS);
				
				if(!partDetails.isEmpty()) {
					
					moduleNodeType.setAddress(CVDDMConstant.TCU_CD);					
					networkType.setNetworkName("HS1");
					networkType.setNetworkProtocol("CAN");
					networkType.setNetworkDataRate("500");			
					moduleNodeType.setODLNetwork(networkType);	
								
					ECUAcronymType ecuAcronymType = new ECUAcronymType();
					
					ecuAcronymType.setName(CVDDMConstant.LBL_TCU);
					
					HistoricType historicType = new HistoricType();
					
					GatewayType gatewayType = new GatewayType();
					
					gatewayType.setGatewayType(CVDDMConstant.NONE);
					
					List<DIDInfoType> didInfoTypes = gatewayType.getDID();
					
					
					for (Map.Entry<String,String> entrySet : partDetails.entrySet()) {

						if(CVDDMConstant.CD_F10A.equalsIgnoreCase(entrySet.getKey())) {

							DIDInfoType didInfoType = new DIDInfoType();

							didInfoType.setDidValue(CVDDMConstant.CD_F10A);
							didInfoType.setDidType(CVDDMConstant.DESC_F10A);
							didInfoType.setResponse(entrySet.getValue());
							didInfoType.setIsConfig(false); 
							didInfoTypes.add(didInfoType);
						}
						if(CVDDMConstant.CD_F110.equalsIgnoreCase(entrySet.getKey())) {

							DIDInfoType didInfoType = new DIDInfoType();

							didInfoType.setDidValue(CVDDMConstant.CD_F110);
							didInfoType.setDidType(CVDDMConstant.DESC_F110);
							didInfoType.setResponse(entrySet.getValue());
							didInfoType.setIsConfig(false);
							didInfoTypes.add(didInfoType);
						}
						if(CVDDMConstant.CD_F111.equalsIgnoreCase(entrySet.getKey())) {

							DIDInfoType didInfoType = new DIDInfoType();

							didInfoType.setDidValue(CVDDMConstant.CD_F111);
							didInfoType.setDidType(CVDDMConstant.DESC_F111);
							didInfoType.setResponse(entrySet.getValue());
							didInfoType.setIsConfig(false);
							didInfoTypes.add(didInfoType);
						}
						if(CVDDMConstant.CD_F113.equalsIgnoreCase(entrySet.getKey())) {

							DIDInfoType didInfoType = new DIDInfoType();

							didInfoType.setDidValue(CVDDMConstant.CD_F113);
							didInfoType.setDidType(CVDDMConstant.DESC_F113);
							didInfoType.setResponse(entrySet.getValue());
							didInfoType.setIsConfig(false);
							didInfoTypes.add(didInfoType);
						}
						if(CVDDMConstant.CD_F188.equalsIgnoreCase(entrySet.getKey())) {

							DIDInfoType didInfoType = new DIDInfoType();

							didInfoType.setDidValue(CVDDMConstant.CD_F188);
							didInfoType.setDidType(CVDDMConstant.DESC_F188);
							didInfoType.setResponse(entrySet.getValue());
							didInfoType.setIsConfig(false);
							didInfoTypes.add(didInfoType);
						}
						
						if(CVDDMConstant.CD_F18C.equalsIgnoreCase(entrySet.getKey())) {

							DIDInfoType didInfoType = new DIDInfoType();

							didInfoType.setDidValue(CVDDMConstant.CD_F18C);
							didInfoType.setDidType(CVDDMConstant.DESC_F18C);
							didInfoType.setResponse(entrySet.getValue());
							didInfoType.setIsConfig(false);
							didInfoTypes.add(didInfoType);
						}
						
						if(CVDDMConstant.CD_DE00.equalsIgnoreCase(entrySet.getKey())) {

							DIDInfoType didInfoType = new DIDInfoType();

							didInfoType.setDidValue(CVDDMConstant.CD_DE00);
							didInfoType.setDidType(CVDDMConstant.DESC_DE00);
							didInfoType.setResponse(entrySet.getValue()); // Need to Generate
							didInfoType.setIsConfig(true);
							didInfoTypes.add(didInfoType);
						}
						
						if(CVDDMConstant.CD_DE01.equalsIgnoreCase(entrySet.getKey())) {

							DIDInfoType didInfoType = new DIDInfoType();

							didInfoType.setDidValue(CVDDMConstant.CD_DE01);
							didInfoType.setDidType(CVDDMConstant.DESC_DE01);
							didInfoType.setResponse(entrySet.getValue()); // Need to Generate
							didInfoType.setIsConfig(true);
							didInfoTypes.add(didInfoType);
						}

					}
					
					gatewayType.getDID().addAll(didInfoTypes);
			            
					historicType.getGateway().add(gatewayType);
					
					ecuAcronymType.getState().add(historicType);

					moduleNodeType.getECUAcronym().add(ecuAcronymType);
				}
			}
			
			if(isSyncPresent) {

				partDetails = (Map<String,String>)inputMap.get(CVDDMConstant.SYNC_PART_NUMBERS);

				if(!partDetails.isEmpty()) {

					moduleNodeType.setAddress(CVDDMConstant.SYNC_CD);					
					networkType.setNetworkName("HS1");
					networkType.setNetworkProtocol("CAN");
					networkType.setNetworkDataRate("500");			
					moduleNodeType.setODLNetwork(networkType);

					ECUAcronymType ecuAcronymType = new ECUAcronymType();

					ecuAcronymType.setName(CVDDMConstant.LBL_APIM);

					HistoricType historicType = new HistoricType();

					GatewayType gatewayType = new GatewayType();

					gatewayType.setGatewayType(CVDDMConstant.NONE);

					List<DIDInfoType> didInfoTypes = gatewayType.getDID();


					for (Map.Entry<String,String> entrySet : partDetails.entrySet()) {

						if(CVDDMConstant.CD_F10A.equalsIgnoreCase(entrySet.getKey())) {

							DIDInfoType didInfoType = new DIDInfoType();

							didInfoType.setDidValue(CVDDMConstant.CD_F10A);
							didInfoType.setDidType(CVDDMConstant.DESC_F10A);
							didInfoType.setResponse(entrySet.getValue());
							didInfoType.setIsConfig(false); 
							didInfoTypes.add(didInfoType);
						}
						if(CVDDMConstant.CD_F110.equalsIgnoreCase(entrySet.getKey())) {

							DIDInfoType didInfoType = new DIDInfoType();

							didInfoType.setDidValue(CVDDMConstant.CD_F110);
							didInfoType.setDidType(CVDDMConstant.DESC_F110);
							didInfoType.setResponse(entrySet.getValue());
							didInfoType.setIsConfig(false);
							didInfoTypes.add(didInfoType);
						}
						if(CVDDMConstant.CD_F111.equalsIgnoreCase(entrySet.getKey())) {

							DIDInfoType didInfoType = new DIDInfoType();

							didInfoType.setDidValue(CVDDMConstant.CD_F111);
							didInfoType.setDidType(CVDDMConstant.DESC_F111);
							didInfoType.setResponse(entrySet.getValue());
							didInfoType.setIsConfig(false);
							didInfoTypes.add(didInfoType);
						}
						if(CVDDMConstant.CD_F113.equalsIgnoreCase(entrySet.getKey())) {

							DIDInfoType didInfoType = new DIDInfoType();

							didInfoType.setDidValue(CVDDMConstant.CD_F113);
							didInfoType.setDidType(CVDDMConstant.DESC_F113);
							didInfoType.setResponse(entrySet.getValue());
							didInfoType.setIsConfig(false);
							didInfoTypes.add(didInfoType);
						}
						if(CVDDMConstant.CD_F188.equalsIgnoreCase(entrySet.getKey())) {

							DIDInfoType didInfoType = new DIDInfoType();

							didInfoType.setDidValue(CVDDMConstant.CD_F188);
							didInfoType.setDidType(CVDDMConstant.DESC_F188);
							didInfoType.setResponse(entrySet.getValue());
							didInfoType.setIsConfig(false);
							didInfoTypes.add(didInfoType);
						}

						if(CVDDMConstant.CD_F16B.equalsIgnoreCase(entrySet.getKey())) {

							DIDInfoType didInfoType = new DIDInfoType();

							didInfoType.setDidValue(CVDDMConstant.CD_F16B);
							didInfoType.setDidType(CVDDMConstant.DESC_F16B);
							didInfoType.setResponse(entrySet.getValue());
							didInfoType.setIsConfig(false);
							didInfoTypes.add(didInfoType);
						}
						if(CVDDMConstant.CD_DE00.equalsIgnoreCase(entrySet.getKey())) {

							DIDInfoType didInfoType = new DIDInfoType();

							didInfoType.setDidValue(CVDDMConstant.CD_DE00);
							didInfoType.setDidType(CVDDMConstant.DESC_DE00);
							didInfoType.setResponse(entrySet.getValue()); // Need to Generate
							didInfoType.setIsConfig(true);
							didInfoTypes.add(didInfoType);
						}
						
						if(CVDDMConstant.CD_DE01.equalsIgnoreCase(entrySet.getKey())) {

							DIDInfoType didInfoType = new DIDInfoType();

							didInfoType.setDidValue(CVDDMConstant.CD_DE01);
							didInfoType.setDidType(CVDDMConstant.DESC_DE01);
							didInfoType.setResponse(entrySet.getValue()); // Need to Generate
							didInfoType.setIsConfig(true);
							didInfoTypes.add(didInfoType);
						}
						if(CVDDMConstant.CD_F124.equalsIgnoreCase(entrySet.getKey())) {

							DIDInfoType didInfoType = new DIDInfoType();

							didInfoType.setDidValue(CVDDMConstant.CD_F124);
							didInfoType.setDidType(CVDDMConstant.DESC_F124);
							didInfoType.setResponse(entrySet.getValue());
							didInfoType.setIsConfig(false);
							didInfoTypes.add(didInfoType);
						}
						
						if(CVDDMConstant.CD_8060.equalsIgnoreCase(entrySet.getKey())) {

							DIDInfoType didInfoType = new DIDInfoType();

							didInfoType.setDidValue(CVDDMConstant.CD_8060);
							didInfoType.setDidType(CVDDMConstant.DESC_8060);
							didInfoType.setResponse(entrySet.getValue());
							didInfoType.setIsConfig(false);
							didInfoTypes.add(didInfoType);
						}
						
						if(CVDDMConstant.CD_F141.equalsIgnoreCase(entrySet.getKey())) {

							DIDInfoType didInfoType = new DIDInfoType();

							didInfoType.setDidValue(CVDDMConstant.CD_F141);
							didInfoType.setDidType(CVDDMConstant.DESC_F141);
							didInfoType.setResponse(entrySet.getValue());
							didInfoType.setIsConfig(false);
							didInfoTypes.add(didInfoType);
						}
						
						if(CVDDMConstant.CD_8033.equalsIgnoreCase(entrySet.getKey())) {

							DIDInfoType didInfoType = new DIDInfoType();

							didInfoType.setDidValue(CVDDMConstant.CD_8033);
							didInfoType.setDidType(CVDDMConstant.DESC_8033);
							didInfoType.setResponse(entrySet.getValue());
							didInfoType.setIsConfig(false);
							didInfoTypes.add(didInfoType);
						}

					}

					gatewayType.getDID().addAll(didInfoTypes);

					historicType.getGateway().add(gatewayType);

					ecuAcronymType.getState().add(historicType);

					moduleNodeType.getECUAcronym().add(ecuAcronymType);
				}
			}
			
			if(isBlemPresent) {
				
				partDetails = (Map<String,String>)inputMap.get(CVDDMConstant.BLEM_PART_NUMBERS);

				if(!partDetails.isEmpty()) {

					moduleNodeType.setAddress(CVDDMConstant.BLEM_CD);					
					networkType.setNetworkName("HS1");
					networkType.setNetworkProtocol("CAN");
					networkType.setNetworkDataRate("125");			
					moduleNodeType.setODLNetwork(networkType);

					ECUAcronymType ecuAcronymType = new ECUAcronymType();

					ecuAcronymType.setName(CVDDMConstant.LBL_RFA);

					HistoricType historicType = new HistoricType();

					GatewayType gatewayType = new GatewayType();

					gatewayType.setGatewayType(CVDDMConstant.NONE);

					List<DIDInfoType> didInfoTypes = gatewayType.getDID();


					for (Map.Entry<String,String> entrySet : partDetails.entrySet()) {

						if(CVDDMConstant.CD_F10A.equalsIgnoreCase(entrySet.getKey())) {

							DIDInfoType didInfoType = new DIDInfoType();

							didInfoType.setDidValue(CVDDMConstant.CD_F10A);
							didInfoType.setDidType(CVDDMConstant.DESC_F10A);
							didInfoType.setResponse(entrySet.getValue());
							didInfoType.setIsConfig(false); 
							didInfoTypes.add(didInfoType);
						}
						if(CVDDMConstant.CD_F110.equalsIgnoreCase(entrySet.getKey())) {

							DIDInfoType didInfoType = new DIDInfoType();

							didInfoType.setDidValue(CVDDMConstant.CD_F110);
							didInfoType.setDidType(CVDDMConstant.DESC_F110);
							didInfoType.setResponse(entrySet.getValue());
							didInfoType.setIsConfig(false);
							didInfoTypes.add(didInfoType);
						}
						if(CVDDMConstant.CD_F111.equalsIgnoreCase(entrySet.getKey())) {

							DIDInfoType didInfoType = new DIDInfoType();

							didInfoType.setDidValue(CVDDMConstant.CD_F111);
							didInfoType.setDidType(CVDDMConstant.DESC_F111);
							didInfoType.setResponse(entrySet.getValue());
							didInfoType.setIsConfig(false);
							didInfoTypes.add(didInfoType);
						}
						if(CVDDMConstant.CD_F113.equalsIgnoreCase(entrySet.getKey())) {

							DIDInfoType didInfoType = new DIDInfoType();

							didInfoType.setDidValue(CVDDMConstant.CD_F113);
							didInfoType.setDidType(CVDDMConstant.DESC_F113);
							didInfoType.setResponse(entrySet.getValue());
							didInfoType.setIsConfig(false);
							didInfoTypes.add(didInfoType);
						}
						if(CVDDMConstant.CD_F188.equalsIgnoreCase(entrySet.getKey())) {

							DIDInfoType didInfoType = new DIDInfoType();

							didInfoType.setDidValue(CVDDMConstant.CD_F188);
							didInfoType.setDidType(CVDDMConstant.DESC_F188);
							didInfoType.setResponse(entrySet.getValue());
							didInfoType.setIsConfig(false);
							didInfoTypes.add(didInfoType);
						}

						if(CVDDMConstant.CD_F18C.equalsIgnoreCase(entrySet.getKey())) {

							DIDInfoType didInfoType = new DIDInfoType();

							didInfoType.setDidValue(CVDDMConstant.CD_F18C);
							didInfoType.setDidType(CVDDMConstant.DESC_F18C);
							didInfoType.setResponse(entrySet.getValue());
							didInfoType.setIsConfig(false);
							didInfoTypes.add(didInfoType);
						}
						if(CVDDMConstant.CD_F120.equalsIgnoreCase(entrySet.getKey())) {

							DIDInfoType didInfoType = new DIDInfoType();

							didInfoType.setDidValue(CVDDMConstant.CD_F120);
							didInfoType.setDidType(CVDDMConstant.DESC_F120);
							didInfoType.setResponse(entrySet.getValue());
							didInfoType.setIsConfig(false); 
							didInfoTypes.add(didInfoType);
						}
						
						if(CVDDMConstant.CD_F124.equalsIgnoreCase(entrySet.getKey())) {

							DIDInfoType didInfoType = new DIDInfoType();

							didInfoType.setDidValue(CVDDMConstant.CD_F124);
							didInfoType.setDidType(CVDDMConstant.DESC_F124);
							didInfoType.setResponse(entrySet.getValue());
							didInfoType.setIsConfig(false); 
							didInfoTypes.add(didInfoType);
						}
					}

					gatewayType.getDID().addAll(didInfoTypes);

					historicType.getGateway().add(gatewayType);

					ecuAcronymType.getState().add(historicType);

					moduleNodeType.getECUAcronym().add(ecuAcronymType);
				}			
			}
			
          if(isECGPresent) {
				
        	  partDetails = (Map<String,String>)inputMap.get(CVDDMConstant.ECG_PART_NUMBERS);

				if(!partDetails.isEmpty()) {

					moduleNodeType.setAddress(CVDDMConstant.ECG_CD);					
					networkType.setNetworkName("HS1");
					networkType.setNetworkProtocol("CAN");
					networkType.setNetworkDataRate("125");			
					moduleNodeType.setODLNetwork(networkType);	
				}	
			}
		}
		
		catch(Exception ex) {  		
			log.severe(CvddmUtil.getStackTraceContent(ex));
		}
		
		log.exiting(CLASS_NAME, METHOD_NAME);
		return moduleNodeType;
		
	}
	
	
	

}