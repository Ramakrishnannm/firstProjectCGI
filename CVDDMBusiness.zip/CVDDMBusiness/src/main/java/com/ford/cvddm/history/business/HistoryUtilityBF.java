package com.ford.cvddm.history.business;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;

import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.domain.history.de.CvddmPartIISpecHistoryDE;
import com.ford.cvddm.domain.history.de.CvddmVINHistoryDE;
import com.ford.cvddm.entitymanager.HistoryEntityManager;
import com.ford.cvddm.sob.business.layer.CVDDMBaseBF;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;
import com.ford.it.util.TextUtil;

/**
 * This class is for - US1108103 Description : Business class to save ANY
 * History record
 * 
 * @author MJEYARAJ
 *
 */
@SessionScoped
public class HistoryUtilityBF extends CVDDMBaseBF implements Serializable {

	private static final long serialVersionUID = 1L;

	private static final String CLASS_NAME = HistoryUtilityBF.class.getName();
	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	@Inject
	private HistoryEntityManager historyEntityManager;

	/**
	 * Business utility to save VIN History record. InputMap should contains valid
	 * HISTORY_UTILITY_ENVIRONMENT_ID, HISTORY_UTILITY_APPLICATION_ID,
	 * HISTORY_UTILITY_VIN, HISTORY_UTILITY_WEBSERVICE_STATUS and
	 * HISTORY_UTILITY_WEBSERVICE_NUMBER
	 * 
	 * Note: HISTORY_UTILITY_ENVIRONMENT_ID and HISTORY_UTILITY_APPLICATION_ID are
	 * ID's not values. ID's are available in ApplicationConfiguration.properties
	 * for every applications and environments.
	 * 
	 * @param inputMap
	 * @return
	 */
	public CvddmVINHistoryDE saveVINHistoryRcrd(Map<String, String> inputMap) {

		try {

			// Environment utility ID is available in ApplicationConfiguration.properties
			// mapped as HISTORY_UTILITY_ENV_*
			String envUtilityId = inputMap.get(CVDDMConstant.HISTORY_UTILITY_ENVIRONMENT_ID);

			// Application utility ID is available in ApplicationConfiguration.properties
			// mapped as HISTORY_UTILITY_APP_*
			String appUtilityId = inputMap.get(CVDDMConstant.HISTORY_UTILITY_APPLICATION_ID);

			String vINNumber = inputMap.get(CVDDMConstant.HISTORY_UTILITY_VIN);
			String webserviceStatus = inputMap.get(CVDDMConstant.HISTORY_UTILITY_WEBSERVICE_STATUS);
			String webserviceError = inputMap.get(CVDDMConstant.HISTORY_UTILITY_WEBSERVICE_ERROR);

			if (TextUtil.isNotBlankOrNull(envUtilityId) && TextUtil.isNotBlankOrNull(appUtilityId)
					&& TextUtil.isNotBlankOrNull(vINNumber) && TextUtil.isNotBlankOrNull(webserviceStatus)
					&& TextUtil.isNotBlankOrNull(webserviceError)) {

				return historyEntityManager.saveVINHistoryRcrd(CvddmUtil.getLoggedInUserCDSID(),
						new Timestamp(System.currentTimeMillis()), envUtilityId, appUtilityId, vINNumber,
						webserviceStatus, webserviceError);
			} else {
				return null;
			}
		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			return null;
		}

	}

	/**
	 * Business utility to save Part II Spec History record. InputMap should
	 * contains valid HISTORY_UTILITY_ENVIRONMENT_ID,
	 * HISTORY_UTILITY_APPLICATION_ID, HISTORY_UTILITY_PARTIISPEC,
	 * HISTORY_UTILITY_WEBSERVICE_STATUS and HISTORY_UTILITY_WEBSERVICE_NUMBER
	 * 
	 * Note: HISTORY_UTILITY_ENVIRONMENT_ID and HISTORY_UTILITY_APPLICATION_ID are
	 * ID's not values. ID's are available in ApplicationConfiguration.properties
	 * for every applications and environments.
	 * 
	 * @param inputMap
	 * @return
	 */
	public CvddmPartIISpecHistoryDE savePartIISpecHistoryRcrd(Map<String, String> inputMap) {

		try {

			// Environment utility ID is available in ApplicationConfiguration.properties
			// mapped as HISTORY_UTILITY_ENV_*
			String envUtilityId = inputMap.get(CVDDMConstant.HISTORY_UTILITY_ENVIRONMENT_ID);

			// Application utility ID is available in ApplicationConfiguration.properties
			// mapped as HISTORY_UTILITY_APP_*
			String appUtilityId = inputMap.get(CVDDMConstant.HISTORY_UTILITY_APPLICATION_ID);

			String partIISpec = inputMap.get(CVDDMConstant.HISTORY_UTILITY_PARTIISPEC);
			String webserviceStatus = inputMap.get(CVDDMConstant.HISTORY_UTILITY_WEBSERVICE_STATUS);
			String webserviceError = inputMap.get(CVDDMConstant.HISTORY_UTILITY_WEBSERVICE_ERROR);

			if (TextUtil.isNotBlankOrNull(envUtilityId) && TextUtil.isNotBlankOrNull(appUtilityId)
					&& TextUtil.isNotBlankOrNull(partIISpec) && TextUtil.isNotBlankOrNull(webserviceStatus)
					&& TextUtil.isNotBlankOrNull(webserviceError)) {

				return historyEntityManager.savePartIISpecHistoryRcrd(CvddmUtil.getLoggedInUserCDSID(),
						new Timestamp(System.currentTimeMillis()), envUtilityId, appUtilityId, partIISpec,
						webserviceStatus, webserviceError);
			} else {
				return null;
			}
		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			return null;
		}

	}

	/*** Start Change : User Story : US1078610 *****/

	/**
	 * Method Name: getValidationHistoryRcrds
	 * 
	 * @Description:This method would fetch all VIN History from
	 *                   PCVDM08_VEH_DATA_VLDTN_REQ database table for input app id.
	 * @param String
	 *            appId
	 * @return List<CvddmVINHistoryDE>
	 */
	public List<CvddmVINHistoryDE> getValidationHistoryRcrds(String appId) {

		return historyEntityManager.getValidationHistoryRcrds(appId);
	}

	/**
	 * @Description:This method would fetch all PartIISpec History from
	 *                   PCVDM22_PART_DATA_VLDTN_REQ database table for input app id.
	 * @param appId
	 * @return List<List<CvddmVINHistoryDE>>
	 */
	
	public List<CvddmPartIISpecHistoryDE> getValidationPartIISpecHistoryRcrds(String appId) {

		return historyEntityManager.getValidationPartIISpecHistoryRcrds(appId);
	}

	/**
	 * Method Name: getValidationHistoryRcrdsByDate
	 * 
	 * @Description:This method would fetch all VIN History from
	 *                   PCVDM08_VEH_DATA_VLDTN_REQ database table for input appId,
	 *                   Timestamp fromDate, Timestamp toDate.
	 * @param String
	 *            String appId,Timestamp fromDate, Timestamp toDate
	 * @return List<CvddmVINHistoryDE>
	 */
	public List<CvddmVINHistoryDE> getValidationHistoryRcrdsByDate(String appId, Timestamp fromDate, Timestamp toDate) {

		return historyEntityManager.getValidationHistoryRcrdsByDate(appId, fromDate, toDate);
	}

	/**
	 * Method Name: getValidationHistoryRcrdsByOptions
	 * 
	 * @Description:This method would fetch all VIN History from
	 *                   PCVDM08_VEH_DATA_VLDTN_REQ database table any input appId,
	 *                   Timestamp fromDate, Timestamp toDate.String
	 *                   vinNumber,String env
	 * @param String
	 *            appId,Timestamp fromDate, Timestamp toDate,String vinNumber,String
	 *            env
	 * @return List<CvddmVINHistoryDE>
	 */
	public List<CvddmVINHistoryDE> getValidationHistoryRcrdsByOptions(String appId, Timestamp fromDate,
			Timestamp toDate, String vinNumber, String env) {

		return historyEntityManager.getValidationHistoryRcrdsByOptions(appId, fromDate, toDate, vinNumber, env);
	}

	/*** End Change : User Story : US1078610 *****/

	/**
	 * @Description:This method would fetch all VIN History from
	 *                   PCVDM22_PART_DATA_VLDTN_REQ database table any input appId,
	 *                   Timestamp fromDate, Timestamp toDate.String
	 *                   partIIspec,String env
	 * 
	 * @param appId
	 * @param fromDate
	 * @param toDate
	 * @param vinNumber
	 * @param env
	 * @return
	 */

	public List<CvddmPartIISpecHistoryDE> getValidationHistoryPartIISpecRcrdsByOptions(String appId, Timestamp fromDate,
			Timestamp toDate, String partIIspec, String env) {

		return historyEntityManager.getValidationHistoryPartIISpecRcrdsByOptions(appId, fromDate, toDate, partIIspec,
				env);
	}

	public List<CvddmPartIISpecHistoryDE> getValidationPartIISHistoryRcrdsByDate(String appId, Timestamp fromDate,
			Timestamp toDate) {

		return historyEntityManager.getValidationPartIISpecHistoryRcrdsByDate(appId, fromDate, toDate);
	}
}