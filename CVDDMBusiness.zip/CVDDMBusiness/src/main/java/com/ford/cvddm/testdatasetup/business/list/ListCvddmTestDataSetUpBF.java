/**
 * 
 */
package com.ford.cvddm.testdatasetup.business.list;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;

import com.ford.cvddm.domain.master.de.CvddmProductGroupDE;
import com.ford.cvddm.domain.master.de.CvddmProductLineDE;
import com.ford.cvddm.domain.master.de.CvddmProductTeamDE;
import com.ford.cvddm.domain.master.de.CvddmTestingTypeDE;
import com.ford.cvddm.domain.testdatasetup.de.CvddmConfigDidSelectionDE;
import com.ford.cvddm.domain.testdatasetup.de.CvddmTdsReqModDE;
import com.ford.cvddm.domain.testdatasetup.de.CvddmTdsReqPartDE;
import com.ford.cvddm.domain.testdatasetup.de.CvddmTestDataReqDE;
import com.ford.cvddm.entitymanager.TestDataEntityManager;
import com.ford.cvddm.sob.business.layer.CVDDMBaseBF;

/**
 * Description : Business Facade Class for Test Data Set Up Functionality.
 * @author NGUPTA18
 *
 */
public class ListCvddmTestDataSetUpBF extends CVDDMBaseBF implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private TestDataEntityManager testDataEntityManager;

	/**
	 * Method Name: getActiveProductGroups
	 * 
	 * @Description:This method would fetch all  Active Product Groups from 
	 *                   PCVDM10_PRDCT_GRP database table.
	 * @param none
	 * @return List<CvddmProductGroupDE>
	 */
	public List<CvddmProductGroupDE> getActiveProductGroups() {

		return testDataEntityManager.getActiveProductGroups();
	}

	/**
	 * Method Name: getActiveProductLines
	 * 
	 * @Description:This method would fetch all  Active Product Lines from 
	 *                   PCVDM11_PRDCT_LINE database table on basis of passed Product Group Id
	 * @param String prdGrpId
	 * @return List<CvddmProductLineDE>
	 */

	public List<CvddmProductLineDE> getActiveProductLines(String prdGrpId)  {

		return testDataEntityManager.getActiveProductLines(prdGrpId);
	}
	
	/**
	 * Method Name: getActiveProductTeams
	 * 
	 * @Description:This method would fetch all  Active Product Teams from 
	 *                   PCVDM12_PRDCT_TEAM database table on basis of passed Product Line Id
	 * @param String prdLineId
	 * @return List<CvddmProductTeamDE>
	 */
	public List<CvddmProductTeamDE> getActiveProductTeams(String prdLineId)  {

		return testDataEntityManager.getActiveProductTeams(prdLineId);
	}
	
	/**
	 * Method Name: getActiveTestingTypes
	 * 
	 * @Description:This method would fetch all  Active Testing Types from 
	 *                   PCVDM13_TEST_TYPE database table.
	 * @param none
	 * @return List<CvddmTestingTypeDE>
	 */
	public List<CvddmTestingTypeDE> getActiveTestingTypes(){
		
		return testDataEntityManager.getActiveTestingTypes();
	}
	
	/*** Start Change :User Story: US1147659 **/
	/**
	 * Method Name: fetchProductGroupById
	 * 
	 * @Description:This method would fetchActive Product Group from 
	 *                   PCVDM10_PRDCT_GRP database table depending on
	 *                   the PK passed.
	 * @param String productGrpId
	 * @return CvddmProductGroupDE
	 */
	public CvddmProductGroupDE fetchProductGroupById(String productGrpId) {

		return testDataEntityManager.fetchProductGroupById(productGrpId);
	}
	/**
	 * Method Name: fetchProductLineById
	 * 
	 * @Description:This method would fetch Active Product Line from 
	 *                   PCVDM11_PRDCT_LINE database table depending on
	 *                   the PK passed.
	 * @param String productLineId
	 * @return CvddmProductLineDE
	 */
	public CvddmProductLineDE fetchProductLineById(String productLineId) {

		return testDataEntityManager.fetchProductLineById(productLineId);
	}
	
	/**
	 * Method Name: fetchProducTeamById
	 * 
	 * @Description:This method would fetch Active Product Team from 
	 *                   PCVDM12_PRDCT_TEAM database table depending on
	 *                   the PK passed.
	 * @param String productTeamId
	 * @return CvddmProductTeamDE
	 */
	public CvddmProductTeamDE fetchProducTeamById(String productTeamId) {

		return testDataEntityManager.fetchProducTeamById(productTeamId);
	}
	
	/**
	 * Method Name: fetchTestingTypeById
	 * 
	 * @Description:This method would fetch Active Product Team from 
	 *                   PCVDM13_TEST_TYPE database table depending on
	 *                   the PK passed.
	 * @param SString testingId
	 * @return CvddmTestingTypeDE
	 */
	public CvddmTestingTypeDE fetchTestingTypeById(String testingId) {

		return testDataEntityManager.fetchTestingTypeById(testingId);
	}
	
	/**
	 * Method Name: saveCvddmTestDataReqDEData
	 * 
	 * @Description:This method would persist data into 
	 *                   PCVDM14_TDS_REQ database table
	 * @param CvddmTestDataReqDE dataReqDE
	 * @return CvddmTestDataReqDE
	 */
	public CvddmTestDataReqDE saveCvddmTestDataReqDEData(CvddmTestDataReqDE dataReqDE) {

		return testDataEntityManager.saveCvddmTestDataReqDEData(dataReqDE);
	}
	
	/**
	 * Method Name: saveCvddmTdsReqModDEData
	 * 
	 * @Description:This method would persist data into 
	 *                   PCVDM16_TDS_REQ_MOD database table
	 * @param CvddmTdsReqModDE dataReqDE
	 * @return CvddmTdsReqModDE
	 */
	
	public CvddmTdsReqModDE saveCvddmTdsReqModDEData(CvddmTdsReqModDE dataReqDE) {
		
		return testDataEntityManager.saveCvddmTdsReqModDEData(dataReqDE);
	}
	
	/**
	 * Method Name: saveCvddmTdsReqPartDEData
	 * 
	 * @Description:This method would persist data into 
	 *                   PCVDM26_TDS_REQ_PART database table
	 * @param CvddmTdsReqPartDE dataReqDE
	 * @return CvddmTdsReqPartDE
	 */
	
	public CvddmTdsReqPartDE saveCvddmTdsReqPartDEData(CvddmTdsReqPartDE dataReqDE) {
		
		return testDataEntityManager.saveCvddmTdsReqPartDEData(dataReqDE);
	}
	
	/**
	 * Method Name: saveCvddmConfigDidSelectionDEData
	 * 
	 * @Description:This method would persist data into 
	 *                   PCVDM24_TDS_REQ_CFG_DID database table
	 * @param CvddmConfigDidSelectionDE dataReqDE
	 * @return CvddmConfigDidSelectionDE
	 */
	
	public CvddmConfigDidSelectionDE saveCvddmConfigDidSelectionDEData(CvddmConfigDidSelectionDE dataReqDE) {
		
		return testDataEntityManager.saveCvddmConfigDidSelectionDEData(dataReqDE);
	}
	
	/*** End Change :User Story: US1147659 **/

}
