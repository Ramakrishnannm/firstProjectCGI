package com.ford.cvddm.gvms.aws;

import java.util.List;

public class PartIISpecFeatures {
	private String id;
	private String name;
	private String didValue;
	private boolean disable=true;
	public boolean isDisable() {
		return disable;
	}

	public void setDisable(boolean disable) {
		this.disable = disable;
	}
	public String getDidValue() {
		return didValue;
	}

	public void setDidValue(String didValue) {
		this.didValue = didValue;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	List<SubFieldListFeatures> subFieldListFeatureslist;

	public List<SubFieldListFeatures> getSubFieldListFeatureslist() {
		return subFieldListFeatureslist;
	}

	public void setSubFieldListFeatureslist(List<SubFieldListFeatures> subFieldListFeatureslist) {
		this.subFieldListFeatureslist = subFieldListFeatureslist;
	}
}
