package com.ford.cvddm.env.business.list;

import java.io.Serializable;
import java.util.List;

import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;

import com.ford.cvddm.domain.env.de.CvddmEnvironmentDE;
import com.ford.cvddm.entitymanager.EnvironmentEntityManager;
import com.ford.cvddm.sob.business.layer.CVDDMBaseBF;

/**
 * Description : Business Facade Class for Environment Functionality.
 * 
 * @author MJEYARAJ
 *
 */
@SessionScoped
public class ListCvddmEnvironmentBF extends CVDDMBaseBF implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EnvironmentEntityManager environmentEntityManager;

	/**
	 * Method Name: fetchAllEnvRcrds
	 * 
	 * @Description:This method would fetch all Environment Records from PCVDM06_ENV
	 *                   database table.
	 * 
	 * @param None
	 * @return List<CvddmEnvironmentDE>
	 */
	public List<CvddmEnvironmentDE> fetchAllEnvRcrds() {

		return environmentEntityManager.fetchAllRecords();
	}

	/**
	 * Method Name: fetchEnvObj
	 * 
	 * @Description:This method would fetch Environment Object from PCVDM06_ENV
	 *                   database table.
	 * 
	 * @param None
	 * @return CvddmEnvironmentDE
	 */
	public CvddmEnvironmentDE fetchEnvObj(String env) {

		return environmentEntityManager.fetchEnvObject(env);
	}

}