/**
 * 
 */
package com.ford.cvddm.ldap.business;

import javax.enterprise.context.ApplicationScoped;

import com.ford.cvddm.common.ldap.LdapUserTO;
import com.ford.cvddm.common.ldap.LdapUtilHelper;
import com.ford.cvddm.sob.business.layer.CVDDMBaseBF;

/**
 * @since US1121586
 * @author NGUPTA18
 * This concrete class provides business functionality to the Presentation Layer
 * while 'hiding' the technology specific Resource Manager instances for operations
 * related to  LDAP/Ford Directory Services i.e FDS
 *
 */
@ApplicationScoped
public class LdapBF extends CVDDMBaseBF {
	
	/**
	 * Method Name: getLdapUserUsingCDSId
	 * @Description:This method would Query Ford Directory Service using passed CDS Id
	 * and return User details from LDAP
	 * @param final String cdsID
	 * @return LdapUserTO
	 */
	
	public LdapUserTO getLdapUserUsingCDSId(final String cdsID) {
        return LdapUtilHelper.getLdapUserUsingCDSId(cdsID);
    }
	
	/**
	 * Method Name: getLdapUserUsingEmailId
	 * @Description:This method would Query Ford Directory Service using passed emailID
	 * and return User details from LDAP 
	 * @param final String emailID
	 * @return LdapUserTO
	 */
	
	public LdapUserTO getLdapUserUsingEmailId(final String emailID) {
        return LdapUtilHelper.getLdapUserUsingEmailId(emailID);
    }
}
