package com.ford.cvddm.gvms.business;

import java.io.Serializable;
import java.util.Map;

import javax.enterprise.context.SessionScoped;

import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.outbound.gvms.vehicleModuleInfo.RequestInfoType;
import com.ford.cvddm.outbound.gvms.vehicleModuleInfo.RequestNode;
import com.ford.cvddm.outbound.gvms.vehicleModuleInfo.RoleENUMType;
import com.ford.cvddm.outbound.gvms.vehicleModuleInfo.StateUpdateRoleType;
import com.ford.cvddm.outbound.gvms.vehicleModuleInfo.VehicleModelYearType;
import com.ford.cvddm.outbound.gvms.vehicleModuleInfo.VehicleModuleRequestType;
import com.ford.cvddm.outbound.gvms.vehicleModuleInfo.VehicleModuleResponseType;
import com.ford.cvddm.outbound.layer.CVDDMConsumerAS;
import com.ford.cvddm.sob.business.layer.CVDDMBaseBF;
import com.ford.cvddm.sob.business.layer.CVDDMBusinessException;
import com.ford.it.exception.FordExceptionAttributes;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;
import com.ford.it.util.TextUtil;
import com.ford.it.wscore.consumer.as.WscBaseGenericConsumerAS;

/**
 * This concrete class provides business functionality to the Presentation Layer
 *  while 'hiding' the technology specific Application Service instances.
 *  This Class would invoke GVMS IBM API Connect - Vehicle Module Info SOA Service.
 *  User Story : US936992
 * @author NGUPTA18
 *
 */
@SessionScoped
public class GvmsVehicleModuleInfoBF extends CVDDMBaseBF implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** The Class Name used for Logging */
    private static final String CLASS_NAME = GvmsVehicleModuleInfoBF.class.getName();

    /** The Logger instance used for Logging */
    private static final ILogger log =
            LogFactory.getInstance().getLogger(CLASS_NAME);

    /**
     * Instance of the Consumer AS needed to interact with the Vehicle Module Info Service
     */
    private WscBaseGenericConsumerAS cvddmConsumerAS;

    /**
     * @return Returns the cvddmConsumerAS.
     */
    public WscBaseGenericConsumerAS getCvddmConsumerAS(String consumerType) {

    	this.cvddmConsumerAS = new CVDDMConsumerAS(consumerType);
        return this.cvddmConsumerAS;
    }

    /**
     * @param CVDDMConsumerAS The cvddmConsumerAS to set.
     */
    public void setCVDDMConsumerAS(final WscBaseGenericConsumerAS cvddmConsumerAS) {
        this.cvddmConsumerAS = cvddmConsumerAS;
    }

    
    /**
     * This method retrieves a VehicleModelYearType Object from GVMS using Vehicle Module Info SOA Service.
     * @param Map <String, Object> inputMap
     * @return VehicleModuleResponseType
     * @throws CVDDMBusinessException when VehicleModuleResponseType Object Could not be retrieved from GVMS.
     */

    public VehicleModuleResponseType retrieveVehicleModuleResponse(Map <String, Object> inputMap) {

    	final String METHOD_NAME = "retrieveVehicleModuleResponse";
    	log.entering(CLASS_NAME, METHOD_NAME);

    	String env = (String) inputMap.get(CVDDMConstant.ENV_TYPE);

    	if(TextUtil.isBlankOrNull(env)) {
    		
    		env = CVDDMConstant.ENV_QA1;
    	}
    	
    	final VehicleModuleRequestType vehicleRequestObj = (VehicleModuleRequestType) inputMap.get(CVDDMConstant.VEHICLE_REQ_OBJ);


    	VehicleModuleResponseType  vehicleModuleResponse = null;


    	try {
    		if(CVDDMConstant.ENV_QA1.equalsIgnoreCase(env)) {

    			vehicleModuleResponse = getCvddmConsumerAS(CVDDMConstant.VEHICLE_MODULE_INFO_SERVICE_CONFIG_QA1).processConsumer(
    					"GetModules", vehicleRequestObj);
    		}
    		else {

    			vehicleModuleResponse = getCvddmConsumerAS(CVDDMConstant.VEHICLE_MODULE_INFO_SERVICE_CONFIG_QA2).processConsumer(
    					"GetModules", vehicleRequestObj);
    		}

    	} catch (final Exception ex) {
    		log.severe(CvddmUtil.getStackTraceContent(ex));
    		throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(
    				CLASS_NAME, METHOD_NAME).build(), CvddmUtil.getStackTraceContent(ex), ex);
    	}

    	log.exiting(CLASS_NAME, METHOD_NAME);

    	// Return the VehicleModuleResponse
    	return vehicleModuleResponse;
    }
      
    /**
     * This method retrieves a VehicleModelYearType Object from GVMS using Vehicle Module Info SOA Service for Dealer Record.
     * @param Map <String, Object> inputMap
     * @return VehicleModelYearType Object.
     */ 
    public VehicleModelYearType getVehicleModelYearTypeForAL(Map <String, Object> inputMap) {

    	final String METHOD_NAME = "getVehicleModelYearTypeForAL";
    	log.entering(CLASS_NAME, METHOD_NAME);
    	
    	VehicleModelYearType  vehicleModelYearType = null;
    	
    	try {

    	final RequestNode requestNode = new  RequestNode();
    	
    	String node = (String) inputMap.get(CVDDMConstant.NODE_TYPE);
    	
    	if(TextUtil.isBlankOrNull(node)) {
    		
    		node = CVDDMConstant.STRING_ALL;
    	}
    	requestNode.setNode(node);
    	
    	final RequestInfoType  requestInfo = new  RequestInfoType();
    	requestInfo.setGetAsBuilt(true);
    	requestInfo.setGetAvailable(true);
    	requestInfo.setGetHistory(false);
    	requestInfo.setGetLatest(true);
    	requestInfo.setGetAsBuilt(false);
    	
    	String vinNumber = (String) inputMap.get(CVDDMConstant.VIN_NUMBER);
    	
    	final VehicleModuleRequestType vehicleRequestObj = new VehicleModuleRequestType();
    	vehicleRequestObj.setVIN(vinNumber);
    	vehicleRequestObj.getRequestNode().add(requestNode);
    	vehicleRequestObj.setRequestInfo(requestInfo);
    	vehicleRequestObj.setLanguage(CVDDMConstant.LOCALE_US);
    	
    	String env = (String) inputMap.get(CVDDMConstant.ENV_TYPE);

    	if(TextUtil.isBlankOrNull(env)) {
    		
    		env = CVDDMConstant.ENV_QA1;
    	}
    	
    	final StateUpdateRoleType stateUpdateRoleType = new StateUpdateRoleType();

    	stateUpdateRoleType.setRole(RoleENUMType.DEALER);

    	vehicleRequestObj.setRequestRole(stateUpdateRoleType);
    	
    	inputMap.put(CVDDMConstant.ENV_TYPE, env);
    	inputMap.put(CVDDMConstant.VEHICLE_REQ_OBJ, vehicleRequestObj);
    	    	
    	VehicleModuleResponseType  vehicleModuleResponse = retrieveVehicleModuleResponse(inputMap);
    	
    	if(!CvddmUtil.isObjectEmpty(vehicleModuleResponse) 
    			&& !CvddmUtil.isObjectEmpty(vehicleModuleResponse.getVehicleModelYear()) ) {
    		
    		vehicleModelYearType = vehicleModuleResponse.getVehicleModelYear();
    		
    	}

    	} catch (final Exception ex) {
    		log.severe(CvddmUtil.getStackTraceContent(ex));
    		throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(
    				CLASS_NAME, METHOD_NAME).build(), CvddmUtil.getStackTraceContent(ex), ex);
    	}

    	log.exiting(CLASS_NAME, METHOD_NAME);

    	// Return the VehicleModuleResponse
    	return vehicleModelYearType;
    }
    
    /**
     * This method retrieves a VehicleModelYearType Object from GVMS using Vehicle Module Info SOA Service for EOLX Record.
     * @param Map <String, Object> inputMap
     * @return VehicleModelYearType Object.
     */ 
    public VehicleModelYearType getVehicleModelYearTypeForEOL(Map <String, Object> inputMap) {

    	final String METHOD_NAME = "getVehicleModelYearTypeForEOL";
    	log.entering(CLASS_NAME, METHOD_NAME);
    	
    	VehicleModelYearType  vehicleModelYearType = null;
    	
    	try {

    	final RequestNode requestNode = new  RequestNode();
    	
    	String node = (String) inputMap.get(CVDDMConstant.NODE_TYPE);
    	
    	if(TextUtil.isBlankOrNull(node)) {
    		
    		node = CVDDMConstant.STRING_ALL;
    	}
    	requestNode.setNode(node);
    	
    	final RequestInfoType  requestInfo = new  RequestInfoType();
    	requestInfo.setGetAsBuilt(true);
    	requestInfo.setGetAvailable(true);
    	requestInfo.setGetHistory(false);
    	requestInfo.setGetLatest(true);
    	requestInfo.setGetAsBuilt(false);
    	
    	String vinNumber = (String) inputMap.get(CVDDMConstant.VIN_NUMBER);
    	
    	final VehicleModuleRequestType vehicleRequestObj = new VehicleModuleRequestType();
    	vehicleRequestObj.setVIN(vinNumber);
    	vehicleRequestObj.getRequestNode().add(requestNode);
    	vehicleRequestObj.setRequestInfo(requestInfo);
    	vehicleRequestObj.setLanguage(CVDDMConstant.LOCALE_US);
    	
    	String env = (String) inputMap.get(CVDDMConstant.ENV_TYPE);

    	if(TextUtil.isBlankOrNull(env)) {
    		
    		env = CVDDMConstant.ENV_QA1;
    	}
    	
    	final StateUpdateRoleType stateUpdateRoleType = new StateUpdateRoleType();

    	stateUpdateRoleType.setRole(RoleENUMType.EOL);

    	vehicleRequestObj.setRequestRole(stateUpdateRoleType);
    	
    	inputMap.put(CVDDMConstant.ENV_TYPE, env);
    	inputMap.put(CVDDMConstant.VEHICLE_REQ_OBJ, vehicleRequestObj);
    	    	
    	VehicleModuleResponseType  vehicleModuleResponse = retrieveVehicleModuleResponse(inputMap);
    	
    	if(!CvddmUtil.isObjectEmpty(vehicleModuleResponse) 
    			&& !CvddmUtil.isObjectEmpty(vehicleModuleResponse.getVehicleModelYear()) ) {
    		
    		vehicleModelYearType = vehicleModuleResponse.getVehicleModelYear();
    		
    	}

    	} catch (final Exception ex) {
    		log.severe(CvddmUtil.getStackTraceContent(ex));
    		throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(
    				CLASS_NAME, METHOD_NAME).build(), CvddmUtil.getStackTraceContent(ex), ex);
    	}

    	log.exiting(CLASS_NAME, METHOD_NAME);

    	// Return the VehicleModuleResponse
    	return vehicleModelYearType;
    }

}