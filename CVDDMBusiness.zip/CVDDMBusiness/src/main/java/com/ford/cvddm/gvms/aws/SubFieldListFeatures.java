package com.ford.cvddm.gvms.aws;

import java.util.List;

public class SubFieldListFeatures {
	
	private String id;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMostsigbit() {
		return mostsigbit;
	}
	public void setMostsigbit(String mostsigbit) {
		this.mostsigbit = mostsigbit;
	}
	public String getLeastsigbit() {
		return leastsigbit;
	}
	public void setLeastsigbit(String leastsigbit) {
		this.leastsigbit = leastsigbit;
	}
	private String name;
	private String mostsigbit;
	private String leastsigbit;
	
	public List<EnumertedParameter> getEnumertedParameters() {
		return enumertedParameters;
	}
	public void setEnumertedParameters(List<EnumertedParameter> enumertedParameters) {
		this.enumertedParameters = enumertedParameters;
	}
	private List<EnumertedParameter> enumertedParameters;


}
