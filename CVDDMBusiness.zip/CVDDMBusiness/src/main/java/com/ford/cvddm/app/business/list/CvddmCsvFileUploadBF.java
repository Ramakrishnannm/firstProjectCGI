package com.ford.cvddm.app.business.list;

import java.io.Serializable;
import java.util.List;

import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import com.ford.cvddm.domain.application.de.CvddmESNCSVUploadDE;
import com.ford.cvddm.domain.application.de.CvddmPartMatrixReferenceCSVUploadDE;
import com.ford.cvddm.domain.application.de.CvddmVinRepoCSVUploadDE;
import com.ford.cvddm.entitymanager.CSVFileUploadEntityManager;
import com.ford.cvddm.sob.business.layer.CVDDMBaseBF;

/**
 * Description : Business Facade Class for CSV file upload Functionality.
 * 
 * RPADI
 *
 */
@SessionScoped
public class CvddmCsvFileUploadBF extends CVDDMBaseBF implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private CSVFileUploadEntityManager cSVFileUploadEntityManager;



	/**
	 * Method Name: saveCvddmCSVRcrds
	 *  
	 *  This method is used to save vinrepo csv records into DB
	 *
	 */
	public boolean saveCvddmCSVRcrds(List<CvddmVinRepoCSVUploadDE> cvddmCSVUploadDE){

		return cSVFileUploadEntityManager.saveCvddmCSVRcrds(cvddmCSVUploadDE);
	}

	/**
	 * Method Name: saveESNCSVRcrds
	 *  
	 *  This method is used to save esn csv records into DB
	 *
	 */
	public boolean saveESNCSVRcrds(List<CvddmESNCSVUploadDE> eSNCSVUploadDE) {

		return cSVFileUploadEntityManager.saveESNCSVRcrds(eSNCSVUploadDE);
	}

	/**
	 * Method Name: savePartMatrxCSVRcrds
	 *  
	 *  This method is used to save partMatrixreference csv records into DB
	 *
	 */
	public boolean savePartMatrxCSVRcrds(List<CvddmPartMatrixReferenceCSVUploadDE> partMatrixReferenceCSVUploadDE) {

		return cSVFileUploadEntityManager.savePartMatrxCSVRcrds(partMatrixReferenceCSVUploadDE);
	}

	/*** Start Change :User Story: US1064801**/

	/**
	 * Method Name: getMockVinDtlsfrmRepo
	 * 
	 * @Description:This method would fetch MockUpVIN from PCVDM19_VIN_REPO table depending on passed
	 * parameters.
	 * @param String progCode,String modelYear,String vehicleName,String noofVins
	 * @return List<CvddmVinRepoCSVUploadDE> 
	 */
	public List<CvddmVinRepoCSVUploadDE>  getMockVinDtlsfrmRepo(String progCode,String modelYear,String vehicleName,String noofVins) {

		return cSVFileUploadEntityManager.getMockVinDtlsfrmRepo( progCode, modelYear, vehicleName, noofVins);
	}

	/**
	 * Method Name: getProdVehicleDetails
	 * 
	 * @Description:This method would disntict fetch Prod Program Code,Model year and Vehicle name PCVDM19_VIN_REPO table
	 * @param none
	 * @return List<CvddmVinRepoCSVUploadDE> 
	 */
	public List<CvddmVinRepoCSVUploadDE> getProdVehicleDetails() {

		return cSVFileUploadEntityManager.getProdVehicleDetails();
	}

	/**
	 * Method Name: updateVINRepoTable
	 * 
	 * @Description:This method would update PCVDM19_VIN_REPO table for particular Request
	 * @param List<CvddmVinRepoCSVUploadDE>
	 * @return boolean
	 */
	public boolean updateVINRepoTable(List<CvddmVinRepoCSVUploadDE> mockupVinDetails) {

		return cSVFileUploadEntityManager.updateVINRepoTable(mockupVinDetails);
	}

	/*** End Change :User Story: US1064801**/

	/*** Start Change :User Story: US1147659**/

	/**
	 * Method Name: getAvailableESNRecords
	 * 
	 * @Description:This method would get available ESN's from PCVDM20_ESN_REPO table
	 * @param String noofESNs
	 * @return List<CvddmESNCSVUploadDE> 
	 * 
	 */
	public List<CvddmESNCSVUploadDE> getAvailableESNRecords(String noofESNs) {

		return cSVFileUploadEntityManager.getAvailableESNRecords(noofESNs);

	}
	
	/**
	 * Method Name: updateESNRepoTable
	 * 
	 * @Description:This method would update PCVDM20_ESN_REPO table for particular Request
	 * @param List<CvddmESNCSVUploadDE>
	 * @return boolean
	 */
	public boolean updateESNRepoTable(List<CvddmESNCSVUploadDE> mockupESNDetails) {

		return cSVFileUploadEntityManager.updateESNRepoTable(mockupESNDetails);
	}
	/*** End Change :User Story: US1147659**/
}