package com.ford.cvddm.sob.business.layer;

import com.ford.it.bf.BaseBF;

/**
 * This is a base Business Facade class.
 *
 * @since jab-v7.0
 */
public abstract class CVDDMBaseBF extends BaseBF {
    // Empty

}
