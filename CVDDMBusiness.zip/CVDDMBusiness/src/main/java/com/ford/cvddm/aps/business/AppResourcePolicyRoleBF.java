/**
 * 
 */
package com.ford.cvddm.aps.business;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.outbound.aps.appResourcePolicyRole.ActionType;
import com.ford.cvddm.outbound.aps.appResourcePolicyRole.GetPolicyRolesRequestType;
import com.ford.cvddm.outbound.aps.appResourcePolicyRole.GetPolicyRolesResponseType;
import com.ford.cvddm.outbound.aps.appResourcePolicyRole.RoleType;
import com.ford.cvddm.outbound.layer.CVDDMConsumerAS;
import com.ford.cvddm.sob.business.layer.CVDDMBaseBF;
import com.ford.cvddm.sob.business.layer.CVDDMBusinessException;
import com.ford.it.exception.FordExceptionAttributes;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;
import com.ford.it.util.TextUtil;
import com.ford.it.wscore.consumer.as.WscBaseGenericConsumerAS;

/**
 * Description : US941845 & US986092 
 * Business Facade Class for ApplicationResourcePolicyRole APS SOA Service.
 * Used to fetch all Roles from APS for Specific CVDDM Resource ( Menu/Sub Menu)
 * @author NGUPTA18
 *
 */
@SessionScoped
public class AppResourcePolicyRoleBF extends CVDDMBaseBF implements Serializable {

	private static final long serialVersionUID = 1L;

	/** The Class Name used for Logging */
	private static final String CLASS_NAME = AppResourcePolicyRoleBF.class.getName();

	/** The Logger instance used for Logging */
	private static final ILogger log =
			LogFactory.getInstance().getLogger(CLASS_NAME);

	/**
	 * Instance of the Consumer AS needed to interact with the ApplicationResourcePolicyRole Service
	 */
	private WscBaseGenericConsumerAS cvddmConsumerAS;

	/**
	 * @return Returns the cvddmConsumerAS.
	 */
	public WscBaseGenericConsumerAS getCvddmConsumerAS(String consumerType) {

		this.cvddmConsumerAS = new CVDDMConsumerAS(consumerType);
		return this.cvddmConsumerAS;
	}

	/**
	 * @param CVDDMConsumerAS The cvddmConsumerAS to set.
	 */
	public void setCVDDMConsumerAS(final WscBaseGenericConsumerAS cvddmConsumerAS) {
		this.cvddmConsumerAS = cvddmConsumerAS;
	}

	/**
	 * Method: getPolicyRolesResponse
	 * This method retrieves GetPolicyRolesResponseType Object from
	 * APS ApplicationResourcePolicyRole Service for CVDDM Application
	 *
	 * @param String resourceName (without Spaces)
	 * @return GetPolicyRolesResponseType
	 * @throws CVDDMBusinessException when GetPolicyRolesResponseType details couldn't be fetched from 
	 *  APS ApplicationResourcePolicyRole Service
	 */

	public GetPolicyRolesResponseType getPolicyRolesResponse(String resourceName) {

		final String METHOD_NAME = "getPolicyRolesResponse";
		log.entering(CLASS_NAME, METHOD_NAME);


		final GetPolicyRolesRequestType rolesRequestType = new  GetPolicyRolesRequestType();


		rolesRequestType.setAction(ActionType.EXECUTE);

		if(TextUtil.isNotBlankOrNull(resourceName)) {

			rolesRequestType.setResource(resourceName);
		}
		else {

			rolesRequestType.setResource(CVDDMConstant.DEFAULT_RESOURCE_NAME);
		}

		rolesRequestType.setApplication(CVDDMConstant.CVDDM_APP_NAME);

		rolesRequestType.setSubject(CVDDMConstant.EMPTY_STRING);

		GetPolicyRolesResponseType rolesResponseType = null;

		try {

			rolesResponseType = getCvddmConsumerAS(CVDDMConstant.APS_GET_ROLES_FR_RESOURCE).processConsumer(
					"GetPolicyRoles", rolesRequestType); 
		}

		catch (final Exception ex) {
			log.severe(CvddmUtil.getStackTraceContent(ex));
    		throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(
    				CLASS_NAME, METHOD_NAME).build(), CvddmUtil.getStackTraceContent(ex), ex);
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
		// Return the GetPolicyRolesResponseType
		return rolesResponseType;
	}

	/**
	 * Method: getRolesForResource
	 * This method retrieves List of Roles which are available in APS for particular
	 * Resource ( CVDDM Menu/Sub Menu/Screen Info )
	 * @param String resourceName
	 * @return List <String>
	 * 
	 */

	public List <String> getRolesForResource(String resourceName) {

		final String METHOD_NAME = "getRolesForResource";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<String> rolesList = new ArrayList<String>();

		GetPolicyRolesResponseType rolesResponseType = null;

		try {

			if(TextUtil.isNotBlankOrNull(resourceName)) {

				resourceName = resourceName.replaceAll("\\s", "");  // Remove whitespaces

				rolesResponseType = getPolicyRolesResponse(resourceName.trim());

				if(!CvddmUtil.isObjectEmpty(rolesResponseType)
						&& !CvddmUtil.isObjectEmpty(rolesResponseType.getPolicyRole())) {

					List<RoleType> roleTypeLst = rolesResponseType.getPolicyRole();

					Iterator <RoleType> roleTypeItr = roleTypeLst.listIterator();

					while(roleTypeItr.hasNext()) {

						RoleType roleType =  roleTypeItr.next();

						if(!CvddmUtil.isObjectEmpty(roleType) 
								&& TextUtil.isNotBlankOrNull(roleType.getName()) ) {

							String roleName = roleType.getName();
							
							log.info("Roles from APS for Resource "+resourceName+ " are : "+ roleName);

							rolesList.add(roleName);
						}
					}		
					log.info("No of Roles available for Resource "+ resourceName + ": "+rolesList.size());
				}
			}	 
		}
		catch(Exception ex) {
			log.severe(CvddmUtil.getStackTraceContent(ex));
    		throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(
    				CLASS_NAME, METHOD_NAME).build(), CvddmUtil.getStackTraceContent(ex), ex);
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
		return rolesList;
	}

}
