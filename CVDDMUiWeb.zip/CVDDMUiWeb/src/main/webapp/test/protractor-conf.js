var HtmlReporter = require('protractor-html-screenshot-reporter');
var path = require('path');

exports.config = {	
	seleniumServerJar: '../node_modules/protractor/selenium/selenium-server-standalone-2.43.1.jar',
	chromeDriver: '../node_modules/protractor/selenium/chromedriver',
	
	allScriptsTimeout: 11000,
	
	specs: [ '../**/*.spec.e2e.js' ],

	
	capabilities: {
		'browserName' : 'chrome'
	},

	// baseUrl: 'http://localhost:18000/CVDDMUiWeb/',

	framework: 'jasmine',

	jasmineNodeOpts: {
		defaultTimeoutInterval : 30000,
		includeStackTrace: true
	},
	
	onPrepare: function() {
		//set browser size
		browser.manage().window().setSize(1024, 768);
		
		require('jasmine-reporters');
		jasmine.getEnv().addReporter(new jasmine.JUnitXmlReporter('test_out/e2e', true, true));
		jasmine.getEnv().addReporter(new HtmlReporter({
			baseDirectory: 'test_out/e2e/screenshots',
			pathBuilder: function pathBuilder(spec, descriptions, results, capabilities) {
				var monthMap = {
					"0": "Jan",
					"1": "Feb",
					"2": "Mar",
					"3": "Apr",
					"4": "May",
					"5": "Jun",
					"6": "Jul",
					"7": "Aug",
					"8": "Sep",
					"9": "Oct",
					"10": "Nov",
					"11": "Dec"
				};
				
				var currentDate = new Date();				
				//Uncomment this section to add the time to the totalDateString, comment/remove the existing totalDateString declaration.

				var currentHoursIn24Hour = currentDate.getHours();
				var currentTimeInHours = currentHoursIn24Hour>12? currentHoursIn24Hour-12: currentHoursIn24Hour;
				var totalDateString = currentDate.getDate()+'-'+ monthMap[currentDate.getMonth()]+ '-'+(currentDate.getYear()+1900) + 
				'-'+ currentTimeInHours+'h-' + currentDate.getMinutes()+'m';

				var totalDateString = currentDate.getDate()+'-'+ monthMap[currentDate.getMonth()]+ '-'+(currentDate.getYear()+1900);
				var browserString = capabilities.caps_.browserName + ' ' + capabilities.caps_.version;
				var suiteString = descriptions.reverse().join('/');
				
				return path.join(totalDateString, browserString, suiteString, descriptions.join('-'));
			}
		}));
	}
};
