/**
 * 
 */
package com.ford.cvddm.inbound.common.pojo;

import java.io.Serializable;
import java.util.List;

import com.ford.cvddm.domain.module.de.CvddmModuleDE;

/**
 * This class would be used for Test Data Set up- US1064801
 * @author NGUPTA18
 *
 */
public class ModuleESNDetails implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private int moduleId;
	
	private String moduleCode;
	
	private String moduleAcronym;
	
	private String moduleDesc;
	
	private String moduleESNValue;
	
	private String virtualReq ;
	
	private List<Boolean> hideUnhidelist;
	
	private List<Boolean> virtualDeviceUnhidelist;
	
	private CvddmModuleDE cvddmModuleDE;


	public int getModuleId() {
		return moduleId;
	}

	public void setModuleId(int moduleId) {
		this.moduleId = moduleId;
	}

	public String getModuleCode() {
		return moduleCode;
	}

	public void setModuleCode(String moduleCode) {
		this.moduleCode = moduleCode;
	}

	public String getModuleAcronym() {
		return moduleAcronym;
	}

	public void setModuleAcronym(String moduleAcronym) {
		this.moduleAcronym = moduleAcronym;
	}

	public String getModuleDesc() {
		return moduleDesc;
	}

	public void setModuleDesc(String moduleDesc) {
		this.moduleDesc = moduleDesc;
	}

	public String getModuleESNValue() {
		return moduleESNValue;
	}

	public void setModuleESNValue(String moduleESNValue) {
		this.moduleESNValue = moduleESNValue;
	}

	public String getVirtualReq() {
		return virtualReq;
	}

	public void setVirtualReq(String virtualReq) {
		this.virtualReq = virtualReq;
	}

	/**
	 * @return the hideUnhidelist
	 */
	public List<Boolean> getHideUnhidelist() {
		return hideUnhidelist;
	}

	/**
	 * @param hideUnhidelist the hideUnhidelist to set
	 */
	public void setHideUnhidelist(List<Boolean> hideUnhidelist) {
		this.hideUnhidelist = hideUnhidelist;
	}

	/**
	 * @return the virtualDeviceUnhidelist
	 */
	public List<Boolean> getVirtualDeviceUnhidelist() {
		return virtualDeviceUnhidelist;
	}

	/**
	 * @param virtualDeviceUnhidelist the virtualDeviceUnhidelist to set
	 */
	public void setVirtualDeviceUnhidelist(List<Boolean> virtualDeviceUnhidelist) {
		this.virtualDeviceUnhidelist = virtualDeviceUnhidelist;
	}

	/**
	 * @return the cvddmModuleDE
	 */
	public CvddmModuleDE getCvddmModuleDE() {
		return cvddmModuleDE;
	}

	/**
	 * @param cvddmModuleDE the cvddmModuleDE to set
	 */
	public void setCvddmModuleDE(CvddmModuleDE cvddmModuleDE) {
		this.cvddmModuleDE = cvddmModuleDE;
	}
	
	
	

}
