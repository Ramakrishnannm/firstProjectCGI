package com.ford.cvddm.inbound.datavalidation.ui.bean;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.common.util.ValidationUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.env.business.list.ListCvddmEnvironmentBF;
import com.ford.cvddm.history.business.HistoryUtilityBF;
import com.ford.cvddm.inbound.layer.base.CVDDMBaseBean;
import com.ford.cvddm.inbound.layer.util.BannersUtil;
import com.ford.cvddm.inbound.layer.util.CommonUtil;
import com.ford.cvddm.inbound.layer.util.PopupAlertUtil;
import com.ford.cvddm.outbound.rvcm.ecu.ECUConfigurationDIDInfo;
import com.ford.cvddm.outbound.rvcm.ecu.GetECUConfigMainResponse;
import com.ford.cvddm.outbound.rvcm.ecu.Node;
import com.ford.cvddm.outbound.rvcm.ecu.PartNumber;
import com.ford.cvddm.outbound.rvcm.ecu.RVCMApplicationTCUValidation;
import com.ford.cvddm.sob.business.layer.CVDDMBusinessException;
import com.ford.it.exception.FordExceptionAttributes;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;
import com.ford.it.util.TextUtil;

@ManagedBean
@ViewScoped
/**
 * For US1021877 : IVS feed part number validation
 * 
 * @author MJEYARAJ
 *
 */
public class RvcmTcuValidationBean extends CVDDMBaseBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private static final String CLASS_NAME = RvcmTcuValidationBean.class.getName();

	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	private List<String> applications; // Hold Values for "applications" Drop Down.

	private String selectedApplication;

	private String vinNumber;

	private boolean alreadyRendered;

	private List<String> envList; // Hold Values for "Environment" Drop Down.

	private String selectedEnv;

	private List<PartNumber> partNumbers;

	private List<ECUConfigurationDIDInfo> ecuConfigs;

	private String programCodeFromResponse;

	private String modelYearFromResponse;

	private String disRTVRespAvl = CVDDMConstant.STRING_N;

	public String getDisRTVRespAvl() {
		return disRTVRespAvl;
	}

	public void setDisRTVRespAvl(String disRTVRespAvl) {
		this.disRTVRespAvl = disRTVRespAvl;
	}

	public List<PartNumber> getPartNumbers() {
		return partNumbers;
	}

	public void setPartNumbers(List<PartNumber> partNumbers) {
		this.partNumbers = partNumbers;
	}

	public List<ECUConfigurationDIDInfo> getEcuConfigs() {
		return ecuConfigs;
	}

	public void setEcuConfigs(List<ECUConfigurationDIDInfo> ecuConfigs) {
		this.ecuConfigs = ecuConfigs;
	}

	public String getProgramCodeFromResponse() {
		return programCodeFromResponse;
	}

	public void setProgramCodeFromResponse(String programCodeFromResponse) {
		this.programCodeFromResponse = programCodeFromResponse;
	}

	public String getModelYearFromResponse() {
		return modelYearFromResponse;
	}

	public void setModelYearFromResponse(String modelYearFromResponse) {
		this.modelYearFromResponse = modelYearFromResponse;
	}

	public String getVinNumber() {
		return vinNumber;
	}

	public void setVinNumber(String vinNumber) {
		this.vinNumber = vinNumber;
	}

	public List<String> getApplications() {
		return applications;
	}

	public void setApplications(List<String> applications) {
		this.applications = applications;
	}

	public String getSelectedApplication() {
		return selectedApplication;
	}

	public void setSelectedApplication(String selectedApplication) {
		this.selectedApplication = selectedApplication;
	}

	public boolean isAlreadyRendered() {
		return alreadyRendered;
	}

	public void setAlreadyRendered(boolean alreadyRendered) {
		this.alreadyRendered = alreadyRendered;
	}

	public List<String> getEnvList() {
		return envList;
	}

	public void setEnvList(List<String> envList) {
		this.envList = envList;
	}

	public String getSelectedEnv() {
		return selectedEnv;
	}

	public void setSelectedEnv(String selectedEnv) {
		this.selectedEnv = selectedEnv;
	}

	@Override
	protected void preRenderViewStartWorkflowTM() {
		log.exiting(CLASS_NAME, "preRenderViewStartWorkflowTM");

	}

	/*** Start Change: User Story : US987948 ***/
	@Override
	protected void preRenderViewTM() {

		String popUpContent = PopupAlertUtil.prepareAlertsMsgDesc(CVDDMConstant.ADMIN_SCRN_CD,
				CVDDMConstant.RVCM_TCU_VALIDATION_SCRN_CD);
		this.setPopUpContent(popUpContent);
		this.popUpContent = popUpContent;

		String bannerContent = BannersUtil.prepareBannerMsgDesc(CVDDMConstant.ADMIN_SCRN_CD,
				CVDDMConstant.RVCM_TCU_VALIDATION_SCRN_CD);
		this.setBannerContent(bannerContent);
		this.bannerContent = bannerContent;

		preRenderRvcmValidationRecord();
	}

	/*** End Change: User Story : US987948 ***/

	@Inject
	private ListCvddmEnvironmentBF listCvddmEnvironmentBF;

	/**
	 * Pre rendering method
	 */
	public void preRenderRvcmValidationRecord() {

		final String METHOD_NAME = "preRenderIvsValidationRecord";
		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			if (!alreadyRendered) { // Validating the rendering for unwanted loading

				setEnvList(CommonUtil.retrieveEnvironments(listCvddmEnvironmentBF));

				setAlreadyRendered(true);

				setDisRTVRespAvl(CVDDMConstant.STRING_N);
			}

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * Method to validate the VIN details in RVCM
	 */
	public void validateTcuInRvcm() {

		final String METHOD_NAME = "validateTcuInRvcm";
		log.entering(CLASS_NAME, METHOD_NAME);

		clearOldData();

		try {

			if (ValidationUtil.validateVinNumber(this.vinNumber)) {

				RVCMApplicationTCUValidation rVCMApplicationTCUValidation = new RVCMApplicationTCUValidation();
				GetECUConfigMainResponse getECUConfigMainResponse = rVCMApplicationTCUValidation
						.validateVINInRVCM(vinNumber, selectedEnv);

				if (CvddmUtil.isObjectEmpty(getECUConfigMainResponse.getGetECUConfigResponse())) {
					FacesContext.getCurrentInstance().addMessage(null,
							new FacesMessage(FacesMessage.SEVERITY_ERROR,
									CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
											CVDDMConstant.NO_ECU_VAL_DATA_MSG),
									CVDDMConstant.VALIDATION_ERR));
					setDisRTVRespAvl(CVDDMConstant.STRING_N);

					/** Start Change : User Story US1078611: ***/
					updateHistoryTable(this.vinNumber, CVDDMConstant.STRING_N, CvddmUtil.getPropertiesValue(
							CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY, CVDDMConstant.NO_ECU_VAL_DATA_MSG));
					/** End Change : User Story US1078611: ***/

				} else {
					Node tcuNodeData = getECUConfigMainResponse.getGetECUConfigResponse().getNodes().get(0);

					if ("210".equalsIgnoreCase(tcuNodeData.getStatus().getCode())) {
						FacesContext.getCurrentInstance()
								.addMessage(null,
										new FacesMessage(FacesMessage.SEVERITY_ERROR,
												CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
														CVDDMConstant.VIN_NOT_FOUND_IN_IVSU),
												CVDDMConstant.VALIDATION_ERR));
						setDisRTVRespAvl(CVDDMConstant.STRING_N);

						/** Start Change : User Story US1078611: ***/
						updateHistoryTable(this.vinNumber, CVDDMConstant.STRING_N, CvddmUtil.getPropertiesValue(
								CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY, CVDDMConstant.VIN_NOT_FOUND_IN_IVSU));
						/** End Change : User Story US1078611: ***/

					} else {
						setPartNumbers(tcuNodeData.getPartNumbers());
						setEcuConfigs(tcuNodeData.getECUConfigurationDIDInfo());
						setProgramCodeFromResponse(getECUConfigMainResponse.getGetECUConfigResponse().getProgramCode());
						setModelYearFromResponse(getECUConfigMainResponse.getGetECUConfigResponse().getModelYear()
								.substring(0, 4).trim());
						setDisRTVRespAvl(CVDDMConstant.STRING_Y);

						/** Start Change : User Story US1078611: ***/
						updateHistoryTable(this.vinNumber, CVDDMConstant.STRING_Y, "");
						/** End Change : User Story US1078611: ***/
					}
				}
			} else {
				log.info("Input VIN is invalid");
				FacesContext.getCurrentInstance().addMessage(null,
						new FacesMessage(FacesMessage.SEVERITY_ERROR,
								CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
										CVDDMConstant.INVALID_VIN_FORMAT_MSG),
								CVDDMConstant.VALIDATION_ERR));
				setDisRTVRespAvl(CVDDMConstant.STRING_N);
			}

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}

		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * private method to clear existing form data
	 */
	private void clearOldData() {

		setDisRTVRespAvl(CVDDMConstant.STRING_N);

		if (!CvddmUtil.isObjectEmpty(partNumbers)) {
			partNumbers.clear();
		}
		if (!CvddmUtil.isObjectEmpty(ecuConfigs)) {
			ecuConfigs.clear();
		}
		if (!CvddmUtil.isObjectEmpty(programCodeFromResponse)) {
			programCodeFromResponse = "";
		}
		if (!CvddmUtil.isObjectEmpty(modelYearFromResponse)) {
			modelYearFromResponse = "";
		}
	}

	/**
	 * Public method to clear existing form data
	 */
	public void clearFormData() {

		setDisRTVRespAvl(CVDDMConstant.STRING_N);

		if (!TextUtil.isBlankOrNull(this.selectedEnv)) {
			this.selectedEnv = null;
		}

		if (!TextUtil.isBlankOrNull(this.vinNumber)) {
			this.vinNumber = null;
		}

		if (!CvddmUtil.isObjectEmpty(partNumbers)) {
			partNumbers.clear();
		}

		if (!CvddmUtil.isObjectEmpty(partNumbers)) {
			partNumbers.clear();
		}
		if (!CvddmUtil.isObjectEmpty(ecuConfigs)) {
			ecuConfigs.clear();
		}
		if (!CvddmUtil.isObjectEmpty(programCodeFromResponse)) {
			programCodeFromResponse = "";
		}
		if (!CvddmUtil.isObjectEmpty(modelYearFromResponse)) {
			modelYearFromResponse = "";
		}
	}

	/** Start Change : User Story US1078611: ***/

	@Inject
	private HistoryUtilityBF historyUtilityBF;

	/**
	 * This method would updateHistoryTable
	 * 
	 * @param vinNumber
	 * @param status
	 * @param errorMessage
	 */
	public void updateHistoryTable(String vinNumber, String status, String errorMessage) {

		final String METHOD_NAME = "updateHistoryTable";

		try {

			Map<String, String> inputMap = new HashMap<String, String>();

			// Environment
			switch (this.selectedEnv) {

			case CVDDMConstant.ENV_QA1:
				inputMap.put(CVDDMConstant.HISTORY_UTILITY_ENVIRONMENT_ID, CvddmUtil.getPropertiesValue(
						CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, CVDDMConstant.HISTORY_UTILITY_ENV_QA1));
				break;

			case CVDDMConstant.ENV_QA2:
				inputMap.put(CVDDMConstant.HISTORY_UTILITY_ENVIRONMENT_ID, CvddmUtil.getPropertiesValue(
						CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, CVDDMConstant.HISTORY_UTILITY_ENV_QA2));
				break;
			default:
				inputMap.put(CVDDMConstant.HISTORY_UTILITY_ENVIRONMENT_ID, CvddmUtil.getPropertiesValue(
						CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, CVDDMConstant.HISTORY_UTILITY_ENV_QA1));
				break;
			}

			// Application
			inputMap.put(CVDDMConstant.HISTORY_UTILITY_APPLICATION_ID, CvddmUtil.getPropertiesValue(
					CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, CVDDMConstant.HISTORY_UTILITY_APP_RVCM));

			// VIN
			inputMap.put(CVDDMConstant.HISTORY_UTILITY_VIN, vinNumber);

			if (CVDDMConstant.STRING_Y.equalsIgnoreCase(status)) {

				inputMap.put(CVDDMConstant.HISTORY_UTILITY_WEBSERVICE_STATUS, CVDDMConstant.STRING_Y);
				inputMap.put(CVDDMConstant.HISTORY_UTILITY_WEBSERVICE_ERROR, CVDDMConstant.SUCCESS);

				historyUtilityBF.saveVINHistoryRcrd(inputMap);
			} else {

				inputMap.put(CVDDMConstant.HISTORY_UTILITY_WEBSERVICE_STATUS, CVDDMConstant.STRING_N);
				inputMap.put(CVDDMConstant.HISTORY_UTILITY_WEBSERVICE_ERROR, errorMessage);
				historyUtilityBF.saveVINHistoryRcrd(inputMap);
			}

		}

		catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}
	}

	/**
	 * Method Name: navigateToHistoryPage
	 * 
	 * @Description: This method would navigate to RVCM History Page.
	 * @return void
	 **/
	public void navigateToHistoryPage() {

		final String METHOD_NAME = "navigateToHistoryPage";

		log.entering(CLASS_NAME, METHOD_NAME);

		try {
			FacesContext context = FacesContext.getCurrentInstance();
			context.getExternalContext().redirect(CvddmUtil.getPropertiesValue(
					CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, CVDDMConstant.RVCM_HISTORY_PAGE_PATH));
		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}
	}

	/** End Change : User Story US1078611: ***/
}
