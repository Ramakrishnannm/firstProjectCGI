package com.ford.cvddm.inbound.gvms.vehiclemoduleinfo.ui.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.UploadedFile;

import com.ford.cvddm.common.layer.CVDDMRequestContext;
import com.ford.cvddm.common.ldap.LdapUserTO;
import com.ford.cvddm.common.user.UserTO;
import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.outbound.gvms.vehicleModuleInfo.VehicleModelYearType;
import com.ford.cvddm.sob.business.layer.CVDDMBusinessException;
import com.ford.it.entity.validation.NotBlank;
import com.ford.it.exception.FordExceptionAttributes;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;
import com.ford.it.util.TextUtil;




/**
 * @author NGUPTA18
 *
 */
@ManagedBean
@ViewScoped
public class ViewVehicleDetailsBean extends VehicleModuleInfoBean  implements Serializable{

	/* Comment for <code>serialVersionUID</code>
	 */
	private static final long serialVersionUID = 1L;
	/** The Class Name used for Logging */
	private static final String CLASS_NAME = ViewVehicleDetailsBean.class.getName();

	/** The Logger instance used for Logging */
	private static final ILogger log = LogFactory.getInstance().getLogger(
			CLASS_NAME);

	private VehicleModelYearType vehicleModelType;
	
	private Integer rating;
	
	private transient List<UserTO> emailNotificationLst = new ArrayList<UserTO>();

	
	
	private transient UploadedFile file;
	 
    public UploadedFile getFile() {
        return file;
    }
 
    public void setFile(UploadedFile file) {
        this.file = file;
    }
    
    /**
	 * @return the rating
	 */
	public Integer getRating() {
		return rating;
	}

	/**
	 * @param rating the rating to set
	 */
	public void setRating(Integer rating) {
		this.rating = rating;
	}

	/**
	 * @return the userEmail
	 */
	public String getUserEmail() {
		return userEmail;
	}

	/**
	 * @param userEmail the userEmail to set
	 */
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}


	private String vinNumber = "3FADP4EJ1JM101090";

	private String programCode;

	private String env ="QA1";
	
	private String emailIds ="";
	
	private String resourceName ="";
	
	@NotBlank
	private String userEmail;
	
	

	public String getVinNumber() {
		return vinNumber;
	}

	public void setVinNumber(final String vinNumber) {
		this.vinNumber = vinNumber;
	}

	public String getProgramCode() {
		return programCode;
	}

	public void setProgramCode(String programCode) {
		this.programCode = programCode;
	}

	public String getEnv() {
		return env;
	}

	public void setEnv(String env) {
		this.env = env;
	}

	public String getEmailIds() {
		return emailIds;
	}

	public void setEmailIds(String emailIds) {
		this.emailIds = emailIds;
	}

	/**
	 * @return the resourceName
	 */
	public String getResourceName() {
		return resourceName;
	}

	/**
	 * @param resourceName the resourceName to set
	 */
	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}

	public VehicleModelYearType getVehicleModelType() {
		return vehicleModelType;
	}

	public void setVehicleModelType(VehicleModelYearType vehicleModelType) {
		this.vehicleModelType = vehicleModelType;
	}
	
	/***  Start Change: User Story : US987948 ***/
	@Override
	protected void preRenderViewTM() {
		
	
		getRequesterDetails();

	}	
	/***  End Change: User Story : US987948 ***/
	

	public String validateVIN() {

		String navigation = "";

		try {

			navigation = "/viewVehicleModuleInfo.xhtml?faces-redirect=true";
			
			
			
			final String METHOD_NAME = "validateVIN";
			log.entering(CLASS_NAME, METHOD_NAME);

			CVDDMRequestContext.getInstance().setEnvironment(this.env);
			
			Map <String, Object> inputMap = new HashMap<String, Object>();
			
			inputMap.put(CVDDMConstant.VIN_NUMBER,this.vinNumber);
			inputMap.put(CVDDMConstant.ENV_TYPE,this.env);
					
			
		

			this.vehicleModelType =
					this.vehicleModuleInfoBF.getVehicleModelYearTypeForAL(inputMap); // Get VehicleModelType for AL/Dealer.

			getCurrentLiteAF.getGetCurrentLiteResponseTypeForALL(inputMap);
			
			this.vehicleModelType =
					this.vehicleModuleInfoBF.getVehicleModelYearTypeForEOL(inputMap); // Get VehicleModelType for EOLX.
					
					programCode = vehicleModelType.getProgramCode();
			if(TextUtil.isBlankOrNull(programCode)) {
				programCode = "GVMS SOA Service Has Issue. Check Logs";
			}
			setProgramCode(programCode);

			
			inputMap.put(CVDDMConstant.IS_TCU_PRESENT, true);
			inputMap.put(CVDDMConstant.IS_SYNC_PRESENT, false);
			inputMap.put(CVDDMConstant.IS_BLEM_PRESENT, false);
			inputMap.put(CVDDMConstant.IS_ECG_PRESENT, false);
			
			Map <String, String> partDetails = new LinkedHashMap<String, String>();
			
			partDetails.put(CVDDMConstant.CD_F10A, "JX7T-14G144-CFA");
			partDetails.put(CVDDMConstant.CD_F110, "DSJX7T-14G087-AG");
			partDetails.put(CVDDMConstant.CD_F111, "KT1T-14G145-EA");
			partDetails.put(CVDDMConstant.CD_F113, "KT1T-14G087-EFA");
			partDetails.put(CVDDMConstant.CD_F188, "JX7T-14G139-CFA");
			partDetails.put(CVDDMConstant.CD_F18C, "U5CV73RV");
			partDetails.put(CVDDMConstant.CD_DE00, "B1667F32DE67");
			partDetails.put(CVDDMConstant.CD_DE01, "3201");
			
			inputMap.put(CVDDMConstant.TCU_PART_NUMBERS, partDetails);
			
			
			gvmsModuleStateBF.pushAnalyzeLogtoGVMS(inputMap);

			log.exiting(CLASS_NAME, METHOD_NAME);
		}
		catch (Exception e) {log.severe(CLASS_NAME+e.getMessage());}

		return navigation;
	}

	public String getAPSUsers() {

		String navigation = "";
		final String METHOD_NAME = "getAPSUsers";

		try {

			navigation = "/viewVehicleModuleInfo.xhtml?faces-redirect=true";

			log.entering(CLASS_NAME, METHOD_NAME);

		   setEmailIds(assignmentsBF.getEmailIdsForApplication().toString());

			

			List <String> rolesList = appResourcePolicyRoleBF.getRolesForResource(this.resourceName);

			setEmailIds(entitlementGroupBF.getEmailIdsForRole(rolesList).toString());

		}
		catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));

			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(
					CLASS_NAME, METHOD_NAME).build(), CvddmUtil.getStackTraceContent(e), e);
		}
		log.exiting(CLASS_NAME, METHOD_NAME);

		return navigation;
	}
	
	public String gotoOtherPage() {
		
		log.info("Rating is>>"+this.rating);
		
		final String METHOD_NAME = "gotoOtherPage";
		
		try {
			
			int i = 1/0;
		}
		catch(Exception e) {
			
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(
					CLASS_NAME, METHOD_NAME).build(), CvddmUtil.getStackTraceContent(e), e);
		}
		
		return METHOD_NAME;
		
	}
	
	public void isValidEmailAddress() {



		StringBuilder stringBuilder = new StringBuilder();

		boolean isValidInput = true;

		Iterator <UserTO> listItr = emailNotificationLst.listIterator();

		while(listItr.hasNext()) {

			UserTO userTO= listItr.next();

			if(TextUtil.isBlankOrNull(userTO.getMail())) {	

				isValidInput = false;

				stringBuilder.append(CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
						CVDDMConstant.EMAIL_ID_NOT_AVAIL));
				stringBuilder.append(CVDDMConstant.BREAK_HTML);

				break;

			}

		}

		if(isValidInput) {

			Set<String> setToReturn = findDuplicates(emailNotificationLst);

			if(!setToReturn.isEmpty()) {

				String emailDupMsg;

				Iterator <String> setIterator = setToReturn.iterator();

				while(setIterator.hasNext()) {

					String emailId = setIterator.next();

					if(!TextUtil.isBlankOrNull(emailId)) {

						isValidInput = false;

						emailDupMsg = CVDDMConstant.STRING_EMAIL_ID+" "+emailId +" "+CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
								CVDDMConstant.DUPLICATE_EMAIL_ID);

						stringBuilder.append(emailDupMsg);
						stringBuilder.append(CVDDMConstant.BREAK_HTML);
					}
				}	
			}
		}	

		if(isValidInput) {


			Iterator <UserTO> listItrs = emailNotificationLst.listIterator();

			while(listItrs.hasNext()) {

				UserTO userTO= listItrs.next();

				String emailMsg ;

				if(TextUtil.isNotBlankOrNull(userTO.getMail())) {

					LdapUserTO  ldapUserTO = ldapBFObj.getLdapUserUsingEmailId(userTO.getMail().trim());

					if(CvddmUtil.isObjectEmpty(ldapUserTO)) {


						emailMsg = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY, 
								CVDDMConstant.INVALID_EMAIL_MESSAGE);
						emailMsg = emailMsg.replace(CVDDMConstant.EMAIL_PLACEHOLDER, userTO.getMail());

						stringBuilder.append(emailMsg);
						stringBuilder.append(CVDDMConstant.BREAK_HTML);
					}
				}
			} 	  
		}
		if(TextUtil.isNotBlankOrNull(stringBuilder.toString())) {

			
			addLocalizedErrorMessageToComponent(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
					CVDDMConstant.PLACEHOLDER_EMAIL_MSG,CVDDMConstant.EMAIL_PANEL, stringBuilder.toString());
		}

	} 
	
	public void upload(FileUploadEvent event) {
        try {
        	log.info("File Name >> "+event.getFile().getFileName());
        } catch (Exception e) {
            log.severe(CvddmUtil.getStackTraceContent(e));
        }
 
	}

	/**
	 * @return the emailNotificationLst
	 */
	public List<UserTO> getEmailNotificationLst() {
		return emailNotificationLst;
	}

	/**
	 * @param emailNotificationLst the emailNotificationLst to set
	 */
	public void setEmailNotificationLst(List<UserTO> emailNotificationLst) {
		this.emailNotificationLst = emailNotificationLst;
	} 
	
	/**
	 * Method Name: removeEmailIds
	 * 
	 * @Description: This method would Delete Email Id's.
	 * @param :None
	 * @return void
	 **/

	public void removeEmailIds(UserTO userTO) {
		
		emailNotificationLst.remove(userTO);
	}
	
	public void addEmailIds() {
		
		
		UserTO userTO = new UserTO();
		emailNotificationLst.add(userTO);
	}
	
	/**
	 * Method Name: findDuplicates
	 * 
	 * @Description: This method would find Duplicate VIN's.
	 * @param :List<VehicleDetails> inputVinNumberLst
	 * @return Set<String>
	 **/

	public  Set<String> findDuplicates(List<UserTO> emailNotificationLst) {

		final Set<String> setToReturn = new HashSet<String>();
		final Set<String> uniqueSet = new HashSet<String>();

		Iterator <UserTO> listIterator = emailNotificationLst.listIterator();

		while(listIterator.hasNext()) {

			UserTO tempObj = listIterator.next();

			if (!uniqueSet.add(tempObj.getMail())) {
				setToReturn.add(tempObj.getMail());
			}
		}
		return setToReturn;
		
		
	}
	
}