package com.ford.cvddm.inbound.datavalidation.ui.bean;

import java.io.ByteArrayInputStream;
import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXParseException;

import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.common.util.ValidationUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.env.business.list.ListCvddmEnvironmentBF;
import com.ford.cvddm.gvms.aws.EnumertedParameter;
import com.ford.cvddm.gvms.aws.PartIISpecFeatures;
import com.ford.cvddm.gvms.aws.PartIISpecFromAWS;
import com.ford.cvddm.gvms.aws.SubFieldListFeatures;
import com.ford.cvddm.history.business.HistoryUtilityBF;
import com.ford.cvddm.inbound.layer.base.CVDDMBaseBean;
import com.ford.cvddm.inbound.layer.util.BannersUtil;
import com.ford.cvddm.inbound.layer.util.CommonUtil;
import com.ford.cvddm.inbound.layer.util.PopupAlertUtil;
import com.ford.cvddm.outbound.givis.rest.GIVISRestClients;
import com.ford.cvddm.sob.business.layer.CVDDMBusinessException;
import com.ford.it.exception.FordExceptionAttributes;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;
import com.ford.it.util.TextUtil;

@ManagedBean
@ViewScoped
/**
 * US1021790 - Part II Specification - Configuration DIDs
 * 
 * @author MJEYARAJ
 *
 */
public class PartIISpecValidationBean extends CVDDMBaseBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private static final String CLASS_NAME = PartIISpecValidationBean.class.getName();

	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	private boolean alreadyRendered;

	private String inputPartIISpec;

	private List<PartIISpecFeatures> partIISpecFeatures;

	private List<PartIISpecFeatures> filteredPartIISpecFeatures;

	private List<String> envList; // Hold Values for "Environment" Drop Down.

	private String partIISpecRespAval = CVDDMConstant.STRING_N;

	public String getPartIISpecRespAval() {
		return partIISpecRespAval;
	}

	public void setPartIISpecRespAval(String partIISpecRespAval) {
		this.partIISpecRespAval = partIISpecRespAval;
	}

	public List<PartIISpecFeatures> getFilteredPartIISpecFeatures() {
		return filteredPartIISpecFeatures;
	}

	public void setFilteredPartIISpecFeatures(List<PartIISpecFeatures> filteredPartIISpecFeatures) {
		this.filteredPartIISpecFeatures = filteredPartIISpecFeatures;
	}

	private String selectedEnv;
	private String inputPartIISpecParam;

	private String selectedEnvParam;

	private boolean redirected;

	public boolean getRedirected() {
		return redirected;
	}

	public void setRedirected(boolean redirected) {
		this.redirected = redirected;
	}

	public String getSelectedEnvParam() {
		return selectedEnvParam;
	}

	public void setSelectedEnvParam(String selectedEnvParam) {
		this.selectedEnvParam = selectedEnvParam;
	}

	public String getInputPartIISpecParam() {
		return inputPartIISpecParam;
	}

	public void setInputPartIISpecParam(String inputPartIISpecParam) {
		String inputpartIIspecString = requiredPartIISpecPart(inputPartIISpecParam);
		this.inputPartIISpecParam = inputpartIIspecString;
	}

	public List<PartIISpecFeatures> getPartIISpecFeatures() {
		return partIISpecFeatures;
	}

	public void setPartIISpecFeatures(List<PartIISpecFeatures> partIISpecFeatures) {
		this.partIISpecFeatures = partIISpecFeatures;
	}

	public List<String> getEnvList() {
		return envList;
	}

	public void setEnvList(List<String> envList) {
		this.envList = envList;
	}

	public String getSelectedEnv() {
		return selectedEnv;
	}

	public void setSelectedEnv(String selectedEnv) {
		this.selectedEnv = selectedEnv;
	}

	public boolean isAlreadyRendered() {
		return alreadyRendered;
	}

	public void setAlreadyRendered(boolean alreadyRendered) {
		this.alreadyRendered = alreadyRendered;
	}

	public String getInputPartIISpec() {
		return inputPartIISpec;
	}

	public void setInputPartIISpec(String inputPartIISpec) {
		this.inputPartIISpec = inputPartIISpec;
	}

	@Override
	protected void preRenderViewStartWorkflowTM() {
		log.exiting(CLASS_NAME, "preRenderViewStartWorkflowTM");

	}

	/**
	 * 
	 * @param inputPartIISpecParam
	 * @return String
	 * 
	 * 
	 */
	/*** Start Change: User Story :US1048243 ***/
	public String requiredPartIISpecPart(String inputPartIISpecParam) {
		String partIIpsec = "";

		if (null != inputPartIISpecParam) {
			String[] partIIspecs = inputPartIISpecParam.split(";");

			for (int i = 0; i < partIIspecs.length; i++) {
				if (partIIspecs[i].contains(CVDDMConstant.PARTIISPEC_ID)) {
					partIIpsec = partIIspecs[i].replace(CVDDMConstant.PARTIISPEC_ID, "");
				}

			}

		} else {
			log.info("InputPartIISpec is " + inputPartIISpec);
		}
		return partIIpsec;

	}

	/*** End Change: User Story :US1048243 ***/
	/*** Start Change: User Story : US987948 ***/
	@Override
	protected void preRenderViewTM() {

		String popUpContent = PopupAlertUtil.prepareAlertsMsgDesc(CVDDMConstant.ADMIN_SCRN_CD,
				CVDDMConstant.PARTIISPEC_VALIDATION_SCRN_CD);
		this.setPopUpContent(popUpContent);
		this.popUpContent = popUpContent;

		String bannerContent = BannersUtil.prepareBannerMsgDesc(CVDDMConstant.ADMIN_SCRN_CD,
				CVDDMConstant.PARTIISPEC_VALIDATION_SCRN_CD);
		this.setBannerContent(bannerContent);
		this.bannerContent = bannerContent;
		/*** Start Change: User Story :US1048243 ***/
		retrieveRedirectedPartIISpec();
		/*** End Change: User Story :US1048243 ***/
		preRenderPartIISpecValidationRecord();
	}

	/*** End Change: User Story : US987948 ***/

	@Inject
	private ListCvddmEnvironmentBF listCvddmEnvironmentBF;

	/**
	 * Pre rendering method
	 */
	public void preRenderPartIISpecValidationRecord() {

		final String METHOD_NAME = "preRenderIvsValidationRecord";
		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			if (!alreadyRendered) { // Validating the rendering for unwanted loading

				setEnvList(CommonUtil.retrieveEnvironments(listCvddmEnvironmentBF));

				setAlreadyRendered(true);
			}

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * To get the AWS format which is Key_DateInMilliSeconds.MDF - This method
	 * returns UTC time in milliseconds
	 * 
	 * @param myDate
	 * @return
	 */
	private String getUTCTimeInMilliSecs(String myDate) {

		SimpleDateFormat sdf = new SimpleDateFormat(CVDDMConstant.UTC_TIME_FORMAT_FOR_AWS);
		sdf.setTimeZone(TimeZone.getTimeZone(CVDDMConstant.UTC_TIME_ZONE));

		Date date = null;
		try {
			date = sdf.parse(myDate);
		} catch (ParseException e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		long millis;
		if (null != date) {
			millis = date.getTime();
			return millis + "";
		} else {
			return "";
		}

	}

	@Inject
	private HistoryUtilityBF historyUtilityBF;

	/**
	 * Method to get the feature list
	 * 
	 * 
	 */
	public void validatePartIISpec() {

		final String METHOD_NAME = "validatePartIISpec";
		log.entering(CLASS_NAME, METHOD_NAME);

		GIVISRestClients gIVISRestClients = new GIVISRestClients();
		PartIISpecFromAWS partIISpecFromAWS = new PartIISpecFromAWS();

		String modifieddate;
		String uTCTime;
		String key;

		clearExistingFormData();

		if (ValidationUtil.validatePartIISpec(this.inputPartIISpec)) {

			try {

				// get modified date from GIVIS
				modifieddate = gIVISRestClients.getAWSModifiedDateFromGivis(this.inputPartIISpec, this.selectedEnv);

				if (TextUtil.isNotBlankOrNull(modifieddate)) {

					log.info("Modified Date" + modifieddate);

					uTCTime = getUTCTimeInMilliSecs(modifieddate.substring(1, modifieddate.length() - 1));

					log.info("Modified Date in UTC milliseconds " + uTCTime);

					key = this.inputPartIISpec + "_" + uTCTime + CVDDMConstant.PARTIISPEC_AWS_FILE_FORMAT;

					log.info("AWS Key " + key);

					byte[] partIISpec = partIISpecFromAWS.getPartIISpecFromAWS(key); // get Part2Spec from AWS

					if (null == partIISpec) {
						log.info("PartIISpec is not available in AWS " + key);
						FacesContext.getCurrentInstance().addMessage(null,
								new FacesMessage(FacesMessage.SEVERITY_ERROR,
										CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
												CVDDMConstant.NO_P2S_DATA_MSG),
										CVDDMConstant.VALIDATION_ERR));
						this.setPartIISpecRespAval(CVDDMConstant.STRING_N);

						updateHistoryTable(this.inputPartIISpec, CVDDMConstant.STRING_N, CvddmUtil.getPropertiesValue(
								CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY, CVDDMConstant.NO_P2S_DATA_MSG));

					} else {
						List<PartIISpecFeatures> features = getFeatureListFromPartIISpec(partIISpec);
						log.info("PartIISpec Feature is " + features);
						this.setPartIISpecRespAval(CVDDMConstant.STRING_Y);
						setPartIISpecFeatures(features);
						updateHistoryTable(this.inputPartIISpec, CVDDMConstant.STRING_Y, "");
						
					}

				}

			} catch (Exception e) {
				log.severe(CvddmUtil.getStackTraceContent(e));
				throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
						CvddmUtil.getStackTraceContent(e), e);
			}
		} else {
			setInvalidPartIISpecMessage();
		}

		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * This method used to retrieve partIIspec upon redirection from ivspartnumber
	 * validation page
	 * 
	 */
	/*** Start Change: User Story :US1048243 ***/
	public void retrieveRedirectedPartIISpec() {

		final String METHOD_NAME = "retrieveRedirectedPartIISpec";
		log.entering(CLASS_NAME, METHOD_NAME);

		GIVISRestClients gIVISRestClients = new GIVISRestClients();
		PartIISpecFromAWS partIISpecFromAWS = new PartIISpecFromAWS();

		String modifieddate;
		String uTCTime;
		String key;

		if (TextUtil.isNotBlankOrNull(this.inputPartIISpecParam)) {

			this.setPartIISpecRespAval(CVDDMConstant.STRING_Y);

			try {

				// get modified date from GIVIS
				modifieddate = gIVISRestClients.getAWSModifiedDateFromGivis(this.inputPartIISpecParam,
						this.selectedEnvParam);

				if (TextUtil.isNotBlankOrNull(modifieddate)) {

					log.info("Modified Date" + modifieddate);

					uTCTime = getUTCTimeInMilliSecs(modifieddate.substring(1, modifieddate.length() - 1));

					log.info("Modified Date in UTC milliseconds " + uTCTime);

					key = this.inputPartIISpecParam + "_" + uTCTime + CVDDMConstant.PARTIISPEC_AWS_FILE_FORMAT;

					log.info("AWS Key " + key);

					byte[] partIISpec = partIISpecFromAWS.getPartIISpecFromAWS(key); // get Part2Spec from AWS

					if (null == partIISpec) {
						log.info("PartIISpec is not available in AWS " + key);
						FacesContext.getCurrentInstance().addMessage(null,
								new FacesMessage(FacesMessage.SEVERITY_ERROR,
										CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
												CVDDMConstant.NO_P2S_DATA_MSG),
										CVDDMConstant.VALIDATION_ERR));
						this.setPartIISpecRespAval(CVDDMConstant.STRING_N);

					} else {
						List<PartIISpecFeatures> features = getFeatureListFromPartIISpec(partIISpec);
						log.info("PartIISpec Feature is " + features);
						setPartIISpecFeatures(features);
					}

				}

			} catch (Exception e) {
				log.severe(CvddmUtil.getStackTraceContent(e));
				throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
						CvddmUtil.getStackTraceContent(e), e);
			}
		}

		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/*** End Change: User Story :US1048243 ***/

	/**
	 * Private method to clear existing form data
	 * 
	 */
	public void clearExistingFormData() {

		final String METHOD_NAME = "clearExistingFormData";
		log.entering(CLASS_NAME, METHOD_NAME);

		if (!CvddmUtil.isObjectEmpty(this.partIISpecFeatures)) {
			this.partIISpecFeatures.clear();
		}

		if (!CvddmUtil.isObjectEmpty(this.filteredPartIISpecFeatures)) {
			this.filteredPartIISpecFeatures.clear();
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

	}

	/**
	 * Private method to clear existing input data
	 * 
	 */
	public void clearExistingInputData() {

		final String METHOD_NAME = "clearExistingInputData";
		log.entering(CLASS_NAME, METHOD_NAME);

		if (!CvddmUtil.isObjectEmpty(this.inputPartIISpec)) {
			this.inputPartIISpec = null;
		}
		if (!CvddmUtil.isObjectEmpty(this.selectedEnv)) {
			this.selectedEnv = null;
		}

		this.setPartIISpecRespAval(CVDDMConstant.STRING_N);

		clearExistingFormData();

		log.exiting(CLASS_NAME, METHOD_NAME);

	}

	/**
	 * Private method to set invalid part II spec
	 * 
	 */
	private void setInvalidPartIISpecMessage() {

		final String METHOD_NAME = "setInvalidPartIISpecMessage";
		log.entering(CLASS_NAME, METHOD_NAME);
		log.info("Input PartIISpec is invalid");
		clearExistingFormData();
		FacesContext.getCurrentInstance().addMessage(null,
				new FacesMessage(FacesMessage.SEVERITY_ERROR, CvddmUtil
						.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY, CVDDMConstant.VALID_P2S_MSG),
						CVDDMConstant.VALIDATION_ERR));
		this.setPartIISpecRespAval(CVDDMConstant.STRING_N);
		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * 
	 * 
	 * @param partIiSpecFileEntry
	 * @return
	 */
	private List<PartIISpecFeatures> getFeatureListFromPartIISpec(byte[] partIiSpecFileEntry) {

		final String METHOD_NAME = "getFeatureListFromPartIISpec";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<PartIISpecFeatures> features = new ArrayList<>();

		try {

			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();

			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(new InputSource(new ByteArrayInputStream(partIiSpecFileEntry)));

			doc.getDocumentElement().normalize();
			log.info("Root element :" + doc.getDocumentElement().getNodeName());

			NodeList nList = doc.getElementsByTagName(CVDDMConstant.PARTIISPEC_DID_TAG_NAME);

			Node requiredNode = null;
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node cureNode = nList.item(temp);
				log.info("Current Element is :" + cureNode.getNodeName());

				if (cureNode.getNodeType() == Node.ELEMENT_NODE) {

					// Get attributes for this Node
					NamedNodeMap attributes = cureNode.getAttributes();
					int numAttrs = attributes.getLength();
					for (int i = 0; i < numAttrs; i++) {

						Attr attr = (Attr) attributes.item(i);

						String attrName = attr.getNodeName();
						String attrValue = attr.getNodeValue();

						// Check if we got Proper Node
						if (TextUtil.isNotBlankOrNull(attrName)
								&& CVDDMConstant.PARTIISPEC_FEATURE_HEADER_ID.equals(attrName)
								&& TextUtil.isNotBlankOrNull(attrValue)) {

							requiredNode = cureNode;
							log.info("Now Got the required Node, Get ALL Features Now");

							Element requiredNodeElement = (Element) requiredNode;

							String featureName = requiredNodeElement
									.getElementsByTagName(CVDDMConstant.PARTIISPEC_FEATURE_HEADER_NAME).item(0)
									.getTextContent().replace("/", "_");
							PartIISpecFeatures p2sFeatures = new PartIISpecFeatures();
							p2sFeatures.setId(attrValue.replace(CVDDMConstant.PARTIISPEC_DID_REPLACE, ""));
							p2sFeatures.setName(featureName);
							NodeList subFieldNodeList = requiredNodeElement
									.getElementsByTagName(CVDDMConstant.SUB_FIELD);

							List<SubFieldListFeatures> subFieldListFeatures = new ArrayList<>();
							for (int featureIndex = 0; featureIndex < subFieldNodeList.getLength(); featureIndex++) {
								SubFieldListFeatures subFieldListFeaturess = new SubFieldListFeatures();
								Node nNode1 = subFieldNodeList.item(featureIndex);
								Element eElement1 = (Element) nNode1;
								String subfieldfeatureId = eElement1.getAttributeNode(CVDDMConstant.ID).getValue();
								String subfieldfeatureName = eElement1.getElementsByTagName(CVDDMConstant.NAME).item(0)
										.getTextContent().replace("/", "_");
								String subfieldmsbbit = eElement1.getElementsByTagName(CVDDMConstant.MOST_SIG_BIT)
										.item(0).getTextContent();
								String subfieldleastsigbit = eElement1.getElementsByTagName(CVDDMConstant.LEAST_SIG_BIT)
										.item(0).getTextContent();

								subFieldListFeaturess.setId(subfieldfeatureId);
								subFieldListFeaturess.setName(subfieldfeatureName);
								subFieldListFeaturess.setMostsigbit(subfieldmsbbit);
								subFieldListFeaturess.setLeastsigbit(subfieldleastsigbit);

								NodeList dataDefinitionList = eElement1
										.getElementsByTagName(CVDDMConstant.DATA_DEFINITION);
								Node definationNode = dataDefinitionList.item(0);

								if (definationNode != null) {
									List<EnumertedParameter> enumertedParameterList = new ArrayList<>();
									NodeList nodeList = definationNode.getChildNodes();

									for (int j = 0; j < nodeList.getLength(); j++) {
										Node childNode = nodeList.item(j);

										if (CVDDMConstant.ENUMERATED_PARAMETERS.equals(childNode.getNodeName())) {

											Node enumParam = nodeList.item(j);
											NodeList enumnodeList = enumParam.getChildNodes();
											for (int k = 0; k < enumnodeList.getLength(); k++) {
												Node enumNode = enumnodeList.item(k);

												if (CVDDMConstant.ENUM_MEMBER.equals(enumNode.getNodeName())) {
													EnumertedParameter enumertedParametervalues = new EnumertedParameter();
													Element eElement2 = (Element) enumNode;

													String value = eElement2
															.getElementsByTagName(CVDDMConstant.ENUM_VALUE).item(0)
															.getTextContent();

													String decription = eElement2
															.getElementsByTagName(CVDDMConstant.DESCRIPTION).item(0)
															.getTextContent();
													enumertedParametervalues.setEnumValue(value);
													enumertedParametervalues.setDescription(decription);
													enumertedParameterList.add(enumertedParametervalues);
												}

											}

										}
									}
									subFieldListFeaturess.setEnumertedParameters(enumertedParameterList);
								}

								subFieldListFeatures.add(subFieldListFeaturess);
							}
							p2sFeatures.setSubFieldListFeatureslist(subFieldListFeatures);
							features.add(p2sFeatures);
						}
					}

				}
			}
		} catch (SAXParseException e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR,
							CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
									CVDDMConstant.INVALID_MDX_FILE),
							CVDDMConstant.VALIDATION_ERR));

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);

		}

		log.exiting(CLASS_NAME, METHOD_NAME);
		return features;
	}

	public void updateHistoryTable(String inputPartIISpec, String status, String errorMessage) {

		final String METHOD_NAME = "updateHistoryTable";

		try {

			Map<String, String> inputMap = new HashMap<String, String>();

			// Environment
			switch (this.selectedEnv) {

			case CVDDMConstant.ENV_QA1:
				inputMap.put(CVDDMConstant.HISTORY_UTILITY_ENVIRONMENT_ID, CvddmUtil.getPropertiesValue(
						CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, CVDDMConstant.HISTORY_UTILITY_ENV_QA1));
				break;

			case CVDDMConstant.ENV_QA2:
				inputMap.put(CVDDMConstant.HISTORY_UTILITY_ENVIRONMENT_ID, CvddmUtil.getPropertiesValue(
						CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, CVDDMConstant.HISTORY_UTILITY_ENV_QA2));
				break;
			default:
				inputMap.put(CVDDMConstant.HISTORY_UTILITY_ENVIRONMENT_ID, CvddmUtil.getPropertiesValue(
						CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, CVDDMConstant.HISTORY_UTILITY_ENV_QA1));
				break;
			}

			// Application
			inputMap.put(CVDDMConstant.HISTORY_UTILITY_APPLICATION_ID, CvddmUtil.getPropertiesValue(
					CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, CVDDMConstant.HISTORY_UTILITY_APP_AWS));

			// PartIIspec
			inputMap.put(CVDDMConstant.HISTORY_UTILITY_PARTIISPEC, inputPartIISpec);

			if (CVDDMConstant.STRING_Y.equalsIgnoreCase(status)) {

				inputMap.put(CVDDMConstant.HISTORY_UTILITY_WEBSERVICE_STATUS, CVDDMConstant.STRING_Y);
				inputMap.put(CVDDMConstant.HISTORY_UTILITY_WEBSERVICE_ERROR, CVDDMConstant.SUCCESS);

				historyUtilityBF.savePartIISpecHistoryRcrd(inputMap);
			} else {

				inputMap.put(CVDDMConstant.HISTORY_UTILITY_WEBSERVICE_STATUS, CVDDMConstant.STRING_N);
				inputMap.put(CVDDMConstant.HISTORY_UTILITY_WEBSERVICE_ERROR, errorMessage);
				historyUtilityBF.savePartIISpecHistoryRcrd(inputMap);
			}

		}

		catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}
	}

	public void navigateToHistoryPage() {

		final String METHOD_NAME = "navigateToHistoryPage";

		log.entering(CLASS_NAME, METHOD_NAME);

		try {
			FacesContext context = FacesContext.getCurrentInstance();
			context.getExternalContext().redirect(CvddmUtil.getPropertiesValue(
					CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, CVDDMConstant.PARTIISPEC_HISTORY_PAGE_PATH));
		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}
	}

}