/**
 * 
 */
package com.ford.cvddm.inbound.layer.util;

import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.domain.maintenance.de.CvddmMaintRcrdDE;
import com.ford.cvddm.maintenance.business.list.ListCvddmMaintenanceBF;
import com.ford.cvddm.sob.business.layer.CVDDMBusinessException;
import com.ford.it.exception.FordExceptionAttributes;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;
import com.ford.it.util.TextUtil;

/**
 * 
Class Name: PopupAlertUtil
@Description: US987948 :This class contains Method for Pop Up or Alerts for CVDDM Application.
@author NGUPTA18
 *
 */
public class PopupAlertUtil {

	private static final String CLASS_NAME =
			PopupAlertUtil.class.getName();
	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	protected static ListCvddmMaintenanceBF cvddmMaintenanceBF ;


	/**
	 * Private class constructor.
	 */

	private PopupAlertUtil() {

		super();

	}

	/***  Start Change: User Story : US987948 ***/

	/**
	 * Method Name: getCommonMenuDts()
	 * @Description:This method retrieves Alert Description for CVDDM Common Menus (All Menus/All Sub Menus).
	 * @param None
	 * @return StringBuilder popUpContent
	 */

	public static StringBuilder getCommonMenuDts() {

		final String METHOD_NAME = "getCommonMenuDts";
		log.entering(CLASS_NAME, METHOD_NAME);

		CvddmMaintRcrdDE  cvddmRcrd = null;

		String cvddmScreenCd  = null;

		StringBuilder popUpContent = new StringBuilder();
		
		cvddmMaintenanceBF = new ListCvddmMaintenanceBF();

		try {
			/** First get check for All Menu Alert Rcrd ****/
			cvddmScreenCd = CvddmUtil.getPropertiesValue( 
					CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, CVDDMConstant.ALL_MENU_SCRN_CD);

		
			cvddmRcrd = cvddmMaintenanceBF.getAlertRecord(cvddmScreenCd);

			if(!CvddmUtil.isObjectEmpty(cvddmRcrd) 
					&& TextUtil.isNotBlankOrNull(cvddmRcrd.getCvdmMaintDesc())) {

				popUpContent.append(cvddmRcrd.getCvdmMaintDesc());
				popUpContent.append(CVDDMConstant.COMMA_SYMBOL);
			}

			/** Second  check for All Sub Menu Alert Rcrd ****/

			cvddmScreenCd = CvddmUtil.getPropertiesValue( 
					CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, CVDDMConstant.ALL_SUB_MENU_SCRN_CD);

			cvddmRcrd = cvddmMaintenanceBF.getAlertRecord(cvddmScreenCd);

			if(!CvddmUtil.isObjectEmpty(cvddmRcrd) 
					&& TextUtil.isNotBlankOrNull(cvddmRcrd.getCvdmMaintDesc())) {

				popUpContent.append(cvddmRcrd.getCvdmMaintDesc());
				popUpContent.append(CVDDMConstant.COMMA_SYMBOL);
			}
		}
		catch(Exception ex) {

			log.severe(CvddmUtil.getStackTraceContent(ex));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(
					CLASS_NAME, METHOD_NAME).build(), CvddmUtil.getStackTraceContent(ex), ex);
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
		return popUpContent;
	}

	/**
	 * Method Name: getParentandSubMenuDts()
	 * @Description:This method retrieves Alert Description passed Parent Menu Screen and its Child/ Sub Menu Screen.
	 * @param String parentScrnCd , String childScrnCd
	 * @return StringBuilder popUpContent
	 */

	public static StringBuilder getParentandSubMenuDts(String parentScrnCd , String childScrnCd) {

		final String METHOD_NAME = "getParentandSubMenuDts";
		log.entering(CLASS_NAME, METHOD_NAME);

		CvddmMaintRcrdDE  cvddmRcrd = null;

		String cvddmScreenCd  = null;

		StringBuilder popUpContent = new StringBuilder();
		
		cvddmMaintenanceBF = new ListCvddmMaintenanceBF();

		try {
			/**   check for Parent Header Menu Alert Rcrd ****/

			cvddmScreenCd = CvddmUtil.getPropertiesValue( 
					CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, parentScrnCd);

			if(TextUtil.isNotBlankOrNull(cvddmScreenCd)) {

				cvddmRcrd = cvddmMaintenanceBF.getAlertRecord(cvddmScreenCd);

				if(!CvddmUtil.isObjectEmpty(cvddmRcrd) 
						&& TextUtil.isNotBlankOrNull(cvddmRcrd.getCvdmMaintDesc())) {

					popUpContent.append(cvddmRcrd.getCvdmMaintDesc());
					popUpContent.append(CVDDMConstant.COMMA_SYMBOL);
				}
			}
			
			/**   check for Child Menu Alert Rcrd ****/

			cvddmScreenCd = CvddmUtil.getPropertiesValue( 
					CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, childScrnCd);

			if(TextUtil.isNotBlankOrNull(cvddmScreenCd)) {

				cvddmRcrd = cvddmMaintenanceBF.getAlertRecord(cvddmScreenCd);

				if(!CvddmUtil.isObjectEmpty(cvddmRcrd) 
						&& TextUtil.isNotBlankOrNull(cvddmRcrd.getCvdmMaintDesc())) {

					popUpContent.append(cvddmRcrd.getCvdmMaintDesc());
					popUpContent.append(CVDDMConstant.COMMA_SYMBOL);
				}
			}
		}
		catch(Exception ex) {

			log.severe(CvddmUtil.getStackTraceContent(ex));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(
					CLASS_NAME, METHOD_NAME).build(), CvddmUtil.getStackTraceContent(ex), ex);
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
		return popUpContent;
	}
	
/***  Start Change: User Story : US987948 ***/
	
	/**
     * Method Name: prepareAlertsMsgDesc()
     * @Description:This method would prepare Final Content for Alert/Pop up.
     * @param String parentScrnCd , String childScrnCd
     * @return String
     */
	
	public static String prepareAlertsMsgDesc(String parentScrnCd , String childScrnCd) {

		final String METHOD_NAME = "prepareAlertsMsgDesc";
		log.entering(CLASS_NAME, METHOD_NAME);

		StringBuilder popUpContent = new StringBuilder();

		StringBuilder tempContent = null;

		String alertMsg = null;

		try {

			tempContent = PopupAlertUtil.getCommonMenuDts();

			popUpContent.append(tempContent);

			tempContent = PopupAlertUtil.getParentandSubMenuDts(parentScrnCd ,childScrnCd);

			popUpContent.append(tempContent);

			if(TextUtil.isNotBlankOrNull(popUpContent.toString())) {

				alertMsg = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY, CVDDMConstant.ALERT_MSG);

				alertMsg = alertMsg.replaceAll("CUSTOMALERT", popUpContent.toString());	
			}

			else {		
				alertMsg = CVDDMConstant.EMPTY_STRING;
			}
		}
		catch(Exception ex) {
			log.severe(CvddmUtil.getStackTraceContent(ex));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(
					CLASS_NAME, METHOD_NAME).build(), CvddmUtil.getStackTraceContent(ex), ex);
		}
		
		return alertMsg;
	}	

	/***  End Change: User Story : US987948 ***/
}
