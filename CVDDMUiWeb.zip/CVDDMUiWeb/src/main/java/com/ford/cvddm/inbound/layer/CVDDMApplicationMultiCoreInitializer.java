//****************************************************************
//* Copyright (c) 2015 Ford Motor Company. All Rights Reserved.
//****************************************************************
package com.ford.cvddm.inbound.layer;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.it.multicore.MultiCoreAttributes;
import com.ford.it.multicore.MultiCoreCapabilityHelper;
import com.ford.it.multicore.MultiCoreTaskManager;
import com.ford.it.multicore.MultiCoreTaskManagerFactory;
import com.ford.it.persistencecore.context.PcConfigInitializer;
import com.ford.it.security.plugins.AuthorizationInitializer;
import com.ford.it.util.oauth2.OAuth2CredentialsConfigInitializer;
import com.ford.it.util.wsl.WSLCredentialsProviderInitializer;
import com.ford.it.wscore.context.WscConfigInitializer;

/**
 * Run the initializers concurrently when the managed threads are available, otherwise run the
 * initializers sequentially.
 */
public class CVDDMApplicationMultiCoreInitializer implements ServletContextListener {

    /**
     * @see javax.servlet.ServletContextListener#contextDestroyed(javax.servlet.ServletContextEvent)
     */
    @Override
    public void contextDestroyed(final ServletContextEvent contextEvent) {
        // default implementation
    }
    /*** Start Change :User Story: US945528**/
    /*Set this system property to "true" to enable partial Email send: succeed even
    if one of the recipients is invalid.*/
    static { 
    	System.setProperty(CVDDMConstant.SYS_PROPERTY_PARTIALSEND, CVDDMConstant.TRUE);
    }
    /*** End Change :User Story: US945528**/

    /**
     * @see javax.servlet.ServletContextListener#contextInitialized(javax.servlet.ServletContextEvent)
     */
    @Override
    public void contextInitialized(final ServletContextEvent contextEvent) {
        final boolean useManagedThread =
                new MultiCoreCapabilityHelper().isManagedThreadCapable();
        if (useManagedThread) {
            concurrentInitializer(contextEvent);

        } else {
            sequentialInitializer(contextEvent);
        }    
        
    }

    private void sequentialInitializer(final ServletContextEvent contextEvent) {
    	
    	new CVDDMApplicationInitializer().contextInitialized(contextEvent);
        new PcConfigInitializer().contextInitialized(contextEvent);
        new AuthorizationInitializer().contextInitialized(contextEvent);
        new WscConfigInitializer().contextInitialized(contextEvent);
        new WSLCredentialsProviderInitializer().contextInitialized(contextEvent);
        //Start Change
        new OAuth2CredentialsConfigInitializer().contextInitialized(contextEvent);
         //End Change
    }

    private void concurrentInitializer(final ServletContextEvent contextEvent) {

        new CVDDMApplicationInitializer().contextInitialized(contextEvent);

        final MultiCoreTaskManagerFactory<CVDDMMultiCoreInitializerInput, Void> tmf =
                new MultiCoreTaskManagerFactory<CVDDMMultiCoreInitializerInput, Void>();

        final List<CVDDMMultiCoreInitializerInput> servletListenerInputList =
                new ArrayList<CVDDMMultiCoreInitializerInput>();

        final CVDDMMultiCoreInitializerInput pcConfigInitializerInput =
            new CVDDMMultiCoreInitializerInput();
        pcConfigInitializerInput.setServletContextListener(new PcConfigInitializer());
        pcConfigInitializerInput.setContextEvent(contextEvent);
        servletListenerInputList.add(pcConfigInitializerInput);

        final CVDDMMultiCoreInitializerInput authorizationInitializerInput =
                new CVDDMMultiCoreInitializerInput();
        authorizationInitializerInput
                .setServletContextListener(new AuthorizationInitializer());
        authorizationInitializerInput.setContextEvent(contextEvent);
        servletListenerInputList.add(authorizationInitializerInput);

        final CVDDMMultiCoreInitializerInput wscConfigInitializerInput =
                new CVDDMMultiCoreInitializerInput();
        wscConfigInitializerInput.setServletContextListener(new WscConfigInitializer());
        wscConfigInitializerInput.setContextEvent(contextEvent);
        servletListenerInputList.add(wscConfigInitializerInput);

        final CVDDMMultiCoreInitializerInput wslCredentialsProviderInitializerInput =
            new CVDDMMultiCoreInitializerInput();
        wslCredentialsProviderInitializerInput
            .setServletContextListener(new WSLCredentialsProviderInitializer());
        wslCredentialsProviderInitializerInput.setContextEvent(contextEvent);
        servletListenerInputList.add(wslCredentialsProviderInitializerInput);
        
        
        

        final MultiCoreAttributes<CVDDMMultiCoreInitializerInput> attributes =
                new MultiCoreAttributes.Builder<CVDDMMultiCoreInitializerInput>(
                        CVDDMMultiCoreInitializerTask.class)
                                .taskInputList(servletListenerInputList)
                                .build();

        final MultiCoreTaskManager<CVDDMMultiCoreInitializerInput, Void> taskManager = tmf
                .createInstance(attributes);

        taskManager.submitTasks();
    }
}