// ******************************************************************************
// * Copyright (c) 2015 Ford Motor Company. All Rights Reserved.
// * Original author: Ford Motor Company J2EE Center of Excellence
// *
// ******************************************************************************
package com.ford.cvddm.inbound.layer;

import javax.enterprise.inject.Produces;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.deltaspike.core.api.scope.ViewAccessScoped;

import com.ford.aps.Subject;
import com.ford.aps.WSL;
import com.ford.cvddm.common.layer.authorization.CVDDMAuthorizationProvider;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.it.jsfcore.util.JcAuthorizationUtil;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;
import com.ford.it.security.plugins.AuthorizationProvider;
import com.ford.it.security.plugins.aps.APSAuthorizationProviderFactory;

/**
 * This factory class creates a 'authorization provider'. When a client invokes
 * the <code>getProvider()</code> method the first time, the factory
 * instantiates a 'authorization provider' and stores it in session. Subsequent
 * calls to the <code>getProvider()</code> method return the cached
 * authorization provider.
 *
 * @since v. 1.0
 */

public class CVDDMAuthorizationProviderFactory
        extends APSAuthorizationProviderFactory {

    /**
     * Logging.
     */
    private static final String CLASS_NAME =
            CVDDMAuthorizationProviderFactory.class.getName();

    /**
     * Logging.
     */
    private static final ILogger log = LogFactory.getInstance().getLogger(
            CLASS_NAME);

    private FacesContext facesContext;

    /**
     * This style of injection, known as parameter injection, is used to support
     * unit testing. During testing, custom objects can be set when real objects
     * such as context are not available.
     *
     * @param facesContext JSF Faces Context
     */
 /*   @Inject
    public void setFacesContext(final FacesContext facesContext) {
        this.facesContext = facesContext;
    }*/

    /**
     * Gets the current faces context.
     *
     * @return FacesContext instance
     */
    protected FacesContext getFacesContext() {
        return this.facesContext;
    }

    /**
     * Producer of AuthorizationProvider
     *
     * @return provider
     */

    @Produces
    @ViewAccessScoped
    @CVDDMAuthProvider
    public AuthorizationProvider produceCVDDMAuthorizationProvider() {

        final String METHOD_NAME = "produceCVDDMAuthorizationProvider";
        log.entering(CLASS_NAME, METHOD_NAME);

        final AuthorizationProvider provider =
                JcAuthorizationUtil.getAuthorizationProvider(
                        (HttpServletRequest)getFacesContext().getExternalContext()
                                .getRequest());

        return provider;
    }

    /**
     * This method returns authorization provider. Overloaded method to allow
     * the use of authorization in those cases when request object is not easily
     * available. Note that this object does not use caching in the request and
     * should be avoided when request object <b>is</b> easily available.
     *
     * @return AuthorizationProvider the authorization provider
     */
    public AuthorizationProvider getProvider() {

        final String METHOD_NAME = "getProvider";
        log.entering(CLASS_NAME, METHOD_NAME);

        // Instantiate a provider.

        final CVDDMAuthorizationProvider provider = new CVDDMAuthorizationProvider();

        log.exiting(CLASS_NAME, METHOD_NAME, provider);
        return provider;
    }

    /**
     * @see com.ford.it.security.plugins.aps.APSAuthorizationProviderFactory#getProvider(java.lang.String)
     */
    @Override
    
    public AuthorizationProvider getProvider(final String userId) {

        final String METHOD_NAME = "getProvider";
        log.entering(CLASS_NAME, METHOD_NAME);

        // Instantiate a provider.

        final CVDDMAuthorizationProvider provider = new CVDDMAuthorizationProvider();
        String email = CVDDMAuthorizationProvider.formatUserEmail(userId);
        final Subject subject  =  createSubject(email);
        provider.setSubject(subject);
        log.exiting(CLASS_NAME, METHOD_NAME, provider);
        return provider;
    }
    
    /**
     * Create a Subject based on the e-mail
     *
     * @param userEmail
     * @return
     */
    public Subject createSubject(final String userEmail) {
        final String METHOD_NAME = "createSubject";
        log.entering(CLASS_NAME, METHOD_NAME);

        final WSL authenticationProvider = new WSL();
        // Update WSL with the userEmail.
        authenticationProvider.setId(userEmail);

        // Perform an FDS lookup for user email.
        final Subject subject = new Subject();

        // setSubjectIdProvider will take SubjectIdProvider as argument
        // and aps.WSL implements SubjectIdProvider.
        subject.setSubjectIdProvider(authenticationProvider);

        // set subject id from which is the userEmail.
        subject.setId(userEmail);

        log.exiting(CLASS_NAME, METHOD_NAME);
        return subject;
    }

    /**
     * This method returns authorization provider.
     *
     * @param request the HttpServletRequest context
     * @return AuthorizationProvider the authorization provider
     */
    @Override
    public AuthorizationProvider getProvider(final HttpServletRequest request) {

        final String METHOD_NAME = "getProvider(HttpServletRequest)";
        log.entering(CLASS_NAME, METHOD_NAME);
        
		FacesContext fc = FacesContext.getCurrentInstance();
		HttpServletRequest req = (HttpServletRequest) fc.getExternalContext().getRequest();
	
        /*UserAuthorizationBean user = new UserAuthorizationBean();
        try {
			user.userCVDDMAuthorized(null);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
        // Note: The provider is cached in the request rather than session.
        // This is because a user has an alias id that can change between
        // requests. Normally this would be cached in session.
        
        // Retrieve the provider from the request.
        AuthorizationProvider authorizationProvider =
                (AuthorizationProvider)request
                        .getAttribute(CVDDMConstant.AUTHORIZATION_PROVIDER);

        // Check for null.
        if (authorizationProvider == null) {

            // instantiate a new provider
        	String userId=null;
    	
           userId=request.getUserPrincipal().getName();
           
           authorizationProvider = getProvider(userId);

            // Store in the request.
            request.setAttribute(CVDDMConstant.AUTHORIZATION_PROVIDER,
                    authorizationProvider);
        }


        log.exiting(CLASS_NAME, METHOD_NAME);
        return authorizationProvider;
    }
    
}
