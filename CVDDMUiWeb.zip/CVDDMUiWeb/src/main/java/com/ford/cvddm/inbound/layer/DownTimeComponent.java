package com.ford.cvddm.inbound.layer;

import javax.faces.component.FacesComponent;
import javax.faces.component.UIComponentBase;

import com.ford.cvddm.constant.CVDDMConstant;

/**
 * DownTimeComponent : This class contains method for CVDDMCore Tags
 * defined in cvddmcore.taglib.xml
 * User Story :US890091
 * @author NGUPTA18
 *
 */
@FacesComponent(value = "cvddmcore.downTime")
public class DownTimeComponent extends UIComponentBase {

	/* (non-Javadoc)
	 * @see javax.faces.component.UIComponent#getFamily()
	 */
	@Override
	public String getFamily() {
		return CVDDMConstant.CVDDM_COMPONENT_FAMILY;
	}

}