//****************************************************************
//* Copyright (c) 2015 Ford Motor Company. All Rights Reserved.
//****************************************************************
package com.ford.cvddm.inbound.layer;

import javax.enterprise.context.ApplicationScoped;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import com.ford.it.multicore.MultiCoreTaskCommand;

/**
 * Task for run CVDDM initializers
 */
@ApplicationScoped
public class CVDDMMultiCoreInitializerTask
        implements MultiCoreTaskCommand<CVDDMMultiCoreInitializerInput, Void> {

    /**
     * @see com.ford.it.multicore.MultiCoreTaskCommand#process(int, java.lang.Object)
     */
    @Override
    public Void process(final int taskId, final CVDDMMultiCoreInitializerInput taskInput)
            throws Exception {

        final ServletContextListener servletContextListener =
                taskInput.getServletContextListener();
        final ServletContextEvent contextEvent = taskInput.getContextEvent();

        servletContextListener.contextInitialized(contextEvent);
        return null;
    }
}