package com.ford.cvddm.inbound.ui.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import org.primefaces.event.CellEditEvent;
import org.primefaces.event.RowEditEvent;

import com.ford.cvddm.bf.CVDDMRequestsBF;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.de.CVDDMRequestsDE;
import com.ford.cvddm.givis.business.EOLFileTransferBF;
import com.ford.cvddm.givis.business.GivisModuleStateBF;
import com.ford.cvddm.gvms.aws.PartIISpecFromAWS;
import com.ford.cvddm.outbound.givis.soap.TestGivisHttpPost;
import com.ford.cvddm.outbound.ivsu.rest.IVSURestClients;
import com.ford.cvddm.outbound.rvcm.ecu.RVCMApplicationTCUValidation;

@ManagedBean
@ApplicationScoped
public class CVDDMRequestsBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<CVDDMRequestsDE> requests = new ArrayList<>();

	public List<CVDDMRequestsDE> getRequests() {
		return requests;
	}

	public void setRequests(List<CVDDMRequestsDE> requests) {
		this.requests = requests;
	}

	private CVDDMRequestsDE selectedRequest;

	public CVDDMRequestsDE getSelectedRequest() {
		return selectedRequest;
	}

	public void setSelectedRequest(CVDDMRequestsDE selectedRequest) {
		this.selectedRequest = selectedRequest;
	}

	private Map<String, String> enviroinments = new HashMap<>();
	private Map<String, String> requestStatusItems = new HashMap<>();

	public Map<String, String> getEnviroinments() {
		return enviroinments;
	}

	public void setEnviroinments(Map<String, String> enviroinments) {
		this.enviroinments = enviroinments;
	}

	public Map<String, String> getRequestStatusItems() {
		return requestStatusItems;
	}

	public void setRequestStatusItems(Map<String, String> requestStatusItems) {
		this.requestStatusItems = requestStatusItems;
	}

	private String requestId;
	private String programCode;
	private long modelYear;
	private String enviroinment;
	private String requestedBy;
	private String requestStatus;

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getProgramCode() {
		return programCode;
	}

	public void setProgramCode(String programCode) {
		this.programCode = programCode;
	}

	public long getModelYear() {
		return modelYear;
	}

	public void setModelYear(long modelYear) {
		this.modelYear = modelYear;
	}

	public String getEnviroinment() {
		return enviroinment;
	}

	public void setEnviroinment(String enviroinment) {
		this.enviroinment = enviroinment;
	}

	public String getRequestedBy() {
		return requestedBy;
	}

	public void setRequestedBy(String requestedBy) {
		this.requestedBy = requestedBy;
	}

	public String getRequestStatus() {
		return requestStatus;
	}

	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}

	public CVDDMRequestsBF getcVDDMRequestsBF() {
		return cVDDMRequestsBF;
	}

	public void setcVDDMRequestsBF(CVDDMRequestsBF cVDDMRequestsBF) {
		this.cVDDMRequestsBF = cVDDMRequestsBF;
	}

	private String ivsFeedDetails;
	private String validateIvsFeedDetails;

	public String getValidateIvsFeedDetails() {
		return validateIvsFeedDetails;
	}

	public void setValidateIvsFeedDetails(String validateIvsFeedDetails) {
		this.validateIvsFeedDetails = validateIvsFeedDetails;
	}

	public String getIvsFeedDetails() {
		return ivsFeedDetails;
	}

	public void setIvsFeedDetails(String ivsFeedDetails) {
		this.ivsFeedDetails = ivsFeedDetails;
	}

	@Inject
	private CVDDMRequestsBF cVDDMRequestsBF;

	@Inject
	private PartIISpecFromAWS partIISpecFromGVMSAWS;

	@Inject
	private RVCMApplicationTCUValidation rVCMApplicationTCUValidation;

	@Inject
	private IVSURestClients iVSURestClients;

	private String givisTokenResponse;

	public String getGivisTokenResponse() {
		return givisTokenResponse;
	}

	public void setGivisTokenResponse(String givisTokenResponse) {
		this.givisTokenResponse = givisTokenResponse;
	}

	@PostConstruct
	public void init() {
		System.out.println("Inside Init");
		List<CVDDMRequestsDE> employees = new ArrayList<>();
		System.out.println("INSIDE INIT METHOD -------------" + employees.size());
		setRequests(employees);

		enviroinments.put("QA1", "QA1");
		enviroinments.put("QA2", "QA2");
		enviroinments.put("QA3", "QA3");

		requestStatusItems.put("Submitted", "Submitted");
		requestStatusItems.put("OnHold", "OnHold");
		requestStatusItems.put("Reviewed", "Reviewed");

		setGivisTokenResponse(testGivisVehicleModuleStateQA1() + "");

	}

	public void onRowEdit(RowEditEvent event) {
		System.out.println("Inside onRowEdit " + (CVDDMRequestsDE) event.getObject());
		cVDDMRequestsBF.updateCVDDMRequests(((CVDDMRequestsDE) event.getObject()));
		FacesMessage msg = new FacesMessage("Request Edited", ((CVDDMRequestsDE) event.getObject()).getRequestId());
		FacesContext.getCurrentInstance().addMessage(null, msg);
	}

	public void onRowCancel(RowEditEvent event) {
		System.out.println("Inside onRowCancel " + (CVDDMRequestsDE) event.getObject());
		FacesMessage msg = new FacesMessage("Edit Cancelled", ((CVDDMRequestsDE) event.getObject()).getRequestId());
		FacesContext.getCurrentInstance().addMessage(null, msg);
	}

	public void onCellEdit(CellEditEvent event) {
		Object oldValue = event.getOldValue();
		Object newValue = event.getNewValue();

		if (newValue != null && !newValue.equals(oldValue)) {
			FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Request Changed",
					"Old: " + oldValue + ", New:" + newValue);
			FacesContext.getCurrentInstance().addMessage(null, msg);
		}
		System.out.println("Inside onCellEdit");
	}

	/**
	 * 
	 * @return
	 */
	public String addAction() {

		CVDDMRequestsDE cVDDMRequestsDE = new CVDDMRequestsDE();
		cVDDMRequestsDE.setRequestedBy(requestedBy);
		cVDDMRequestsDE.setRequestStatus(requestStatus);
		cVDDMRequestsDE.setEnviroinment(enviroinment);
		cVDDMRequestsDE.setProgramCode(programCode);
		cVDDMRequestsDE.setModelYear(modelYear);
		cVDDMRequestsBF.saveCVDDMRequests(cVDDMRequestsDE);

		FacesMessage msg = new FacesMessage("New Req added");
		FacesContext.getCurrentInstance().addMessage(null, msg);

		List<CVDDMRequestsDE> employees = cVDDMRequestsBF.retrieveCVDDMRequestsListReadOnly();
		setRequests(employees);

		return null;
	}

	/**
	 * 
	 */
	public void delete(CVDDMRequestsDE cVDDMRequestsDE) {
		System.out.println("Inside delete");
		cVDDMRequestsBF.deleteCVDDMRequests(cVDDMRequestsDE.getRequestId());
		FacesMessage msg = new FacesMessage("Request Deleted", (cVDDMRequestsDE.getRequestId()));
		FacesContext.getCurrentInstance().addMessage(null, msg);
	}

	String partIISpecString;

	public String getPartIISpecString() {
		return partIISpecString;
	}

	public void setPartIISpecString(String partIISpecString) {
		this.partIISpecString = partIISpecString;
	}

	String partIISpecFromIVSUString;

	public String getPartIISpecFromIVSUString() {
		return partIISpecFromIVSUString;
	}

	public void setPartIISpecFromIVSUString(String partIISpecFromIVSUString) {
		this.partIISpecFromIVSUString = partIISpecFromIVSUString;
	}

	/**
	 * 
	 * @return
	 */
	private boolean testGivisVehicleModuleStateQA1() {
		boolean done = false;
		try {
			Map<String, Object> inputMap = new HashMap<>();
			inputMap.put(CVDDMConstant.VIN_NUMBER, "");

			inputMap.put(CVDDMConstant.ENV_TYPE, "QA2");

			//GivisModuleStateBF givisModuleStateBF = new GivisModuleStateBF();
			//done = givisModuleStateBF.pushAnalyzeLogtoGIVIS(inputMap);
			
			EOLFileTransferBF eolFileTransferBF = new EOLFileTransferBF();
			done = eolFileTransferBF.initiateEOLTransfer(inputMap);
		} catch (Exception e) {
			System.out.println("********************** 10 ********** " + e.getMessage());
			e.printStackTrace();
		}

		return done;

	}

}
