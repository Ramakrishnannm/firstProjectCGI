package com.ford.cvddm.inbound.layer.authorization;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.event.ComponentSystemEvent;

import org.apache.deltaspike.core.api.scope.GroupedConversationScoped;

import com.ford.cvddm.inbound.layer.base.CVDDMBaseBean;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;

@ManagedBean(name = "user")
@SessionScoped
@GroupedConversationScoped
public class UserAuthorizationBean extends CVDDMBaseBean {



	 private static final String CLASS_NAME =
			 UserAuthorizationBean.class.getName();
	 private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	@Override
	protected void preRenderViewStartWorkflowTM() {
		log.info("preRenderViewStartWorkflowTM");

	}	
	public void userCVDDMAuthorized(ComponentSystemEvent event) {/*

		String returnType ="";
		try {

			final String METHOD_NAME = "userCVDDMAuthorized";
			log.entering(CLASS_NAME, METHOD_NAME);
			

			String authErrorPage="/error/authorizationErrorPage.faces?faces-redirect=true";
			String apsDownErrorPage="/error/apsDownErrorPage.faces?faces-redirect=true";

			FacesContext fc = FacesContext.getCurrentInstance();
			//NavigationHandler nh = FacesContext.getCurrentInstance().getApplication().getNavigationHandler();



			ConfigurableNavigationHandler nav =
					(ConfigurableNavigationHandler)
					fc.getApplication().getNavigationHandler();

			HttpServletRequest req = (HttpServletRequest) fc.getExternalContext().getRequest();
			
			HttpServletResponse rep = (HttpServletResponse)fc.getExternalContext().getResponse();

			System.out.println("Completed Path ============>"+req.
					getContextPath());

			final CVDDMAuthorizationProviderFactory factory = new CVDDMAuthorizationProviderFactory();
			final String userId = req.getUserPrincipal().getName();
			final AuthorizationProvider provider = factory.getProvider(userId);

			boolean isAPSUser = false;
			boolean isAPSDown = false;
			try {
				isAPSUser = provider.isAuthorized("User", "execute");


			} catch (AuthorizationException e) {
				e.printStackTrace();
				isAPSDown = true;
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
				isAPSDown = true;

			}
			if(isAPSDown) {
				System.out.println("APSDown ============>");
				//nh.handleNavigation(fc,null,apsDownErrorPage);
				//fc.renderResponse();
				//rep.sendRedirect(req.getContextPath() + apsDownErrorPage);
				returnType ="apsError";

			}
			else if(!isAPSUser){
				System.out.println("Not APSUser ============>");
				//nh.handleNavigation(fc,null,authErrorPage);
				//fc.renderResponse();
				//rep.sendRedirect(req.getContextPath() + authErrorPage);
				//nav.performNavigation(authErrorPage);
				//nav.performNavigation("authorizationErrorPage.faces");
				returnType ="authError";
			}
			else {
				returnType ="homePage";
			}
			log.exiting(CLASS_NAME, METHOD_NAME);
		}
		catch(Exception ex) {

			ex.printStackTrace();

		}
		System.out.println("returnType ============>"+returnType);
		return returnType;

	*/}
	

}
