package com.ford.cvddm.inbound.layer.authenticate;

import java.util.Locale;

import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.deltaspike.core.api.scope.WindowScoped;

import com.ford.cvddm.common.layer.CVDDMRequestContext;
import com.ford.cvddm.common.layer.exception.CVDDMAuthorizationException;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.inbound.layer.base.CVDDMBaseBean;
import com.ford.it.context.RequestContext;
import com.ford.it.exception.FordExceptionAttributes;
import com.ford.it.jsfcore.util.JcConstant;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;

/**
 * Bean for Authentication.
 *
 * NOTE: THIS BEAN (AND ASSOCIATED AUTHENTICATION PAGE) ARE NOT TO BE COPIED BY
 * APPLICATIONS. THEY ARE IMPLEMENTED TO SUPPORT FAKE AUTHENTICATION
 * FUNCTIONALITY IN CVDDM.
 *
 * @since v. 6.0
 */
@Named
@WindowScoped
public class AuthenticationBean extends CVDDMBaseBean {

    /**
     * Default <code>serialVersionUID</code>
     */
    private static final long serialVersionUID = 1L;

    /** Logging. */
    private static final String CLASS_NAME = AuthenticationBean.class.getName();

    /** Logging. */
    private static final ILogger log = LogFactory.getInstance().getLogger(
            CLASS_NAME);

    /**
     * Navigation to next step
     */
    public static final String NAVIGATE_LIST_BOOKING =
            "/home.faces?faces-redirect=true&"
                    + JcConstant.BEGIN_WORKFLOW_FLAG + "=true";

    /**
     * Default Language selection for internationalization
     */
    private String userSpecifiedLang = "en";

    private String userRole = "";

    /* 'PRERENDER' METHODS START HERE */

    /**
     * @see com.ford.it.jsfcore.bean.JcBaseBean#preRenderViewStartWorkflowTM()
     */
    @Override
    protected void preRenderViewStartWorkflowTM() {
        // Nothing done here.
    }

    /* 'PROCESS' METHODS START HERE */
    /**
     * This method is invoked when Enter as Customer Button is pressed.
     *
     * @return List Bookings link
     */
    public String processCustomer() {

        final String METHOD_NAME = "processCustomer";
        log.entering(CLASS_NAME, METHOD_NAME);

        // Set the logged in e-mail based on the real user logged in.
        final String emailId = RequestContext.getLocalInstance().getEmail();

        if (null == emailId) {
            final StringBuilder msg = new StringBuilder();
            msg.append("Can't determine eMail Id for authorization of user [");
            msg.append(RequestContext.getLocalInstance().getUserId());
            msg.append("]. If you're running CVDDM on the desktop ensure you ");
            msg.append("have an entry for your cdsid/email in the ");
            msg.append("users.props file used by the Desktop Server Configurator. ");
            msg.append("The entry should look similar to the following: [");
            msg.append("mycdsid:mycdsid:002:001:mail=mycdsid@ford.com;cn=MyFirstName MyLastName]");
            throw new CVDDMAuthorizationException(
                    new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
                    msg.toString());
        }


        this.userRole = "Analyst Admin";

        populateCVDDMLoggedInEmailIdAndLang(
                (HttpServletRequest)getFacesContext().getExternalContext()
                        .getRequest(), emailId, getUserSpecifiedLang());

        log.exiting(CLASS_NAME, METHOD_NAME, NAVIGATE_LIST_BOOKING);

        // navigate to the booking list page
        return NAVIGATE_LIST_BOOKING;
    }

    /**
     * This method is invoked when Enter as Agent button is pressed.
     *
     * @return List Bookings link
     */
    public String processAgent() {
        final String METHOD_NAME = "processAgent";
        log.entering(CLASS_NAME, METHOD_NAME);

        this.userRole = "";
        // Set the logged in e-mail to the CVDDM Agent e-mail. This simulates
        // being logged in as the CVDDM Agent
        populateCVDDMLoggedInEmailIdAndLang(
                (HttpServletRequest)getFacesContext().getExternalContext()
                        .getRequest(), "",
                getUserSpecifiedLang());

        log.exiting(CLASS_NAME, METHOD_NAME, NAVIGATE_LIST_BOOKING);

        // navigate to the booking list page
        return NAVIGATE_LIST_BOOKING;

    }

    /* 'POPULATE' METHODS START HERE */

    /**
     * Sets the email ID and language into session (for caching) and request
     * context (for processing)
     *
     * @param request Http Request
     * @param eMailId Email ID (user or cvddmagent)
     * @param userSpecifiedLang Chosen language
     */
    protected void populateCVDDMLoggedInEmailIdAndLang(
            final HttpServletRequest request, final String eMailId,
            final String userSpecifiedLang) {

        final String METHOD_NAME = "populateCVDDMLoggedInEmailIdAndLang";
        log.entering(CLASS_NAME, METHOD_NAME);

        final String windowId = request.getParameter("dswid");

        // Set the eMailId into session. It will be read from there by
        // CVDDMRequestContextFilter and set into RequestContext at each
        // page view to maintain the identity of the user.
        request.getSession().setAttribute(
                "" + windowId, eMailId);

      //  CVDDMRequestContext.getInstance().setcvddmAliasEmailId(eMailId);

        // set the user language
        this.getLocaleBean().setLanguage(userSpecifiedLang);

        log.exiting(CLASS_NAME, METHOD_NAME);
    }

    /* ACCESSOR METHODS START HERE */

    /**
     * @return Returns the userSpecifiedLang.
     */
    public String getUserSpecifiedLang() {

        return this.userSpecifiedLang;
    }

    /**
     * @param userSpecifiedLang The userSpecifiedLang to set.
     */
    public void setUserSpecifiedLang(final String userSpecifiedLang) {
        if (StringUtils.isNotBlank(userSpecifiedLang))
            this.userSpecifiedLang = userSpecifiedLang;
        // otherwise ignore the request to reset language.

    }

    /**
     * Sets the current language for the application
     */
    public void processLanguageChanged() {
        this.getLocaleBean().setLocale(new Locale(getUserSpecifiedLang()));
    }

    /**
     * @return current application role
     */
    public String getUserRole() {
        return this.userRole;
    }

    /**
     * @param userRole current application role
     */
    public void setUserRole(final String userRole) {

        this.userRole = userRole;

    }

}
