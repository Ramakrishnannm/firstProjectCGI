//****************************************************************
//* Copyright (c) 2015 Ford Motor Company. All Rights Reserved.
//****************************************************************
package com.ford.cvddm.inbound.layer;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

/**
 * Input data type for @CVDDMMultiCoreInitializerTask
 */
public class CVDDMMultiCoreInitializerInput {

    /**
     * @return Returns the servletContextListener.
     */
    public ServletContextListener getServletContextListener() {
        return this.servletContextListener;
    }

    /**
     * @param servletContextListener The servletContextListener to set.
     */
    public void setServletContextListener(
            final ServletContextListener servletContextListener) {

        this.servletContextListener = servletContextListener;
    }

    /**
     * @return Returns the contextEvent.
     */
    public ServletContextEvent getContextEvent() {
        return this.contextEvent;
    }

    /**
     * @param contextEvent The contextEvent to set.
     */
    public void setContextEvent(final ServletContextEvent contextEvent) {

        this.contextEvent = contextEvent;
    }

    private ServletContextListener servletContextListener;
    private ServletContextEvent contextEvent;

}
