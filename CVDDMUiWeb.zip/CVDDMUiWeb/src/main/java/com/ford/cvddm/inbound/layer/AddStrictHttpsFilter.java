package com.ford.cvddm.inbound.layer;
import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet Filter implementation class AddStrictHttpsFilter
 * Author: NGUPTA18
 */
@WebFilter("/*")  
public class AddStrictHttpsFilter implements Filter {  
  
    public void doFilter(final ServletRequest request, final ServletResponse response, final FilterChain chain)  
        throws IOException, ServletException {  
        final HttpServletResponse resp = (HttpServletResponse)response;  
        resp.setHeader("Strict-Transport-Security", "max-age=30000; includeSubDomains");  
        chain.doFilter(request, response);  
    }  
    
  public void destroy() {  
        // Nothing to do here  
    }  
  
    public void init(final FilterConfig arg0) throws ServletException {  
        // Nothing to do here either  
    }  
}  
