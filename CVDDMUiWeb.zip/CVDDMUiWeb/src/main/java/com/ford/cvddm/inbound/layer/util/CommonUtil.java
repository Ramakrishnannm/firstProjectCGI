package com.ford.cvddm.inbound.layer.util;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.domain.env.de.CvddmEnvironmentDE;
import com.ford.cvddm.env.business.list.ListCvddmEnvironmentBF;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;

/**
 * 
 * 
 * @author MJEYARAJ
 *
 */
public class CommonUtil {

	private static final String CLASS_NAME = CommonUtil.class.getName();
	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	/**
	 * Private class constructor.
	 */
	private CommonUtil() {

		super();
	}

	/**
	 * Method Name: retrieveEnvironments
	 * 
	 * @Description: Method to retrieve the environments
	 * @param :
	 *            none
	 * @return List<String>
	 */
	public static List<String> retrieveEnvironments(ListCvddmEnvironmentBF listCvddmEnvironmentBF) {

		final String METHOD_NAME = "retrieveEnvironments";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<String> enviroinments = new ArrayList<>();
		List<CvddmEnvironmentDE> environmentDEs = listCvddmEnvironmentBF.fetchAllEnvRcrds();

		if (!CvddmUtil.isObjectEmpty(environmentDEs)) {
			enviroinments = environmentDEs.stream().map(CvddmEnvironmentDE::getEnvName).collect(Collectors.toList());
		} else {
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, CvddmUtil
							.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY, CVDDMConstant.ERR_LOADING_ENV),
							CVDDMConstant.VALIDATION_ERR));
		}
		log.exiting(CLASS_NAME, METHOD_NAME);

		return enviroinments;
	}

}
