/**
 * 
 */
package com.ford.cvddm.inbound.testdatasetup.ui.bean;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.deltaspike.core.api.scope.GroupedConversationScoped;

import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.domain.application.de.CvddmPartMatrixReferenceCSVUploadDE;
import com.ford.cvddm.domain.history.de.CvddmPartIISpecHistoryDE;
import com.ford.cvddm.history.business.HistoryUtilityBF;
import com.ford.cvddm.inbound.layer.base.CVDDMBaseBean;
import com.ford.cvddm.partlineage.business.PartMatrixBF;
import com.ford.cvddm.sob.business.layer.CVDDMBusinessException;
import com.ford.it.exception.FordExceptionAttributes;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;

/**
 * @since US1064841
 * 
 *        Description: This Bean contains method for Part Matrix References
 * 
 * @author MJEYARAJ
 *
 */
@Named
@GroupedConversationScoped
public class PartMatrixReferenceBean extends CVDDMBaseBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final String CLASS_NAME = PartMatrixReferenceBean.class.getName();

	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	@Inject
	private PartMatrixBF partMatrixBF;

	private List<CvddmPartMatrixReferenceCSVUploadDE> partMatrixRefDEs;

	public List<CvddmPartMatrixReferenceCSVUploadDE> getPartMatrixRefDEs() {
		return partMatrixRefDEs;
	}

	public void setPartMatrixRefDEs(List<CvddmPartMatrixReferenceCSVUploadDE> partMatrixRefDEs) {
		this.partMatrixRefDEs = partMatrixRefDEs;
	}

	@Override
	protected void preRenderViewStartWorkflowTM() {
		log.exiting(CLASS_NAME, "preRenderViewStartWorkflowTM");
	}

	@Override
	protected void preRenderViewTM() {

		log.info("preRenderViewTM");
		getPartMatrixRef();

	}

	/**
	 * Private method to load Part Matrix References
	 * 
	 */
	private void getPartMatrixRef() {

		final String METHOD_NAME = "getPartMatrixRef";

		try {
			setPartMatrixRefDEs(partMatrixBF.fetchAllPartMatrixRcrds());
		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}
	}

}
