/**
 * 
 */
package com.ford.cvddm.inbound.datavalidation.ui.bean;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.deltaspike.core.api.scope.GroupedConversationScoped;

import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.common.util.ValidationUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.domain.env.de.CvddmEnvironmentDE;
import com.ford.cvddm.domain.history.de.CvddmVINHistoryDE;
import com.ford.cvddm.env.business.list.ListCvddmEnvironmentBF;
import com.ford.cvddm.history.business.HistoryUtilityBF;
import com.ford.cvddm.inbound.layer.base.CVDDMBaseBean;
import com.ford.cvddm.sob.business.layer.CVDDMBusinessException;
import com.ford.it.exception.FordExceptionAttributes;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;
import com.ford.it.util.TextUtil;

/**
 * 
 * US1078611 - This Bean contains method for RVCM TCU Vin Validation History.
 * 
 * @author MJEYARAJ
 *
 */
@Named
@GroupedConversationScoped
public class RvcmTcuValidationHistoryBean extends CVDDMBaseBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final String CLASS_NAME = RvcmTcuValidationHistoryBean.class.getName();

	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	@Inject
	private HistoryUtilityBF historyUtilityBF;

	private List<CvddmVINHistoryDE> cvddmVINHistoryDEs;

	private Timestamp fromDate;

	private Timestamp toDate;

	private String vinNumber;

	private String envType;

	@Inject
	private ListCvddmEnvironmentBF listCvddmEnvironmentBF;

	private List<CvddmEnvironmentDE> environmentList;

	/**
	 * @return the environmentList
	 */
	public List<CvddmEnvironmentDE> getEnvironmentList() {
		return environmentList;
	}

	/**
	 * @param environmentList
	 *            the environmentList to set
	 */
	public void setEnvironmentList(List<CvddmEnvironmentDE> environmentList) {
		this.environmentList = environmentList;
	}

	/**
	 * @return the envType
	 */
	public String getEnvType() {
		return envType;
	}

	/**
	 * @param envType
	 *            the envType to set
	 */
	public void setEnvType(String envType) {
		this.envType = envType;
	}

	/**
	 * @return the vinNumber
	 */
	public String getVinNumber() {
		return vinNumber;
	}

	/**
	 * @param vinNumber
	 *            the vinNumber to set
	 */
	public void setVinNumber(String vinNumber) {
		this.vinNumber = vinNumber;
	}

	public Timestamp getFromDate() {
		return fromDate;
	}

	public void setFromDate(Timestamp fromDate) {
		this.fromDate = fromDate;
	}

	public Timestamp getToDate() {
		return toDate;
	}

	public void setToDate(Timestamp toDate) {
		this.toDate = toDate;
	}

	public List<CvddmVINHistoryDE> getCvddmVINHistoryDEs() {
		return this.cvddmVINHistoryDEs;
	}

	public void setCvddmVINHistoryDEs(List<CvddmVINHistoryDE> cvddmVINHistoryDEs) {
		this.cvddmVINHistoryDEs = cvddmVINHistoryDEs;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ford.it.jsfcore.bean.JcBaseBean#preRenderViewStartWorkflowTM()
	 */
	@Override
	protected void preRenderViewStartWorkflowTM() {
		log.exiting(CLASS_NAME, "preRenderViewStartWorkflowTM");
	}

	@Override
	protected void preRenderViewTM() {

		log.info("preRenderViewTM");
		if (isNotPostBack()) {
			this.fetchHistoryDetails();
			getEnvironmentTypes();
		}
	}

	/**
	 * Method Name: getEnvironmentTypes
	 * 
	 * @Description: This method would load values for "Environment" Drop Down.
	 * @param :
	 *            none
	 * @return void
	 **/
	public void getEnvironmentTypes() {

		final String METHOD_NAME = "getEnvironmentTypes";

		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			List<CvddmEnvironmentDE> envList = listCvddmEnvironmentBF.fetchAllEnvRcrds();
			if (!CvddmUtil.isObjectEmpty(envList) && !envList.isEmpty()) {

				setEnvironmentList(envList);
			}

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * Method Name: fetchHistoryDetails
	 * 
	 * @Description:This method would fetch all VIN History from
	 *                   PCVDM08_VEH_DATA_VLDTN_REQ database table
	 * @return void
	 */
	public void fetchHistoryDetails() {

		cvddmVINHistoryDEs = historyUtilityBF.getValidationHistoryRcrds(CvddmUtil.getPropertiesValue(
				CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, CVDDMConstant.HISTORY_UTILITY_APP_RVCM));

		if (!CvddmUtil.isObjectEmpty(cvddmVINHistoryDEs) && !cvddmVINHistoryDEs.isEmpty()) {

			log.info("fetchHistoryDetails");
			setCvddmVINHistoryDEs(cvddmVINHistoryDEs);
		}
	}

	/**
	 * Method Name: updateRcrdsonPanelonEnv
	 * 
	 * @Description:This method would fetch all VIN History from
	 *                   PCVDM08_VEH_DATA_VLDTN_REQ database table when Env Type is
	 *                   Set to Please select
	 * @return void
	 */
	public void updateRcrdsonPanelonEnv() {

		if (TextUtil.isBlankOrNull(this.envType)) {

			fetchHistoryDetails();

		}
	}

	/**
	 * Method Name: getFromDateRange
	 * 
	 * @Description:This method would get From Date Range
	 * @return Date
	 */
	public Date getFromDateRange() {
		return CvddmUtil.getLastYearDatePlusOneDay();
	}

	/**
	 * Method Name: getToDateRange
	 * 
	 * @Description:This method would get To Date Range
	 * @return void
	 */
	public Date getToDateRange() {
		return CvddmUtil.getTodaysDate();
	}

	/**
	 * Method Name: filterByDateRange
	 * 
	 * @Description:This method would filter Data by Date Range
	 * @return void
	 */
	public void filterByDateRange() {

		final String METHOD_NAME = "filterByDateRange";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<CvddmVINHistoryDE> tempcvddmVINHistoryDEs = new ArrayList<CvddmVINHistoryDE>();

		Timestamp toEnDate = null;

		boolean isOktoSearch = true;

		try {

			if (TextUtil.isBlankOrNull(envType) && TextUtil.isBlankOrNull(vinNumber)
					&& CvddmUtil.isObjectEmpty(fromDate) && CvddmUtil.isObjectEmpty(toDate)) {

				isOktoSearch = false;

				FacesContext.getCurrentInstance().addMessage(null,
						new FacesMessage(FacesMessage.SEVERITY_ERROR,
								CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
										CVDDMConstant.EMPTY_FILTER_CRITERIA),
								CVDDMConstant.VALIDATION_ERR));
			}

			if (!isValidInputDate()) {

				isOktoSearch = false;
			}

			if (TextUtil.isNotBlankOrNull(vinNumber) && !ValidationUtil.validateVinNumber(vinNumber)) {

				isOktoSearch = false;

				String vinErrorMsg = CVDDMConstant.VIN_NAME + vinNumber + " " + CvddmUtil
						.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY, CVDDMConstant.MULTIVIN_VALID_MSG);

				FacesContext.getCurrentInstance().addMessage(CVDDMConstant.RVCM_JSF_ID_HIST_VIN_NUMBER,
						new FacesMessage(FacesMessage.SEVERITY_ERROR, null, vinErrorMsg));

			}

			if (isOktoSearch) {

				if (!CvddmUtil.isObjectEmpty(toDate)) {

					/** Below logic is to include inclusive To Date in UTC Format **/
					Calendar calendar = Calendar.getInstance();
					TimeZone tz = TimeZone.getTimeZone(CVDDMConstant.TIMEZONE_UTC);
					calendar.setTimeZone(tz);
					calendar.setTimeInMillis(toDate.getTime());
					calendar.add(Calendar.DATE, 1);
					Date tempObj = calendar.getTime();

					toEnDate = new Timestamp(tempObj.getTime());

					/** Above logic is to include inclusive To Date in UTC Format **/
					log.info("toEnDate >>>" + toEnDate);
				}

				tempcvddmVINHistoryDEs = historyUtilityBF
						.getValidationHistoryRcrdsByOptions(
								CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
										CVDDMConstant.HISTORY_UTILITY_APP_RVCM),
								fromDate, toEnDate, vinNumber, envType);

				if (!CvddmUtil.isObjectEmpty(tempcvddmVINHistoryDEs)) {

					this.cvddmVINHistoryDEs = tempcvddmVINHistoryDEs;
					this.setCvddmVINHistoryDEs(cvddmVINHistoryDEs);
				}
			}
		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}

		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * Method Name: isValidInputDate
	 * 
	 * @Description:This method would validate Input Date
	 * @return boolean
	 */
	public boolean isValidInputDate() {

		final String METHOD_NAME = "isValidInputDate";

		log.entering(CLASS_NAME, METHOD_NAME);

		boolean isValidInput = true;

		if (!CvddmUtil.isObjectEmpty(this.fromDate) && !CvddmUtil.isObjectEmpty(this.toDate)
				&& this.toDate.before(this.fromDate)) {

			isValidInput = false;

			FacesContext.getCurrentInstance().addMessage(CVDDMConstant.RVCM_JSF_ID_HIST_TO_DATE,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, null,
							getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_APPLICATION_RESOURCE_KEY,
									CVDDMConstant.LABEL_HIST_TO_DATE)
									+ " "
									+ getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
											CVDDMConstant.DATE_GREATER_THAN_MSG)
									+ " " + getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_APPLICATION_RESOURCE_KEY,
											CVDDMConstant.LABEL_HIST_FROM_DATE)));
		}
		return isValidInput;
	}

	/**
	 * Method Name: processClearFilter
	 * 
	 * @Description:This method would clear all filters
	 * @return void
	 */
	public void processClearFilter() {

		final String METHOD_NAME = "processClearFilter";
		log.entering(CLASS_NAME, METHOD_NAME);

		this.fromDate = null;
		this.toDate = null;
		this.vinNumber = null;
		this.envType = null;
		this.fetchHistoryDetails();

		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * Method Name: navigateToValidationPage
	 * 
	 * @Description:his method would navigate to RVCM Vin Validation Page.
	 * @return void
	 */
	public void navigateToValidationPage() {

		final String METHOD_NAME = "navigateToValidationPage";

		log.entering(CLASS_NAME, METHOD_NAME);

		try {
			this.fromDate = null;
			this.toDate = null;
			this.vinNumber = null;
			this.envType = null;
			if (!CvddmUtil.isObjectEmpty(cvddmVINHistoryDEs) && !cvddmVINHistoryDEs.isEmpty()) {

				this.cvddmVINHistoryDEs.clear();
			}
			FacesContext context = FacesContext.getCurrentInstance();
			context.getExternalContext().redirect(CvddmUtil.getPropertiesValue(
					CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, CVDDMConstant.RVCM_VIN_VALIDATION_PAGE_PATH));
		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}
	}
}
