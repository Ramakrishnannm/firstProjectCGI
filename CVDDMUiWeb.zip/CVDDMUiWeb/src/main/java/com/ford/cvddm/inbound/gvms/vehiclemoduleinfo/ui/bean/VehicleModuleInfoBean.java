package com.ford.cvddm.inbound.gvms.vehiclemoduleinfo.ui.bean;

import com.ford.cvddm.inbound.layer.base.CVDDMBaseBean;
import com.ford.cvddm.ldap.business.LdapBF;
import com.ford.cvddm.maintenance.business.list.ListCvddmMaintenanceBF;
import com.ford.cvddm.aps.business.AppResourcePolicyRoleBF;
import com.ford.cvddm.aps.business.EntitlementGroupBF;
import com.ford.cvddm.aps.business.RetrieveRoleAssignmentsBF;
import com.ford.cvddm.gvms.business.GvmsGetCurrentLiteBF;
import com.ford.cvddm.gvms.business.GvmsModuleStateBF;
import com.ford.cvddm.gvms.business.GvmsVehicleModuleInfoBF;

import javax.inject.Inject;

public abstract class VehicleModuleInfoBean extends CVDDMBaseBean {

	@Override
	protected void preRenderViewStartWorkflowTM() {
	

	}
	
	 /**
     * Comment for <code>serialVersionUID</code>
     */
    private static final long serialVersionUID = 1L;

    /**
     * Provides a handle to a Business Facade instance.
     */
    @Inject
    protected GvmsVehicleModuleInfoBF vehicleModuleInfoBF;
    
    @Inject
    protected RetrieveRoleAssignmentsBF assignmentsBF ;
    
    @Inject
    protected AppResourcePolicyRoleBF appResourcePolicyRoleBF ;

    @Inject
    protected EntitlementGroupBF entitlementGroupBF ;
    
    @Inject
    protected GvmsGetCurrentLiteBF getCurrentLiteAF ;
    
    @Inject
    protected ListCvddmMaintenanceBF cvddmMaintenanceBF ;
    
    @Inject
    protected GvmsModuleStateBF gvmsModuleStateBF ;
    
    @Inject
    protected LdapBF ldapBFObj;

}