// ******************************************************************************
// * Copyright (c) 2015 Ford Motor Company. All Rights Reserved.
// * Original author: Ford Motor Company J2EE Center of Excellence
// *
// ******************************************************************************
package com.ford.cvddm.inbound.layer;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.*;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.inject.Qualifier;

/**
 * This annotation is a Ford standard CDI qualifier for injecting CVDDMAuthorizationProvider.
 *
 * @since 6.6.
 */
@Qualifier()
@Retention(RUNTIME)
@Target({METHOD, FIELD, PARAMETER})
public @interface CVDDMAuthProvider {
    // Empty Block.
}
