package com.ford.cvddm.inbound.common.pojo;

import java.util.List;

import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;

import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.domain.module.de.CvddmModuleDE;
import com.ford.cvddm.gvms.aws.PartIISpecFeatures;
import com.ford.cvddm.outbound.ivsu.rest.ValidateIVSFeedResponse;

/**
 * IO component for Add config did feature Screen
 * 
 * 
 * @author RPADI
 *
 */
public class ConfigDidFeatureSelection {

	// Selected Module
	private String node;

	// Object for Selected module
	private CvddmModuleDE cvddmModuleDE;

	// PartIISpec of selected IVS Feed Response
	private String partIISpec;
	/*** Start Change :User Story: US1147659 **/
	private ValidateIVSFeedResponse iVSFeedResponseSel;
	/*** End Change :User Story: US1147659 **/

	private List<PartIISpecFeatures> partIISpecFeatures;

	private List<PartIISpecFeatures> partIISpecFeaturesslctd;

	public List<PartIISpecFeatures> getPartIISpecFeaturesslctd() {
		return partIISpecFeaturesslctd;
	}

	public void setPartIISpecFeaturesslctd(List<PartIISpecFeatures> partIISpecFeaturesslctd) {
		this.partIISpecFeaturesslctd = partIISpecFeaturesslctd;
	}

	public List<PartIISpecFeatures> getPartIISpecFeatures() {
		return partIISpecFeatures;
	}

	public void setPartIISpecFeatures(List<PartIISpecFeatures> partIISpecFeatures) {
		this.partIISpecFeatures = partIISpecFeatures;
	}

	private String disPartIIspecvlRespAvl = CVDDMConstant.STRING_N;

	public String getDisPartIIspecvlRespAvl() {
		return disPartIIspecvlRespAvl;
	}

	public void setDisPartIIspecvlRespAvl(String disPartIIspecvlRespAvl) {
		this.disPartIIspecvlRespAvl = disPartIIspecvlRespAvl;
	}

	// "Y" in case of IVS Feed Response Availability. "N" in case of
	// Non-Availability. In case of Non-Availability, node will not be considered
	// for further setup.
	private String disPnbrMdlLvlRespAvl = CVDDMConstant.STRING_N;

	private String disApplicationAvl = CVDDMConstant.STRING_N;

	public String getPartIISpec() {
		return partIISpec;
	}

	public void setPartIISpec(String partIISpec) {
		this.partIISpec = partIISpec;
	}

	public CvddmModuleDE getCvddmModuleDE() {
		return cvddmModuleDE;
	}

	public void setCvddmModuleDE(CvddmModuleDE cvddmModuleDE) {
		this.cvddmModuleDE = cvddmModuleDE;
	}

	public String getDisApplicationAvl() {
		return disApplicationAvl;
	}

	public void setDisApplicationAvl(String disApplicationAvl) {
		this.disApplicationAvl = disApplicationAvl;
	}

	public String getDisPnbrMdlLvlRespAvl() {
		return disPnbrMdlLvlRespAvl;
	}

	public void setDisPnbrMdlLvlRespAvl(String disPnbrMdlLvlRespAvl) {
		this.disPnbrMdlLvlRespAvl = disPnbrMdlLvlRespAvl;
	}

	public String getNode() {
		return node;
	}

	public void setNode(String node) {
		this.node = node;
	}

	/*** Start Change :User Story: US1147659 **/
	/**
	 * @return the iVSFeedResponseSel
	 */
	public ValidateIVSFeedResponse getiVSFeedResponseSel() {
		return iVSFeedResponseSel;
	}

	/**
	 * @param iVSFeedResponseSel
	 *            the iVSFeedResponseSel to set
	 */
	public void setiVSFeedResponseSel(ValidateIVSFeedResponse iVSFeedResponseSel) {
		this.iVSFeedResponseSel = iVSFeedResponseSel;
	}

	/*** End Change :User Story: US1147659 **/

	public void enableInputText(SelectEvent event) {
		for (int i = 0; i < partIISpecFeaturesslctd.size(); i++) {
			for (int j = 0; j < partIISpecFeatures.size(); j++) {
				if (partIISpecFeaturesslctd.get(i).getId().equals(partIISpecFeatures.get(j).getId())) {
					partIISpecFeatures.get(j).setDisable(false);
				}
			}
		}
	}

	public void onRowSelect(SelectEvent selectEvent) {
		PartIISpecFeatures partIIspec = (PartIISpecFeatures) selectEvent.getObject();

		for (PartIISpecFeatures prtspec : partIISpecFeatures) {
			if (partIIspec.getId().equals(prtspec.getId())) {
				prtspec.setDisable(false);
			} else {
				prtspec.setDisable(true);
			}
		}

	}

	public void onRowUnselect(UnselectEvent unselectEvent) {
		PartIISpecFeatures partIIspec = (PartIISpecFeatures) unselectEvent.getObject();

		for (PartIISpecFeatures partIIspecfeature : partIISpecFeatures) {
			if (partIIspec.getId().equals(partIIspecfeature.getId())) {
				partIIspecfeature.setDidValue(null);
				partIIspecfeature.setDisable(true);
			}
		}
	}

}
