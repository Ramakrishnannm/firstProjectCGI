package com.ford.cvddm.inbound.layer.exception;

import javax.faces.context.ExceptionHandler;
import javax.faces.context.ExceptionHandlerFactory;

import com.ford.it.jsfcore.exception.JcCommonExceptionHandler;
import com.ford.it.jsfcore.exception.JcExceptionHandlerFactory;

/**
 * CVDDM's Custom Exception Handler factory (registered through faces-config).
 *
 * @since 6.0
 *
 */
public class CVDDMExceptionHandlerFactory extends JcExceptionHandlerFactory {
    private ExceptionHandlerFactory parent;

    /**
     * Construct a JcExceptionHandlerFactory instance
     *
     * @param parent parent factory (factories are chained).
     */
    public CVDDMExceptionHandlerFactory(final ExceptionHandlerFactory parent) {
        super(parent);
        this.parent = parent;
    }

    /**
     * @see javax.faces.context.ExceptionHandlerFactory#getExceptionHandler()
     */
    @Override
    public ExceptionHandler getExceptionHandler() {

        final ExceptionHandler handler =
                new CVDDMExceptionHandler(new JcCommonExceptionHandler(
                        this.parent.getExceptionHandler()));

        return handler;
    }
}
