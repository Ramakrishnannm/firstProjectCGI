/**
 * 
 */
package com.ford.cvddm.inbound.maintenance.ui.bean;

import java.io.Serializable;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.TimeZone;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.faces.model.SelectItemGroup;
import javax.inject.Inject;

import com.ford.cvddm.aps.business.AppResourcePolicyRoleBF;
import com.ford.cvddm.aps.business.EntitlementGroupBF;
import com.ford.cvddm.aps.business.RetrieveRoleAssignmentsBF;
import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.domain.maintenance.de.CvddmMaintRcrdDE;
import com.ford.cvddm.domain.master.de.CvddmMaintTypeDE;
import com.ford.cvddm.domain.master.de.CvddmScreenInfoDE;
import com.ford.cvddm.inbound.layer.base.CVDDMBaseBean;
import com.ford.cvddm.inbound.layer.util.BannersUtil;
import com.ford.cvddm.inbound.layer.util.PopupAlertUtil;
import com.ford.cvddm.maintenance.business.list.ListCvddmMaintenanceBF;
import com.ford.cvddm.sob.business.layer.CVDDMBusinessException;
import com.ford.it.exception.FordExceptionAttributes;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;
import com.ford.it.util.TextUtil;

/**
 * @author NGUPTA18
 * 
 * 
 *
 */
@ManagedBean
@ViewScoped
public class CreateCvddmMaintenanceBean extends CVDDMBaseBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final String CLASS_NAME = CreateCvddmMaintenanceBean.class.getName();

	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	private String maintTitle = ""; // Maintenance Title

	private String maintDescription = ""; // Maintenance Description

	private String maintFor; // Maintenance For

	private List<CvddmScreenInfoDE> maintForList;
	private List<CvddmMaintTypeDE> maintTypeList; // Hold Values for "Maintenance Type" Drop Down.

	private String maintType; // Maintenance Type

	private Date fromDateTime; // From Date and Time

	private Date toDateTime; // To Date and Time

	private boolean emailNotify = false; // Email Notification

	private Date startDate; // Start Date for Calendar.

	private Date endDate; // End Date for Calendar.

	@Inject
	private ListCvddmMaintenanceBF listCvddmMaintenanceBF;

	/*** Start Change :User Story: US945528**/

	@Inject
	private AppResourcePolicyRoleBF appResourcePolicyRoleBF ;

	@Inject
	protected RetrieveRoleAssignmentsBF assignmentsBF ;

	@Inject
	private EntitlementGroupBF entitlementGroupBF ;

	/*** End Change :User Story: US945528**/

	private List<SelectItem> mainForListValues = new ArrayList<SelectItem>(); // Hold Values for "Maintenance For" Drop
	// Down.

	public List<SelectItem> getMainForListValues() {
		return mainForListValues;
	}

	public void setMainForListValues(List<SelectItem> mainForListValues) {
		this.mainForListValues = mainForListValues;
	}

	/** Start Change :User Story: US890083 ****/
	private List<CvddmMaintRcrdDE> selectedMaintRcrds;

	/**
	 * @return the selectedMaintRcrds
	 */
	public List<CvddmMaintRcrdDE> getSelectedMaintRcrds() {
		return selectedMaintRcrds;
	}

	/**
	 * @param selectedMaintRcrds
	 *            the selectedMaintRcrds to set
	 */
	public void setSelectedMaintRcrds(List<CvddmMaintRcrdDE> selectedMaintRcrds) {
		this.selectedMaintRcrds = selectedMaintRcrds;
	}

	private String displayDeleteButton = CVDDMConstant.STRING_N;

	/**
	 * @return the displayDeleteButton
	 */
	public String getDisplayDeleteButton() {
		return displayDeleteButton;
	}

	/**
	 * @param displayDeleteButton
	 *            the displayDeleteButton to set
	 */
	public void setDisplayDeleteButton(String displayDeleteButton) {
		this.displayDeleteButton = displayDeleteButton;
	}

	/** End Change :User Story: US890083 ****/
	/** Start Change :User Story: US890080 ****/

	private List<CvddmMaintRcrdDE> maintenanceRecords;

	public List<CvddmMaintRcrdDE> getMaintenanceRecords() {
		return maintenanceRecords;
	}

	public void setMaintenanceRecords(List<CvddmMaintRcrdDE> maintenanceRecords) {
		this.maintenanceRecords = maintenanceRecords;
	}

	private boolean alreadyRendered;

	public boolean isAlreadyRendered() {
		return alreadyRendered;
	}

	public void setAlreadyRendered(boolean alreadyRendered) {
		this.alreadyRendered = alreadyRendered;
	}

	/** End Change :User Story: US890080 ****/



	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ford.it.jsfcore.bean.JcBaseBean#preRenderViewStartWorkflowTM()
	 */
	@Override
	protected void preRenderViewStartWorkflowTM() {

		log.exiting(CLASS_NAME, "preRenderViewStartWorkflowTM");
	}

	/*** Start Change: User Story : US987948 ***/
	@Override
	protected void preRenderViewTM() {

		/** Start Change :User Story: US890083 ****/
		if (isNotPostBack()) {
			/** End Change :User Story: US890083 ****/
			String popUpContent = PopupAlertUtil.prepareAlertsMsgDesc(CVDDMConstant.ADMIN_SCRN_CD,
					CVDDMConstant.MAINT_CONTROLLER_SCRN_CD);
			this.setPopUpContent(popUpContent);
			this.popUpContent = popUpContent;

			String bannerContent = BannersUtil.prepareBannerMsgDesc(CVDDMConstant.ADMIN_SCRN_CD,
					CVDDMConstant.MAINT_CONTROLLER_SCRN_CD);
			this.setBannerContent(bannerContent);
			this.bannerContent = bannerContent;

			preRenderCreateMaintenanceRecord();
		} // Added as part of US890083
	}

	/*** End Change: User Story : US987948 ***/
	public void preRenderCreateMaintenanceRecord() {

		final String METHOD_NAME = "preRenderCreateMaintenanceRecord";
		log.entering(CLASS_NAME, METHOD_NAME);

		this.populateMaintForDrpDown();

		this.populateMaintTypeDrpDown();

		this.retrieveAndSetMaintenanceRecords();

		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	public String getMaintTitle() {
		return maintTitle;
	}

	public void setMaintTitle(String maintTitle) {
		this.maintTitle = maintTitle;
	}

	public String getMaintDescription() {
		return maintDescription;
	}

	public void setMaintDescription(String maintDescription) {
		this.maintDescription = maintDescription;
	}

	/**
	 * @return the maintFor
	 */
	public String getMaintFor() {
		return maintFor;
	}

	/**
	 * @param maintFor
	 *            the maintFor to set
	 */
	public void setMaintFor(String maintFor) {
		this.maintFor = maintFor;
	}

	/**
	 * @return the maintType
	 */
	public String getMaintType() {
		return maintType;
	}

	/**
	 * @param maintType
	 *            the maintType to set
	 */
	public void setMaintType(String maintType) {
		this.maintType = maintType;
	}

	public Date getFromDateTime() {
		return fromDateTime;
	}

	public void setFromDateTime(Date fromDateTime) {
		this.fromDateTime = fromDateTime;
	}

	public Date getToDateTime() {
		return toDateTime;
	}

	public void setToDateTime(Date toDateTime) {
		this.toDateTime = toDateTime;
	}

	public boolean isEmailNotify() {
		return emailNotify;
	}

	public void setEmailNotify(boolean emailNotify) {
		this.emailNotify = emailNotify;
	}

	/**
	 * @return the listCvddmMaintenanceBF
	 */
	public ListCvddmMaintenanceBF getListCvddmMaintenanceBF() {
		return listCvddmMaintenanceBF;
	}

	/**
	 * @param listCvddmMaintenanceBF
	 *            the listCvddmMaintenanceBF to set
	 */
	public void setListCvddmMaintenanceBF(ListCvddmMaintenanceBF listCvddmMaintenanceBF) {
		this.listCvddmMaintenanceBF = listCvddmMaintenanceBF;
	}

	/*
	 * Method Name: getStartDate
	 * 
	 * @Description: This method would fetch Servers Current Date in UTC
	 * 
	 * @param : None
	 * 
	 * @return Date
	 */
	public Date getStartDate() {

		final String METHOD_NAME = "getStartDate";

		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			startDate = CvddmUtil.getTimeZoneCurrentDate(CVDDMConstant.TIMEZONE_UTC);
		} catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
		return startDate;
	}

	/*
	 * Method Name: getEndDate
	 * 
	 * @Description: This method would set End Date as One month from Start Date.
	 * 
	 * @param : None
	 * 
	 * @return Date
	 */
	public Date getEndDate() {

		final String METHOD_NAME = "getEndDate";

		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			Calendar cal = Calendar.getInstance();
			cal.setTime(CvddmUtil.getTimeZoneCurrentDate(CVDDMConstant.TIMEZONE_UTC));
			cal.setTimeZone(TimeZone.getTimeZone(CVDDMConstant.TIMEZONE_UTC));
			cal.add(Calendar.MONTH, 1);
			endDate = cal.getTime();
		} catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		log.exiting(CLASS_NAME, METHOD_NAME);
		return endDate;
	}

	/**
	 * @return the maintForList
	 */
	public List<CvddmScreenInfoDE> getMaintForList() {
		return maintForList;
	}

	/**
	 * @param maintForList
	 *            the maintForList to set
	 */
	public void setMaintForList(List<CvddmScreenInfoDE> maintForList) {
		this.maintForList = maintForList;
	}

	/**
	 * @return the maintTypeList
	 */
	public List<CvddmMaintTypeDE> getMaintTypeList() {
		return maintTypeList;
	}

	/**
	 * @param maintTypeList
	 *            the maintTypeList to set
	 */
	public void setMaintTypeList(List<CvddmMaintTypeDE> maintTypeList) {
		this.maintTypeList = maintTypeList;
	}

	/**
	 * Method Name: populateMaintForDrpDown
	 * 
	 * @Description: This method would load values for "Maintenance For" Drop Down.
	 * @param :
	 *            none
	 * @return void
	 **/

	public void populateMaintForDrpDown() {

		final String METHOD_NAME = "populateMaintForDrpDown";

		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			/** Start Change :User Story: US941763 ****/

			List<CvddmScreenInfoDE> maintList = listCvddmMaintenanceBF.retrieveAllScreens();

			ListIterator<CvddmScreenInfoDE> listItr = maintList.listIterator();

			SelectItemGroup cmnMenuGrp = new SelectItemGroup(CVDDMConstant.COMMON_MENUS);

			SelectItemGroup menuGrp = new SelectItemGroup(CVDDMConstant.LIST_MENUS);

			SelectItemGroup subMenuGrp = new SelectItemGroup(CVDDMConstant.LIST_SUB_MENUS);

			List<SelectItem> cmnMenuLst = new ArrayList<SelectItem>();

			List<SelectItem> menuLst = new ArrayList<SelectItem>();

			List<SelectItem> subMenuList = new ArrayList<SelectItem>();

			String cmnMenuCds = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
					CVDDMConstant.COMMON_MENU_SCRN_CD);

			String[] cmnMenuScnCdArray = cmnMenuCds.split(",");

			String menuCds = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
					CVDDMConstant.LIST_MENU_SCRN_CD);

			String[] menuScnCdArray = menuCds.split(",");

			while (listItr.hasNext()) {

				CvddmScreenInfoDE cvddmScreenInfoDE = listItr.next();

				String screenId = cvddmScreenInfoDE.getCvddmScreenId() + "";

				if (!CvddmUtil.isArrayEmpty(cmnMenuScnCdArray) && Arrays.asList(cmnMenuScnCdArray).contains(screenId)) {

					SelectItem selectItem = new SelectItem(cvddmScreenInfoDE.getCvddmScreenId(),
							cvddmScreenInfoDE.getCvdmScreenName());

					cmnMenuLst.add(selectItem);
				} else if (!CvddmUtil.isArrayEmpty(menuScnCdArray)
						&& Arrays.asList(menuScnCdArray).contains(screenId)) {

					SelectItem selectItem = new SelectItem(cvddmScreenInfoDE.getCvddmScreenId(),
							cvddmScreenInfoDE.getCvdmScreenName());

					menuLst.add(selectItem);
				} else {

					SelectItem selectItem = new SelectItem(cvddmScreenInfoDE.getCvddmScreenId(),
							cvddmScreenInfoDE.getCvdmScreenName());

					subMenuList.add(selectItem);
				}
			}

			SelectItem[] commonMenus = new SelectItem[cmnMenuLst.size()];
			commonMenus = cmnMenuLst.toArray(commonMenus);

			SelectItem[] menuArray = new SelectItem[menuLst.size()];
			menuArray = menuLst.toArray(menuArray);

			SelectItem[] subMenus = new SelectItem[subMenuList.size()];
			subMenus = subMenuList.toArray(subMenus);

			cmnMenuGrp.setSelectItems(commonMenus);

			menuGrp.setSelectItems(menuArray);

			subMenuGrp.setSelectItems(subMenus);

			mainForListValues = new ArrayList<SelectItem>();

			mainForListValues.add(cmnMenuGrp);
			mainForListValues.add(menuGrp);
			mainForListValues.add(subMenuGrp);

			setMainForListValues(mainForListValues);

			/** End Change :User Story: US941763 ****/
		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * Method Name: populateMaintTypeDrpDown
	 * 
	 * @Description: This method would load values for "Maintenance Type" Drop Down.
	 * @param :
	 *            none
	 * @return void
	 **/

	public void populateMaintTypeDrpDown() {

		final String METHOD_NAME = "populateMaintTypeDrpDown";

		log.entering(CLASS_NAME, METHOD_NAME);

		try {
			setMaintTypeList(listCvddmMaintenanceBF.retrieveActiveMaintTypes());
			this.maintTypeList = listCvddmMaintenanceBF.retrieveActiveMaintTypes();
		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * Method Name: submitMaintenanceData
	 * 
	 * @Description: This method would insert Maintenance Data Record in Database.
	 * @param :
	 *            None
	 * @return String
	 */
	public String submitMaintenanceData() {

		String navigation = "";

		final String METHOD_NAME = "submitMaintenanceData";

		boolean isSuccess = true;

		/*** Start Change :User Story: US945528**/

		Map<String,String> inputMap = new HashMap<String, String>();

		SimpleDateFormat sdf = new SimpleDateFormat(CVDDMConstant.DATE_PATTERN_AM_PM);


		/*** End Change :User Story: US945528**/

		log.entering(CLASS_NAME, METHOD_NAME);

		try {
			navigation = "/maintenance/createCvddmMaintenance.faces";

			if (!isValidFromDate()) {

				isSuccess = false;
				FacesContext.getCurrentInstance()
				.addMessage("createMaintenanceForm:fromDateTime",
						new FacesMessage(FacesMessage.SEVERITY_ERROR,
								CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
										CVDDMConstant.FROM_DATE_CURRENT_DATE_MSG),
								CVDDMConstant.VALIDATION_ERR));
			}

			if (!isValidToDate()) {
				isSuccess = false;
				FacesContext.getCurrentInstance().addMessage("createMaintenanceForm:toDateTime",
						new FacesMessage(FacesMessage.SEVERITY_ERROR,
								CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
										CVDDMConstant.TO_DATE_FROM_DATE_MSG),
								CVDDMConstant.VALIDATION_ERR));
			}

			if (isNotValidDowntime()) {
				isSuccess = false;
				FacesContext.getCurrentInstance().addMessage("createMaintenanceForm:maintType",
						new FacesMessage(FacesMessage.SEVERITY_ERROR,
								CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
										CVDDMConstant.MAINT_TYPE_DWN_VALID),
								CVDDMConstant.VALIDATION_ERR));
			}

			/** Start Change :User Story: US941659 ****/

			if (isNotValidMaint()) {
				isSuccess = false;
				FacesContext.getCurrentInstance().addMessage("createMaintenanceForm:maintType",
						new FacesMessage(FacesMessage.SEVERITY_ERROR,
								CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
										CVDDMConstant.MAINT_TYPE_SITE_INVALID),
								CVDDMConstant.VALIDATION_ERR));
			}
			/** End Change :User Story: US941659 ****/

			if (isSuccess) {

				Map<String, Object> inputDataMap = populateInputDataMap();

				CvddmMaintRcrdDE cvddmMaintRcrdDE = listCvddmMaintenanceBF.saveCvddmMaintRcrd(inputDataMap);

				if (!CvddmUtil.isObjectEmpty(cvddmMaintRcrdDE)) {

					/*** Start Change :User Story: US945528**/

					if(CVDDMConstant.STRING_Y.equalsIgnoreCase(cvddmMaintRcrdDE.getCvdmEmailNotify())) {


						Date fromDate = cvddmMaintRcrdDE.getCvdmMaintFromDt();


						Date toDate = cvddmMaintRcrdDE.getCvdmMaintToDt();

						String strFrmDate = sdf.format(fromDate);

						log.info("strFrmDate >>> "+strFrmDate);


						String strtoDate = sdf.format(toDate);


						log.info("strtoDate >>> "+strtoDate);


						inputMap.put(CVDDMConstant.EMAIL_MAINT_DESC,cvddmMaintRcrdDE.getCvdmMaintDesc());
						inputMap.put(CVDDMConstant.EMAIL_FROM_DATE_STR,strFrmDate);
						inputMap.put(CVDDMConstant.EMAIL_TO_DATE_STR,strtoDate);
						inputMap.put(CVDDMConstant.EMAIL_MAINT_SCREENCD,
								String.valueOf(cvddmMaintRcrdDE.getCvddmScreenInfoDE().getCvddmScreenId()));
						inputMap.put(CVDDMConstant.EMAIL_MAINT_SCREEN_NAME,cvddmMaintRcrdDE.getCvddmScreenInfoDE().getCvdmScreenName());

						prepareEmailandSend(inputMap);	
					}

					/*** End Change :User Story: US945528**/

					FacesContext.getCurrentInstance().addMessage(null,
							new FacesMessage(FacesMessage.SEVERITY_INFO,
									CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
											CVDDMConstant.MAINT_CRT_SUCCESS_MSG),
									null));
					clearFormVariables();
				} else {

					FacesContext.getCurrentInstance().addMessage(null,
							new FacesMessage(FacesMessage.SEVERITY_ERROR,
									CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
											CVDDMConstant.MAINT_CRT_FAIL_MSG),
									CVDDMConstant.VALIDATION_ERR));
				}
			}

			log.exiting(CLASS_NAME, METHOD_NAME);

		} catch (Exception e) {
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR,
							CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
									CVDDMConstant.MAINT_CRT_FAIL_MSG),
							CVDDMConstant.VALIDATION_ERR));
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);

		} finally {
			preRenderCreateMaintenanceRecord();
			log.exiting(CLASS_NAME, METHOD_NAME);
		}

		preRenderCreateMaintenanceRecord();
		return navigation;
	}

	/**
	 * Method Name: isValidToDate
	 * 
	 * @Description: This method validate whether To Date & Time is Greater than
	 *               From Date & Time.
	 * @param :
	 *            None
	 * @return boolean
	 */

	public boolean isValidToDate() {

		boolean isValid = false;
		final String METHOD_NAME = "isValidToDate";
		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			isValid = this.fromDateTime.getTime() < this.toDateTime.getTime();
		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
		return isValid;
	}

	/**
	 * Method Name: isValidFromDate
	 * 
	 * @Description: This method validate whether From Date & Time is greater than
	 *               Current Server Date.
	 * @param :
	 *            None
	 * @return boolean
	 */

	public boolean isValidFromDate() {

		boolean isValid = false;
		final String METHOD_NAME = "isValidFromDate";
		log.entering(CLASS_NAME, METHOD_NAME);

		Date serverCurrentDate = CvddmUtil.getTimeZoneCurrentDate(CVDDMConstant.TIMEZONE_UTC);

		try {
			if (!CvddmUtil.isObjectEmpty(serverCurrentDate)) {

				isValid = this.fromDateTime.getTime() >= serverCurrentDate.getTime();
			}

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
		return isValid;
	}

	/**
	 * Method Name: updateDateTime
	 * 
	 * @Description: This method would update From and To Date Time
	 * @param :
	 *            None
	 * @return void
	 */

	public void updateDateTime() {

		final String METHOD_NAME = "updateDateTime";
		log.entering(CLASS_NAME, METHOD_NAME);

		this.getStartDate();
		this.getEndDate();

		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * Method Name: clearFormVariables
	 * 
	 * @Description: This method would be used to clear values of Form.
	 * @param :
	 *            None
	 * @return Void
	 */

	public void clearFormVariables() {

		maintFor = null;
		maintTitle = null;
		maintType = null;
		maintDescription = null;
		toDateTime = null;
		fromDateTime = null;
		emailNotify = false;
	}

	/**
	 * Method Name: isNotValidDowntime
	 * 
	 * @Description: This method validates whether Downtime Option of Maintenance
	 *               Type is valid for Selected Option of Maintenance For.
	 * @param :
	 *            None
	 * @return boolean
	 */

	public boolean isNotValidDowntime() {

		boolean isNotValid = false;
		final String METHOD_NAME = "isNotValidDowntime";
		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			String dwnTimesScrnCds = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
					CVDDMConstant.MAINT_FOR_SCRN_DWNTIME_REQ);

			String[] dwnTimeScnCdArray = dwnTimesScrnCds.split(",");

			String maintypeCd = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
					CVDDMConstant.MAINT_TYPE_DWNTIME_CD);

			String[] maintypeCdArry = maintypeCd.split(",");

			if (!CvddmUtil.isArrayEmpty(dwnTimeScnCdArray) && !CvddmUtil.isArrayEmpty(maintypeCdArry)
					&& !CvddmUtil.isObjectEmpty(this.maintFor) && !CvddmUtil.isObjectEmpty(this.maintType)
					&& !Arrays.asList(dwnTimeScnCdArray).contains(this.maintFor)
					&& Arrays.asList(maintypeCdArry).contains(this.maintType)) {

				isNotValid = true;
			}
		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
		return isNotValid;
	}

	/** Start Change :User Story: US941659 ****/

	/**
	 * Method Name: isNotValidMaint
	 * 
	 * @Description: This method validates whether Alert or Banners Option of
	 *               Maintenance Type is valid for Across Site Option of Maintenance
	 *               For Drop Down.
	 * @param :
	 *            None
	 * @return boolean
	 */

	public boolean isNotValidMaint() {

		boolean isNotValid = false;
		final String METHOD_NAME = "isNotValidMaint";
		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			String dwnTimesScrnCds = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
					CVDDMConstant.MAINT_FOR_SCRN_DWNTIME_REQ);

			String[] dwnTimeScnCdArray = dwnTimesScrnCds.split(",");

			String maintypeCd = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
					CVDDMConstant.MAINT_TYPE_DWNTIME_CD);

			String[] maintypeCdArry = maintypeCd.split(",");

			if (!CvddmUtil.isArrayEmpty(dwnTimeScnCdArray) && !CvddmUtil.isArrayEmpty(maintypeCdArry)
					&& !CvddmUtil.isObjectEmpty(this.maintFor) && !CvddmUtil.isObjectEmpty(this.maintType)
					&& Arrays.asList(dwnTimeScnCdArray).contains(this.maintFor)
					&& !Arrays.asList(maintypeCdArry).contains(this.maintType)) {

				isNotValid = true;
			}

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
		return isNotValid;
	}

	/** End Change :User Story: US941659 ****/

	/**
	 * Method Name: populateInputDataMap
	 * 
	 * @Description: This method would populate InputDataMap with the values entered
	 *               by User on Create Maintenance Record Screen.
	 * @param :
	 *            none
	 * @return Map<String, Object> tempMap
	 ***/

	public Map<String, Object> populateInputDataMap() {

		final String METHOD_NAME = "populateInputDataMap";

		Map<String, Object> tempMap = new HashMap<String, Object>();

		CvddmMaintRcrdDE cvddmMaintRcrdDE = null;

		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			cvddmMaintRcrdDE = new CvddmMaintRcrdDE();

			if (TextUtil.isNotBlankOrNull(this.maintFor)) {

				Long cvddmScreenId = Long.valueOf(this.maintFor);

				tempMap.put(CVDDMConstant.CVDDM_SCREEN_ID_PK, cvddmScreenId);
			}

			if (TextUtil.isNotBlankOrNull(this.maintType)) {

				tempMap.put(CVDDMConstant.MAINT_TYPE_CD_PK, this.maintType);
			}

			if (TextUtil.isNotBlankOrNull(this.maintTitle)) {

				cvddmMaintRcrdDE.setCvdmMaintTitle(this.maintTitle);
			}

			if (TextUtil.isNotBlankOrNull(this.maintDescription)) {

				cvddmMaintRcrdDE.setCvdmMaintDesc(this.maintDescription);
			}

			if (!CvddmUtil.isObjectEmpty(this.emailNotify)) {

				if (this.emailNotify) {
					cvddmMaintRcrdDE.setCvdmEmailNotify(CVDDMConstant.STRING_Y);
				} else {
					cvddmMaintRcrdDE.setCvdmEmailNotify(CVDDMConstant.STRING_N);
				}
			}

			if (!CvddmUtil.isObjectEmpty(this.fromDateTime)) {

				Timestamp frmDtTime = new Timestamp(fromDateTime.getTime());

				cvddmMaintRcrdDE.setCvdmMaintFromDt(frmDtTime);
			}

			if (!CvddmUtil.isObjectEmpty(this.toDateTime)) {

				Timestamp toDtTime = new Timestamp(toDateTime.getTime());

				cvddmMaintRcrdDE.setCvdmMaintToDt(toDtTime);
			}

			/** Start Change :User Story: US1064749 ****/
			cvddmMaintRcrdDE.setCvdmActiveFlag(CVDDMConstant.STRING_Y);

			String userId = CvddmUtil .getLoggedInUserCDSID();
			cvddmMaintRcrdDE.setCvdmMaintCreatedUser(userId);

			cvddmMaintRcrdDE.setCvdmMaintCreatedTime(new Timestamp(System.currentTimeMillis()));
			/** End Change :User Story: US1064749 ****/

			tempMap.put(CVDDMConstant.MAINT_RCRD_DE_OBJ, cvddmMaintRcrdDE);

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

		return tempMap;
	}

	/** Start Change :User Story: US890080 ****/

	/**
	 * Method to retrieve all the maintenance records
	 */
	public void retrieveAndSetMaintenanceRecords() {

		final String METHOD_NAME = "retrieveAndSetMaintenanceRecords";
		log.entering(CLASS_NAME, METHOD_NAME);

		try {
			/** Start Change :User Story: US890083 ****/
			List<CvddmMaintRcrdDE> maintenanceRecordsFromDB = listCvddmMaintenanceBF.retrieveMaintRcrds();

			if (!CvddmUtil.isObjectEmpty(maintenanceRecordsFromDB) && !maintenanceRecordsFromDB.isEmpty()) {

				log.info("Number of Active Maintenance records from DB " + maintenanceRecordsFromDB.size());

				setMaintenanceRecords(maintenanceRecordsFromDB);
				this.displayDeleteButton = CVDDMConstant.STRING_Y;
			} else if (!CvddmUtil.isObjectEmpty(maintenanceRecords)) {
				this.maintenanceRecords.clear();
				this.displayDeleteButton = CVDDMConstant.STRING_N;
			}
			/** End Change :User Story: US890083 ****/
		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	// Methods for Date filter
	public String datePattern() {
		return CVDDMConstant.DATE_PATTERN_AM_PM;
	}

	public String customFormatDate(Date date) {
		if (date != null) {
			DateFormat format = new SimpleDateFormat(datePattern());
			return format.format(date);
		}
		return "";
	}

	/** End Change :User Story: US890080 ****/
	/** Start Change :User Story: US890083 ****/
	/**
	 * Method Name: softDeleteRrcd
	 * 
	 * @Description: This method would Soft Delete Maintenance Record from
	 *               PCVDM05_MAINT_REQ by updating Active Flag to N.
	 * @param :none
	 * @return void
	 ***/

	public void softDeleteRrcd() {

		final String METHOD_NAME = "softDeleteRrcd";
		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			if (!CvddmUtil.isObjectEmpty(selectedMaintRcrds) && !selectedMaintRcrds.isEmpty()) {

				List<CvddmMaintRcrdDE> listCvddmMntRcrds = this.selectedMaintRcrds;

				Iterator<CvddmMaintRcrdDE> itrRcrds = listCvddmMntRcrds.iterator();

				while (itrRcrds.hasNext()) {

					CvddmMaintRcrdDE cvddmMaintRcrd = itrRcrds.next();

					log.info("Active Flag before " + cvddmMaintRcrd.getCvdmActiveFlag());

					if (CVDDMConstant.STRING_Y.equalsIgnoreCase(cvddmMaintRcrd.getCvdmActiveFlag())) {

						cvddmMaintRcrd.setCvdmActiveFlag(CVDDMConstant.STRING_N);

						log.info("Rcrd Id updated " + cvddmMaintRcrd.getCvdmMaintRcrdId());

						listCvddmMaintenanceBF.softDeleteRrcd(cvddmMaintRcrd);

					}
				}
			}
		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
		} finally {
			retrieveAndSetMaintenanceRecords();
			log.exiting(CLASS_NAME, METHOD_NAME);
		}
	}

	/**
	 ** 
	 * Method Name: checkRecordSelected
	 * 
	 * @Description: Method to check records selected for deletion or not.
	 * @param :none
	 * @return void
	 * 
	 */
	public void checkRecordSelected() {
		if (CvddmUtil.isObjectEmpty(this.selectedMaintRcrds) || this.selectedMaintRcrds.isEmpty())
			addLocalizedValidationFailureMessage(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
					CVDDMConstant.VAL_MSG_MAINT_RCRD_SEL);
	}
	/** End Change :User Story: US890083 ****/

	/*** Start Change :User Story: US945528**/
	/**
	 * Method Name: prepareEmailandSend
	 * 
	 * @Description: This method would send Email to Users.
	 * @param :Map<String,String> inputMap
	 * @return Void
	 */

	public void prepareEmailandSend(Map<String,String> inputMap) {

		final String METHOD_NAME = "prepareEmailandSend";

		List <String> rolesList = new ArrayList<String>();

		String emailIds = CVDDMConstant.EMPTY_STRING;

		try {
			String cmnMenuCds = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
					CVDDMConstant.COMMON_MENU_SCRN_CD);

			String[] cmnMenuScnCdArray = cmnMenuCds.split(",");

			String maintScrCd = inputMap.get(CVDDMConstant.EMAIL_MAINT_SCREENCD);

			log.severe("Got Roles from APS from Screen "+inputMap.get(CVDDMConstant.EMAIL_MAINT_SCREEN_NAME));

			if (!CvddmUtil.isArrayEmpty(cmnMenuScnCdArray) 
					&& Arrays.asList(cmnMenuScnCdArray).contains(maintScrCd)) {

				emailIds = assignmentsBF.getEmailIdsForApplication().toString();

			}
			else {

				rolesList = appResourcePolicyRoleBF.getRolesForResource(inputMap.get(CVDDMConstant.EMAIL_MAINT_SCREEN_NAME));

				emailIds = entitlementGroupBF.getEmailIdsForRole(rolesList).toString();

			}

			log.severe("Got Email Ids from APS "+emailIds);

			inputMap.put(CVDDMConstant.EMAIL_IDS_DETAILS,emailIds);

			log.severe("CvddmUtil.sendMaintEmail invoked");
			CvddmUtil.sendMaintEmail(inputMap);
		}
		catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}
	}
	/*** End Change :User Story: US945528**/

}
