/**
 * 
 */
package com.ford.cvddm.inbound.csvfileupload.ui.bean;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import org.eclipse.persistence.exceptions.DatabaseException;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.UploadedFile;

import com.ford.cvddm.app.business.list.CvddmCsvFileUploadBF;
import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.domain.application.de.CvddmESNCSVUploadDE;
import com.ford.cvddm.domain.application.de.CvddmPartMatrixReferenceCSVUploadDE;
import com.ford.cvddm.domain.application.de.CvddmVinRepoCSVUploadDE;
import com.ford.cvddm.inbound.layer.base.CVDDMBaseBean;
import com.ford.cvddm.sob.business.layer.CVDDMBusinessException;
import com.ford.it.exception.FordExceptionAttributes;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;

/**
 * This class is used for csv fileupload functionality
 * 
 * @author RPADI
 *
 */
@ManagedBean
@ViewScoped
public class CSVFileUploadBean extends CVDDMBaseBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final String CLASS_NAME = CSVFileUploadBean.class.getName();

	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	@Override
	protected void preRenderViewTM() {

	}

	@Override
	protected void preRenderViewStartWorkflowTM() {

	}

	private UploadedFile file;

	public UploadedFile getFile() {
		return file;
	}

	public void setFile(UploadedFile file) {
		this.file = file;
	}

	@Inject
	CvddmCsvFileUploadBF cvddmCsvFileUploadBF;

	String fileName;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String upload() {

		if (fileName != null)
			return "success";
		return "success";
	}

	/**
	 * this is used to upload vin, esn repo and partmatrix csv files
	 * 
	 * @param event
	 * @return
	 */
	public String handleFileUpload(FileUploadEvent event) {
		final String METHOD_NAME = "handleFileUpload";
		String navigation = "";
		log.entering(CLASS_NAME, METHOD_NAME);
		navigation = "/fileupload/csvFileUpload.faces?faces-redirect=true";
		List<CvddmVinRepoCSVUploadDE> cvddmCSVUploadDE = new ArrayList<>();
		List<CvddmESNCSVUploadDE> eSNCSVUploadDE = new ArrayList<>();
		List<CvddmPartMatrixReferenceCSVUploadDE> partMatrixReferenceCSVUploadDE = new ArrayList<>();

		file = event.getFile();
		byte[] contents = file.getContents();
		InputStream is = null;
		BufferedReader bfReader = null;

		try {
			is = new ByteArrayInputStream(contents);
			bfReader = new BufferedReader(new InputStreamReader(is));
			String line = null;
			int count = 0;
			if (event.getFile().getFileName().equals(CVDDMConstant.VIN_REPO_CSVNAME) && this.file.getSize() != 0) {
				while ((line = bfReader.readLine()) != null) {

					if (count != 0) {
						String[] items = line.split(",");
						try {
							if (items.length > 6)
								throw new ArrayIndexOutOfBoundsException();
							CvddmVinRepoCSVUploadDE cvddmCSVUploadDEe = new CvddmVinRepoCSVUploadDE();

							cvddmCSVUploadDEe.setVin(items[0].trim());
							cvddmCSVUploadDEe.setMake(items[1].trim());
							cvddmCSVUploadDEe.setProgramCode(items[2].trim());
							cvddmCSVUploadDEe.setModelYear(items[3].trim());
							cvddmCSVUploadDEe.setVehicleName(items[4].trim());
							cvddmCSVUploadDEe.setStatus(items[5].trim());
							cvddmCSVUploadDE.add(cvddmCSVUploadDEe);

						} catch (ArrayIndexOutOfBoundsException | NumberFormatException | NullPointerException
								| DatabaseException e) {

							if (!CvddmUtil.isObjectEmpty(cvddmCSVUploadDE)) {
								throwInvalidCSVErrorMsg();
							}
							log.severe(CvddmUtil.getStackTraceContent(e));
						}
					}
					count++;
				}

				boolean vinreprocsvsave = cvddmCsvFileUploadBF.saveCvddmCSVRcrds(cvddmCSVUploadDE);
				if (!vinreprocsvsave || count == 1) {
					throwInvalidCSVErrorMsg();
				} else {
					throwValidCSVErrorMsg(CVDDMConstant.CSV_CRT_SUCCESS_MSG);
				}

			} else if (event.getFile().getFileName().equals(CVDDMConstant.ESN_REPO_CSVNAME)
					&& this.file.getSize() != 0) {
				while ((line = bfReader.readLine()) != null) {

					if (count != 0) {
						String[] items = line.split(",");

						try {
							if (items.length > 6)
								throwInvalidCSVErrorMsg();
							CvddmESNCSVUploadDE esnCSVUploadDEe = new CvddmESNCSVUploadDE();

							esnCSVUploadDEe.seteSN(items[0].trim());
							esnCSVUploadDEe.setpSKey(items[1].trim());
							esnCSVUploadDEe.setMqttPassword(items[2].trim());
							esnCSVUploadDEe.setiMEI(items[3].trim());
							esnCSVUploadDEe.setiCCID(items[4].trim());
							esnCSVUploadDEe.setStatus(items[5].trim());
							eSNCSVUploadDE.add(esnCSVUploadDEe);

						} catch (ArrayIndexOutOfBoundsException | NumberFormatException | NullPointerException
								| DatabaseException e) {
							throwInvalidCSVErrorMsg();
							log.severe(CvddmUtil.getStackTraceContent(e));
						}
					}
					count++;
				}
				boolean esnreprocsvsave = cvddmCsvFileUploadBF.saveESNCSVRcrds(eSNCSVUploadDE);

				if (!esnreprocsvsave || count == 1) {
					throwInvalidCSVErrorMsg();
				} else {
					throwValidCSVErrorMsg(CVDDMConstant.ESN_CSV_CRT_SUCCESS_MSG);

				}
			} else if (event.getFile().getFileName().equals(CVDDMConstant.PARTMATRX_REPO_CSVNAME)
					&& this.file.getSize() != 0) {
				while ((line = bfReader.readLine()) != null) {

					if (count != 0) {
						String[] items = line.split(",");

						try {
							if (items.length > 8)
								throwInvalidCSVErrorMsg();
							CvddmPartMatrixReferenceCSVUploadDE partMatrixReferenceCSVUploadDEe = new CvddmPartMatrixReferenceCSVUploadDE();

							partMatrixReferenceCSVUploadDEe.setRegion(items[0].trim());
							partMatrixReferenceCSVUploadDEe.setSoftwareReleaseVersion(items[1].trim());
							partMatrixReferenceCSVUploadDEe.setFeatureBundle(items[2].trim());
							partMatrixReferenceCSVUploadDEe.setNode(items[3].trim());
							partMatrixReferenceCSVUploadDEe.setAssemblyPartIIspec(items[4].trim());
							partMatrixReferenceCSVUploadDEe.setSortingOrder(Integer.parseInt(items[5].trim()));
							partMatrixReferenceCSVUploadDEe.setProgramCode(items[6].trim());
							partMatrixReferenceCSVUploadDEe.setModelYear(items[7].trim());

							partMatrixReferenceCSVUploadDE.add(partMatrixReferenceCSVUploadDEe);

						} catch (ArrayIndexOutOfBoundsException | NumberFormatException | NullPointerException
								| DatabaseException e) {
							throwInvalidCSVErrorMsg();
							log.severe(CvddmUtil.getStackTraceContent(e));
						}
					}
					count++;
				}
				boolean partMatrxreprocsvsave = cvddmCsvFileUploadBF
						.savePartMatrxCSVRcrds(partMatrixReferenceCSVUploadDE);

				if (!partMatrxreprocsvsave || count == 1) {
					throwInvalidCSVErrorMsg();
				} else {
					throwValidCSVErrorMsg(CVDDMConstant.PARTMATRIX_CSV_CRT_SUCCESS_MSG);
				}
			} else {
				throwInvalidCSVErrorMsg();
			}
		}

		catch (IOException e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		} finally {
			try {
				if (is != null)
					is.close();
			} catch (Exception ex) {
				log.severe(CvddmUtil.getStackTraceContent(ex));

			}
		}

		return navigation;
	}

	/**
	 * this method is used to throw an invalid csv error message
	 * 
	 */
	private void throwInvalidCSVErrorMsg() {
		FacesContext.getCurrentInstance().addMessage(null,
				new FacesMessage(FacesMessage.SEVERITY_ERROR, CvddmUtil
						.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY, CVDDMConstant.CSV_FAIL_MSG),
						CVDDMConstant.VALIDATION_ERR));
	}

	/**
	 * this method is used to throw an valid csv error message
	 * 
	 */
	private void throwValidCSVErrorMsg(String message) {
		FacesContext.getCurrentInstance().addMessage(null,
				new FacesMessage(FacesMessage.SEVERITY_INFO,
						CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY, message),
						CVDDMConstant.VALIDATION_ERR));
	}
}