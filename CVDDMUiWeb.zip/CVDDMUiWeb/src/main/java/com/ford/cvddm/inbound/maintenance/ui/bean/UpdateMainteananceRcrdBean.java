/**
 * 
 */
package com.ford.cvddm.inbound.maintenance.ui.bean;

import java.io.Serializable;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.TimeZone;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.faces.model.SelectItemGroup;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.deltaspike.core.api.scope.GroupedConversationScoped;

import com.ford.cvddm.aps.business.AppResourcePolicyRoleBF;
import com.ford.cvddm.aps.business.EntitlementGroupBF;
import com.ford.cvddm.aps.business.RetrieveRoleAssignmentsBF;
import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.domain.maintenance.de.CvddmMaintRcrdDE;
import com.ford.cvddm.domain.master.de.CvddmMaintTypeDE;
import com.ford.cvddm.domain.master.de.CvddmScreenInfoDE;
import com.ford.cvddm.inbound.layer.base.CVDDMBaseBean;
import com.ford.cvddm.maintenance.business.list.ListCvddmMaintenanceBF;
import com.ford.cvddm.sob.business.layer.CVDDMBusinessException;
import com.ford.it.exception.FordExceptionAttributes;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;
import com.ford.it.util.TextUtil;

/**
 * @since US941215
 * 
 * @author NGUPTA18
 *
 */
@Named
@GroupedConversationScoped
public class UpdateMainteananceRcrdBean extends CVDDMBaseBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final String CLASS_NAME = UpdateMainteananceRcrdBean.class.getName();

	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	@Inject
	private ListCvddmMaintenanceBF listCvddmMaintenanceBF;
	
	@Inject
	private AppResourcePolicyRoleBF appResourcePolicyRoleBF ;
	
	@Inject
    protected RetrieveRoleAssignmentsBF assignmentsBF ;

	@Inject
	private EntitlementGroupBF entitlementGroupBF ;


	private String selectedRcrd;

	private String hiddenSelectedRcrd;
	
	private String noErrorAvl = "";

	private String displayEditPanel = CVDDMConstant.STRING_Y;

	private String maintTitle = ""; // Maintenance Title

	private String maintDescription = ""; // Maintenance Description

	private String maintFor; // Maintenance For

	private List<CvddmScreenInfoDE> maintForList;
	private List<CvddmMaintTypeDE> maintTypeList; // Hold Values for "Maintenance Type" Drop Down.

	private String maintType; // Maintenance Type

	private Date fromDateTime; // From Date and Time

	private Date toDateTime; // To Date and Time

	private boolean emailNotify = false; // Email Notification

	private Date startDate; // Start Date for Calendar.
	
	private Date hdnFrmDateTime; // Hidden From Date and Time

	public Date getStartDate() {
		return startDate;
	}


	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}


	public Date getEndDate() {
		return endDate;
	}


	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	private Date endDate; // End Date for Calendar.

	private List<SelectItem> mainForListValues = new ArrayList<SelectItem>(); // Hold Values for "Maintenance For" Drop Down.


	public ListCvddmMaintenanceBF getListCvddmMaintenanceBF() {
		return listCvddmMaintenanceBF;
	}


	public void setListCvddmMaintenanceBF(ListCvddmMaintenanceBF listCvddmMaintenanceBF) {
		this.listCvddmMaintenanceBF = listCvddmMaintenanceBF;
	}


	public String getMaintTitle() {
		return maintTitle;
	}


	public void setMaintTitle(String maintTitle) {
		this.maintTitle = maintTitle;
	}


	public String getMaintDescription() {
		return maintDescription;
	}


	public void setMaintDescription(String maintDescription) {
		this.maintDescription = maintDescription;
	}


	public String getMaintFor() {
		return maintFor;
	}


	public void setMaintFor(String maintFor) {
		this.maintFor = maintFor;
	}


	public List<CvddmScreenInfoDE> getMaintForList() {
		return maintForList;
	}


	public void setMaintForList(List<CvddmScreenInfoDE> maintForList) {
		this.maintForList = maintForList;
	}


	public List<CvddmMaintTypeDE> getMaintTypeList() {
		return maintTypeList;
	}


	public void setMaintTypeList(List<CvddmMaintTypeDE> maintTypeList) {
		this.maintTypeList = maintTypeList;
	}


	public String getMaintType() {
		return maintType;
	}


	public void setMaintType(String maintType) {
		this.maintType = maintType;
	}


	public Date getFromDateTime() {
		return fromDateTime;
	}


	public void setFromDateTime(Date fromDateTime) {
		this.fromDateTime = fromDateTime;
	}


	public Date getToDateTime() {
		return toDateTime;
	}


	public void setToDateTime(Date toDateTime) {
		this.toDateTime = toDateTime;
	}


	public boolean isEmailNotify() {
		return emailNotify;
	}


	public void setEmailNotify(boolean emailNotify) {
		this.emailNotify = emailNotify;
	}




	/**
	 * @return the selectedRcrd
	 */
	public String getSelectedRcrd() {
		return selectedRcrd;
	}


	/**
	 * @param selectedRcrd the selectedRcrd to set
	 */
	public void setSelectedRcrd(String selectedRcrd) {
		this.selectedRcrd = selectedRcrd;
	}


	/**
	 * @return the hiddenSelectedRcrd
	 */
	public String getHiddenSelectedRcrd() {
		return hiddenSelectedRcrd;
	}


	/**
	 * @param hiddenSelectedRcrd the hiddenSelectedRcrd to set
	 */
	public void setHiddenSelectedRcrd(String hiddenSelectedRcrd) {
		this.hiddenSelectedRcrd = hiddenSelectedRcrd;
	}


	public List<SelectItem> getMainForListValues() {
		return mainForListValues;
	}


	public void setMainForListValues(List<SelectItem> mainForListValues) {
		this.mainForListValues = mainForListValues;
	}


	/**
	 * @return the displayEditPanel
	 */
	public String getDisplayEditPanel() {
		return displayEditPanel;
	}


	/**
	 * @param displayEditPanel the displayEditPanel to set
	 */
	public void setDisplayEditPanel(String displayEditPanel) {
		this.displayEditPanel = displayEditPanel;
	}

	/**
	 * @return the noErrorAvl
	 */
	public String getNoErrorAvl() {
		return noErrorAvl;
	}


	/**
	 * @param noErrorAvl the noErrorAvl to set
	 */
	public void setNoErrorAvl(String noErrorAvl) {
		this.noErrorAvl = noErrorAvl;
	}


	/**
	 * @return the hdnFrmDateTime
	 */
	public Date getHdnFrmDateTime() {
		return hdnFrmDateTime;
	}


	/**
	 * @param hdnFrmDateTime the hdnFrmDateTime to set
	 */
	public void setHdnFrmDateTime(Date hdnFrmDateTime) {
		this.hdnFrmDateTime = hdnFrmDateTime;
	}


	/* (non-Javadoc)
	 * @see com.ford.it.jsfcore.bean.JcBaseBean#preRenderViewStartWorkflowTM()
	 */
	@Override
	protected void preRenderViewStartWorkflowTM() {

		log.exiting(CLASS_NAME, "preRenderViewStartWorkflowTM");

		preRenderUpdateRecord();
	}

	public void preRenderUpdateRecord( ) {

		final String METHOD_NAME = "preRenderUpdateRecord";
		log.entering(CLASS_NAME, METHOD_NAME);

		if(isNotPostBack()) {



			this.populateMaintForDrpDown();

			this.populateMaintTypeDrpDown();

			this.populateUpdateRcrdonScreen();
		}
	}

	/**
	 * Method Name: populateMaintForDrpDown
	 * 
	 * @Description: This method would load values for "Maintenance For" Drop Down.
	 * @param :
	 *            none
	 * @return void
	 **/

	public void populateMaintForDrpDown() {

		final String METHOD_NAME = "populateMaintForDrpDown";

		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			List<CvddmScreenInfoDE> maintList = listCvddmMaintenanceBF.retrieveAllScreens();

			ListIterator<CvddmScreenInfoDE> listItr = maintList.listIterator();

			SelectItemGroup cmnMenuGrp = new SelectItemGroup(CVDDMConstant.COMMON_MENUS);

			SelectItemGroup menuGrp = new SelectItemGroup(CVDDMConstant.LIST_MENUS);

			SelectItemGroup subMenuGrp = new SelectItemGroup(CVDDMConstant.LIST_SUB_MENUS);

			List<SelectItem> cmnMenuLst = new ArrayList<SelectItem>();

			List<SelectItem> menuLst = new ArrayList<SelectItem>();

			List<SelectItem> subMenuList = new ArrayList<SelectItem>();

			String cmnMenuCds = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
					CVDDMConstant.COMMON_MENU_SCRN_CD);

			String[] cmnMenuScnCdArray = cmnMenuCds.split(",");

			String menuCds = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
					CVDDMConstant.LIST_MENU_SCRN_CD);

			String[] menuScnCdArray = menuCds.split(",");

			while (listItr.hasNext()) {

				CvddmScreenInfoDE cvddmScreenInfoDE = listItr.next();

				String screenId = cvddmScreenInfoDE.getCvddmScreenId()+"";

				if (!CvddmUtil.isArrayEmpty(cmnMenuScnCdArray) && Arrays.asList(cmnMenuScnCdArray).contains(screenId)) {

					SelectItem selectItem = new SelectItem(cvddmScreenInfoDE.getCvddmScreenId(),
							cvddmScreenInfoDE.getCvdmScreenName());

					cmnMenuLst.add(selectItem);
				} else if (!CvddmUtil.isArrayEmpty(menuScnCdArray)
						&& Arrays.asList(menuScnCdArray).contains(screenId)) {

					SelectItem selectItem = new SelectItem(cvddmScreenInfoDE.getCvddmScreenId(),
							cvddmScreenInfoDE.getCvdmScreenName());

					menuLst.add(selectItem);
				} else {

					SelectItem selectItem = new SelectItem(cvddmScreenInfoDE.getCvddmScreenId(),
							cvddmScreenInfoDE.getCvdmScreenName());

					subMenuList.add(selectItem);
				}
			}

			SelectItem[] commonMenus = new SelectItem[cmnMenuLst.size()];
			commonMenus = cmnMenuLst.toArray(commonMenus);

			SelectItem[] menuArray = new SelectItem[menuLst.size()];
			menuArray = menuLst.toArray(menuArray);

			SelectItem[] subMenus = new SelectItem[subMenuList.size()];
			subMenus = subMenuList.toArray(subMenus);

			cmnMenuGrp.setSelectItems(commonMenus);

			menuGrp.setSelectItems(menuArray);

			subMenuGrp.setSelectItems(subMenus);

			mainForListValues = new ArrayList<SelectItem>();

			mainForListValues.add(cmnMenuGrp);
			mainForListValues.add(menuGrp);
			mainForListValues.add(subMenuGrp);

			setMainForListValues(mainForListValues);

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * Method Name: populateMaintTypeDrpDown
	 * 
	 * @Description: This method would load values for "Maintenance Type" Drop Down.
	 * @param :
	 *            none
	 * @return void
	 **/

	public void populateMaintTypeDrpDown() {

		final String METHOD_NAME = "populateMaintTypeDrpDown";

		log.entering(CLASS_NAME, METHOD_NAME);

		try {
			setMaintTypeList(listCvddmMaintenanceBF.retrieveActiveMaintTypes());
			this.maintTypeList = listCvddmMaintenanceBF.retrieveActiveMaintTypes();
		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
	}


	/*
	 * Method Name: updateEndDate
	 * 
	 * @Description: This method would set End Date as One month from Start Date.
	 * 
	 * @param : Date startDate
	 * 
	 * @return Date
	 */
	public Date updateEndDate(Date startDate) {

		final String METHOD_NAME = "updateEndDate";

		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			Calendar cal = Calendar.getInstance();
			cal.setTime(startDate);
			cal.setTimeZone(TimeZone.getTimeZone(CVDDMConstant.TIMEZONE_UTC));
			cal.add(Calendar.MONTH, 1);
			this.endDate = cal.getTime();
			setEndDate(this.endDate);
		} catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		log.exiting(CLASS_NAME, METHOD_NAME);
		return endDate;
	}


	/**
	 * Method Name: getMaintRcrdForUpdate()
	 * 
	 * @Description: This method would load CvddmMaintRrcdDE from PCVDM05_MAINT_REQ Table.
	 * @param : none
	 * @return CvddmMaintRcrdDE
	 **/

	public CvddmMaintRcrdDE getMaintRcrdForUpdate() {


		final String METHOD_NAME = "getMaintRcrdForUpdate";
		log.entering(CLASS_NAME, METHOD_NAME);

		CvddmMaintRcrdDE cvddmMaintRcrd = null;

		try {

			if(TextUtil.isNotBlankOrNull(getSelectedRcrd())) {

				cvddmMaintRcrd = listCvddmMaintenanceBF.fetchRcrdforUpdate(getSelectedRcrd());
				log.info("Getting details from Param Selected Record Value");
			}

			else if(TextUtil.isNotBlankOrNull(getHiddenSelectedRcrd())) {

				cvddmMaintRcrd = listCvddmMaintenanceBF.fetchRcrdforUpdate(getSelectedRcrd());

				log.info("Getting details from Hidden Selected Record Value");
			}
		}
		catch(Exception e) {			
			log.severe(CvddmUtil.getStackTraceContent(e));		
		}
		finally {
			log.exiting(CLASS_NAME, METHOD_NAME);
		}
		return cvddmMaintRcrd;
	}

	/**
	 * Method Name: populateUpdateRcrdonScreen
	 * 
	 * @Description: This method would populate Data on Edit Screen.
	 * @param :none
	 * @return void
	 **/

	public void populateUpdateRcrdonScreen() {

		final String METHOD_NAME = "populateUpdateRcrdonScreen";

		log.entering(CLASS_NAME, METHOD_NAME);

		CvddmMaintRcrdDE cvddmMaintRcrd = null;

		try {

			cvddmMaintRcrd =  getMaintRcrdForUpdate();

			if(!CvddmUtil.isObjectEmpty(cvddmMaintRcrd) ) {

				if(CVDDMConstant.STRING_Y.equalsIgnoreCase(cvddmMaintRcrd.getCvdmEmailNotify())) {

					this.emailNotify = true;
				}
				else {

					this.emailNotify = false;
				}

				this.maintFor = String.valueOf(cvddmMaintRcrd.getCvddmScreenInfoDE().getCvddmScreenId());
				setMaintFor(String.valueOf(cvddmMaintRcrd.getCvddmScreenInfoDE().getCvddmScreenId()));

				this.maintType =  String.valueOf(cvddmMaintRcrd.getCvddmMaintTypeDE().getCvdmMaintTypeCd());
				setMaintType(String.valueOf(cvddmMaintRcrd.getCvddmMaintTypeDE().getCvdmMaintTypeCd()));

				this.maintTitle = cvddmMaintRcrd.getCvdmMaintTitle();
				setMaintTitle(cvddmMaintRcrd.getCvdmMaintTitle());

				this.maintDescription = cvddmMaintRcrd.getCvdmMaintDesc();
				setMaintDescription(cvddmMaintRcrd.getCvdmMaintDesc());

				this.fromDateTime = cvddmMaintRcrd.getCvdmMaintFromDt();
				setFromDateTime(cvddmMaintRcrd.getCvdmMaintFromDt());
				this.hdnFrmDateTime=cvddmMaintRcrd.getCvdmMaintFromDt();
				setHdnFrmDateTime(cvddmMaintRcrd.getCvdmMaintFromDt());

				this.toDateTime = cvddmMaintRcrd.getCvdmMaintToDt();
				setToDateTime(cvddmMaintRcrd.getCvdmMaintToDt());

				setStartDate(cvddmMaintRcrd.getCvdmMaintFromDt());
				this.startDate = cvddmMaintRcrd.getCvdmMaintFromDt();

				updateEndDate(getStartDate());
				updateEndDate(this.startDate);

				setHiddenSelectedRcrd(String.valueOf(cvddmMaintRcrd.getCvdmMaintRcrdId()));
				this.hiddenSelectedRcrd= String.valueOf(cvddmMaintRcrd.getCvdmMaintRcrdId());
				this.displayEditPanel = CVDDMConstant.STRING_Y;
				setDisplayEditPanel(CVDDMConstant.STRING_Y);
			}
			else {

				this.displayEditPanel = CVDDMConstant.STRING_N;
				setDisplayEditPanel(CVDDMConstant.STRING_N);
				addLocalizedValidationFailureMessage(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
						CVDDMConstant.NOTVALID_ACTIVE_RCRD_MSG);
			}


		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			addLocalizedValidationFailureMessage(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
					CVDDMConstant.ERROR_UPDATE_RCRD_MSG);
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * Method Name: isValidData
	 * 
	 * @Description: This method would validate values for Edit Record functionality.
	 * @param :none
	 * @return void
	 **/

	public boolean isValidData() {

		final String METHOD_NAME = "isValidData";

		boolean isValidData = true;

		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			Date serverCurrentDate = CvddmUtil.getTimeZoneCurrentDate(CVDDMConstant.TIMEZONE_UTC);


			if(this.toDateTime.before(serverCurrentDate)) {

				isValidData = false;
				this.noErrorAvl = CVDDMConstant.STRING_N;
				setNoErrorAvl(CVDDMConstant.STRING_N);
				FacesContext.getCurrentInstance().addMessage("updateMaintenanceForm:toDateTime",
						new FacesMessage(FacesMessage.SEVERITY_ERROR,
								CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
										CVDDMConstant.TO_DATE_FROM_DATE_CRRT_MSG),
								CVDDMConstant.VALIDATION_ERR));			
			}
			if(this.toDateTime.getTime()<=hdnFrmDateTime.getTime()) {

				isValidData = false;
				this.noErrorAvl = CVDDMConstant.STRING_N;
				setNoErrorAvl(CVDDMConstant.STRING_N);
				FacesContext.getCurrentInstance().addMessage("updateMaintenanceForm:toDateTime",
						new FacesMessage(FacesMessage.SEVERITY_ERROR,
								CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
										CVDDMConstant.TO_DATE_FROM_DATE_MSG),
								CVDDMConstant.VALIDATION_ERR));			
			}
		}

		catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			addLocalizedValidationFailureMessage(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
					CVDDMConstant.ERROR_UPDATE_RCRD_MSG);
		}

		return isValidData;
	}

	/**
	 * Method Name: updateMaintenanceRcrd
	 * 
	 * @Description: This method would update Maintenance Record Details in DB.
	 * @param :none
	 * @return String
	 **/


	public String updateMaintenanceRcrd() {

		String navigation = null;

		final String METHOD_NAME = "updateMaintenanceRcrd";
		log.entering(CLASS_NAME, METHOD_NAME);
		
		/*** Start Change :User Story: US945528**/
		
		Map<String,String> inputMap = new HashMap<String, String>();
		
		SimpleDateFormat sdf = new SimpleDateFormat(CVDDMConstant.DATE_PATTERN_AM_PM);

		
		/*** End Change :User Story: US945528**/

		boolean isValidInput = true;

		try {

			isValidInput = isValidData();

			if(isValidInput) {

				CvddmMaintRcrdDE cvddmMaintRcrd = getMaintRcrdForUpdate();

				if(!CvddmUtil.isObjectEmpty(cvddmMaintRcrd)) {

					cvddmMaintRcrd.setCvdmMaintTitle(this.maintTitle);

					cvddmMaintRcrd.setCvdmMaintDesc(this.maintDescription);


					if (this.emailNotify) {
						cvddmMaintRcrd.setCvdmEmailNotify(CVDDMConstant.STRING_Y);
					} else {
						cvddmMaintRcrd.setCvdmEmailNotify(CVDDMConstant.STRING_N);
					}
					
					Timestamp toDtTime = new Timestamp(toDateTime.getTime());

					cvddmMaintRcrd.setCvdmMaintToDt(toDtTime);
					
					/*** Start Change :User Story: US945528**/
					
                   if (this.emailNotify) {
                	   
                		Date fromDate = cvddmMaintRcrd.getCvdmMaintFromDt();
                		
                		
                		Date toDate = cvddmMaintRcrd.getCvdmMaintToDt();

                		String strFrmDate = sdf.format(fromDate);
                		
                		log.severe("strFrmDate >>> "+strFrmDate);


                		String strtoDate = sdf.format(toDate);
                		
                		
                		log.severe("strtoDate >>> "+strtoDate);

						
						inputMap.put(CVDDMConstant.EMAIL_MAINT_DESC,this.maintDescription);
						inputMap.put(CVDDMConstant.EMAIL_FROM_DATE_STR,strFrmDate);
						inputMap.put(CVDDMConstant.EMAIL_TO_DATE_STR,strtoDate);
						inputMap.put(CVDDMConstant.EMAIL_MAINT_SCREENCD,
								     String.valueOf(cvddmMaintRcrd.getCvddmScreenInfoDE().getCvddmScreenId()));
						inputMap.put(CVDDMConstant.EMAIL_MAINT_SCREEN_NAME,cvddmMaintRcrd.getCvddmScreenInfoDE().getCvdmScreenName());

					}
					
                   /*** End Change :User Story: US945528**/

					listCvddmMaintenanceBF.updtCvddmMaintRcrd(cvddmMaintRcrd);

					addLocalizedSuccessMessage(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
							CVDDMConstant.RCRD_UPDT_SUCCESS_MSG);
					
					/*** Start Change :User Story: US945528**/
					if(this.emailNotify) {
						prepareEmailandSend(inputMap);		
					}
					/*** End Change :User Story: US945528**/

					clearFormVariables();
					this.noErrorAvl = CVDDMConstant.STRING_Y;
				}
				else {
					this.displayEditPanel = CVDDMConstant.STRING_Y;
					setDisplayEditPanel(CVDDMConstant.STRING_Y);
					addLocalizedValidationFailureMessage(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
							CVDDMConstant.RCRD_UPDT_FAIL_MSG);
				}
			}
		}
		catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			addLocalizedValidationFailureMessage(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
					CVDDMConstant.RCRD_UPDT_FAIL_MSG);
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}
		log.exiting(CLASS_NAME, METHOD_NAME, navigation);

		navigation= CVDDMConstant.UPDT_MAINT_NAVIGATION;

		return navigation;

	}


	/**
	 * Method Name: clearFormVariables
	 * 
	 * @Description: This method would be used to clear values of Form.
	 * @param :
	 *            None
	 * @return Void
	 */

	public void clearFormVariables() {

		maintFor = null;
		maintTitle = null;
		maintType = null;
		maintDescription = null;
		toDateTime = null;
		fromDateTime = null;
		emailNotify = false;
		this.noErrorAvl = CVDDMConstant.STRING_Y;
	}

	/**
	 * Method Name: navigateToParentPage
	 * 
	 * @Description: This method would redirect to Maintenance Summary Page.
	 * @param :
	 *            None
	 * @return Void
	 */

	public void navigateToParentPage() {

		final String METHOD_NAME = "navigateToParentPage";

		try {
			FacesContext context = FacesContext.getCurrentInstance();
			context.getExternalContext().redirect(CVDDMConstant.CRT_MAINT_NAVIGATION);
		}
		catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}
	}
	/*** Start Change :User Story: US945528**/
	/**
	 * Method Name: prepareEmailandSend
	 * 
	 * @Description: This method would send Email to Users.
	 * @param :Map<String,String> inputMap
	 * @return Void
	 */

	public void prepareEmailandSend(Map<String,String> inputMap) {

		final String METHOD_NAME = "prepareEmailandSend";
		
		List <String> rolesList = new ArrayList<String>();
		
		String emailIds = CVDDMConstant.EMPTY_STRING;

		try {
			String cmnMenuCds = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
					CVDDMConstant.COMMON_MENU_SCRN_CD);

			String[] cmnMenuScnCdArray = cmnMenuCds.split(CVDDMConstant.COMMA);
			
			String maintScrCd = inputMap.get(CVDDMConstant.EMAIL_MAINT_SCREENCD);
			
			log.info("Got Roles from APS from Screen "+inputMap.get(CVDDMConstant.EMAIL_MAINT_SCREEN_NAME));
			
			if (!CvddmUtil.isArrayEmpty(cmnMenuScnCdArray) 
					&& Arrays.asList(cmnMenuScnCdArray).contains(maintScrCd)) {
				
				emailIds = assignmentsBF.getEmailIdsForApplication().toString();

			}
			else {
			
			rolesList = appResourcePolicyRoleBF.getRolesForResource(inputMap.get(CVDDMConstant.EMAIL_MAINT_SCREEN_NAME));
			
			emailIds = entitlementGroupBF.getEmailIdsForRole(rolesList).toString();

			}
			
			log.info("Got Email Ids from APS "+emailIds);
			
			inputMap.put(CVDDMConstant.EMAIL_IDS_DETAILS,emailIds);
			
			log.severe("CvddmUtil.sendMaintEmail invoked");
			CvddmUtil.sendMaintEmail(inputMap);
		}
		catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}
	}
	/*** End Change :User Story: US945528**/
}