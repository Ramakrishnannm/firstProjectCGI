// ******************************************************************************
// * Copyright (c) 2015 Ford Motor Company. All Rights Reserved.
// * Original author: Ford Motor Company J2EE Center of Excellence
// *
// ******************************************************************************
package com.ford.cvddm.inbound.layer.base;

import javax.inject.Inject;
import javax.xml.datatype.XMLGregorianCalendar;

import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.inbound.layer.CVDDMAuthProvider;
import com.ford.it.context.UserAttributes;
import com.ford.it.jsfcore.bean.JcBaseBean;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;
import com.ford.it.security.plugins.AuthorizationProvider;

/**
 * This is an abstract cvddm base bean class.
 *
 * @since 6.0.
 *
 */
public abstract class CVDDMBaseBean extends JcBaseBean {

    private static final long serialVersionUID = 1L;
    
    /**** Start Change : User story: US1062806 ****/
    
    private static final String CLASS_NAME = CVDDMBaseBean.class.getName();
    
    private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);
    
    /**** End Change : User story: US1062806 ****/
    
    /*** Start Change: User Story : US987948 ***/
    
    protected String popUpContent =  CVDDMConstant.EMPTY_STRING;
    
	public String getPopUpContent() {
		return popUpContent;
	}

	public void setPopUpContent(final String popUpContent) {
		this.popUpContent = popUpContent;
	}
	/*** End Change: User Story : US987948 ***/
	
	/*** Start Change: User Story : US890086 ***/
	
	protected String bannerContent =  CVDDMConstant.EMPTY_STRING;

	public String getBannerContent() {
		return bannerContent;
	}

	public void setBannerContent(final String bannerContent) {
		this.bannerContent = bannerContent;
	}
	/*** End Change: User Story : US890086 ***/
	
	
	/**** Start Change : User story: US1062806 ****/
	
	protected String loggedInUserCdsId;

	protected String loggedInUserName;
	
	protected String loggedInUserManagerId;
	
	/**
	 * @return the loggedInUserCdsId
	 */
	public String getLoggedInUserCdsId() {
		return loggedInUserCdsId;
	}

	/**
	 * @param loggedInUserCdsId the loggedInUserCdsId to set
	 */
	public void setLoggedInUserCdsId(final String loggedInUserCdsId) {
		this.loggedInUserCdsId = loggedInUserCdsId;
	}

	public String getLoggedInUserName() {
		return loggedInUserName;
	}

	public void setLoggedInUserName(final String loggedInUserName) {
		this.loggedInUserName = loggedInUserName;
	}

	public String getLoggedInUserManagerId() {
		return loggedInUserManagerId;
	}

	public void setLoggedInUserManagerId(final String loggedInUserManagerId) {
		this.loggedInUserManagerId = loggedInUserManagerId;
	}

	/****  End Change : User story: US1062806 ****/

	/**
     * Custom sorting for XMLGregorianCalendar used in Flight Type
     *
     * @param calendar1 first XMLGregorianCalendar to compare
     * @param calendar2 second XMLGregorianCalendar to compare
     *
     * @return comparison result
     */
    public int processCalendarSorting(final Object calendar1,
            final Object calendar2) {

        int result = 0;

        final XMLGregorianCalendar cal1 = (XMLGregorianCalendar)calendar1;
        final XMLGregorianCalendar cal2 = (XMLGregorianCalendar)calendar2;

        result = cal1.compare(cal2);

        return result;
    }

    @Inject
    @CVDDMAuthProvider
    /**
     * Injects AuthorizationProvider from the producer method
     */
    private AuthorizationProvider authorizationProvider;

    /**
     *
     * Returns the AuthorizationProvider
     *
     * @return AuthorizationProvider
     */

    public AuthorizationProvider getAuthorizationProvider() {
        return this.authorizationProvider;
    }

    /**
     * setAuthorizationProvider
     *
     * @param authorizationProvider
     */

    public void setAuthorizationProvider(final AuthorizationProvider authorizationProvider) {
        this.authorizationProvider = authorizationProvider;
    }
    
    /**** Start Change : User story: US1062806 ****/
    
    /**
	 * Method Name: getRequesterDetails
	 * 
	 * @Description:This method would set Requester Name, Cds Id and their Manager CDS Id.
	 * @param none
	 * @return void
	 */

	public void getRequesterDetails() {

		final String METHOD_NAME = "getRequesterDetails";

		log.entering(CLASS_NAME, METHOD_NAME);
		
		setLoggedInUserCdsId(CvddmUtil.getLoggedInUserCDSID());
		setLoggedInUserName(CvddmUtil.getUserAttributesValue(UserAttributes.FULL_NAME_PRINCIPAL_CLASS_NM));
		setLoggedInUserManagerId(CvddmUtil.getUserAttributesValue(CVDDMConstant.FORD_MANAGER_CDSID_PRINCIPAL_CLASS_NM));
		
		log.exiting(CLASS_NAME, METHOD_NAME);
		
	}
	
	/**** End Change : User story: US1062806 ****/

}
