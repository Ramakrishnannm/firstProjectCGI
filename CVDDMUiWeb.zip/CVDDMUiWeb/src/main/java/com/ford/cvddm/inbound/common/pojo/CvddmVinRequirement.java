/**
 * 
 */
package com.ford.cvddm.inbound.common.pojo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * This class would be used for Test Data Set up- US1064801
 * @author NGUPTA18
 *
 */
public class CvddmVinRequirement implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String vinNumber;
	
    private List<ModuleESNDetails> moduleESNDetailLst = new ArrayList<ModuleESNDetails>();

	public String getVinNumber() {
		return vinNumber;
	}

	public void setVinNumber(String vinNumber) {
		this.vinNumber = vinNumber;
	}

	public List<ModuleESNDetails> getModuleESNDetailLst() {
		return moduleESNDetailLst;
	}

	public void setModuleESNDetailLst(List<ModuleESNDetails> moduleESNDetailLst) {
		this.moduleESNDetailLst = moduleESNDetailLst;
	}

}
