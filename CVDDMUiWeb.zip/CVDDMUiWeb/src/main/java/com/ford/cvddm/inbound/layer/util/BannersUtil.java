/**
 * 
 */
package com.ford.cvddm.inbound.layer.util;

import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.domain.maintenance.de.CvddmMaintRcrdDE;
import com.ford.cvddm.maintenance.business.list.ListCvddmMaintenanceBF;
import com.ford.cvddm.sob.business.layer.CVDDMBusinessException;
import com.ford.it.exception.FordExceptionAttributes;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;
import com.ford.it.util.TextUtil;

/**
 * 
Class Name: BannersUtil
@Description: US890086 :This class contains Method related to 
              Banners Functionality of CVDDM Application.
@author NGUPTA18
 *
 */
public class BannersUtil {
	
	private static final String CLASS_NAME =
			BannersUtil.class.getName();
	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	protected static ListCvddmMaintenanceBF cvddmMaintenanceBF ;


	/**
	 * Private class constructor.
	 */

	private BannersUtil() {

		super();

	}
	
	/***  Start Change: User Story : US890086 ***/

	/**
	 * Method Name: getCommonMenuDts()
	 * @Description:This method retrieves Banners Description for CVDDM Common Menus (All Menus/All Sub Menus).
	 * @param None
	 * @return StringBuilder bannerContent
	 */

	public static StringBuilder getCommonMenuDts() {

		final String METHOD_NAME = "getCommonMenuDts";
		log.entering(CLASS_NAME, METHOD_NAME);

		CvddmMaintRcrdDE  cvddmRcrd = null;

		String cvddmScreenCd  = null;

		StringBuilder bannerContent = new StringBuilder();
		
		cvddmMaintenanceBF = new ListCvddmMaintenanceBF();

		try {
			/** First get check for All Menu Banner Rcrd ****/
			cvddmScreenCd = CvddmUtil.getPropertiesValue( 
					CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, CVDDMConstant.ALL_MENU_SCRN_CD);

		
			cvddmRcrd = cvddmMaintenanceBF.getBannerRecord(cvddmScreenCd);

			if(!CvddmUtil.isObjectEmpty(cvddmRcrd) 
					&& TextUtil.isNotBlankOrNull(cvddmRcrd.getCvdmMaintDesc())) {

				bannerContent.append(cvddmRcrd.getCvdmMaintDesc());
				bannerContent.append(CVDDMConstant.COMMA_SYMBOL);
			}

			/** Second  check for All Sub Menu Banner Rcrd ****/

			cvddmScreenCd = CvddmUtil.getPropertiesValue( 
					CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, CVDDMConstant.ALL_SUB_MENU_SCRN_CD);

			cvddmRcrd = cvddmMaintenanceBF.getBannerRecord(cvddmScreenCd);

			if(!CvddmUtil.isObjectEmpty(cvddmRcrd) 
					&& TextUtil.isNotBlankOrNull(cvddmRcrd.getCvdmMaintDesc())) {

				bannerContent.append(cvddmRcrd.getCvdmMaintDesc());
				bannerContent.append(CVDDMConstant.COMMA_SYMBOL);
			}
		}
		catch(Exception ex) {

			log.severe(CvddmUtil.getStackTraceContent(ex));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(
					CLASS_NAME, METHOD_NAME).build(), CvddmUtil.getStackTraceContent(ex), ex);
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
		return bannerContent;
	}

	/**
	 * Method Name: getParentandSubMenuDts()
	 * @Description:This method retrieves Banners Description for passed 
	 * Parent Menu Screen and its Child/ Sub Menu Screen.
	 * @param String parentScrnCd , String childScrnCd
	 * @return StringBuilder bannerContent
	 */

	public static StringBuilder getParentandSubMenuDts(String parentScrnCd , String childScrnCd) {

		final String METHOD_NAME = "getParentandSubMenuDts";
		log.entering(CLASS_NAME, METHOD_NAME);

		CvddmMaintRcrdDE  cvddmRcrd = null;

		String cvddmScreenCd  = null;

		StringBuilder bannerContent = new StringBuilder();
		
		cvddmMaintenanceBF = new ListCvddmMaintenanceBF();

		try {
			/*** Check for Parent Header Menu Banner Rcrd ****/

			cvddmScreenCd = CvddmUtil.getPropertiesValue( 
					CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, parentScrnCd);

			if(TextUtil.isNotBlankOrNull(cvddmScreenCd)) {

				cvddmRcrd = cvddmMaintenanceBF.getBannerRecord(cvddmScreenCd);

				if(!CvddmUtil.isObjectEmpty(cvddmRcrd) 
						&& TextUtil.isNotBlankOrNull(cvddmRcrd.getCvdmMaintDesc())) {

					bannerContent.append(cvddmRcrd.getCvdmMaintDesc());
					bannerContent.append(CVDDMConstant.COMMA_SYMBOL);
				}
			}
			
			/**   check for Child Menu Banner Rcrd ****/

			cvddmScreenCd = CvddmUtil.getPropertiesValue( 
					CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, childScrnCd);

			if(TextUtil.isNotBlankOrNull(cvddmScreenCd)) {

				cvddmRcrd = cvddmMaintenanceBF.getBannerRecord(cvddmScreenCd);

				if(!CvddmUtil.isObjectEmpty(cvddmRcrd) 
						&& TextUtil.isNotBlankOrNull(cvddmRcrd.getCvdmMaintDesc())) {

					bannerContent.append(cvddmRcrd.getCvdmMaintDesc());
					bannerContent.append(CVDDMConstant.COMMA_SYMBOL);
				}
			}
		}
		catch(Exception ex) {

			log.severe(CvddmUtil.getStackTraceContent(ex));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(
					CLASS_NAME, METHOD_NAME).build(), CvddmUtil.getStackTraceContent(ex), ex);
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
		return bannerContent;
	}
	
	/**
     * Method Name: prepareBannerMsgDesc()
     * @Description:This method would prepare Final Content for Banners.
     * @param String parentScrnCd , String childScrnCd
     * @return String
     */
	
	public static String prepareBannerMsgDesc(String parentScrnCd , String childScrnCd) {

		final String METHOD_NAME = "prepareBannerMsgDesc";
		log.entering(CLASS_NAME, METHOD_NAME);

		StringBuilder bannerContent = new StringBuilder();

		StringBuilder tempContent = null;

		String bannerMsg = null;

		try {

			tempContent = getCommonMenuDts();

			bannerContent.append(tempContent);

			tempContent = getParentandSubMenuDts(parentScrnCd ,childScrnCd);

			bannerContent.append(tempContent);

			if(TextUtil.isNotBlankOrNull(bannerContent.toString())) {

				bannerMsg = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY, CVDDMConstant.BANNER_MSG);

				bannerMsg = bannerMsg.replaceAll("CUSTOMBANNER", bannerContent.toString());
			}

			else {		
				bannerMsg = CVDDMConstant.EMPTY_STRING;
			}
		}
		catch(Exception ex) {
			log.severe(CvddmUtil.getStackTraceContent(ex));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(
					CLASS_NAME, METHOD_NAME).build(), CvddmUtil.getStackTraceContent(ex), ex);
		}
		
		return bannerMsg;
	}	

	/***  End Change: User Story : US890086 ***/

}
