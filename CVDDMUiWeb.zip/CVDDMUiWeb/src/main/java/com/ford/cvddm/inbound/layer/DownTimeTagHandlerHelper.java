package com.ford.cvddm.inbound.layer;

import java.text.SimpleDateFormat;
import java.util.Date;
import javax.faces.application.ConfigurableNavigationHandler;
import javax.faces.application.FacesMessage;
import javax.faces.application.ViewHandler;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.view.facelets.FaceletContext;
import javax.faces.view.facelets.FaceletException;
import javax.inject.Inject;
import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.domain.maintenance.de.CvddmMaintRcrdDE;
import com.ford.cvddm.maintenance.business.list.ListCvddmMaintenanceBF;
import com.ford.cvddm.sob.business.layer.CVDDMBusinessException;
import com.ford.it.exception.FordExceptionAttributes;
import com.ford.it.jsfcore.util.JcLoggingUtil;
import com.ford.it.logging.Level;
import com.ford.it.util.TextUtil;


/**
 * DownTimeTagHandlerHelper : This class contains method for CVDDMCore Tags
 * defined in cvddmcore.taglib.xml.
 * User Story :US890091
 * @author NGUPTA18
 *
 */
public class DownTimeTagHandlerHelper {


	private static final String CLASS_NAME =
			DownTimeTagHandlerHelper.class.getName();

	private static final com.ford.it.logging.ILogger log =
			com.ford.it.logging.LogFactory.getInstance().getLogger(CLASS_NAME);

	@Inject
	protected ListCvddmMaintenanceBF cvddmMaintenanceBF ;
	
	public ListCvddmMaintenanceBF getCvddmMaintenanceBF() {
		return cvddmMaintenanceBF = new ListCvddmMaintenanceBF(); 
	}




	public void setCvddmMaintenanceBF(ListCvddmMaintenanceBF cvddmMaintenanceBF) {
		this.cvddmMaintenanceBF = cvddmMaintenanceBF;
	}

	private static String DOWNTIME_PAGE = "downTimePage";

	/**
	 * @return Returns the facesContext.
	 */
	public FacesContext getFacesContext() {

		return FacesContext.getCurrentInstance();
	}
	
	


	/**
	 * @see javax.faces.view.facelets.ComponentHandler#onComponentCreated(javax.faces.view.facelets.FaceletContext,
	 *      javax.faces.component.UIComponent, javax.faces.component.UIComponent)
	 *
	 * @param faceletContext
	 * @param uiDowntime
	 * @param parent
	 */
	public void onComponentCreate(final FaceletContext faceletContext, final UIComponent uiDowntime,
			final UIComponent parent) {
		final String METHOD_NAME = "onComponentCreate";
		final String downPage = getCvddmDownPage(uiDowntime);

		try {
			final FacesContext facesContext = getFacesContext();

			CvddmMaintRcrdDE  cvddmRcrd = getCvddmMaintenanceBF().getDownTimeRecord();

			if(!CvddmUtil.isObjectEmpty(cvddmRcrd) 
					&& !CvddmUtil.isObjectEmpty(cvddmRcrd.getCvdmMaintToDt()) 
					&& !CvddmUtil.isObjectEmpty(cvddmRcrd.getCvdmMaintFromDt())) {

				String downMessage = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY, CVDDMConstant.DOWNTIME_PAGE_MSG);

				SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm a");

				Date fromDate = cvddmRcrd.getCvdmMaintFromDt();

				Date toDate = cvddmRcrd.getCvdmMaintToDt();

				String strFrmDate = sdf.format(fromDate);

				String strtoDate = sdf.format(toDate);

				downMessage = downMessage.replaceAll("FRMDATEHOLDER", strFrmDate);

				downMessage = downMessage.replaceAll("TODATEHOLDER", strtoDate);

				FacesMessage message = new FacesMessage(downMessage);

				message.setDetail(null);

				facesContext.addMessage(null, message);
				
				navigateToDownTimePage(downPage,facesContext);
			}

		}  catch (final Exception exception) {
			log.severe(CvddmUtil.getStackTraceContent(exception));
			throw new CVDDMBusinessException(
					new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(exception), exception);
		}
	}
	
	
	
	/**
	 * Method Name: getCvddmDownPage
	 * 
	 * @Description:This method would return DownTime Page  provided by the User
	 *  within cvddmcore:downTime Tags.
	 * @param final UIComponent uiDowntime
	 * @return String
	 */

	private String getCvddmDownPage(final UIComponent uiDowntime) {
		final String METHOD_NAME = "getCvddmDownPage";
		final String downPage =
				(String)uiDowntime.getAttributes().get(DOWNTIME_PAGE);
		if (TextUtil.isBlankOrNull(downPage)) {
			throw new CVDDMBusinessException(
					new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					"The downTimePage attribute is required in cvddmcore:downTime  tag.");
		}
		return downPage;
	}
	
	/**
	 * Method Name: navigateToDownTimePage
	 * 
	 * @Description: This method would redirect to downPage link provided in
	 *  by the User within cvddmcore:downTime Tags
	 * @param final UIComponent uiDowntime
	 * @return void
	 */
	
	private void navigateToDownTimePage(final String downPage, final FacesContext facesContext) {
        final String METHOD_NAME = "navigateToDownTimePage";

        final ConfigurableNavigationHandler navigationHandler =
                (ConfigurableNavigationHandler)facesContext.getApplication()
                        .getNavigationHandler();

        final Level level = JcLoggingUtil.getErrorPageDetailLoggingLevel();
        if (null != level) {
            log.logp(level, CLASS_NAME, METHOD_NAME,
                    "Return to downPage[" + downPage + "].");
        }

        final ViewHandler viewHandler = facesContext.getApplication().getViewHandler();
        final String errorPageViewId = viewHandler.deriveViewId(facesContext, downPage);
        if (null == errorPageViewId) {
            throw new FaceletException("No downPage page ["
                                       + downPage + "] found.");
        }
        navigationHandler.performNavigation(downPage);
    }

}