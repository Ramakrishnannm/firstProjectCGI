/**
 * 
 */
package com.ford.cvddm.inbound.testdatasetup.ui.bean;

import java.io.ByteArrayInputStream;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;
import java.util.TimeZone;
import java.util.TreeSet;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.deltaspike.core.api.scope.GroupedConversationScoped;
import org.primefaces.context.RequestContext;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXParseException;

import com.ford.cvddm.app.business.list.CvddmCsvFileUploadBF;
import com.ford.cvddm.common.ldap.LdapUserTO;
import com.ford.cvddm.common.user.UserTO;
import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.common.util.ValidationUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.domain.application.de.CvddmESNCSVUploadDE;
import com.ford.cvddm.domain.application.de.CvddmVinRepoCSVUploadDE;
import com.ford.cvddm.domain.env.de.CvddmEnvironmentDE;
import com.ford.cvddm.domain.master.de.CvddmProductGroupDE;
import com.ford.cvddm.domain.master.de.CvddmProductLineDE;
import com.ford.cvddm.domain.master.de.CvddmProductTeamDE;
import com.ford.cvddm.domain.master.de.CvddmRegionDE;
import com.ford.cvddm.domain.master.de.CvddmTestingTypeDE;
import com.ford.cvddm.domain.module.de.CvddmModuleDE;
import com.ford.cvddm.domain.testdatasetup.de.CvddmConfigDidSelectionDE;
import com.ford.cvddm.domain.testdatasetup.de.CvddmTdsReqModDE;
import com.ford.cvddm.domain.testdatasetup.de.CvddmTdsReqPartDE;
import com.ford.cvddm.domain.testdatasetup.de.CvddmTestDataReqDE;
import com.ford.cvddm.env.business.list.ListCvddmEnvironmentBF;
import com.ford.cvddm.gvms.aws.EnumertedParameter;
import com.ford.cvddm.gvms.aws.PartIISpecFeatures;
import com.ford.cvddm.gvms.aws.PartIISpecFromAWS;
import com.ford.cvddm.gvms.aws.SubFieldListFeatures;
import com.ford.cvddm.inbound.common.pojo.ConfigDidFeatureSelection;
import com.ford.cvddm.inbound.common.pojo.CvddmVinRequirement;
import com.ford.cvddm.inbound.common.pojo.ModuleESNDetails;
import com.ford.cvddm.inbound.common.pojo.PartNumbersSelection;
import com.ford.cvddm.inbound.layer.base.CVDDMBaseBean;
import com.ford.cvddm.inbound.layer.util.BannersUtil;
import com.ford.cvddm.inbound.layer.util.CommonUtil;
import com.ford.cvddm.inbound.layer.util.PopupAlertUtil;
import com.ford.cvddm.ldap.business.LdapBF;
import com.ford.cvddm.module.business.list.ListCvddmModuleBF;
import com.ford.cvddm.outbound.givis.rest.GIVISRestClients;
import com.ford.cvddm.outbound.givis.rest.ProgramCodeTO;
import com.ford.cvddm.outbound.ivsu.rest.IVSURestClients;
import com.ford.cvddm.outbound.ivsu.rest.ValidateIVSFeed;
import com.ford.cvddm.outbound.ivsu.rest.ValidateIVSFeedRequest;
import com.ford.cvddm.outbound.ivsu.rest.ValidateIVSFeedResponse;
import com.ford.cvddm.region.business.list.ListCvddmRegionBF;
import com.ford.cvddm.sob.business.layer.CVDDMBusinessException;
import com.ford.cvddm.testdatasetup.business.list.ListCvddmTestDataSetUpBF;
import com.ford.it.exception.FordExceptionAttributes;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;
import com.ford.it.util.TextUtil;

/**
 * @since US1061675
 * @author NGUPTA18 This is the Parent Bean for CVDDM Test Data Set Up
 *         Functionality. All Child Beans if applicable should have references
 *         over here.
 *
 */
@Named
@GroupedConversationScoped
public class CreateTestDataSetUpBean extends CVDDMBaseBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final String CLASS_NAME = CreateTestDataSetUpBean.class.getName();

	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	@Inject
	protected LdapBF ldapBFObj;

	@Inject
	protected ListCvddmTestDataSetUpBF testDataSetUpBF;

	private String selectedProductGroup;

	private String selectedProductLine;

	private String selectedProductTeam;

	private String selectedTestingType;

	private String testingSubject;

	private Timestamp codeDropDate;

	private Timestamp testingStartDate;

	private Timestamp testingEndDate;

	private Timestamp testDataReqOnDate;

	private List<CvddmProductLineDE> productLineList;

	private List<CvddmProductTeamDE> productTeamList;

	private List<CvddmTestingTypeDE> testingTypeList;

	private boolean disableAddButton;

	String nodeTypeCodes = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
			CVDDMConstant.NODES_WHICH_NEED_VIRTUAL_DEVICE_QUESTION);

	String[] nodeTypeCdArry = nodeTypeCodes.split(",");

	/*** Start Change :User Story: US1064801 **/

	@Inject
	protected ListCvddmRegionBF listCvddmRegionBF;

	@Inject
	protected CvddmCsvFileUploadBF cvddmVINRepoBF;

	private String vinsRequired;

	private String selectProdVehicleDtl;

	private String selectedPriority;

	private String selectedMockUpVin;

	private List<CvddmVinRequirement> userProvidedVinDetails = new ArrayList<CvddmVinRequirement>();

	private List<CvddmVinRepoCSVUploadDE> mockupVinDetails = new ArrayList<CvddmVinRepoCSVUploadDE>();

	private List<CvddmESNCSVUploadDE> esncsvUploadDEs = new ArrayList<CvddmESNCSVUploadDE>();

	private List<ModuleESNDetails> modulelistForMockupVin = new ArrayList<ModuleESNDetails>();

	private List<CvddmVinRepoCSVUploadDE> vinRepoCSVUploadDEs = new ArrayList<CvddmVinRepoCSVUploadDE>();

	private List<String> prodVehicleDts = new ArrayList<String>();

	private String selectedRegionType;

	private String uniqueReservereId;

	private List<CvddmRegionDE> cvddmRegionsList;

	private boolean displayMockUpPanel;

	public boolean isDisplayMockUpPanel() {
		return displayMockUpPanel;
	}

	public void setDisplayMockUpPanel(boolean displayMockUpPanel) {
		this.displayMockUpPanel = displayMockUpPanel;
	}

	public boolean isDisplayUserEnterPanel() {
		return displayUserEnterPanel;
	}

	public void setDisplayUserEnterPanel(boolean displayUserEnterPanel) {
		this.displayUserEnterPanel = displayUserEnterPanel;
	}

	private boolean displayUserEnterPanel;

	/**
	 * @return the cvddmRegionsList
	 */
	public List<CvddmRegionDE> getCvddmRegionsList() {
		return cvddmRegionsList;
	}

	/**
	 * @param cvddmRegionsList
	 *            the cvddmRegionsList to set
	 */
	public void setCvddmRegionsList(List<CvddmRegionDE> cvddmRegionsList) {
		this.cvddmRegionsList = cvddmRegionsList;
	}

	/**
	 * @return the selectedRegionType
	 */
	public String getSelectedRegionType() {
		return selectedRegionType;
	}

	/**
	 * @param selectedRegionType
	 *            the selectedRegionType to set
	 */
	public void setSelectedRegionType(String selectedRegionType) {
		this.selectedRegionType = selectedRegionType;
	}

	public String getVinsRequired() {
		return vinsRequired;
	}

	public void setVinsRequired(String vinsRequired) {
		this.vinsRequired = vinsRequired;
	}

	public String getSelectProdVehicleDtl() {
		return selectProdVehicleDtl;
	}

	public void setSelectProdVehicleDtl(String selectProdVehicleDtl) {
		this.selectProdVehicleDtl = selectProdVehicleDtl;
	}

	public String getSelectedPriority() {
		return selectedPriority;
	}

	public void setSelectedPriority(String selectedPriority) {
		this.selectedPriority = selectedPriority;
	}

	public List<CvddmVinRepoCSVUploadDE> getVinRepoCSVUploadDEs() {
		return vinRepoCSVUploadDEs;
	}

	public void setVinRepoCSVUploadDEs(List<CvddmVinRepoCSVUploadDE> vinRepoCSVUploadDEs) {
		this.vinRepoCSVUploadDEs = vinRepoCSVUploadDEs;
	}

	public List<String> getProdVehicleDts() {
		return prodVehicleDts;
	}

	public void setProdVehicleDts(List<String> prodVehicleDts) {
		this.prodVehicleDts = prodVehicleDts;
	}

	private boolean disableAddVinButton;

	public boolean isDisableAddVinButton() {
		return disableAddVinButton;
	}

	public void setDisableAddVinButton(boolean disableAddVinButton) {
		this.disableAddVinButton = disableAddVinButton;
	}

	/*** End Change :User Story: US1064801 **/

	/*** Start Change :User Story: US1063866 -- PartNumbers Selection Screen **/

	private List<String> vehiclesList; // Hold Values for "Vehicles" Drop Down.

	private List<String> envList; // Hold Values for "Environment" Drop Down.

	private SortedSet<String> nodeList; // Hold Values for "Modules" Drop Down.

	private SortedSet<String> selectedNodeList; // Hold Values for selected Nodes/Modules.

	private SortedSet<String> nodeListOthers; // Hold Values for "Modules" Drop Down.

	private SortedSet<String> selectedNodeListOthers; // Hold Values for Selected Nodes/Modules.

	private String disPnbrRespAvl = CVDDMConstant.STRING_N;

	private String disVehiclesDropdown = CVDDMConstant.STRING_N;

	private String disEnvsDropdown = CVDDMConstant.STRING_Y;

	private String disModulesSelection = CVDDMConstant.STRING_N;

	public String getDisVehiclesDropdown() {
		return disVehiclesDropdown;
	}

	public void setDisVehiclesDropdown(String disVehiclesDropdown) {
		this.disVehiclesDropdown = disVehiclesDropdown;
	}

	public String getDisEnvsDropdown() {
		return disEnvsDropdown;
	}

	public void setDisEnvsDropdown(String disEnvsDropdown) {
		this.disEnvsDropdown = disEnvsDropdown;
	}

	public String getDisModulesSelection() {
		return disModulesSelection;
	}

	public void setDisModulesSelection(String disModulesSelection) {
		this.disModulesSelection = disModulesSelection;
	}

	public String getDisPnbrRespAvl() {
		return disPnbrRespAvl;
	}

	public void setDisPnbrRespAvl(String disPnbrRespAvl) {
		this.disPnbrRespAvl = disPnbrRespAvl;
	}

	// Output of "AddPartnumbers" screen
	private transient List<PartNumbersSelection> partNumbersSelectionList;
	private String selectedEnv;
	private String selectedVehicle;
	private CvddmEnvironmentDE selectedCvddmEnvironmentDE;

	public CvddmEnvironmentDE getSelectedCvddmEnvironmentDE() {
		return selectedCvddmEnvironmentDE;
	}

	public void setSelectedCvddmEnvironmentDE(CvddmEnvironmentDE selectedCvddmEnvironmentDE) {
		this.selectedCvddmEnvironmentDE = selectedCvddmEnvironmentDE;
	}

	private transient List<ConfigDidFeatureSelection> configDidFeatureSelectionList;

	public List<ConfigDidFeatureSelection> getConfigDidFeatureSelectionList() {
		return configDidFeatureSelectionList;
	}

	public void setConfigDidFeatureSelectionList(List<ConfigDidFeatureSelection> configDidFeatureSelectionList) {
		this.configDidFeatureSelectionList = configDidFeatureSelectionList;
	}

	public List<PartNumbersSelection> getPartNumbersSelectionList() {
		return partNumbersSelectionList;
	}

	public void setPartNumbersSelectionList(List<PartNumbersSelection> partNumbersSelectionList) {
		this.partNumbersSelectionList = partNumbersSelectionList;
	}

	public SortedSet<String> getNodeListOthers() {
		return nodeListOthers;
	}

	public void setNodeListOthers(SortedSet<String> nodeListOthers) {
		this.nodeListOthers = nodeListOthers;
	}

	public SortedSet<String> getSelectedNodeListOthers() {
		return selectedNodeListOthers;
	}

	public void setSelectedNodeListOthers(SortedSet<String> selectedNodeListOthers) {
		this.selectedNodeListOthers = selectedNodeListOthers;
	}

	public SortedSet<String> getSelectedNodeList() {
		return selectedNodeList;
	}

	public void setSelectedNodeList(SortedSet<String> selectedNodeList) {
		this.selectedNodeList = selectedNodeList;
	}

	public List<String> getVehiclesList() {
		return vehiclesList;
	}

	public void setVehiclesList(List<String> vehiclesList) {
		this.vehiclesList = vehiclesList;
	}

	public String getSelectedVehicle() {
		return selectedVehicle;
	}

	public void setSelectedVehicle(String selectedVehicle) {
		this.selectedVehicle = selectedVehicle;
	}

	public List<String> getEnvList() {
		return envList;
	}

	public void setEnvList(List<String> envList) {
		this.envList = envList;
	}

	public String getSelectedEnv() {
		return selectedEnv;
	}

	public void setSelectedEnv(String selectedEnv) {
		this.selectedEnv = selectedEnv;
	}

	public SortedSet<String> getNodeList() {
		return nodeList;
	}

	public void setNodeList(SortedSet<String> nodeList) {
		this.nodeList = nodeList;
	}

	@Inject
	private ListCvddmEnvironmentBF listCvddmEnvironmentBF;

	@Inject
	private ListCvddmModuleBF listCvddmModuleBF;

	private transient List<ProgramCodeTO> programCodes;

	public List<ProgramCodeTO> getProgramCodes() {
		return programCodes;
	}

	public void setProgramCodes(List<ProgramCodeTO> programCodes) {
		this.programCodes = programCodes;
	}

	/*** End Change :User Story: US1063866 -- Partnumbers Selection Screen **/

	/*** Start Change :User Story: US1064102 -- Configdid selection screen **/

	private transient List<PartIISpecFeatures> partIISpecFeatures;
	private String partIISpecRespAval = CVDDMConstant.STRING_N;

	public String getPartIISpecRespAval() {
		return partIISpecRespAval;
	}

	public void setPartIISpecRespAval(String partIISpecRespAval) {
		this.partIISpecRespAval = partIISpecRespAval;
	}

	public List<PartIISpecFeatures> getPartIISpecFeatures() {
		return partIISpecFeatures;
	}

	public void setPartIISpecFeatures(List<PartIISpecFeatures> partIISpecFeatures) {
		this.partIISpecFeatures = partIISpecFeatures;
	}

	/*** End Change :User Story: US1064102 -- Configdid selection screen **/

	private transient List<UserTO> emailNotificationLst = new ArrayList<UserTO>();

	private List<CvddmProductGroupDE> productGroupList;

	public List<CvddmProductGroupDE> getProductGroupList() {
		return productGroupList;
	}

	public void setProductGroupList(List<CvddmProductGroupDE> productGroupList) {
		this.productGroupList = productGroupList;
	}

	public List<CvddmProductLineDE> getProductLineList() {
		return productLineList;
	}

	public void setProductLineList(List<CvddmProductLineDE> productLineList) {
		this.productLineList = productLineList;
	}

	public List<CvddmProductTeamDE> getProductTeamList() {
		return productTeamList;
	}

	public void setProductTeamList(List<CvddmProductTeamDE> productTeamList) {
		this.productTeamList = productTeamList;
	}

	public List<CvddmTestingTypeDE> getTestingTypeList() {
		return testingTypeList;
	}

	public void setTestingTypeList(List<CvddmTestingTypeDE> testingTypeList) {
		this.testingTypeList = testingTypeList;
	}

	/**
	 * @return the disableAddButton
	 */
	public boolean isDisableAddButton() {
		return disableAddButton;
	}

	/**
	 * @param disableAddButton
	 *            the disableAddButton to set
	 */
	public void setDisableAddButton(boolean disableAddButton) {
		this.disableAddButton = disableAddButton;
	}

	public String getSelectedProductGroup() {
		return selectedProductGroup;
	}

	public void setSelectedProductGroup(String selectedProductGroup) {
		this.selectedProductGroup = selectedProductGroup;
	}

	public String getSelectedProductLine() {
		return selectedProductLine;
	}

	public void setSelectedProductLine(String selectedProductLine) {
		this.selectedProductLine = selectedProductLine;
	}

	public String getSelectedProductTeam() {
		return selectedProductTeam;
	}

	public void setSelectedProductTeam(String selectedProductTeam) {
		this.selectedProductTeam = selectedProductTeam;
	}

	public String getSelectedTestingType() {
		return selectedTestingType;
	}

	public void setSelectedTestingType(String selectedTestingType) {
		this.selectedTestingType = selectedTestingType;
	}

	public String getTestingSubject() {
		return testingSubject;
	}

	public void setTestingSubject(String testingSubject) {
		this.testingSubject = testingSubject;
	}

	public Timestamp getCodeDropDate() {
		return codeDropDate;
	}

	public void setCodeDropDate(Timestamp codeDropDate) {
		this.codeDropDate = codeDropDate;
	}

	public Timestamp getTestingStartDate() {
		return testingStartDate;
	}

	public void setTestingStartDate(Timestamp testingStartDate) {
		this.testingStartDate = testingStartDate;
	}

	public Timestamp getTestingEndDate() {
		return testingEndDate;
	}

	public void setTestingEndDate(Timestamp testingEndDate) {
		this.testingEndDate = testingEndDate;
	}

	public Timestamp getTestDataReqOnDate() {
		return testDataReqOnDate;
	}

	public void setTestDataReqOnDate(Timestamp testDataReqOnDate) {
		this.testDataReqOnDate = testDataReqOnDate;
	}

	/**
	 * @return the emailNotificationLst
	 */
	public List<UserTO> getEmailNotificationLst() {
		return emailNotificationLst;
	}

	/**
	 * @param emailNotificationLst
	 *            the emailNotificationLst to set
	 */
	public void setEmailNotificationLst(List<UserTO> emailNotificationLst) {
		this.emailNotificationLst = emailNotificationLst;
	}

	/*** Start Change :User Story: US1064801 **/
	public List<CvddmVinRequirement> getUserProvidedVinDetails() {
		return userProvidedVinDetails;
	}

	public void setUserProvidedVinDetails(List<CvddmVinRequirement> userProvidedVinDetails) {
		this.userProvidedVinDetails = userProvidedVinDetails;
	}

	/**
	 * @return the uniqueReservereId
	 */
	public String getUniqueReservereId() {
		return uniqueReservereId;
	}

	/**
	 * @param uniqueReservereId
	 *            the uniqueReservereId to set
	 */
	public void setUniqueReservereId(String uniqueReservereId) {
		this.uniqueReservereId = uniqueReservereId;
	}

	/**
	 * @return the modulelistForMockupVin
	 */
	public List<ModuleESNDetails> getModulelistForMockupVin() {
		return modulelistForMockupVin;
	}

	/**
	 * @param modulelistForMockupVin
	 *            the modulelistForMockupVin to set
	 */
	public void setModulelistForMockupVin(List<ModuleESNDetails> modulelistForMockupVin) {
		this.modulelistForMockupVin = modulelistForMockupVin;
	}

	/**
	 * @return the selectedMockUpVin
	 */
	public String getSelectedMockUpVin() {
		return selectedMockUpVin;
	}

	/**
	 * @param selectedMockUpVin
	 *            the selectedMockUpVin to set
	 */
	public void setSelectedMockUpVin(String selectedMockUpVin) {
		this.selectedMockUpVin = selectedMockUpVin;
	}

	public List<CvddmVinRepoCSVUploadDE> getMockupVinDetails() {
		return mockupVinDetails;
	}

	public void setMockupVinDetails(List<CvddmVinRepoCSVUploadDE> mockupVinDetails) {
		this.mockupVinDetails = mockupVinDetails;
	}

	/**
	 * @return the esncsvUploadDEs
	 */
	public List<CvddmESNCSVUploadDE> getEsncsvUploadDEs() {
		return esncsvUploadDEs;
	}

	/**
	 * @param esncsvUploadDEs
	 *            the esncsvUploadDEs to set
	 */
	public void setEsncsvUploadDEs(List<CvddmESNCSVUploadDE> esncsvUploadDEs) {
		this.esncsvUploadDEs = esncsvUploadDEs;
	}

	/*** End Change :User Story: US1064801 **/

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ford.it.jsfcore.bean.JcBaseBean#preRenderViewStartWorkflowTM()
	 */
	@Override
	protected void preRenderViewStartWorkflowTM() {

		log.exiting(CLASS_NAME, "preRenderViewStartWorkflowTM");

	}

	@Override
	protected void preRenderViewTM() {

		if (isNotPostBack()) {
			String popUpContent = PopupAlertUtil.prepareAlertsMsgDesc(CVDDMConstant.TEST_DATA_SET_UP_SCRN_CD,
					CVDDMConstant.DATA_SET_UP_SCRN_CD);
			this.setPopUpContent(popUpContent);
			this.popUpContent = popUpContent;

			String bannerContent = BannersUtil.prepareBannerMsgDesc(CVDDMConstant.TEST_DATA_SET_UP_SCRN_CD,
					CVDDMConstant.DATA_SET_UP_SCRN_CD);
			this.setBannerContent(bannerContent);
			this.bannerContent = bannerContent;

			getActiveProductGroups();
			getRequesterDetails();
			getActiveTestingType();
			/*** Start Change :User Story: US1064801 **/
			getActiveRegions();
			/*** End Change :User Story: US1064801 **/

			/*** Start Change :User Story: US1063866 **/
			setEnvList(CommonUtil.retrieveEnvironments(listCvddmEnvironmentBF));

			TreeSet<String> nodeTreeSetFromDB = generateValuesForModulesDropdown();

			TreeSet<String> nodeTreeSet = new TreeSet<>();
			nodeTreeSet.add(CVDDMConstant.FREQUENTLY_SELECTED_MODULE_TCU);
			nodeTreeSet.add(CVDDMConstant.FREQUENTLY_SELECTED_MODULE_SYNC);
			nodeTreeSet.add(CVDDMConstant.FREQUENTLY_SELECTED_MODULE_BLEM);
			nodeTreeSet.add(CVDDMConstant.FREQUENTLY_SELECTED_MODULE_ECG);
			setNodeList(nodeTreeSet);

			TreeSet<String> nodeTreeSetOthers = new TreeSet<>();
			nodeTreeSetOthers.addAll(nodeTreeSetFromDB);
			nodeTreeSetOthers.removeAll(nodeTreeSet);
			setNodeListOthers(nodeTreeSetOthers);

			if (this.disEnvsDropdown.equalsIgnoreCase(CVDDMConstant.STRING_N)) {
				disableEditingInputs();
			}

			/*** End Change :User Story: US1063866 **/
		}
	}

	/**
	 * Method Name: getActiveProductGroups
	 * 
	 * @Description:This method would fetch all Active Product Groups from
	 *                   PCVDM10_PRDCT_GRP database table.
	 * @param none
	 * @return void
	 */

	public void getActiveProductGroups() {

		final String METHOD_NAME = "getActiveProductGroups";

		log.entering(CLASS_NAME, METHOD_NAME);

		setProductGroupList(testDataSetUpBF.getActiveProductGroups());

		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * Method Name: getActiveTestingType
	 * 
	 * @Description:This method would fetch all Active Testing Type from
	 *                   PCVDM13_TEST_TYPE database table.
	 * @param none
	 * @return void
	 */

	public void getActiveTestingType() {

		final String METHOD_NAME = "getActiveTestingType";

		log.entering(CLASS_NAME, METHOD_NAME);

		setTestingTypeList(testDataSetUpBF.getActiveTestingTypes());

		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/*** Start Change :User Story: US1064801 **/

	/**
	 * Method Name: getActiveRegions
	 * 
	 * @Description:This method would fetch all Active Regions from PCVDM17_REGION
	 *                   database table.
	 * @param none
	 * @return List<CvddmRegionDE>
	 */

	public void getActiveRegions() {

		final String METHOD_NAME = "getActiveRegions";

		log.entering(CLASS_NAME, METHOD_NAME);

		setCvddmRegionsList(listCvddmRegionBF.getActiveRegions());

		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * Method Name: getActiveProductGroups
	 * 
	 * @Description:This method would fetch all Active Product Groups from
	 *                   PCVDM10_PRDCT_GRP database table.
	 * @param none
	 * @return void
	 */

	/*** End Change :User Story: US1064801 **/

	/**
	 * @return Returns the today.
	 */
	public Date getToday() {
		return new Date();
	}

	/**
	 * @ Test data required on (Date Picker should be greater than Today's Date)
	 * 
	 */
	public Date getDefaultTestReqOnDate() {

		final String METHOD_NAME = "getDefaultTestReqOnDate";

		Date defaultTestReqOn = new Date();
		try {

			Calendar cal = Calendar.getInstance();
			cal.setTime(CvddmUtil.getTimeZoneCurrentDate(CVDDMConstant.TIMEZONE_UTC));
			cal.setTimeZone(TimeZone.getTimeZone(CVDDMConstant.TIMEZONE_UTC));
			cal.add(Calendar.DAY_OF_MONTH, 1);
			defaultTestReqOn = cal.getTime();
		} catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}
		return defaultTestReqOn;
	}

	/**
	 * Method Name: continueToPartNumbers
	 * 
	 * @Description: This method would process Product Details and navigate to Part
	 *               Numbers Page.
	 * @return String
	 **/
	public String continueToPartNumbers() {

		final String METHOD_NAME = "continueToPartNumbers";

		log.entering(CLASS_NAME, METHOD_NAME);

		String navigation = CVDDMConstant.EMPTY_STRING;
		boolean isSuccess = true;

		try {

			log.info("Inside continueToPartNumbers");

			if (!isValidProductList()) {

				isSuccess = false;
			}

			if (!isValidTestingDates()) {

				isSuccess = false;
			}
			if (!isValidTestingTypeSubject()) {

				isSuccess = false;
			}
			if (!isValidEmailAddress()) {

				isSuccess = false;
			}
			if (isSuccess) {

				navigation = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
						CVDDMConstant.PART_NUMBER_PAGE_PATH);
			} else {

				navigation = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
						CVDDMConstant.PRODUCT_TEAM_PAGE_PATH);
			}
		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

		return navigation;

	}

	/**
	 * Method Name: navigateToHomePage()
	 * 
	 * @Description: This method would navigate User to CVDDM Home Page.
	 * @return String
	 **/
	public String navigateToHomePage() {

		final String METHOD_NAME = "navigateToHomePage";

		log.entering(CLASS_NAME, METHOD_NAME);

		String navigation = CVDDMConstant.EMPTY_STRING;

		try {

			log.info("Inside navigateToHomePage");

			navigation = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
					CVDDMConstant.HOME_PAGE_PATH);
		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

		return navigation;
	}

	/**
	 * Method Name: processProductLineDropDown
	 * 
	 * @Description: This method would populate Product Lines Dropdown
	 * @return void
	 **/
	public void processProductLineDropDown() {

		final String METHOD_NAME = "processProductLineDropDown";

		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			if (!CvddmUtil.isObjectEmpty(productLineList) && !productLineList.isEmpty()) {

				productLineList.clear();
			}

			if (!CvddmUtil.isObjectEmpty(productTeamList) && !productTeamList.isEmpty()) {

				productTeamList.clear();
			}

			if (TextUtil.isNotBlankOrNull(selectedProductGroup)
					&& !CVDDMConstant.STRING_ZERO.equalsIgnoreCase(selectedProductGroup)) {

				productLineList = testDataSetUpBF.getActiveProductLines(selectedProductGroup);

				if (!CvddmUtil.isObjectEmpty(productLineList) && !productLineList.isEmpty()) {

					setProductLineList(testDataSetUpBF.getActiveProductLines(selectedProductGroup));
				} else {

					FacesContext.getCurrentInstance().addMessage(CVDDMConstant.JSF_ID_TEST_PRD_LINE,
							new FacesMessage(FacesMessage.SEVERITY_ERROR, null, getLocalizedStringFromBundle(
									CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY, CVDDMConstant.PRODUCT_LINE_NOT_AVAIL)));
				}

			}

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		} finally {
			selectedProductLine = CVDDMConstant.STRING_ZERO;
			selectedProductTeam = CVDDMConstant.STRING_ZERO;
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

	}

	/**
	 * Method Name: processProductTeamDropDown
	 * 
	 * @Description: This method would populate Product Team Dropdown
	 * @return void
	 **/
	public void processProductTeamDropDown() {

		final String METHOD_NAME = "processProductTeamDropDown";

		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			log.info("Inside processProductTeamDropDown");

			if (!CvddmUtil.isObjectEmpty(productTeamList) && !productTeamList.isEmpty()) {

				productTeamList.clear();
			}

			if (TextUtil.isNotBlankOrNull(selectedProductLine)
					&& !CVDDMConstant.STRING_ZERO.equalsIgnoreCase(selectedProductLine)) {

				productTeamList = testDataSetUpBF.getActiveProductTeams(selectedProductLine);

				if (!CvddmUtil.isObjectEmpty(productTeamList) && !productTeamList.isEmpty()) {

					setProductTeamList(testDataSetUpBF.getActiveProductTeams(selectedProductLine));
				} else {
					FacesContext.getCurrentInstance().addMessage(CVDDMConstant.JSF_ID_TEST_PRD_TEAM,
							new FacesMessage(FacesMessage.SEVERITY_ERROR, null, getLocalizedStringFromBundle(
									CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY, CVDDMConstant.PRODUCT_TEAM_NOT_AVAIL)));
				}

			}
		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		} finally {
			selectedProductTeam = CVDDMConstant.STRING_ZERO;
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

	}

	/**
	 * Method Name: removeEmailIds
	 * 
	 * @Description: This method would Delete Email Id's.
	 * @param :None
	 * @return void
	 **/

	public void removeEmailIds(UserTO userTO) {

		final String METHOD_NAME = "removeEmailIds";

		log.entering(CLASS_NAME, METHOD_NAME);

		emailNotificationLst.remove(userTO);

		Integer maxEmailIdAllowed = Integer.valueOf(CvddmUtil.getPropertiesValue(
				CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, CVDDMConstant.NO_OF_ADDN_EMAIL_ALLOWED));

		if (!CvddmUtil.isObjectEmpty(emailNotificationLst) && emailNotificationLst.size() < maxEmailIdAllowed) {

			setDisableAddButton(false);
		}

		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * Method Name: addEmailIds
	 * 
	 * @Description: This method would Add Email Id's.
	 * @param :None
	 * @return void
	 **/

	public void addEmailIds() {

		final String METHOD_NAME = "addEmailIds";

		log.entering(CLASS_NAME, METHOD_NAME);

		Integer maxEmailIdAllowed = Integer.valueOf(CvddmUtil.getPropertiesValue(
				CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, CVDDMConstant.NO_OF_ADDN_EMAIL_ALLOWED));

		if (!CvddmUtil.isObjectEmpty(emailNotificationLst) && emailNotificationLst.size() < maxEmailIdAllowed) {

			emailNotificationLst.add(new UserTO());
		} else {
			setDisableAddButton(true);
			addLocalizedErrorMessageToComponent(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
					CVDDMConstant.NO_OF_EMAIL_ALLOWED_MSG, CVDDMConstant.EMAIL_PANEL, maxEmailIdAllowed.toString());
		}

		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * Method Name: isValidProductList
	 * 
	 * @Description: This method would validate User provide Product drop downs
	 * @param :None
	 * @return boolean isValidInput
	 **/

	public boolean isValidProductList() {

		final String METHOD_NAME = "isValidProductList";

		log.entering(CLASS_NAME, METHOD_NAME);

		boolean isValidInput = true;

		if (CVDDMConstant.STRING_ZERO.equals(this.selectedProductGroup)) {

			isValidInput = false;

			FacesContext.getCurrentInstance().addMessage(CVDDMConstant.JSF_ID_TEST_PRD_GRP,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, null,
							getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_APPLICATION_RESOURCE_KEY,
									CVDDMConstant.LABEL_PRD_GRP) + " "
									+ getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
											CVDDMConstant.REQUIRED_MSG)));

		}
		if (CVDDMConstant.STRING_ZERO.equals(this.selectedProductLine)) {

			isValidInput = false;

			FacesContext.getCurrentInstance().addMessage(CVDDMConstant.JSF_ID_TEST_PRD_LINE,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, null,
							getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_APPLICATION_RESOURCE_KEY,
									CVDDMConstant.LABEL_PRD_LINE) + " "
									+ getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
											CVDDMConstant.REQUIRED_MSG)));

		}
		if (CVDDMConstant.STRING_ZERO.equals(this.selectedProductTeam)) {

			isValidInput = false;

			FacesContext.getCurrentInstance().addMessage(CVDDMConstant.JSF_ID_TEST_PRD_TEAM,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, null,
							getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_APPLICATION_RESOURCE_KEY,
									CVDDMConstant.LABEL_PRD_TEAM) + " "
									+ getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
											CVDDMConstant.REQUIRED_MSG)));
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

		return isValidInput;
	}

	/**
	 * Method Name: isValidEmailAddress
	 * 
	 * @Description: This method would validate User provided Email Id's
	 * @param :None
	 * @return boolean isValidInput
	 **/

	public boolean isValidEmailAddress() {

		final String METHOD_NAME = "isValidEmailAddress";

		log.entering(CLASS_NAME, METHOD_NAME);

		StringBuilder stringBuilder = new StringBuilder();

		boolean isValidInput = true;

		Iterator<UserTO> listItr = emailNotificationLst.listIterator();

		while (listItr.hasNext()) {

			UserTO userTO = listItr.next();

			if (TextUtil.isBlankOrNull(userTO.getMail())) {

				isValidInput = false;

				stringBuilder.append(CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
						CVDDMConstant.EMAIL_ID_NOT_AVAIL));
				stringBuilder.append(CVDDMConstant.BREAK_HTML);

				break;

			}

		}

		if (isValidInput) {

			Set<String> setToReturn = CvddmUtil.findDuplicateEmailIds(emailNotificationLst);

			if (!setToReturn.isEmpty()) {

				String emailDupMsg;

				Iterator<String> setIterator = setToReturn.iterator();

				while (setIterator.hasNext()) {

					String emailId = setIterator.next();

					if (!TextUtil.isBlankOrNull(emailId)) {

						isValidInput = false;

						emailDupMsg = CVDDMConstant.STRING_EMAIL_ID + " " + emailId + " "
								+ CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
										CVDDMConstant.DUPLICATE_EMAIL_ID);

						stringBuilder.append(emailDupMsg);
						stringBuilder.append(CVDDMConstant.BREAK_HTML);
					}
				}
			}
		}

		if (isValidInput) {

			Iterator<UserTO> listItrs = emailNotificationLst.listIterator();

			while (listItrs.hasNext()) {

				UserTO userTO = listItrs.next();

				String emailMsg;

				if (TextUtil.isNotBlankOrNull(userTO.getMail())) {

					LdapUserTO ldapUserTO = ldapBFObj.getLdapUserUsingEmailId(userTO.getMail().trim());

					if (CvddmUtil.isObjectEmpty(ldapUserTO)) {

						emailMsg = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
								CVDDMConstant.INVALID_EMAIL_MESSAGE);
						emailMsg = emailMsg.replace(CVDDMConstant.EMAIL_PLACEHOLDER, userTO.getMail());

						stringBuilder.append(emailMsg);
						stringBuilder.append(CVDDMConstant.BREAK_HTML);
					}
				}
			}
		}
		if (TextUtil.isNotBlankOrNull(stringBuilder.toString())) {

			isValidInput = false;

			addLocalizedErrorMessageToComponent(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
					CVDDMConstant.PLACEHOLDER_EMAIL_MSG, CVDDMConstant.EMAIL_PANEL, stringBuilder.toString());
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
		return isValidInput;
	}

	/**
	 * Method Name: isValidTestingDates
	 * 
	 * @Description: This method would validate User provided Testing Dates
	 * @param :None
	 * @return boolean isValidInput
	 **/

	public boolean isValidTestingDates() {

		final String METHOD_NAME = "isValidTestingDates";

		log.entering(CLASS_NAME, METHOD_NAME);

		boolean isValidInput = true;

		if (CvddmUtil.isObjectEmpty(this.testingStartDate)) {

			isValidInput = false;
			FacesContext.getCurrentInstance().addMessage(CVDDMConstant.JSF_ID_TEST_START_DATE,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, null,
							getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_APPLICATION_RESOURCE_KEY,
									CVDDMConstant.LABEL_TEST_START_DATE) + " "
									+ getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
											CVDDMConstant.REQUIRED_MSG)));

		}
		if (CvddmUtil.isObjectEmpty(this.testingEndDate)) {

			isValidInput = false;

			FacesContext.getCurrentInstance().addMessage(CVDDMConstant.JSF_ID_TEST_END_DATE,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, null,
							getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_APPLICATION_RESOURCE_KEY,
									CVDDMConstant.LABEL_TEST_END_DATE) + " "
									+ getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
											CVDDMConstant.REQUIRED_MSG)));
		}

		if (CvddmUtil.isObjectEmpty(this.testDataReqOnDate)) {

			isValidInput = false;
			FacesContext.getCurrentInstance().addMessage(CVDDMConstant.JSF_ID_TEST_REQ_DATE,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, null,
							getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_APPLICATION_RESOURCE_KEY,
									CVDDMConstant.LABEL_TEST_REQ_DATE) + " "
									+ getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
											CVDDMConstant.REQUIRED_MSG)));
		}

		if (!CvddmUtil.isObjectEmpty(this.testingEndDate)
				&& !ValidationUtil.isDateGreaterthanCurrentDate(this.testingEndDate)) {

			isValidInput = false;
			FacesContext.getCurrentInstance().addMessage(CVDDMConstant.JSF_ID_TEST_END_DATE,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, null,
							getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_APPLICATION_RESOURCE_KEY,
									CVDDMConstant.LABEL_TEST_END_DATE) + " "
									+ getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
											CVDDMConstant.DATE_NOT_PAST_MSG)));
		}

		if (!CvddmUtil.isObjectEmpty(this.testDataReqOnDate)
				&& !ValidationUtil.isDateGreaterthanCurrentDate(this.testDataReqOnDate)) {

			isValidInput = false;
			FacesContext.getCurrentInstance().addMessage(CVDDMConstant.JSF_ID_TEST_REQ_DATE,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, null,
							getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_APPLICATION_RESOURCE_KEY,
									CVDDMConstant.LABEL_TEST_REQ_DATE) + " "
									+ getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
											CVDDMConstant.DATE_NOT_PAST_MSG)));
		}

		if (!CvddmUtil.isObjectEmpty(this.testingStartDate) && !CvddmUtil.isObjectEmpty(this.testingEndDate)
				&& this.testingEndDate.before(this.testingStartDate)) {

			isValidInput = false;
			FacesContext.getCurrentInstance().addMessage(CVDDMConstant.JSF_ID_TEST_END_DATE,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, null,
							getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_APPLICATION_RESOURCE_KEY,
									CVDDMConstant.LABEL_TEST_END_DATE)
							+ " "
							+ getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
									CVDDMConstant.DATE_GREATER_THAN_MSG)
							+ " " + getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_APPLICATION_RESOURCE_KEY,
									CVDDMConstant.LABEL_TEST_START_DATE)));
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

		return isValidInput;
	}

	/**
	 * Method Name: isValidTestingTypeSubject
	 * 
	 * @Description: This method would validate User provided Testing Type and
	 *               Subject
	 * @param :None
	 * @return boolean isValidInput
	 **/

	public boolean isValidTestingTypeSubject() {

		final String METHOD_NAME = "isValidTestingTypeSubject";

		log.entering(CLASS_NAME, METHOD_NAME);

		boolean isValidInput = true;

		if (TextUtil.isBlankOrNull(this.selectedTestingType)) {

			isValidInput = false;
			FacesContext.getCurrentInstance().addMessage(CVDDMConstant.JSF_ID_TEST_TYPES,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, null,
							getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_APPLICATION_RESOURCE_KEY,
									CVDDMConstant.LABEL_TEST_TEST_TYPE) + " "
									+ getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
											CVDDMConstant.REQUIRED_MSG)));

		}

		if (TextUtil.isBlankOrNull(this.testingSubject)) {

			isValidInput = false;
			FacesContext.getCurrentInstance().addMessage(CVDDMConstant.JSF_ID_TEST_SUBJECT,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, null,
							getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_APPLICATION_RESOURCE_KEY,
									CVDDMConstant.LABEL_TEST_SUBJECT) + " "
									+ getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
											CVDDMConstant.REQUIRED_MSG)));
		}
		return isValidInput;

	}

	/*** Start Change :User Story: US1064801 **/
	/**
	 * Method Name: continueToVinReqPage
	 * 
	 * @Description: This method would run Validations on Feature Did Page and
	 *               navigate to Vin Requirement Page.
	 * @return String
	 **/
	public String continueToVinReqPage() {

		final String METHOD_NAME = "continueToVinReqPage";

		log.entering(CLASS_NAME, METHOD_NAME);

		String navigation = CVDDMConstant.EMPTY_STRING;
		boolean isSuccess = validateRespOfConfigDidFeatureScreen();

		try {

			log.info("Inside continueToVinReqPage");

			if (isSuccess) {

				navigation = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
						CVDDMConstant.VIN_REQ_PAGE_PATH);
			} else {

				navigation = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
						CVDDMConstant.FEATURE_DID_PAGE_PATH);
			}
		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

		return navigation;
	}

	/**
	 * Method Name: continueToFeatureDidPage
	 * 
	 * @Description: This method would run validations for Part Number Page and
	 *               navigate to Feature DID page
	 * @return String
	 **/
	public String continueToFeatureDidPage() {

		final String METHOD_NAME = "continueToFeatureDidPage";

		log.entering(CLASS_NAME, METHOD_NAME);

		String navigation = CVDDMConstant.EMPTY_STRING;
		boolean isSuccess = validateRespOfAPNScreen();

		try {

			log.info("Inside continueToFeatureDidPage");

			if (isSuccess) {
				selectedPartIISpecData();

				navigation = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
						CVDDMConstant.FEATURE_DID_PAGE_PATH);
			} else {

				navigation = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
						CVDDMConstant.PART_NUMBER_PAGE_PATH);
			}
		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

		return navigation;
	}

	/**
	 * Method Name: continueToReviewPage
	 * 
	 * @Description: This method would run validations for Vin Requirement Page and
	 *               navigate to Review and Submit page
	 * @return String
	 **/
	public String continueToReviewPage() {

		final String METHOD_NAME = "continueToReviewPage";

		log.entering(CLASS_NAME, METHOD_NAME);

		String navigation = CVDDMConstant.EMPTY_STRING;
		boolean isSuccess = true;

		try {

			log.info("Inside continueToReviewPage");

			if (!isValidPriority()) {

				isSuccess = false;
			}

			if (!isValidRegion()) {

				isSuccess = false;
			}

			if (!isValidMockVinOption()) {

				isSuccess = false;
			}
			if (TextUtil.isNotBlankOrNull(selectedMockUpVin)
					&& CVDDMConstant.STRING_Y.equalsIgnoreCase(selectedMockUpVin.trim())) {

				isSuccess = validateMockVinDetails(CVDDMConstant.SUBMIT_ACTION);
			}

			if (TextUtil.isNotBlankOrNull(selectedMockUpVin)
					&& CVDDMConstant.STRING_N.equalsIgnoreCase(selectedMockUpVin.trim())) {

				isSuccess = validateUserProvidedVinDetails(CVDDMConstant.SUBMIT_ACTION);
			}

			if (isSuccess) {

				navigation = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
						CVDDMConstant.REVIEW_PAGE_PATH);
			} else {

				navigation = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
						CVDDMConstant.VIN_REQ_PAGE_PATH);
			}
		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

		return navigation;
	}

	/**
	 * Method Name: isValidPriority
	 * 
	 * @Description: This method would validate User provide Priority Type
	 * @param :None
	 * @return boolean isValidInput
	 **/

	public boolean isValidPriority() {

		final String METHOD_NAME = "isValidPriority";

		log.entering(CLASS_NAME, METHOD_NAME);

		boolean isValidInput = true;

		if (TextUtil.isBlankOrNull(selectedPriority)) {

			isValidInput = false;

			FacesContext.getCurrentInstance().addMessage(CVDDMConstant.JSF_ID_VIN_REQ_PRIORITY,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, null,
							getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_APPLICATION_RESOURCE_KEY,
									CVDDMConstant.LABEL_VIN_REQ_PRIORITY) + " "
									+ getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
											CVDDMConstant.REQUIRED_MSG)));
		}
		return isValidInput;
	}

	/**
	 * Method Name: isValidRegion
	 * 
	 * @Description: This method would validate User provide Region
	 * @param :None
	 * @return boolean isValidInput
	 **/

	public boolean isValidRegion() {

		final String METHOD_NAME = "isValidRegion";

		log.entering(CLASS_NAME, METHOD_NAME);

		boolean isValidInput = true;

		if (TextUtil.isBlankOrNull(selectedRegionType)) {

			isValidInput = false;

			FacesContext.getCurrentInstance().addMessage(CVDDMConstant.JSF_ID_VIN_REQ_REGION,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, null,
							getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_APPLICATION_RESOURCE_KEY,
									CVDDMConstant.LABEL_VIN_REQ_REGION) + " "
									+ getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
											CVDDMConstant.REQUIRED_MSG)));
		}
		return isValidInput;
	}

	/**
	 * Method Name: isValidMockVinOption
	 * 
	 * @Description: This method would validate User provided Mock up VIN option
	 * @param :None
	 * @return boolean isValidInput
	 **/

	public boolean isValidMockVinOption() {

		final String METHOD_NAME = "isValidMockVinOption";

		log.entering(CLASS_NAME, METHOD_NAME);

		boolean isValidInput = true;

		if (TextUtil.isBlankOrNull(selectedMockUpVin)) {

			isValidInput = false;

			FacesContext.getCurrentInstance().addMessage(CVDDMConstant.JSF_ID_VIN_REQ_MOCKUPVIN,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, null,
							getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_APPLICATION_RESOURCE_KEY,
									CVDDMConstant.LABEL_VIN_REQ_MOCKUPVIN) + " "
									+ getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
											CVDDMConstant.REQUIRED_MSG)));
		}
		return isValidInput;
	}

	/**
	 * Method Name: hideDisplayVinPanels
	 * 
	 * @Description: This method would Hide/Display Mock up VIN or User provided VIN
	 *               Section depending on IsMockVINRequired Drop down. It would also
	 *               clear both MockupVIN List and User Provided List when User
	 *               toggles IsMockVINRequired Drop down
	 * @param :None
	 * @return void
	 **/

	public void hideDisplayVinPanels() {

		final String METHOD_NAME = "hideDisplayVinPanels";

		try {

			log.entering(CLASS_NAME, METHOD_NAME);

			if (!CvddmUtil.isObjectEmpty(userProvidedVinDetails) && !userProvidedVinDetails.isEmpty()) {

				userProvidedVinDetails.clear();
			}
			if (!CvddmUtil.isObjectEmpty(mockupVinDetails) && !mockupVinDetails.isEmpty()) {

				mockupVinDetails.clear();
			}

			if (!CvddmUtil.isObjectEmpty(vinRepoCSVUploadDEs) && !vinRepoCSVUploadDEs.isEmpty()) {

				vinRepoCSVUploadDEs.clear();
			}

			if (TextUtil.isNotBlankOrNull(selectedMockUpVin)
					&& CVDDMConstant.STRING_Y.equalsIgnoreCase(selectedMockUpVin.trim())) {

				displayMockUpPanel = true;
				displayUserEnterPanel = false;

				vinRepoCSVUploadDEs = cvddmVINRepoBF.getProdVehicleDetails();

				prepareProdVehicleDetailsDrpDown(vinRepoCSVUploadDEs);

				modulelistForMockupVin = prepareModuleESNsforVins(partNumbersSelectionList);

			} else if (TextUtil.isNotBlankOrNull(selectedMockUpVin)
					&& CVDDMConstant.STRING_N.equalsIgnoreCase(selectedMockUpVin.trim())) {

				displayMockUpPanel = false;
				displayUserEnterPanel = true;
				this.vinsRequired = null;
				this.selectProdVehicleDtl = null;
			} else {

				displayMockUpPanel = false;
				displayUserEnterPanel = false;
				this.vinsRequired = null;
				this.selectProdVehicleDtl = null;
			}
		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * Method Name: prepareProdVehicleDetailsDrpDown
	 * 
	 * @Description: This method would Prepare ProdVehicleDetailsDrpDown
	 * @param :List<CvddmVinRepoCSVUploadDE>
	 *            vinRepoCSVUploadDEs
	 * @return void
	 **/

	public void prepareProdVehicleDetailsDrpDown(List<CvddmVinRepoCSVUploadDE> vinRepoCSVUploadDEs) {

		final String METHOD_NAME = "prepareProdVehicleDetailsDrpDown";
		log.entering(CLASS_NAME, METHOD_NAME);

		Iterator<CvddmVinRepoCSVUploadDE> vinRepoItr = vinRepoCSVUploadDEs.listIterator();

		List<String> tempStringList = new ArrayList<>();

		while (vinRepoItr.hasNext()) {

			CvddmVinRepoCSVUploadDE vinRepoDE = vinRepoItr.next();

			tempStringList.add(
					vinRepoDE.getProgramCode().trim() + CVDDMConstant.HYPHEN_SYMBOL + vinRepoDE.getModelYear().trim()
					+ CVDDMConstant.HYPHEN_SYMBOL + vinRepoDE.getVehicleName().trim());

		}

		this.setProdVehicleDts(tempStringList.stream().distinct().collect(Collectors.toList()));

		log.exiting(CLASS_NAME, METHOD_NAME);

	}

	/**
	 * Method Name: clearMockVinDtls
	 * 
	 * @Description: This method would Clear MockVin Section Details.
	 * @param :None
	 * @return void
	 **/

	public void clearMockVinDtls() {

		final String METHOD_NAME = "clearMockVinDtls";
		log.entering(CLASS_NAME, METHOD_NAME);

		this.selectProdVehicleDtl = null;
		this.vinsRequired = null;

		if (!CvddmUtil.isObjectEmpty(modulelistForMockupVin) && !modulelistForMockupVin.isEmpty()) {

			modulelistForMockupVin.clear();

			modulelistForMockupVin = prepareModuleESNsforVins(partNumbersSelectionList);
		}
		if (TextUtil.isNotBlankOrNull(selectedMockUpVin)
				&& CVDDMConstant.STRING_Y.equalsIgnoreCase(selectedMockUpVin.trim())) {

			displayMockUpPanel = true;
			displayUserEnterPanel = false;

			vinRepoCSVUploadDEs = cvddmVINRepoBF.getProdVehicleDetails();

			prepareProdVehicleDetailsDrpDown(vinRepoCSVUploadDEs);

			modulelistForMockupVin = prepareModuleESNsforVins(partNumbersSelectionList);

		}

		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * Method Name: validateMockVinDetails
	 * 
	 * @Description: This method would validate Mock Vin Details
	 * @param String
	 *            actionType
	 * @return boolean
	 */

	public boolean validateMockVinDetails(String actionType) {

		final String METHOD_NAME = "validateMockVinDetails";
		log.entering(CLASS_NAME, METHOD_NAME);

		boolean isSuccess = true;

		StringBuilder stringBuilder = new StringBuilder();

		try {

			if (!isValidNoofVins()) {

				isSuccess = false;
			}

			if (!isValidProdVehicleDtls()) {

				isSuccess = false;
			}
			stringBuilder = isValidVirtualSelected(modulelistForMockupVin, CVDDMConstant.EMPTY_STRING);

			if (!TextUtil.isBlankOrNull(stringBuilder.toString())) {

				isSuccess = false;

				addLocalizedValidationFailureMessageToComponent(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
						CVDDMConstant.ECU_REQUIRED_MSG, CVDDMConstant.JSF_ID_VIN_REQ_ECUMODULE_TYPE2,
						stringBuilder.toString());
			}

			if (isSuccess && !updateVINRepoTable(CVDDMConstant.EMPTY_STRING)) {

				isSuccess = false;

				addLocalizedValidationFailureMessageToComponent(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
						CVDDMConstant.NOT_ENOUGH_VINS_MSG, CVDDMConstant.MOCKUP_VIN_PANEL_ID,
						getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_APPLICATION_RESOURCE_KEY,
								CVDDMConstant.LABEL_VIN_REQ_NOOFVINS),
						getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_APPLICATION_RESOURCE_KEY,
								CVDDMConstant.LABEL_VIN_REQ_PRDVEHICLE));
			}
			/*** Start Change :User Story: US1147659 **/
			if (isSuccess && !updateESNRepoTable(CVDDMConstant.EMPTY_STRING)) {

				isSuccess = false;
				addLocalizedValidationFailureMessageToComponent(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
						CVDDMConstant.NOT_ENOUGH_ESNS_MSG, CVDDMConstant.MOCKUP_VIN_PANEL_ID);
			}
			if (isSuccess && CVDDMConstant.OK_ACTION.equalsIgnoreCase(actionType)) {

				addLocalizedSuccessMessageToComponent(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
						CVDDMConstant.VIN_REQ_OK_MSG, CVDDMConstant.MOCKUP_VIN_PANEL_ID);
			}
			/*** End Change :User Story: US1147659 **/

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

		return isSuccess;

	}

	/**
	 * Method Name: isValidNoofVins
	 * 
	 * @Description: This method would validate User provided No of Vin option is
	 *               valid or not
	 * @param :None
	 * @return boolean isValidInput
	 **/

	public boolean isValidNoofVins() {

		final String METHOD_NAME = "isValidNoofVins";

		log.entering(CLASS_NAME, METHOD_NAME);

		boolean isValidInput = true;

		Integer maxVinAllowed = Integer.valueOf(CvddmUtil.getPropertiesValue(
				CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, CVDDMConstant.NO_OF_MOCK_VINS_ALLOWED));

		if (TextUtil.isBlankOrNull(vinsRequired)) {

			isValidInput = false;

			FacesContext.getCurrentInstance().addMessage(CVDDMConstant.JSF_ID_VIN_REQ_NOOFVINS,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, null,
							getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_APPLICATION_RESOURCE_KEY,
									CVDDMConstant.LABEL_VIN_REQ_NOOFVINS) + " "
									+ getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
											CVDDMConstant.REQUIRED_MSG)));
		}
		if (isValidInput && (CVDDMConstant.SINGLE_ZERO.equalsIgnoreCase(vinsRequired.trim())
				|| CVDDMConstant.DOUBLE_ZERO.equalsIgnoreCase(vinsRequired.trim()))) {

			isValidInput = false;

			FacesContext.getCurrentInstance().addMessage(CVDDMConstant.JSF_ID_VIN_REQ_NOOFVINS,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, null,
							getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_APPLICATION_RESOURCE_KEY,
									CVDDMConstant.LABEL_VIN_REQ_NOOFVINS) + " " + CVDDMConstant.NOT_VALID));
		}
		if (isValidInput && !vinsRequired.matches(getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
				CVDDMConstant.NO_OF_VIN_FORMAT))) {

			isValidInput = false;

			FacesContext.getCurrentInstance().addMessage(CVDDMConstant.JSF_ID_VIN_REQ_NOOFVINS,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, null,
							getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_APPLICATION_RESOURCE_KEY,
									CVDDMConstant.LABEL_VIN_REQ_NOOFVINS) + " "
									+ getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
											CVDDMConstant.NO_OF_VIN_FORMAT_MSG)));
		}
		if (isValidInput && !TextUtil.isBlankOrNull(vinsRequired)) {

			String tempVinsRequired = CvddmUtil.removeZero(vinsRequired);

			if (TextUtil.isNotBlankOrNull(tempVinsRequired) && Integer.valueOf(tempVinsRequired) > maxVinAllowed) {

				isValidInput = false;

				addLocalizedValidationFailureMessageToComponent(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
						CVDDMConstant.NO_OF_MOCK_VINS_ALLOWED_MSG, CVDDMConstant.JSF_ID_VIN_REQ_NOOFVINS_TYPE2,
						maxVinAllowed.toString());
			}

		}
		return isValidInput;
	}

	/**
	 * Method Name: isValidProdVehicleDtls
	 * 
	 * @Description: This method would validate User provided Prod Vehicle Detail
	 * @param :None
	 * @return boolean isValidInput
	 **/

	public boolean isValidProdVehicleDtls() {

		final String METHOD_NAME = "isValidProdVehicleDtls";

		log.entering(CLASS_NAME, METHOD_NAME);

		boolean isValidInput = true;

		if (TextUtil.isBlankOrNull(selectProdVehicleDtl)) {

			isValidInput = false;

			FacesContext.getCurrentInstance().addMessage(CVDDMConstant.JSF_ID_VIN_REQ_PRDVEHICLE,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, null,
							getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_APPLICATION_RESOURCE_KEY,
									CVDDMConstant.LABEL_VIN_REQ_PRDVEHICLE) + " "
									+ getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
											CVDDMConstant.REQUIRED_MSG)));
		}

		return isValidInput;
	}

	/**
	 * Method Name: isValidVirtualSelected
	 * 
	 * @Description: This method would validate User selected Is Virtual Device
	 *               Question or not.
	 * @param :List<ModuleESNDetails>
	 *            modulelist,String vinNumber
	 * @return StringBuilder
	 **/

	public StringBuilder isValidVirtualSelected(List<ModuleESNDetails> modulelist, String vinNumber) {

		final String METHOD_NAME = "isValidVirtualSelected";

		log.entering(CLASS_NAME, METHOD_NAME);

		StringBuilder stringBuilder = new StringBuilder();

		if (!CvddmUtil.isObjectEmpty(modulelist) && !modulelist.isEmpty()) {

			Iterator<ModuleESNDetails> moduleESNLst = modulelist.iterator();

			while (moduleESNLst.hasNext()) {

				ModuleESNDetails tempEsnObj = moduleESNLst.next();

				if (Arrays.asList(nodeTypeCdArry).contains(tempEsnObj.getModuleCode())
						&& TextUtil.isBlankOrNull(tempEsnObj.getVirtualReq())) {

					if (TextUtil.isNotBlankOrNull(vinNumber)) {
						stringBuilder.append(CVDDMConstant.VIN_NAME);
						stringBuilder.append(vinNumber);
						stringBuilder.append(CVDDMConstant.COLON_SYMBOL);
					}
					stringBuilder.append(tempEsnObj.getModuleCode());
					stringBuilder.append(CVDDMConstant.HYPHEN_SYMBOL);
					stringBuilder.append(tempEsnObj.getModuleAcronym());
					stringBuilder.append(CVDDMConstant.COLON_SYMBOL);
					stringBuilder.append(getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_APPLICATION_RESOURCE_KEY,
							CVDDMConstant.LABEL_VIRTUAL_DEVICE_REQ));
					stringBuilder.append(CVDDMConstant.EMPTY_STRING);
					stringBuilder.append(CVDDMConstant.NOT_SELECTED);

					if (moduleESNLst.hasNext()) {

						stringBuilder.append(CVDDMConstant.BREAK_HTML);
					}
				}
			}
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

		return stringBuilder;
	}

	/**
	 * Method Name: isValidVirtualESN
	 * 
	 * @Description: This method would validate User provide ESN value or not for Is
	 *               Virtual Device Question as No
	 * @param :List<ModuleESNDetails>modulelist,String
	 *            vinNumber
	 * @return StringBuilder
	 **/

	public StringBuilder isValidVirtualESN(List<ModuleESNDetails> modulelist, String vinNumber) {

		final String METHOD_NAME = "isValidVirtualESN";

		log.entering(CLASS_NAME, METHOD_NAME);

		StringBuilder stringBuilder = new StringBuilder();

		if (!CvddmUtil.isObjectEmpty(modulelist) && !modulelist.isEmpty()) {

			Iterator<ModuleESNDetails> moduleESNLst = modulelist.iterator();

			while (moduleESNLst.hasNext()) {

				ModuleESNDetails tempEsnObj = moduleESNLst.next();

				if (!TextUtil.isNotBlankOrNull(tempEsnObj.getVirtualReq())
						&& CVDDMConstant.STRING_N.equalsIgnoreCase(tempEsnObj.getVirtualReq())
						&& TextUtil.isBlankOrNull(tempEsnObj.getModuleESNValue())) {

					if (TextUtil.isNotBlankOrNull(vinNumber)) {
						stringBuilder.append(CVDDMConstant.VIN_NAME);
						stringBuilder.append(vinNumber);
						stringBuilder.append(CVDDMConstant.COLON_SYMBOL);
					}
					stringBuilder.append(tempEsnObj.getModuleCode());
					stringBuilder.append(CVDDMConstant.COLON_SYMBOL);
					stringBuilder.append(tempEsnObj.getModuleDesc());
					stringBuilder.append(CVDDMConstant.COLON_SYMBOL);
					stringBuilder.append(getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_APPLICATION_RESOURCE_KEY,
							CVDDMConstant.LABEL_ESN));
					stringBuilder.append(CVDDMConstant.EMPTY_STRING);
					stringBuilder.append(getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
							CVDDMConstant.REQUIRED_MSG));
					if (moduleESNLst.hasNext()) {

						stringBuilder.append(CVDDMConstant.BREAK_HTML);
					}
				}
			}
		}
		log.exiting(CLASS_NAME, METHOD_NAME);

		return stringBuilder;
	}

	/**
	 * Method Name: validateUserProvidedVinDetails
	 * 
	 * @Description: This method would validate User provided VIN Details
	 * @param :String
	 *            actionType
	 * @return boolean
	 * 
	 **/

	public boolean validateUserProvidedVinDetails(String actionType) {

		final String METHOD_NAME = "validateUserProvidedVinDetails";

		log.entering(CLASS_NAME, METHOD_NAME);

		boolean isValidInput = true;

		if (!CvddmUtil.isObjectEmpty(userProvidedVinDetails) && userProvidedVinDetails.isEmpty()) {

			isValidInput = false;
			addLocalizedValidationFailureMessageToComponent(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
					CVDDMConstant.ATLEAST_ONE_VIN_FOR_DATA_SET_UP, CVDDMConstant.JSF_ID_VIN_REQ_VINPANEL_TYPE2);
		}

		if (!validateUserVINNumbers()) {

			isValidInput = false;
		}
		if (isValidInput && !validateUserESNSelected()) {

			isValidInput = false;
		}
		if (isValidInput && !validateDuplicateUserESN()) {

			isValidInput = false;
		}
		if (isValidInput && !updateESNRepoTable(CVDDMConstant.EMPTY_STRING)) {

			isValidInput = false;
			addLocalizedValidationFailureMessageToComponent(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
					CVDDMConstant.NOT_ENOUGH_ESNS_MSG, CVDDMConstant.JSF_ID_VIN_REQ_VINPANEL_TYPE2);
		}

		if (isValidInput && CVDDMConstant.OK_ACTION.equalsIgnoreCase(actionType)) {

			addLocalizedSuccessMessageToComponent(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY, CVDDMConstant.VIN_REQ_OK_MSG,
					CVDDMConstant.JSF_ID_VIN_REQ_VINPANEL_TYPE2);
		}
		/*** End Change :User Story: US1147659 **/

		log.exiting(CLASS_NAME, METHOD_NAME);

		return isValidInput;
	}

	/**
	 * Method Name: validateUserESNValue
	 * 
	 * @Description: This method would validate User provided ESN Value
	 * @param :none
	 * @return boolean
	 * 
	 **/

	public boolean validateUserESNValue() {

		final String METHOD_NAME = "validateUserESNValue";

		StringBuilder stringBuilder = new StringBuilder();

		boolean isValidInput = true;

		Iterator<CvddmVinRequirement> tempVinReqItr = userProvidedVinDetails.iterator();

		while (tempVinReqItr.hasNext()) {

			CvddmVinRequirement vinRequirement = tempVinReqItr.next();

			StringBuilder tempBuilder = isValidVirtualSelected(vinRequirement.getModuleESNDetailLst(),
					vinRequirement.getVinNumber());

			if (!TextUtil.isBlankOrNull(tempBuilder.toString())) {

				stringBuilder.append(CVDDMConstant.BREAK_HTML);
				stringBuilder.append(tempBuilder.toString());
			}
		}

		if (!TextUtil.isBlankOrNull(stringBuilder.toString())) {

			isValidInput = false;

			addLocalizedValidationFailureMessageToComponent(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
					CVDDMConstant.ECU_REQUIRED_MSG, CVDDMConstant.JSF_ID_VIN_REQ_USER_VINS_DT,
					stringBuilder.toString());
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

		return isValidInput;
	}

	/**
	 * Method Name: validateUserESNSelected
	 * 
	 * @Description: This method would validate User provided ESN Dropdown
	 * @param :none
	 * @return boolean
	 * 
	 **/

	public boolean validateUserESNSelected() {

		final String METHOD_NAME = "validateUserESNSelected";

		log.entering(CLASS_NAME, METHOD_NAME);

		boolean isValidInput = true;

		StringBuilder stringBuilder = new StringBuilder();

		Iterator<CvddmVinRequirement> tempVinReqItr = userProvidedVinDetails.iterator();

		while (tempVinReqItr.hasNext()) {

			CvddmVinRequirement vinRequirement = tempVinReqItr.next();

			StringBuilder tempBuilder = isValidVirtualSelected(vinRequirement.getModuleESNDetailLst(),
					vinRequirement.getVinNumber());

			if (!TextUtil.isBlankOrNull(tempBuilder.toString())) {

				stringBuilder.append(CVDDMConstant.BREAK_HTML);
				stringBuilder.append(tempBuilder.toString());
			}
		}

		if (!TextUtil.isBlankOrNull(stringBuilder.toString())) {

			isValidInput = false;

			addLocalizedValidationFailureMessageToComponent(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
					CVDDMConstant.ECU_REQUIRED_MSG, CVDDMConstant.JSF_ID_VIN_REQ_USER_VINS_DT,
					stringBuilder.toString());
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

		return isValidInput;
	}

	/**
	 * Method Name: validateDuplicateUserESN
	 * 
	 * @Description: This method would validate User provided Duplicate ESN Numbers
	 * @param :none
	 * @return boolean
	 * 
	 **/

	public boolean validateDuplicateUserESN() {

		final String METHOD_NAME = "validateDuplicateUserESN";

		log.entering(CLASS_NAME, METHOD_NAME);

		boolean isValidInput = true;

		StringBuilder vinErrorMsg = new StringBuilder();

		Set<String> setToReturn = findDuplicatesESNs(this.userProvidedVinDetails);

		if (!setToReturn.isEmpty()) {

			String vinValidMsgs;

			Iterator<String> setIterator = setToReturn.iterator();

			while (setIterator.hasNext()) {

				String tempESN = setIterator.next();
				if (!TextUtil.isBlankOrNull(tempESN)) {
					vinValidMsgs = CVDDMConstant.ESN_NAME + tempESN + " " + CvddmUtil
							.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY, CVDDMConstant.DUPLICATE_ESN);

					vinErrorMsg.append(vinValidMsgs);
					vinErrorMsg.append(CVDDMConstant.BREAK_HTML);
				}
			}
		}

		if (!TextUtil.isBlankOrNull(vinErrorMsg.toString())) {

			isValidInput = false;
			addLocalizedValidationFailureMessageToComponent(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
					CVDDMConstant.USER_VIN_VALID_MSG, CVDDMConstant.JSF_ID_VIN_REQ_USER_VINS_DT,
					vinErrorMsg.toString());
		}

		return isValidInput;
	}

	/**
	 * Method Name: validateUserVINNumbers
	 * 
	 * @Description: This method would validate User provided VIN Numbers
	 * @param :void
	 * @return boolean
	 * 
	 **/

	public boolean validateUserVINNumbers() {

		final String METHOD_NAME = "validateUserVINNumbers";

		log.entering(CLASS_NAME, METHOD_NAME);

		boolean isValidInput = true;

		StringBuilder vinErrorMsg = new StringBuilder();

		Iterator<CvddmVinRequirement> tempVinReqItr = userProvidedVinDetails.iterator();

		String vinValidMsg;

		while (tempVinReqItr.hasNext()) {

			CvddmVinRequirement vinRequirement = tempVinReqItr.next();

			if (TextUtil.isBlankOrNull(vinRequirement.getVinNumber())) {

				vinErrorMsg.append(CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
						CVDDMConstant.VIN_VALUE_NOT_AVAIL));
				vinErrorMsg.append(CVDDMConstant.BREAK_HTML);

				break;

			} else if (TextUtil.isNotBlankOrNull(vinRequirement.getVinNumber()) && (vinRequirement.getVinNumber()
					.length() != Integer.valueOf(CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
							CVDDMConstant.VALID_VIN_LENGTH))
					|| !vinRequirement.getVinNumber().matches(CvddmUtil.getPropertiesValue(
							CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY, CVDDMConstant.VALID_VIN_FORMAT)))) {

				vinValidMsg = CVDDMConstant.VIN_NAME + vinRequirement.getVinNumber() + " " + CvddmUtil
						.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY, CVDDMConstant.MULTIVIN_VALID_MSG);

				vinErrorMsg.append(vinValidMsg);
				vinErrorMsg.append(CVDDMConstant.BREAK_HTML);
			}
		}

		Set<String> setToReturn = findDuplicatesVINS(userProvidedVinDetails);

		if (!setToReturn.isEmpty()) {

			String vinValidMsgs;

			Iterator<String> setIterator = setToReturn.iterator();

			while (setIterator.hasNext()) {

				String tempVin = setIterator.next();
				if (!TextUtil.isBlankOrNull(tempVin)) {
					vinValidMsgs = CVDDMConstant.VIN_NAME + tempVin + " " + CvddmUtil
							.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY, CVDDMConstant.DUPLICATE_VIN);

					vinErrorMsg.append(vinValidMsgs);
					vinErrorMsg.append(CVDDMConstant.BREAK_HTML);
				}
			}
		}

		if (!TextUtil.isBlankOrNull(vinErrorMsg.toString())) {

			isValidInput = false;
			addLocalizedValidationFailureMessageToComponent(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
					CVDDMConstant.USER_VIN_VALID_MSG, CVDDMConstant.JSF_ID_VIN_REQ_USER_VINS_DT,
					vinErrorMsg.toString());
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

		return isValidInput;

	}

	/**
	 * Method Name: clearUserVinDtls
	 * 
	 * @Desciption Clear User provided vin details
	 * @param none
	 * @return -void
	 */

	public void clearUserVinDtls() {

		final String METHOD_NAME = "clearUserVinDtls";
		log.entering(CLASS_NAME, METHOD_NAME);

		if (!CvddmUtil.isObjectEmpty(userProvidedVinDetails) && !userProvidedVinDetails.isEmpty()) {

			userProvidedVinDetails.clear();

		}

		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * Method Name: searchProdVehicleDetails
	 * 
	 * @Desciption Populates the Prod Vehicle Details Drop down that contain the
	 *             user's entry
	 * @param autocompleteQuery
	 *            - user's string
	 * @return - list of all Prod Vehicle Details that contain the autocompleteQuery
	 *         string.
	 */
	public List<String> searchProdVehicleDetails(final String autocompleteQuery) {

		final String METHOD_NAME = "searchProdVehicleDetails";
		log.entering(CLASS_NAME, METHOD_NAME, autocompleteQuery);

		List<String> suggestList = new ArrayList<String>();
		if (TextUtil.isBlankOrNull(autocompleteQuery)) {

			return this.prodVehicleDts;
		} else {
			final String queryUpperCase = autocompleteQuery.toUpperCase();

			for (final CvddmVinRepoCSVUploadDE vinRepoDE : this.vinRepoCSVUploadDEs) {

				final String programCodeUpperCase = vinRepoDE.getProgramCode().toUpperCase();
				final String modelYearUpperCase = vinRepoDE.getModelYear().toUpperCase();
				final String vehicleNameUpperCase = vinRepoDE.getVehicleName().toUpperCase();

				if (programCodeUpperCase.contains(queryUpperCase) || modelYearUpperCase.contains(queryUpperCase)
						|| vehicleNameUpperCase.contains(queryUpperCase))
					suggestList.add(vinRepoDE.getProgramCode().trim() + CVDDMConstant.HYPHEN_SYMBOL
							+ vinRepoDE.getModelYear().trim() + CVDDMConstant.HYPHEN_SYMBOL
							+ vinRepoDE.getVehicleName().trim());
			}
		}

		if (!suggestList.isEmpty()) {

			this.prodVehicleDts = suggestList.stream().distinct().collect(Collectors.toList());
			this.setProdVehicleDts(suggestList.stream().distinct().collect(Collectors.toList()));

			return prodVehicleDts;
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
		return suggestList;
	}

	/**
	 * Method Name: addUserVinNumbers
	 * 
	 * @Description: This method would Add more Vin's.
	 * @param :None
	 * @return void
	 **/

	public void addUserVinNumbers() {

		log.info("addUserVinNumbers");

		Integer maxVinAllowed = Integer.valueOf(CvddmUtil.getPropertiesValue(
				CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, CVDDMConstant.NO_OF_MOCK_VINS_ALLOWED));

		if (!CvddmUtil.isObjectEmpty(userProvidedVinDetails) && userProvidedVinDetails.size() < maxVinAllowed) {

			CvddmVinRequirement vinRequirement = new CvddmVinRequirement();

			List<ModuleESNDetails> tempModuleESNList = prepareModuleESNsforVins(partNumbersSelectionList);

			vinRequirement.setModuleESNDetailLst(tempModuleESNList);

			userProvidedVinDetails.add(vinRequirement);
		} else {
			setDisableAddVinButton(true);
			addLocalizedValidationFailureMessageToComponent(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
					CVDDMConstant.NO_OF_MOCK_VINS_ALLOWED_MSG, CVDDMConstant.JSF_ID_VIN_REQ_VINPANEL_TYPE2,
					maxVinAllowed.toString());
		}
	}

	/**
	 * Method Name: removeUserVINs
	 * 
	 * @Description: This method would Delete User provided VIN's
	 * @param :None
	 * @return void
	 **/

	public void removeUserVINs(CvddmVinRequirement vinRequirement) {

		final String METHOD_NAME = "removeUserVINs";

		log.entering(CLASS_NAME, METHOD_NAME);

		userProvidedVinDetails.remove(vinRequirement);

		Integer maxVinAllowed = Integer.valueOf(CvddmUtil.getPropertiesValue(
				CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, CVDDMConstant.NO_OF_MOCK_VINS_ALLOWED));

		if (!CvddmUtil.isObjectEmpty(userProvidedVinDetails) && userProvidedVinDetails.size() < maxVinAllowed) {

			setDisableAddVinButton(false);
		}

		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/*** Start Change :User Story: US1064885 **/

	/**
	 * Method Name: displayESNOption
	 * 
	 * @Description: This method would Display ESN Text Box User Selection
	 * @param :None
	 * @return void
	 **/

	public void displayESNOption() {

		final String METHOD_NAME = "displayESNOption";

		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			if (!CvddmUtil.isObjectEmpty(userProvidedVinDetails) && !userProvidedVinDetails.isEmpty()) {

				Iterator<CvddmVinRequirement> iter = userProvidedVinDetails.iterator();

				while (iter.hasNext()) {

					CvddmVinRequirement tempObj = iter.next();

					List<ModuleESNDetails> tempList = tempObj.getModuleESNDetailLst();

					Iterator<ModuleESNDetails> tempIter = tempList.iterator();

					while (tempIter.hasNext()) {

						ModuleESNDetails esnDetails = tempIter.next();

						if (Arrays.asList(nodeTypeCdArry).contains(esnDetails.getModuleCode())) {

							if (CVDDMConstant.STRING_N.equalsIgnoreCase(esnDetails.getVirtualReq())) {

								List<Boolean> tempVisibleList = Arrays.asList(true, true);

								esnDetails.setHideUnhidelist(tempVisibleList);

							} else {

								esnDetails.setModuleESNValue(null);
								List<Boolean> tempVisibleList = Arrays.asList(false, false);
								esnDetails.setHideUnhidelist(tempVisibleList);
							}

						}

					}

				}

			}
		} catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

	}

	/**
	 * Method Name: prepareModuleESNsforMockupVins
	 * 
	 * @Description: This method would Delete User provided VIN's
	 * @param :List<PartNumbersSelection>partNumberSelList
	 * @return List<ModuleESNDetails>
	 **/

	public List<ModuleESNDetails> prepareModuleESNsforVins(List<PartNumbersSelection> partNumberSelList) {

		final String METHOD_NAME = "prepareModuleESNsforVins";

		List<ModuleESNDetails> tempModuleESNList = new ArrayList<ModuleESNDetails>();

		List<Boolean> tempVisibleList;

		List<Boolean> virtualVisibleList;

		log.entering(CLASS_NAME, METHOD_NAME);

		if (!CvddmUtil.isObjectEmpty(partNumberSelList) && !partNumberSelList.isEmpty()) {

			Iterator<PartNumbersSelection> tempitr = partNumberSelList.iterator();

			while (tempitr.hasNext()) {

				PartNumbersSelection tempObj = tempitr.next();

				CvddmModuleDE cvddmModuleDE = tempObj.getCvddmModuleDE();

				if (!CvddmUtil.isObjectEmpty(tempObj.getVldteIvsFdRespSelected())
						&& (TextUtil.isNotBlankOrNull(cvddmModuleDE.getModule()))
						&& Arrays.asList(nodeTypeCdArry).contains(cvddmModuleDE.getModule().trim())) {

					ModuleESNDetails modTempObj = new ModuleESNDetails();
					modTempObj.setCvddmModuleDE(cvddmModuleDE);
					modTempObj.setModuleCode(cvddmModuleDE.getModule());
					if (TextUtil.isNotBlankOrNull(cvddmModuleDE.getModuleDesc())) {
						modTempObj.setModuleAcronym(cvddmModuleDE.getModuleName() + CVDDMConstant.HYPHEN_SYMBOL
								+ cvddmModuleDE.getModuleDesc());
					} else {
						modTempObj.setModuleAcronym(cvddmModuleDE.getModuleName());
					}
					modTempObj.setModuleDesc(cvddmModuleDE.getModuleDesc());
					if (Arrays.asList(nodeTypeCdArry).contains(cvddmModuleDE.getModule().trim())) {
						virtualVisibleList = Arrays.asList(true, true);
						tempVisibleList = Arrays.asList(false, false);
					} else {
						virtualVisibleList = Arrays.asList(false, false);
						tempVisibleList = Arrays.asList(true, true);
					}

					modTempObj.setVirtualDeviceUnhidelist(virtualVisibleList);
					modTempObj.setHideUnhidelist(tempVisibleList);
					tempModuleESNList.add(modTempObj);
				}
			}
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

		return tempModuleESNList;
	}

	/**
	 * Method Name: findDuplicatesVINS
	 * 
	 * @Description: This method would find Duplicate VIN's.
	 * @param :List<CvddmVinRequirement>
	 *            userProvidedVinDetails
	 * @return Set<String>
	 **/

	public Set<String> findDuplicatesVINS(List<CvddmVinRequirement> userProvidedVinDetails) {

		final Set<String> setToReturn = new HashSet<String>();
		final Set<String> uniqueSet = new HashSet<String>();

		Iterator<CvddmVinRequirement> listIterator = userProvidedVinDetails.listIterator();

		while (listIterator.hasNext()) {

			CvddmVinRequirement tempObj = listIterator.next();

			if (!uniqueSet.add(tempObj.getVinNumber().trim())) {
				setToReturn.add(tempObj.getVinNumber());
			}
		}
		return setToReturn;
	}

	/**
	 * Method Name: findDuplicatesESNs
	 * 
	 * @Description: This method would find Duplicate ESNs.
	 * @param :List<CvddmVinRequirement>
	 *            userProvidedVinDetails
	 * @return Set<String>
	 **/

	public Set<String> findDuplicatesESNs(List<CvddmVinRequirement> userProvidedVinDetails) {

		final Set<String> setToReturn = new HashSet<String>();
		final Set<String> uniqueSet = new HashSet<String>();

		Iterator<CvddmVinRequirement> listIterator = userProvidedVinDetails.listIterator();

		while (listIterator.hasNext()) {

			CvddmVinRequirement tempObj = listIterator.next();

			Iterator<ModuleESNDetails> listESNIterator = tempObj.getModuleESNDetailLst().listIterator();

			while (listESNIterator.hasNext()) {

				ModuleESNDetails esnDetails = listESNIterator.next();

				if (TextUtil.isNotBlankOrNull(esnDetails.getModuleESNValue())
						&& !uniqueSet.add(esnDetails.getModuleESNValue().trim())) {
					setToReturn.add(esnDetails.getModuleESNValue());
				}
			}

		}
		return setToReturn;
	}

	/*** End Change :User Story: US1064885 **/

	/*** End Change :User Story: US1064801 **/
	/*** Start Change :User Story: US1147659 **/

	/**
	 * Method Name: submitDataSetUpReq
	 * 
	 * @Description: This method would persist Data to all Data Set up tables and
	 *               would call method to send Email on successful insertion
	 * @return void
	 **/

	public void submitDataSetUpReq() {

		final String METHOD_NAME = "submitDataSetUpReq";

		boolean isSuccess = true;

		CvddmTestDataReqDE testDataReqDE = null;

		CvddmTdsReqModDE tdsReqModDE = null;

		CvddmTdsReqPartDE tdsReqPartDE = null;

		CvddmConfigDidSelectionDE didSelectionDE = null;

		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			if (TextUtil.isNotBlankOrNull(selectedMockUpVin)
					&& CVDDMConstant.STRING_Y.equalsIgnoreCase(selectedMockUpVin.trim())) {

				if (!updateVINRepoTable(CVDDMConstant.SUBMIT_ACTION)) {

					isSuccess = false;

					log.info("Add Error Message for Review and Submit");

					addLocalizedValidationFailureMessageToComponent(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
							CVDDMConstant.NOT_ENOUGH_VINS_MSG, CVDDMConstant.MOCKUP_VIN_PANEL_ID,
							CVDDMConstant.JSF_ID_VIN_REQ_NOOFVINS_TYPE2, CVDDMConstant.JSF_ID_VIN_REQ_PRDVEHICLE_TYPE2);
				}
				if (isSuccess && !updateESNRepoTable(CVDDMConstant.SUBMIT_ACTION)) {

					log.info("In future add Update ESN check on Module basis and message");
					isSuccess = false;
					addLocalizedValidationFailureMessageToComponent(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
							CVDDMConstant.NOT_ENOUGH_ESNS_MSG, CVDDMConstant.MOCKUP_VIN_PANEL_ID);
				}
			} else if (TextUtil.isNotBlankOrNull(selectedMockUpVin)
					&& CVDDMConstant.STRING_N.equalsIgnoreCase(selectedMockUpVin.trim())) {

				if (!updateESNRepoTable(CVDDMConstant.SUBMIT_ACTION)) {

					log.info("In future add Update ESN check on Module basis and message");
					isSuccess = false;
					addLocalizedValidationFailureMessageToComponent(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
							CVDDMConstant.NOT_ENOUGH_ESNS_MSG, CVDDMConstant.JSF_ID_VIN_REQ_VINPANEL_TYPE2);
				} else {

					log.info("run more validations");
				}

			}

			if (isSuccess) {

				testDataReqDE = saveCvddmTestDataReqDEData();

				if (!CvddmUtil.isObjectEmpty(testDataReqDE)
						&& !CvddmUtil.isObjectEmpty(testDataReqDE.getCvdmTdsReqId())) {

					log.info("REQUEST NUMBER IS" + testDataReqDE.getCvdmTdsReqId());

					if(!CvddmUtil.isObjectEmpty(this.partNumbersSelectionList) && !this.partNumbersSelectionList.isEmpty()) {

						Iterator<PartNumbersSelection> partNumberItr = this.partNumbersSelectionList.iterator();

						while (partNumberItr.hasNext()) {

							PartNumbersSelection numbersSelection = partNumberItr.next();

							tdsReqModDE = saveCvddmTdsReqModDEData(testDataReqDE, numbersSelection.getCvddmModuleDE());

							if (!CvddmUtil.isObjectEmpty(tdsReqModDE)
									&& !CvddmUtil.isObjectEmpty(tdsReqModDE.getCvdmTdsReqModId())) {

								log.info("tdsReqModDE PK " + tdsReqModDE.getCvdmTdsReqModId());

								tdsReqPartDE = saveCvddmTdsReqPartDEData(tdsReqModDE,
										numbersSelection.getVldteIvsFdRespSelected());

								if (!CvddmUtil.isObjectEmpty(tdsReqPartDE) && !CvddmUtil
										.isObjectEmpty(tdsReqPartDE.getCvddmTdsReqModDE().getCvdmTdsReqModId())) {

									log.info("tdsReqPartDE PK " + tdsReqPartDE.getCvddmTdsReqModDE().getCvdmTdsReqModId());

									if(!CvddmUtil.isObjectEmpty(this.configDidFeatureSelectionList) 
											&& !this.configDidFeatureSelectionList.isEmpty()) {

										Iterator<ConfigDidFeatureSelection> configDidFeatureItr = this.configDidFeatureSelectionList.iterator();

										while(configDidFeatureItr.hasNext()) {

											ConfigDidFeatureSelection featureSelection = configDidFeatureItr.next();

											if(featureSelection.getCvddmModuleDE().getModuleId().equalsIgnoreCase(numbersSelection.getCvddmModuleDE().getModuleId())
												&& !CvddmUtil.isObjectEmpty(featureSelection.getPartIISpecFeaturesslctd()) 
													&& !featureSelection.getPartIISpecFeaturesslctd().isEmpty()	) {


													Iterator<PartIISpecFeatures> selConfigDids  = featureSelection.getPartIISpecFeaturesslctd().iterator();

													while(selConfigDids.hasNext()) {

														PartIISpecFeatures specFeatures = selConfigDids.next();

														didSelectionDE = saveCvddmConfigDidSelectionDEData(tdsReqModDE,specFeatures);

													}

											}

										}

									}

								}
								else {
									
									log.info("Roll back for tdsReqModDE");
									log.info("Roll back for testDataReqDE");
								}

							}
							else {
								
								log.info("Roll back for testDataReqDE");
							}

						}	

					}
				}

			} else {

				log.info("We have failures, please check tables");
			}

			log.info("Selected product line is" + this.selectedProductLine);

		} catch (Exception e) {

			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}
		log.entering(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * Method Name: updateVINRepoTable
	 * 
	 * @Description: This method would update records in [PCVDM19_VIN_REPO] table
	 *               for for Mock up VINs provided No.of VIN exist.
	 * @param String
	 *            actionType
	 * @return boolean
	 **/

	public boolean updateVINRepoTable(String actionType) {

		final String METHOD_NAME = "updateVINRepoTable";

		log.entering(CLASS_NAME, METHOD_NAME);

		boolean isSuccess = true;

		try {

			log.info("Selected product line is" + this.selectedProductLine);

			log.info("Value of Vehicle is >>> " + selectProdVehicleDtl);

			if (!CvddmUtil.isObjectEmpty(selectProdVehicleDtl)) {

				String[] tempArray = selectProdVehicleDtl.split(CVDDMConstant.HYPHEN_SYMBOL);

				if (!CvddmUtil.isArrayEmpty(tempArray)) {

					mockupVinDetails = cvddmVINRepoBF.getMockVinDtlsfrmRepo(tempArray[0].trim(), tempArray[1].trim(),
							tempArray[2].trim(), this.vinsRequired);

					if (!CvddmUtil.isObjectEmpty(mockupVinDetails) && !mockupVinDetails.isEmpty()) {

						if (CVDDMConstant.SUBMIT_ACTION.equalsIgnoreCase(actionType)) {

							UUID uuid = UUID.randomUUID();

							uuid.toString();

							log.info(" uuid.toString()>>> " + uuid.toString());

							List<CvddmVinRepoCSVUploadDE> mockupVinTempLst = new ArrayList<CvddmVinRepoCSVUploadDE>();

							Iterator<CvddmVinRepoCSVUploadDE> vinRepoItr = mockupVinDetails.iterator();

							while (vinRepoItr.hasNext()) {

								CvddmVinRepoCSVUploadDE tempObj = vinRepoItr.next();
								tempObj.setStatus(uuid.toString().substring(0, 7)); // Replace by Request Id later
								mockupVinTempLst.add(tempObj);
							}

							cvddmVINRepoBF.updateVINRepoTable(mockupVinTempLst);

						}

					} else {

						isSuccess = false;
					}

				}
			} else {

				isSuccess = false;
			}

		} catch (Exception e) {

			isSuccess = false;
			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

		return isSuccess;

	}

	/**
	 * Method Name: updateESNRepoTable
	 * 
	 * @Description: This method would update records in [PCVDM20_ESN_REPO] table
	 *               for Virtual ESNs provided No.of ESN exist.
	 * @param String
	 *            actionType
	 * @return boolean
	 **/

	public boolean updateESNRepoTable(String actionType) {

		final String METHOD_NAME = "updateESNRepoTable";

		log.entering(CLASS_NAME, METHOD_NAME);

		boolean isSuccess = true;

		String noofESNsReq = CVDDMConstant.EMPTY_STRING;

		try {

			if (TextUtil.isNotBlankOrNull(this.vinsRequired)
					&& CVDDMConstant.STRING_Y.equalsIgnoreCase(this.selectedMockUpVin)) {
				noofESNsReq = this.vinsRequired;

			} else if (!CvddmUtil.isObjectEmpty(this.userProvidedVinDetails) && !this.userProvidedVinDetails.isEmpty()
					&& TextUtil.isNotBlankOrNull(this.userProvidedVinDetails.get(0).getVinNumber())) {

				noofESNsReq = String.valueOf(this.userProvidedVinDetails.size());
			}
			esncsvUploadDEs = cvddmVINRepoBF.getAvailableESNRecords(noofESNsReq);

			if (!CvddmUtil.isObjectEmpty(esncsvUploadDEs) && !esncsvUploadDEs.isEmpty()) {

				if (CVDDMConstant.SUBMIT_ACTION.equalsIgnoreCase(actionType)) {

					UUID uuid = UUID.randomUUID();

					uuid.toString();

					log.info(" uuid.toString()>>> " + uuid.toString());

					List<CvddmESNCSVUploadDE> mockupESNTempLst = new ArrayList<CvddmESNCSVUploadDE>();

					Iterator<CvddmESNCSVUploadDE> esnRepoItr = mockupESNTempLst.iterator();

					while (esnRepoItr.hasNext()) {

						CvddmESNCSVUploadDE tempObj = esnRepoItr.next();
						tempObj.setStatus(uuid.toString().substring(0, 7)); // Replace by Request Id later
						mockupESNTempLst.add(tempObj);
					}

					cvddmVINRepoBF.updateESNRepoTable(mockupESNTempLst);

				}

			} else {

				isSuccess = false;
			}

		} catch (Exception e) {

			isSuccess = false;
			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

		return isSuccess;

	}

	/**
	 * Method Name: saveCvddmTestDataReqDEData
	 * 
	 * @Description: This method would fetch and persist Data to the core
	 *               PCVDM14_TDS_REQ table
	 * @return CvddmTestDataReqDE
	 * 
	 **/
	public CvddmTestDataReqDE saveCvddmTestDataReqDEData() {

		final String METHOD_NAME = "saveCvddmTestDataReqDEData";

		CvddmTestDataReqDE dataReqDE = null;

		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			CvddmTestDataReqDE pushRecordDE = new CvddmTestDataReqDE();
			pushRecordDE.setRequestUserCdsId(this.loggedInUserCdsId);
			pushRecordDE.setRequesterDisplayName(this.loggedInUserName);
			pushRecordDE.setRequestManagerCdsId(this.loggedInUserManagerId);
			pushRecordDE.setRequestDateTime(
					new Timestamp(CvddmUtil.getTimeZoneCurrentDate(CVDDMConstant.UTC_TIME_ZONE).getTime()));

			CvddmProductTeamDE cvddmProductTeamDE = testDataSetUpBF.fetchProducTeamById(this.selectedProductTeam);

			if (!CvddmUtil.isObjectEmpty(cvddmProductTeamDE)) {

				pushRecordDE.setCvddmProductTeamDE(cvddmProductTeamDE);
			}
			if (!CvddmUtil.isObjectEmpty(this.codeDropDate)) {

				pushRecordDE.setCvdmCodeDropDate(this.codeDropDate);
			}
			if (!CvddmUtil.isObjectEmpty(this.testingStartDate)) {

				pushRecordDE.setCvdmTestingStartDate(this.testingStartDate);
			}
			if (!CvddmUtil.isObjectEmpty(this.testingEndDate)) {

				pushRecordDE.setCvdmTestingEndDate(this.testingEndDate);
			}
			if (TextUtil.isNotBlankOrNull(this.testingSubject)) {

				pushRecordDE.setCvdmSubject(this.testingSubject.trim());
			}

			CvddmTestingTypeDE testingTypeDE = testDataSetUpBF.fetchTestingTypeById(this.selectedTestingType);

			if (!CvddmUtil.isObjectEmpty(testingTypeDE)) {

				pushRecordDE.setCvddmTestingTypeDE(testingTypeDE);
			}

			if (!CvddmUtil.isObjectEmpty(selectedCvddmEnvironmentDE)) {

				pushRecordDE.setCvddmEnvironmentDE(selectedCvddmEnvironmentDE);
			}

			if (TextUtil.isNotBlankOrNull(this.selectedVehicle)) {

				String[] tempVehicleArr = selectedVehicle.split(CVDDMConstant.HYPHEN_SYMBOL);

				if (!CvddmUtil.isArrayEmpty(tempVehicleArr)) {

					pushRecordDE.setCvdmPgmCode(tempVehicleArr[0].trim());
					pushRecordDE.setCvdmModelYear(Long.valueOf(tempVehicleArr[1].trim()));
					pushRecordDE.setCvdmVehicleName(tempVehicleArr[2].trim());
				}
			}

			if (TextUtil.isNotBlankOrNull(this.selectedPriority)) {

				pushRecordDE.setCvdmPriority(this.selectedPriority.trim());
			}

			if (!CvddmUtil.isObjectEmpty(this.testDataReqOnDate)) {

				pushRecordDE.setCvdmTestDataRequiredOn(this.testDataReqOnDate);
			}

			if (!CvddmUtil.isObjectEmpty(this.emailNotificationLst) && !emailNotificationLst.isEmpty()) {

				StringBuilder emailIds = new StringBuilder();

				Iterator<UserTO> emailIter = emailNotificationLst.iterator();

				while (emailIter.hasNext()) {

					UserTO userTO = emailIter.next();

					emailIds.append(userTO.getMail().trim());
					if (emailIter.hasNext()) {
						emailIds.append(CVDDMConstant.COMMA_SYMBOL);
					}
				}
				pushRecordDE.setCvdmEmailNotificationList(emailIds.toString());
			}

			dataReqDE = testDataSetUpBF.saveCvddmTestDataReqDEData(pushRecordDE);

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
		return dataReqDE;
	}

	/**
	 * Method Name: saveCvddmTdsReqModDEData
	 * 
	 * @Description:This method would persist data into PCVDM16_TDS_REQ_MOD database
	 *                   table
	 * @param CvddmTestDataReqDE
	 *            testDataReqDE,CvddmModuleDE cvddmModuleDE
	 * @return CvddmTdsReqModDE
	 */

	public CvddmTdsReqModDE saveCvddmTdsReqModDEData(CvddmTestDataReqDE testDataReqDE, CvddmModuleDE cvddmModuleDE) {

		final String METHOD_NAME = "saveCvddmTestDataReqDEData";

		CvddmTdsReqModDE tdsReqModDE = null;

		log.entering(CLASS_NAME, METHOD_NAME);

		try {
			CvddmTdsReqModDE pushRecordDE = new CvddmTdsReqModDE();

			if (!CvddmUtil.isObjectEmpty(testDataReqDE)) {

				pushRecordDE.setCvddmTestDataReqDE(testDataReqDE);
			}
			if (!CvddmUtil.isObjectEmpty(cvddmModuleDE)) {

				pushRecordDE.setCvddmModuleDE(cvddmModuleDE);
			}

			tdsReqModDE = testDataSetUpBF.saveCvddmTdsReqModDEData(pushRecordDE);
		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
		}
		log.exiting(CLASS_NAME, METHOD_NAME);

		return tdsReqModDE;
	}

	/**
	 * Method Name: saveCvddmTdsReqPartDEData
	 * 
	 * @Description:This method would persist data into PCVDM26_TDS_REQ_PART
	 *                   database table
	 * @param CvddmTdsReqModDE
	 *            tdsReqModDE,ValidateIVSFeedResponse vldteIvsFdRespSelected
	 * @return CvddmTdsReqPartDE
	 * 
	 **/
	public CvddmTdsReqPartDE saveCvddmTdsReqPartDEData(CvddmTdsReqModDE tdsReqModDE,ValidateIVSFeedResponse respSelected) {

		final String METHOD_NAME = "saveCvddmTdsReqPartDEData";

		CvddmTdsReqPartDE tdsReqPartDE = null;

		log.entering(CLASS_NAME, METHOD_NAME);

		try {
			CvddmTdsReqPartDE pushRecordDE = new CvddmTdsReqPartDE();

			pushRecordDE.setCvddmTdsReqModDE(tdsReqModDE);

			if (!CvddmUtil.isObjectEmpty(respSelected)) {

				if (TextUtil.isNotBlankOrNull(respSelected.getPartLineageData())) {

					pushRecordDE.setPartLineageData(Integer.parseInt(respSelected.getPartLineageData()));
				}

				if (TextUtil.isNotBlankOrNull(respSelected.getAssembly())) {

					pushRecordDE.setAssembly(respSelected.getAssembly());
				}

				if (TextUtil.isNotBlankOrNull(respSelected.getAssemblyDescription())) {

					pushRecordDE.setAssemblyDescription(respSelected.getAssemblyDescription());
				}

				if (TextUtil.isNotBlankOrNull(respSelected.getHardwarePartNumber())) {

					pushRecordDE.setHardwarePartNumber(respSelected.getHardwarePartNumber());
				}

				if (TextUtil.isNotBlankOrNull(respSelected.getHardwareDescription())) {

					pushRecordDE.setHardwareDescription(respSelected.getHardwareDescription());
				}

				if (TextUtil.isNotBlankOrNull(respSelected.getSoftwareParts())) {

					pushRecordDE.setSoftwareParts(respSelected.getSoftwareParts());
				}

				if (TextUtil.isNotBlankOrNull(respSelected.getApplications())) {

					pushRecordDE.setApplications(respSelected.getApplications());
				}

				if (TextUtil.isNotBlankOrNull(respSelected.getServiceXMLType())) {

					pushRecordDE.setServiceXMLType(Integer.parseInt(respSelected.getServiceXMLType()));
				}

				if (TextUtil.isNotBlankOrNull(respSelected.getReplacementModuleIsInOperation())) {

					pushRecordDE.setReplacementModuleIsInOperation(respSelected.getReplacementModuleIsInOperation());
				}

				if (TextUtil.isNotBlankOrNull(respSelected.getProgramInService())) {

					pushRecordDE.setProgramInService(respSelected.getProgramInService());
				}
			}

			tdsReqPartDE = testDataSetUpBF.saveCvddmTdsReqPartDEData(pushRecordDE);

		} catch (Exception e) {
			tdsReqPartDE =null;
			log.severe(CvddmUtil.getStackTraceContent(e));
		}
		log.exiting(CLASS_NAME, METHOD_NAME);

		return tdsReqPartDE;
	}

	/**
	 * Method Name: saveCvddmConfigDidSelectionDEData
	 * 
	 * @Description:This method would persist data into 
	 *                   PCVDM24_TDS_REQ_CFG_DID database table
	 * @param CvddmConfigDidSelectionDE dataReqDE,PartIISpecFeatures specFeatures
	 * @return CvddmConfigDidSelectionDE
	 */

	public CvddmConfigDidSelectionDE saveCvddmConfigDidSelectionDEData(CvddmTdsReqModDE tdsReqModDE,PartIISpecFeatures specFeatures) {

		final String METHOD_NAME = "saveCvddmConfigDidSelectionDEData";

		CvddmConfigDidSelectionDE configDidSelectionDE = null;

		log.entering(CLASS_NAME, METHOD_NAME);

		try {
			CvddmConfigDidSelectionDE pushRecordDE = new CvddmConfigDidSelectionDE();
			pushRecordDE.setCvddmTdsReqModDE(tdsReqModDE);
			pushRecordDE.setCvdmConfigDidId(specFeatures.getId());
			pushRecordDE.setCvdmConfigDidName(specFeatures.getName());
			pushRecordDE.setCvdmConfigDidValue(specFeatures.getDidValue());

			configDidSelectionDE = testDataSetUpBF.saveCvddmConfigDidSelectionDEData(pushRecordDE);


		}

		catch (Exception e) {
			configDidSelectionDE =null;
			log.severe(CvddmUtil.getStackTraceContent(e));
		}
		log.exiting(CLASS_NAME, METHOD_NAME);

		return configDidSelectionDE;

	}

	/*** End Change :User Story: US1147659 **/

	/*** Start Change :User Story: US1063866 -- Add PartNumbers Screen **/

	/**
	 * Method Name: retrieveVehiclesForSelectedEnv
	 * 
	 * @Description: Method to retrieve the Vehicles for the selected Environment
	 * @param :
	 *            none
	 * @return none
	 */
	public void retrieveVehiclesForSelectedEnv() {

		final String METHOD_NAME = "retrieveVehiclesForSelectedEnv";
		log.entering(CLASS_NAME, METHOD_NAME);

		GIVISRestClients gIVISRestClients = new GIVISRestClients();

		List<ProgramCodeTO> programCodesFromGivis;

		if (TextUtil.isBlankOrNull(this.selectedEnv) || CVDDMConstant.STRING_ZERO.equalsIgnoreCase(this.selectedEnv)) {
			clearPrtNbrForm();
		} else {

			try {

				programCodesFromGivis = gIVISRestClients.getPartNumbersFromGivis(this.selectedEnv);

			} catch (Exception e) {
				log.severe(CvddmUtil.getStackTraceContent(e));
				throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
						CvddmUtil.getStackTraceContent(e), e);
			}

			setProgramCodes(programCodesFromGivis);
			generateVehiclesDropdownValues(programCodesFromGivis);

			this.disVehiclesDropdown = CVDDMConstant.STRING_Y;
			this.disModulesSelection = CVDDMConstant.STRING_Y;

		}

		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * Method Name: generateVehiclesDropdownValues
	 * 
	 * @Description: Private method to generate the Vehicle DropDown values
	 * 
	 * @param :
	 *            List<ProgramCodeTO>
	 * @return none
	 */
	private void generateVehiclesDropdownValues(List<ProgramCodeTO> programCodes) {

		final String METHOD_NAME = "generateVehiclesDropdownValues";
		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			List<String> vehDrpDwnVls = new ArrayList<>();

			for (ProgramCodeTO programCode : programCodes) {
				vehDrpDwnVls.add(programCode.getProgramCode() + " - " + programCode.getModelYear() + " - "
						+ programCode.getVehicleName());
			}

			this.setVehiclesList(vehDrpDwnVls);

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

	}

	/**
	 * Method Name: searchVehcile
	 * 
	 * @Description: Method for auto completion of Vehicle DropDown
	 * 
	 * @param :
	 *            String
	 * @return List<String>
	 */
	public List<String> searchVehcile(String query) {

		final String METHOD_NAME = "searchVehcile";
		log.entering(CLASS_NAME, METHOD_NAME);

		log.info("Query=" + query);

		try {

			if (CVDDMConstant.EMPTY_STRING.equals(query)) {
				return this.vehiclesList;
			}

			else {
				return this.vehiclesList.stream() // convert list to stream
						.filter(line -> line.contains(query.toUpperCase())) // filter with query
						.collect(Collectors.toList()); // collect the output and convert streams to
			}

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}
	}

	/**
	 * Method Name: genPartNbrDtlsForSlctdNds
	 * 
	 * @Description: Method to generate the PartNumber details
	 * 
	 *               Note: This has to be enabled while enabling "Others" section in
	 *               future 'selectedNodeListAll.addAll(selectedNodeListOthers);'
	 * 
	 * @param :
	 *            none
	 * @return none
	 */
	public void genPartNbrDtlsForSlctdNds() {

		final String METHOD_NAME = "genPartNbrDtlsForSlctdNds";
		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			clearPrtNbrExstngResp();

			if (validateInputDataAddPartNumberDetails()) {

				TreeSet<String> selectedNodeListAll = new TreeSet<>();
				selectedNodeListAll.addAll(selectedNodeList);

				this.partNumbersSelectionList = new ArrayList<>();

				if (!CvddmUtil.isObjectEmpty(selectedNodeListAll) && !selectedNodeListAll.isEmpty()) {

					for (String module : selectedNodeListAll) {

						ValidateIVSFeedRequest validateIVSFeedRequest = generateValidateIVSFeedRequest(module);

						IVSURestClients iVSURestClients = new IVSURestClients();

						List<ValidateIVSFeedResponse> validateIVSFeedResponse = iVSURestClients
								.validateIVSFeed(validateIVSFeedRequest, this.selectedEnv);

						// Removing duplicates
						/*
						 * Map<String, ValidateIVSFeedResponse> validateIVSFeedResponseMap =
						 * validateIVSFeedResponseFromIvsu .stream()
						 * .collect(Collectors.toMap(ValidateIVSFeedResponse::getAssembly,
						 * Function.identity()));
						 * 
						 * Collection<ValidateIVSFeedResponse> validateIVSFeedResponseCollection =
						 * validateIVSFeedResponseMap .values();
						 * 
						 * List<ValidateIVSFeedResponse> validateIVSFeedResponse = new
						 * ArrayList<>(validateIVSFeedResponseCollection);
						 */

						PartNumbersSelection partNumbersSelection = new PartNumbersSelection();
						partNumbersSelection.setNode(module);
						partNumbersSelection.setCvddmModuleDE(listCvddmModuleBF.fetchModRcrd(module.substring(0, 3)));

						if (!CvddmUtil.isObjectEmpty(validateIVSFeedResponse) && !validateIVSFeedResponse.isEmpty()) {
							partNumbersSelection.setValidateIVSFeedResponse(validateIVSFeedResponse);
							partNumbersSelection.setDisPnbrMdlLvlRespAvl(CVDDMConstant.STRING_Y);

							if (TextUtil.isBlankOrNull(validateIVSFeedResponse.get(0).getApplications())) {
								partNumbersSelection.setDisApplicationAvl(CVDDMConstant.STRING_N);
							} else {
								partNumbersSelection.setDisApplicationAvl(CVDDMConstant.STRING_Y);
							}

						} else {
							partNumbersSelection.setValidateIVSFeedResponse(new ArrayList<ValidateIVSFeedResponse>());
							partNumbersSelection.setDisPnbrMdlLvlRespAvl(CVDDMConstant.STRING_N);
						}

						partNumbersSelectionList.add(partNumbersSelection);

					}

					disableEditingInputs();

				}

				if (!CvddmUtil.isObjectEmpty(partNumbersSelectionList) && !partNumbersSelectionList.isEmpty()) {
					this.disPnbrRespAvl = CVDDMConstant.STRING_Y;
				} else {
					this.disPnbrRespAvl = CVDDMConstant.STRING_N;
				}

			}

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

	}

	/**
	 * Private method to generate ValidateIVSFeedRequest
	 * 
	 * @return
	 */
	private ValidateIVSFeedRequest generateValidateIVSFeedRequest(String module) {

		final String METHOD_NAME = "generateValidateIVSFeedRequest";
		log.entering(CLASS_NAME, METHOD_NAME);

		ValidateIVSFeedRequest validateIVSFeedRequest = new ValidateIVSFeedRequest();
		ValidateIVSFeed validateIVSFeed = new ValidateIVSFeed();

		try {
			String[] partNumberData = this.selectedVehicle.split("-");

			validateIVSFeed.setProgramCode(partNumberData[0]);
			validateIVSFeed.setModelYear(Integer.parseInt(partNumberData[1].trim()));
			validateIVSFeed.setNode(module.substring(0, 3));
			// Flag - 'P' : Default value
			validateIVSFeed.setFlag(CVDDMConstant.IVS_FEED_FLAG);
			validateIVSFeedRequest.setValidateIVSFeed(validateIVSFeed);

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

		return validateIVSFeedRequest;
	}

	/**
	 * Private method to disable the inputs in APN screen
	 * 
	 */
	private void disableEditingInputs() {

		// Disabling the inputs for not allowing further modification
		this.disVehiclesDropdown = CVDDMConstant.STRING_N;
		this.disModulesSelection = CVDDMConstant.STRING_N;
		this.disEnvsDropdown = CVDDMConstant.STRING_N;

	}

	/**
	 * Method to clear the form values in PartNumber screen
	 * 
	 */
	public void clearPrtNbrForm() {
		this.selectedEnv = null;
		this.selectedVehicle = null;
		this.selectedNodeList = null;
		this.selectedNodeListOthers = null;
		this.disPnbrRespAvl = CVDDMConstant.STRING_N;

		this.disVehiclesDropdown = CVDDMConstant.STRING_N;
		this.disModulesSelection = CVDDMConstant.STRING_N;
		this.disEnvsDropdown = CVDDMConstant.STRING_Y;

		clearPrtNbrExstngResp();

		/** Start Change : US1064801 ***/
		this.selectedMockUpVin = null;
		hideDisplayVinPanels();
		/** End Change : US1064801 ***/
	}

	/**
	 * Method to clear the form values in PartNumber response
	 * 
	 */
	private void clearPrtNbrExstngResp() {
		this.partNumbersSelectionList = null;
		this.disPnbrRespAvl = CVDDMConstant.STRING_N;
	}

	/**
	 * 
	 * Private method to Generate Values For Modules DropDown
	 * 
	 * @return
	 */
	private TreeSet<String> generateValuesForModulesDropdown() {

		final String METHOD_NAME = "generateValuesForModulesDropdown";
		log.entering(CLASS_NAME, METHOD_NAME);

		TreeSet<String> modulesDrpDwnValues = new TreeSet<>();

		try {

			List<CvddmModuleDE> valuesFromDB = listCvddmModuleBF.fetchAllModActiveRcrds();

			if (!CvddmUtil.isObjectEmpty(valuesFromDB)) {

				for (CvddmModuleDE cvddmModuleDE : valuesFromDB) {
					if (TextUtil.isBlankOrNull(cvddmModuleDE.getModuleDesc())) {
						modulesDrpDwnValues.add(cvddmModuleDE.getModule() + "-" + cvddmModuleDE.getModuleName());
					} else {
						modulesDrpDwnValues.add(cvddmModuleDE.getModule() + "-" + cvddmModuleDE.getModuleName() + "-"
								+ cvddmModuleDE.getModuleDesc());
					}

				}

			}

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

		return modulesDrpDwnValues;
	}

	/**
	 * Private method to validate the input form data
	 * 
	 * 
	 * @return
	 */
	private boolean validateInputDataAddPartNumberDetails() {

		boolean isValidInput = true;

		final String METHOD_NAME = "validateInputDataAddPartNumberDetails";
		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			if (CVDDMConstant.STRING_ZERO.equals(this.selectedEnv)) {

				isValidInput = false;

				FacesContext.getCurrentInstance().addMessage(CVDDMConstant.JSF_ID_APN_ENV,
						new FacesMessage(FacesMessage.SEVERITY_ERROR, null,
								getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_APPLICATION_RESOURCE_KEY,
										CVDDMConstant.LABEL_APN_ENV) + " "
										+ getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
												CVDDMConstant.REQUIRED_MSG)));

			} else {

				setSelectedCvddmEnvironmentDE(listCvddmEnvironmentBF.fetchEnvObj(this.selectedEnv));

			}

			if (TextUtil.isBlankOrNull(this.selectedVehicle)) {

				isValidInput = false;

				FacesContext.getCurrentInstance().addMessage(CVDDMConstant.JSF_ID_APN_PARTNUM,
						new FacesMessage(FacesMessage.SEVERITY_ERROR, null,
								getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_APPLICATION_RESOURCE_KEY,
										CVDDMConstant.LABEL_APN_PARTNUM) + " "
										+ getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
												CVDDMConstant.REQUIRED_MSG)));

			}
			if (CvddmUtil.isObjectEmpty(this.selectedNodeList) || this.selectedNodeList.isEmpty()) {

				isValidInput = false;

				FacesContext.getCurrentInstance().addMessage(CVDDMConstant.JSF_ID_APN_MODULE,
						new FacesMessage(FacesMessage.SEVERITY_ERROR, null,
								getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_APPLICATION_RESOURCE_KEY,
										CVDDMConstant.LABEL_APN_MODULE) + " "
										+ getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
												CVDDMConstant.REQUIRED_MSG)));
			}

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

		return isValidInput;

	}

	/**
	 * Private method to validate the output of Add PartNumber Screen
	 * 
	 * @return
	 */
	private boolean validateRespOfAPNScreen() {

		boolean validResp = true;

		final String METHOD_NAME = "validateRespOfAPNScreen";
		log.entering(CLASS_NAME, METHOD_NAME);

		try {
			if (!CvddmUtil.isObjectEmpty(this.partNumbersSelectionList)) {

				for (PartNumbersSelection partNumbersSelection : this.partNumbersSelectionList) {

					if ((partNumbersSelection.getDisPnbrMdlLvlRespAvl().equals(CVDDMConstant.STRING_Y))
							&& (CvddmUtil.isObjectEmpty(partNumbersSelection.getVldteIvsFdRespSelected()))) {

						FacesContext.getCurrentInstance().addMessage(CVDDMConstant.JSF_ID_APN_RESPMSG,
								new FacesMessage(FacesMessage.SEVERITY_ERROR,
										CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
												CVDDMConstant.VAL_MSG_APN_SLCT_PARTNBR) + " - "
												+ partNumbersSelection.getNode(),
												CVDDMConstant.VALIDATION_ERR));

						validResp = false;

					}

				}

			} else {
				validateInputDataAddPartNumberDetails();
				validResp = false;

				/*
				 * FacesContext.getCurrentInstance()
				 * .addMessage(CVDDMConstant.JSF_ID_APN_SPNMSG, new
				 * FacesMessage(FacesMessage.SEVERITY_ERROR,
				 * CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
				 * CVDDMConstant.VAL_MSG_APN_SLCT_PARTNBR_ALL), CVDDMConstant.VALIDATION_ERR));
				 */
			}

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

		return validResp;
	}

	/**
	 * Method to open Part Matrix Reference in new window
	 * 
	 */
	public void openPMRInNewWindow() {

		final String METHOD_NAME = "openPMRInNewWindow";
		log.entering(CLASS_NAME, METHOD_NAME);

		try {
			String navigation = "/testDataSetup/partMatrixReference.faces";
			RequestContext.getCurrentInstance().execute("window.open('" + navigation + "')");

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}

		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/*** End Change :User Story: US1063866 -- Add PartNumbers Screen **/

	/*** Start Change :User Story: US1064102 -- Configdid selection screen **/

	/**
	 * Method Name: generateConfigDidFeatureDetls
	 * 
	 * @Description: Method to generate the Config did feature details
	 * @param :
	 *            none
	 * @return none
	 */
	public void selectedPartIISpecData() {
		final String METHOD_NAME = "selectedPartIISpecData";
		log.entering(CLASS_NAME, METHOD_NAME);
		List<PartIISpecFeatures> features = new ArrayList<>();
		GIVISRestClients gIVISRestClients = new GIVISRestClients();
		PartIISpecFromAWS partIISpecFromAWS = new PartIISpecFromAWS();

		String modifieddate;
		String uTCTime;
		String key;
		this.configDidFeatureSelectionList = new ArrayList<ConfigDidFeatureSelection>();
		Iterator<PartNumbersSelection> partIIspecsIterator = partNumbersSelectionList.iterator();

		while (partIIspecsIterator.hasNext()) {

			PartNumbersSelection partNumbersSelectionn = partIIspecsIterator.next();

			ValidateIVSFeedResponse iVSFeedResponse = partNumbersSelectionn.getVldteIvsFdRespSelected();

			ConfigDidFeatureSelection configDidSelection = new ConfigDidFeatureSelection();
			configDidSelection.setNode(partNumbersSelectionn.getNode());
			configDidSelection.setCvddmModuleDE(partNumbersSelectionn.getCvddmModuleDE());
			/*** Start Change :User Story: US1147659 **/
			configDidSelection.setiVSFeedResponseSel(iVSFeedResponse);
			/*** End Change :User Story: US1147659 **/

			if (!CvddmUtil.isObjectEmpty(iVSFeedResponse)
					&& !CvddmUtil.isObjectEmpty(iVSFeedResponse.getSoftwareParts())) {

				String softwareParts = iVSFeedResponse.getSoftwareParts();

				String partIISpecc = requiredPartIISpecPart(softwareParts);

				configDidSelection.setPartIISpec(partIISpecc);

				if (TextUtil.isNotBlankOrNull(partIISpecc)) {

					try {

						// get modified date from GIVIS
						modifieddate = gIVISRestClients.getAWSModifiedDateFromGivis(partIISpecc, getSelectedEnv());

						if (TextUtil.isNotBlankOrNull(modifieddate)) {

							log.info("Modified Date" + modifieddate);

							uTCTime = CvddmUtil
									.getUTCTimeInMilliSecs(modifieddate.substring(1, modifieddate.length() - 1));

							log.info("Modified Date in UTC milliseconds " + uTCTime);

							key = partIISpecc + "_" + uTCTime + CVDDMConstant.PARTIISPEC_AWS_FILE_FORMAT;

							log.info("AWS Key " + key);

							byte[] partIISpec = partIISpecFromAWS.getPartIISpecFromAWS(key); // get Part2Spec from AWS

							if (null == key || null == partIISpec) {
								log.info("PartIISpec is not available in AWS " + key);
								configDidSelection.setDisPartIIspecvlRespAvl(CVDDMConstant.STRING_N);
								configDidSelection.setPartIISpecFeatures(features);
								configDidFeatureSelectionList.add(configDidSelection);

							} else {
								features = getFeatureListFromPartIISpec(partIISpec);
								log.info("PartIISpec Feature is " + features);
								configDidSelection.setDisPartIIspecvlRespAvl(CVDDMConstant.STRING_Y);
								configDidSelection.setPartIISpecFeatures(features);
								configDidFeatureSelectionList.add(configDidSelection);
							}

						}

					} catch (Exception e) {
						log.severe(CvddmUtil.getStackTraceContent(e));
						throw new CVDDMBusinessException(
								new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
								CvddmUtil.getStackTraceContent(e), e);
					}
				}

			}

			if (!CvddmUtil.isObjectEmpty(configDidFeatureSelectionList) && !configDidFeatureSelectionList.isEmpty()) {
				this.partIISpecRespAval = CVDDMConstant.STRING_Y;
			} else {
				this.partIISpecRespAval = CVDDMConstant.STRING_N;
			}

		}

	}

	private boolean validateRespOfConfigDidFeatureScreen() {

		boolean validResp = true;
		if (!CvddmUtil.isObjectEmpty(this.configDidFeatureSelectionList) && !configDidFeatureSelectionList.isEmpty()) {

			for (ConfigDidFeatureSelection partNumbersSelection : this.configDidFeatureSelectionList) {

				if ((partNumbersSelection.getDisPartIIspecvlRespAvl().equals(CVDDMConstant.STRING_Y))) {
					List<PartIISpecFeatures> selectedConfigdids = partNumbersSelection.getPartIISpecFeaturesslctd();

					Iterator<PartIISpecFeatures> selection = selectedConfigdids.listIterator();
					while (selection.hasNext()) {
						PartIISpecFeatures partIIspecfeatures = selection.next();

						log.info("$$$$ Did Id &&&&" + partIIspecfeatures.getId());
						log.info("$$$$ Did Name &&&&" + partIIspecfeatures.getName());
						log.info("$$$$ Did value &&&&" + partIIspecfeatures.getDidValue());
						if (TextUtil.isBlankOrNull(partIIspecfeatures.getDidValue())) {
							// partIIspecfeatures.setSelectedConfig(true);
							FacesContext.getCurrentInstance().addMessage(CVDDMConstant.JSF_ID_CONFIG_DID_RESPMSG,
									new FacesMessage(FacesMessage.SEVERITY_ERROR,
											CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
													CVDDMConstant.VAL_MSG_APN_SLCT_CONFIG_DID) + " - "
													+ partIIspecfeatures.getId(),
													CVDDMConstant.VALIDATION_ERR));

							validResp = false;
						}
					}

				}

			}
		}

		return validResp;
	}

	public String requiredPartIISpecPart(String inputPartIISpecParam) {
		String partIIpsec = "";

		if (null != inputPartIISpecParam) {
			String[] partIIspecs = inputPartIISpecParam.split(";");

			for (int i = 0; i < partIIspecs.length; i++) {
				if (partIIspecs[i].contains(CVDDMConstant.PARTIISPEC_ID)) {
					partIIpsec = partIIspecs[i].replace(CVDDMConstant.PARTIISPEC_ID, "");
				}

			}

		} else {
			log.info("InputPartIISpec is " + inputPartIISpecParam);
		}
		return partIIpsec;

	}

	private List<PartIISpecFeatures> getFeatureListFromPartIISpec(byte[] partIiSpecFileEntry) {

		final String METHOD_NAME = "getFeatureListFromPartIISpec";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<PartIISpecFeatures> features = new ArrayList<>();

		try {

			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();

			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(new InputSource(new ByteArrayInputStream(partIiSpecFileEntry)));

			doc.getDocumentElement().normalize();
			log.info("Root element :" + doc.getDocumentElement().getNodeName());

			NodeList nList = doc.getElementsByTagName(CVDDMConstant.PARTIISPEC_DID_TAG_NAME);

			Node requiredNode = null;
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node cureNode = nList.item(temp);
				log.info("Current Element is :" + cureNode.getNodeName());

				if (cureNode.getNodeType() == Node.ELEMENT_NODE) {

					// Get attributes for this Node
					NamedNodeMap attributes = cureNode.getAttributes();
					int numAttrs = attributes.getLength();
					for (int i = 0; i < numAttrs; i++) {

						Attr attr = (Attr) attributes.item(i);

						String attrName = attr.getNodeName();
						String attrValue = attr.getNodeValue();

						// Check if we got Proper Node
						if (TextUtil.isNotBlankOrNull(attrName)
								&& CVDDMConstant.PARTIISPEC_FEATURE_HEADER_ID.equals(attrName)
								&& TextUtil.isNotBlankOrNull(attrValue)) {

							requiredNode = cureNode;
							log.info("Now Got the required Node, Get ALL Features Now");

							Element requiredNodeElement = (Element) requiredNode;

							String featureName = requiredNodeElement
									.getElementsByTagName(CVDDMConstant.PARTIISPEC_FEATURE_HEADER_NAME).item(0)
									.getTextContent().replace("/", "_");
							PartIISpecFeatures p2sFeatures = new PartIISpecFeatures();
							p2sFeatures.setId(attrValue.replace(CVDDMConstant.PARTIISPEC_DID_REPLACE, ""));
							p2sFeatures.setName(featureName);
							NodeList subFieldNodeList = requiredNodeElement
									.getElementsByTagName(CVDDMConstant.SUB_FIELD);

							List<SubFieldListFeatures> subFieldListFeatures = new ArrayList<>();
							for (int featureIndex = 0; featureIndex < subFieldNodeList.getLength(); featureIndex++) {
								SubFieldListFeatures subFieldListFeaturess = new SubFieldListFeatures();
								Node nNode1 = subFieldNodeList.item(featureIndex);
								Element eElement1 = (Element) nNode1;
								String subfieldfeatureId = eElement1.getAttributeNode(CVDDMConstant.ID).getValue();
								String subfieldfeatureName = eElement1.getElementsByTagName(CVDDMConstant.NAME).item(0)
										.getTextContent().replace("/", "_");
								String subfieldmsbbit = eElement1.getElementsByTagName(CVDDMConstant.MOST_SIG_BIT)
										.item(0).getTextContent();
								String subfieldleastsigbit = eElement1.getElementsByTagName(CVDDMConstant.LEAST_SIG_BIT)
										.item(0).getTextContent();

								subFieldListFeaturess.setId(subfieldfeatureId);
								subFieldListFeaturess.setName(subfieldfeatureName);
								subFieldListFeaturess.setMostsigbit(subfieldmsbbit);
								subFieldListFeaturess.setLeastsigbit(subfieldleastsigbit);

								NodeList dataDefinitionList = eElement1
										.getElementsByTagName(CVDDMConstant.DATA_DEFINITION);
								Node definationNode = dataDefinitionList.item(0);

								if (definationNode != null) {
									List<EnumertedParameter> enumertedParameterList = new ArrayList<>();
									NodeList nodeList = definationNode.getChildNodes();

									for (int j = 0; j < nodeList.getLength(); j++) {
										Node childNode = nodeList.item(j);

										if (CVDDMConstant.ENUMERATED_PARAMETERS.equals(childNode.getNodeName())) {

											Node enumParam = nodeList.item(j);
											NodeList enumnodeList = enumParam.getChildNodes();
											for (int k = 0; k < enumnodeList.getLength(); k++) {
												Node enumNode = enumnodeList.item(k);

												if (CVDDMConstant.ENUM_MEMBER.equals(enumNode.getNodeName())) {
													EnumertedParameter enumertedParametervalues = new EnumertedParameter();
													Element eElement2 = (Element) enumNode;

													String value = eElement2
															.getElementsByTagName(CVDDMConstant.ENUM_VALUE).item(0)
															.getTextContent();

													String decription = eElement2
															.getElementsByTagName(CVDDMConstant.DESCRIPTION).item(0)
															.getTextContent();
													enumertedParametervalues.setEnumValue(value);
													enumertedParametervalues.setDescription(decription);
													enumertedParameterList.add(enumertedParametervalues);
												}

											}

										}
									}
									subFieldListFeaturess.setEnumertedParameters(enumertedParameterList);
								}

								subFieldListFeatures.add(subFieldListFeaturess);
							}
							p2sFeatures.setSubFieldListFeatureslist(subFieldListFeatures);
							features.add(p2sFeatures);
						}
					}

				}
			}
		} catch (SAXParseException e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR,
							CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
									CVDDMConstant.INVALID_MDX_FILE),
							CVDDMConstant.VALIDATION_ERR));

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);

		}

		log.exiting(CLASS_NAME, METHOD_NAME);
		return features;
	}
	/*** End Change :User Story: US1064102 -- Config did selection screen **/

}
