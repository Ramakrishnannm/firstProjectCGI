/**
 * 
 */
package com.ford.cvddm.inbound.testdevicescheduler.ui.bean;

/**
 * @author NGUPTA18
 *
 */
public interface DeleteMeBeforeProjectGoLive {

}
