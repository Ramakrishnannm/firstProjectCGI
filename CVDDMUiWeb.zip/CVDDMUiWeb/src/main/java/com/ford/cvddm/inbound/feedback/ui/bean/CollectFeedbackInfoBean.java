/**
 * 
 */
package com.ford.cvddm.inbound.feedback.ui.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.inject.Inject;

import com.ford.cvddm.app.business.list.ListCvddmFeebackBF;
import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.domain.application.de.CvddmFeedbackRcrdDE;
import com.ford.cvddm.domain.master.de.CvddmScreenInfoDE;
import com.ford.cvddm.inbound.layer.base.CVDDMBaseBean;
import com.ford.cvddm.sob.business.layer.CVDDMBusinessException;
import com.ford.it.exception.FordExceptionAttributes;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;
import com.ford.it.util.TextUtil;

/**
 * This class is used for cvddm feedback functionality
 * 
 * @author RPADI
 *
 */
@ManagedBean
@ViewScoped
public class CollectFeedbackInfoBean extends CVDDMBaseBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final String CLASS_NAME = CollectFeedbackInfoBean.class.getName();

	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	private String feedbackDescription = "";

	public String getFeedbackDescription() {
		return feedbackDescription;
	}

	public void setFeedbackDescription(String feedbackDescription) {
		this.feedbackDescription = feedbackDescription;
	}

	private String feedbackFor; // Feedback For
	private Integer rating;
	private String feedbackSuggestion;

	public String getFeedbackSuggestion() {
		return feedbackSuggestion;
	}

	public void setFeedbackSuggestion(String feedbackSuggestion) {
		this.feedbackSuggestion = feedbackSuggestion;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

	private List<CvddmScreenInfoDE> feedbackForList;

	private List<SelectItem> feedbackForListValues;

	public List<SelectItem> getFeedbackForListValues() {
		return feedbackForListValues;
	}

	public void setFeedbackForListValues(List<SelectItem> mainForListValues) {
		this.feedbackForListValues = mainForListValues;
	}

	private boolean alreadyRendered;

	public boolean isAlreadyRendered() {
		return alreadyRendered;
	}

	public void setAlreadyRendered(boolean alreadyRendered) {
		this.alreadyRendered = alreadyRendered;
	}

	@Inject
	private ListCvddmFeebackBF listCvddmFeebackBF;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ford.it.jsfcore.bean.JcBaseBean#preRenderViewStartWorkflowTM()
	 */
	@Override
	protected void preRenderViewStartWorkflowTM() {

		log.exiting(CLASS_NAME, "preRenderViewStartWorkflowTM");
	}

	public void preRenderCreateFeedbackRecord() {

		final String METHOD_NAME = "preRenderCreateFeedbackRecord";
		log.entering(CLASS_NAME, METHOD_NAME);

		if (!alreadyRendered) {

			this.populateFeedBackForDrpDown();

			this.setAlreadyRendered(true);

		}

		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	@Override
	protected void preRenderViewTM() {
		preRenderCreateFeedbackRecord();

	}

	public String getFeedbackFor() {
		return feedbackFor;
	}

	public void setFeedbackFor(String feedbackFor) {
		this.feedbackFor = feedbackFor;
	}

	/**
	 * @return the FeedbackForList
	 */
	public List<CvddmScreenInfoDE> getFeedbackForList() {
		return feedbackForList;
	}

	/**
	 * @param FeedbackForList
	 *            the FeedbackForList to set
	 */
	public void setFeedbackForList(List<CvddmScreenInfoDE> feedbackForList) {
		this.feedbackForList = feedbackForList;
	}

	private String pageName;

	public String getPageName() {
		return pageName;
	}

	public void setPageName(String pageName) {
		this.pageName = pageName;
	}

	public void populateFeedBackForDrpDown() {

		final String METHOD_NAME = "populateFeedBackForDrpDown";

		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			List<CvddmScreenInfoDE> pageList = listCvddmFeebackBF.retrieveAllScreens();

			ListIterator<CvddmScreenInfoDE> listItr = pageList.listIterator();

			feedbackForListValues = new ArrayList<>();
			while (listItr.hasNext()) {

				CvddmScreenInfoDE cvddmScreenInfoDE = listItr.next();

				SelectItem selectItem = new SelectItem(cvddmScreenInfoDE.getCvddmScreenId(),
						cvddmScreenInfoDE.getCvdmScreenName());

				if (!cvddmScreenInfoDE.getCvdmScreenName().equals(CVDDMConstant.FEEDBACK_PAGE_ACRS_SITE)
						&& !cvddmScreenInfoDE.getCvdmScreenName().equals(CVDDMConstant.FEEDBACK_PAGE_ALL_MENU)
						&& !cvddmScreenInfoDE.getCvdmScreenName().equals(CVDDMConstant.FEEDBACK_PAGE_ALL_SUB_MENUS)) {
					feedbackForListValues.add(selectItem);
				}
				setFeedbackForListValues(feedbackForListValues);

			}

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * Method Name: submitFeedbackData
	 * 
	 * @Description: This method would insert Feedback Data Record in Database.
	 * @param :
	 *            None
	 * @return String
	 */
	public String submitFeedbackData() {

		String navigation = "";

		final String METHOD_NAME = "submitFeedbackData";

		boolean isSuccess = true;

		log.entering(CLASS_NAME, METHOD_NAME);

		try {
			navigation = "/validation/collectFeedbackInfo.faces?faces-redirect=true";

			if (isSuccess) {

				Map<String, Object> inputDataMap = populateInputDataMap();

				CvddmFeedbackRcrdDE cvddmFeedbackRcrdDE = listCvddmFeebackBF.saveCvddmFeedbackRcrd(inputDataMap);

				if (!CvddmUtil.isObjectEmpty(cvddmFeedbackRcrdDE)) {

					FacesContext.getCurrentInstance().addMessage(null,
							new FacesMessage(FacesMessage.SEVERITY_INFO,
									CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
											CVDDMConstant.FEEDBACK_CRT_SUCCESS_MSG),
									null));
					clearFormVariables();
				} else {

					FacesContext.getCurrentInstance()
							.addMessage(null,
									new FacesMessage(FacesMessage.SEVERITY_ERROR,
											CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
													CVDDMConstant.FEEDBACK_CRT_FAIL_MSG),
											CVDDMConstant.VALIDATION_ERR));
				}
			}

			log.exiting(CLASS_NAME, METHOD_NAME);

		} catch (Exception e) {
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR,
							CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
									CVDDMConstant.FEEDBACK_CRT_FAIL_MSG),
							CVDDMConstant.VALIDATION_ERR));
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);

		}
		return navigation;
	}

	/**
	 * Method Name: clearFormVariables
	 * 
	 * @Description: This method would be used to clear values of Form.
	 * @param :
	 *            None
	 * @return Void
	 */

	public void clearFormVariables() {

		feedbackFor = null;
		feedbackDescription = null;
		feedbackSuggestion = null;
		rating = null;

	}

	/**
	 * Method Name: populateInputDataMap
	 * 
	 * @Description: This method would populate InputDataMap with the values entered
	 *               by User on Create Feedback Record Screen.
	 * @param :
	 *            none
	 * @return Map<String, Object> tempMap
	 ***/

	public Map<String, Object> populateInputDataMap() {

		final String METHOD_NAME = "populateInputDataMap";

		Map<String, Object> tempMap = new HashMap<>();

		CvddmFeedbackRcrdDE cvddmFeedbackRcrdDE = null;

		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			cvddmFeedbackRcrdDE = new CvddmFeedbackRcrdDE();
	
			if (TextUtil.isNotBlankOrNull(this.pageName)) {

				Long cvddmScreenId = Long.valueOf(listCvddmFeebackBF.retrieveSelectedScreenNameId(this.pageName));

				tempMap.put(CVDDMConstant.CVDDM_SCREEN_ID_PK, cvddmScreenId);
			}

			if (this.rating != null) {

				cvddmFeedbackRcrdDE.setRating(this.rating);
			}

			if (TextUtil.isNotBlankOrNull(this.feedbackDescription)) {

				cvddmFeedbackRcrdDE.setCvddmFeedbackDesc(this.feedbackDescription);
			}

			if (TextUtil.isNotBlankOrNull(this.feedbackSuggestion)) {

				cvddmFeedbackRcrdDE.setCvddmFeedbackSuggestion(this.feedbackSuggestion);
			}
			tempMap.put(CVDDMConstant.FEEDBACK_RCRD_DE_OBJ, cvddmFeedbackRcrdDE);

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

		return tempMap;
	}

}