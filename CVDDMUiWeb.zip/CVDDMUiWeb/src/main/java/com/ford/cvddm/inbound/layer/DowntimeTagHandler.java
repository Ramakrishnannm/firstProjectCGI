package com.ford.cvddm.inbound.layer;

import javax.faces.view.facelets.ComponentHandler;
import javax.faces.component.UIComponent;
import javax.faces.view.facelets.ComponentConfig;
import javax.faces.view.facelets.FaceletContext;


/**
 * DowntimeTagHandler : This class contains method for CVDDMCore Tags
 * defined in cvddmcore.taglib.xml
 * User Story :US890091
 * @author NGUPTA18
 *
 */

public class DowntimeTagHandler extends ComponentHandler {
	
	 /**
     * Logging Setup
     */
    private static final String CLASS_NAME =
    		DowntimeTagHandler.class.getName();

    /**
     * Logging Setup
     */
    private static final com.ford.it.logging.ILogger log =
            com.ford.it.logging.LogFactory.getInstance().getLogger(CLASS_NAME);

    DownTimeTagHandlerHelper downTimeTagHandlerHelper = new DownTimeTagHandlerHelper();
    
    
    

    /**
     * Construct a DowntimeTagHandler instance
     * 
     * @param config component config
     */
    public DowntimeTagHandler(final ComponentConfig config) {
        super(config);

    }

    /**
     * @see javax.faces.view.facelets.ComponentHandler#onComponentCreated(javax.faces.view.facelets.FaceletContext,
     *      javax.faces.component.UIComponent, javax.faces.component.UIComponent)
     */
    @Override
    public void onComponentCreated(final FaceletContext faceletContext,
            final UIComponent uiDowntime, final UIComponent parent) {
        final String METHOD_NAME = "onComponentCreated";
        log.entering(CLASS_NAME, METHOD_NAME);
        super.onComponentCreated(faceletContext, uiDowntime, parent);
        this.downTimeTagHandlerHelper.onComponentCreate(faceletContext, uiDowntime, parent);
    }

}