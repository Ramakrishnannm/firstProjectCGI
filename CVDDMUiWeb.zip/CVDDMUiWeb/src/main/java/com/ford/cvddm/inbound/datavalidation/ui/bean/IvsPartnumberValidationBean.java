package com.ford.cvddm.inbound.datavalidation.ui.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.stream.Collectors;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.domain.env.de.CvddmEnvironmentDE;
import com.ford.cvddm.env.business.list.ListCvddmEnvironmentBF;
import com.ford.cvddm.inbound.layer.base.CVDDMBaseBean;
import com.ford.cvddm.inbound.layer.util.BannersUtil;
import com.ford.cvddm.inbound.layer.util.CommonUtil;
import com.ford.cvddm.inbound.layer.util.PopupAlertUtil;
import com.ford.cvddm.outbound.givis.rest.GIVISRestClients;
import com.ford.cvddm.outbound.givis.rest.ProgramCodeTO;
import com.ford.cvddm.outbound.ivsu.rest.IVSURestClients;
import com.ford.cvddm.outbound.ivsu.rest.ValidateIVSFeed;
import com.ford.cvddm.outbound.ivsu.rest.ValidateIVSFeedRequest;
import com.ford.cvddm.outbound.ivsu.rest.ValidateIVSFeedResponse;
import com.ford.cvddm.sob.business.layer.CVDDMBusinessException;
import com.ford.it.exception.FordExceptionAttributes;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;

@ManagedBean
@ViewScoped
/**
 * For US1021877 : IVS feed part number validation
 * 
 * @author MJEYARAJ
 *
 */
public class IvsPartnumberValidationBean extends CVDDMBaseBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private static final String CLASS_NAME = IvsPartnumberValidationBean.class.getName();

	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	private List<ProgramCodeTO> programCodes;

	private List<String> partNumbers; // Hold Values for "Partnumbers" Drop Down.

	private String selectedPartNumber;

	private boolean alreadyRendered;

	private List<String> envList; // Hold Values for "Environment" Drop Down.

	private String selectedEnv;

	private Set<String> nodeList; // Hold Values for "Node" Drop Down.

	private String selectedNode;

	private boolean partNumberRendered; // To validate the Partnumber rendered or not

	private String disIPNRespAvl = CVDDMConstant.STRING_N;

	private List<ValidateIVSFeedResponse> validateIVSFeedList; // Response from IVS for datatble.

	private List<ValidateIVSFeedResponse> filteredValidateIVSFeedList;

	@Override
	protected void preRenderViewStartWorkflowTM() {
		log.exiting(CLASS_NAME, "preRenderViewStartWorkflowTM");

	}

	/*** Start Change: User Story : US987948 ***/
	@Override
	protected void preRenderViewTM() {

		String popUpContent = PopupAlertUtil.prepareAlertsMsgDesc(CVDDMConstant.ADMIN_SCRN_CD,
				CVDDMConstant.IVS_PARTNUMBER_VALIDATION_SCRN_CD);
		this.setPopUpContent(popUpContent);
		this.popUpContent = popUpContent;

		String bannerContent = BannersUtil.prepareBannerMsgDesc(CVDDMConstant.ADMIN_SCRN_CD,
				CVDDMConstant.IVS_PARTNUMBER_VALIDATION_SCRN_CD);
		this.setBannerContent(bannerContent);
		this.bannerContent = bannerContent;

		preRenderIvsValidationRecord();
	}

	/*** End Change: User Story : US987948 ***/

	public Set<String> getNodeList() {
		return nodeList;
	}

	public List<ValidateIVSFeedResponse> getFilteredValidateIVSFeedList() {
		return filteredValidateIVSFeedList;
	}

	public void setFilteredValidateIVSFeedList(List<ValidateIVSFeedResponse> filteredValidateIVSFeedList) {
		this.filteredValidateIVSFeedList = filteredValidateIVSFeedList;
	}

	public String getDisIPNRespAvl() {
		return disIPNRespAvl;
	}

	public void setDisIPNRespAvl(String disIPNRespAvl) {
		this.disIPNRespAvl = disIPNRespAvl;
	}

	public void setNodeList(Set<String> set) {
		this.nodeList = set;
	}

	public String getSelectedNode() {
		return selectedNode;
	}

	public void setSelectedNode(String selectedNode) {
		this.selectedNode = selectedNode;
	}

	public List<ValidateIVSFeedResponse> getValidateIVSFeedList() {
		return validateIVSFeedList;
	}

	public void setValidateIVSFeedList(List<ValidateIVSFeedResponse> validateIVSFeedList) {
		this.validateIVSFeedList = validateIVSFeedList;
	}

	public boolean isPartNumberRendered() {
		return partNumberRendered;
	}

	public void setPartNumberRendered(boolean partNumberRendered) {
		this.partNumberRendered = partNumberRendered;
	}

	public List<String> getPartNumbers() {
		return partNumbers;
	}

	public void setPartNumbers(List<String> partNumbers) {
		this.partNumbers = partNumbers;
	}

	public String getSelectedPartNumber() {
		return selectedPartNumber;
	}

	public void setSelectedPartNumber(String selectedPartNumber) {
		this.selectedPartNumber = selectedPartNumber;
	}

	public List<String> getEnvList() {
		return envList;
	}

	public void setEnvList(List<String> envList) {
		this.envList = envList;
	}

	public String getSelectedEnv() {
		return selectedEnv;
	}

	public void setSelectedEnv(String selectedEnv) {
		this.selectedEnv = selectedEnv;
	}

	public List<ProgramCodeTO> getProgramCodes() {
		return programCodes;
	}

	public void setProgramCodes(List<ProgramCodeTO> programCodes) {
		this.programCodes = programCodes;
	}

	public boolean isAlreadyRendered() {
		return alreadyRendered;
	}

	public void setAlreadyRendered(boolean alreadyRendered) {
		this.alreadyRendered = alreadyRendered;
	}

	@Inject
	private ListCvddmEnvironmentBF listCvddmEnvironmentBF;

	/**
	 * Pre rendering method
	 */
	@SuppressWarnings("unchecked")
	public void preRenderIvsValidationRecord() {

		final String METHOD_NAME = "preRenderIvsValidationRecord";
		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			if (!alreadyRendered) { // Validating the rendering for unwanted loading

				setEnvList(CommonUtil.retrieveEnvironments(listCvddmEnvironmentBF));
				setPartNumberRendered(false);

				ResourceBundle bundle = CvddmUtil.getPropertiesFile(CVDDMConstant.NODES_ACRONYMS_PROPERTIES);
				setNodeList(bundle.keySet());

				setAlreadyRendered(true);
			}

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * Method Name: retrievePartNumbers
	 * 
	 * @Description: Method to retrieve the PartNumbers
	 * @param :
	 *            none
	 * @return none
	 */
	public void retrievePartNumbers() {

		final String METHOD_NAME = "retrievePartNumbers";
		log.entering(CLASS_NAME, METHOD_NAME);

		GIVISRestClients gIVISRestClients = new GIVISRestClients();

		List<ProgramCodeTO> partNumbersFromGivis;

		try {
			partNumbersFromGivis = gIVISRestClients.getPartNumbersFromGivis(this.selectedEnv);

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}

		setProgramCodes(partNumbersFromGivis);
		generatePartNumbersDropdownValues(partNumbersFromGivis);
		setPartNumberRendered(true);
		clearExistingForm();
		clearExistingVehicleData();
		clearExistingEcuData();
		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * Method Name: generatePartNumbersDropdownValues
	 * 
	 * @Description: Private method to generate the PartNumbers dropdown values
	 * @param :
	 *            List<ProgramCodeTO>
	 * @return none
	 */
	private void generatePartNumbersDropdownValues(List<ProgramCodeTO> programCodes) {

		final String METHOD_NAME = "generatePartNumbersDropdownValues";
		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			List<String> partNumbersForDropDown = new ArrayList<>();

			for (ProgramCodeTO programCode : programCodes) {
				partNumbersForDropDown.add(programCode.getProgramCode() + " - " + programCode.getModelYear() + " - "
						+ programCode.getVehicleName());
			}

			this.setPartNumbers(partNumbersForDropDown);

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

	}

	/**
	 * Method Name: validateIVSData
	 * 
	 * @Description: Method to validate the IVS data
	 * @param :
	 *            none
	 * @return none
	 */
	public String validateIVSData() {

		final String METHOD_NAME = "validateIVSData";
		log.entering(CLASS_NAME, METHOD_NAME);

		String navigation = "/validation/ivsPartnumberValidation.faces?faces-redirect=true";

		clearExistingForm();

		if (partNumberValidation()) {
			try {

				if (!CvddmUtil.isObjectEmpty(validateIVSFeedList)) {
					validateIVSFeedList.clear();
				}

				ValidateIVSFeedRequest validateIVSFeedRequest = new ValidateIVSFeedRequest();
				ValidateIVSFeed validateIVSFeed = new ValidateIVSFeed();

				String[] partNumberData = this.selectedPartNumber.split("-");

				validateIVSFeed.setProgramCode(partNumberData[0]);
				validateIVSFeed.setModelYear(Integer.parseInt(partNumberData[1].trim()));
				validateIVSFeed.setNode(this.selectedNode.substring(0, 3));
				// Flag - 'P' : Default value
				validateIVSFeed.setFlag(CVDDMConstant.IVS_FEED_FLAG);
				validateIVSFeedRequest.setValidateIVSFeed(validateIVSFeed);

				IVSURestClients iVSURestClients = new IVSURestClients();

				List<ValidateIVSFeedResponse> validateIVSFeedResponse = iVSURestClients
						.validateIVSFeed(validateIVSFeedRequest, this.selectedEnv);

				if (CvddmUtil.isObjectEmpty(validateIVSFeedResponse)) {
					FacesContext.getCurrentInstance().addMessage(null,
							new FacesMessage(FacesMessage.SEVERITY_ERROR,
									CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
											CVDDMConstant.NO_VAL_DATA_MSG),
									CVDDMConstant.VALIDATION_ERR));
					setDisIPNRespAvl(CVDDMConstant.STRING_N);
				} else {

					if (validateIVSFeedResponse.size() == 0) {
						FacesContext.getCurrentInstance().addMessage(null,
								new FacesMessage(FacesMessage.SEVERITY_ERROR,
										CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
												CVDDMConstant.NO_VAL_DATA_MSG),
										CVDDMConstant.VALIDATION_ERR));
						setDisIPNRespAvl(CVDDMConstant.STRING_N);
					} else {
						setValidateIVSFeedList(validateIVSFeedResponse);
						setDisIPNRespAvl(CVDDMConstant.STRING_Y);
					}
				}

			} catch (Exception e) {
				log.severe(CvddmUtil.getStackTraceContent(e));
				throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
						CvddmUtil.getStackTraceContent(e), e);
			}
		}

		log.exiting(CLASS_NAME, METHOD_NAME);
		return navigation;

	}

	/**
	 * Method Name: clearExistingForm
	 * 
	 * @Description: Method to clear existing output panel
	 * @param :
	 *            none
	 * @return none
	 */
	public void clearExistingForm() {
		final String METHOD_NAME = "clearExistingForm";
		log.entering(CLASS_NAME, METHOD_NAME);

		setDisIPNRespAvl(CVDDMConstant.STRING_N);

		if (!CvddmUtil.isObjectEmpty(this.validateIVSFeedList)) {
			this.validateIVSFeedList.clear();
		}

		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * Method Name: clearExistingForm
	 * 
	 * @Description: Method to clear existing output panel
	 * @param :
	 *            none
	 * @return none
	 */
	public void clearEntireForm() {
		final String METHOD_NAME = "clearExistingForm";
		log.entering(CLASS_NAME, METHOD_NAME);

		setDisIPNRespAvl(CVDDMConstant.STRING_N);

		this.selectedEnv = null;
		this.selectedNode = null;
		this.selectedPartNumber = null;

		if (!CvddmUtil.isObjectEmpty(this.validateIVSFeedList)) {
			this.validateIVSFeedList.clear();
		}

		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * Method Name: clearExistingVehicleData
	 * 
	 * @Description: Method to clear existing Vehicle data
	 * @param :
	 *            none
	 * @return none
	 */
	public void clearExistingVehicleData() {
		final String METHOD_NAME = "clearExistingVehicleData";
		log.entering(CLASS_NAME, METHOD_NAME);

		if (!CvddmUtil.isObjectEmpty(this.selectedPartNumber)) {
			this.selectedPartNumber = "";
		}

		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * Method Name: clearExistingEcuData
	 * 
	 * @Description: Method to clear existing ecu data
	 * @param :
	 *            none
	 * @return none
	 */
	public void clearExistingEcuData() {
		final String METHOD_NAME = "clearExistingEcuData";
		log.entering(CLASS_NAME, METHOD_NAME);

		if (!CvddmUtil.isObjectEmpty(this.selectedNode)) {
			this.selectedNode = "";
		}

		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * Method Name: partNumberValidation
	 * 
	 * @Description: Method to validate the submit form
	 * @param :
	 *            none
	 * @return boolean
	 */
	private boolean partNumberValidation() {

		final String METHOD_NAME = "validateIVSData";
		log.entering(CLASS_NAME, METHOD_NAME);

		boolean validationSuccessfull = true;

		if (("".equals(this.selectedPartNumber) || ("".equals(this.selectedPartNumber)))) {
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR,
							CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
									CVDDMConstant.PART_NUMBER_VAL_MSG),
							CVDDMConstant.VALIDATION_ERR));
			validationSuccessfull = false;
		}

		if (("".equals(this.selectedNode) || ("".equals(this.selectedNode)))) {
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, CvddmUtil
							.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY, CVDDMConstant.NODE_VAL_MSG),
							CVDDMConstant.VALIDATION_ERR));
			validationSuccessfull = false;
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

		return validationSuccessfull;
	}

	/**
	 * Method Name: searchNodes
	 * 
	 * @Description: Method for auto completion of partnumbers
	 * @param :
	 *            String
	 * @return List<String>
	 */
	public List<String> searchPartNumbers(String query) {

		final String METHOD_NAME = "searchPartNumbers";
		log.entering(CLASS_NAME, METHOD_NAME);

		log.info("Query=" + query);

		try {

			if (CVDDMConstant.EMPTY_STRING.equals(query)) {
				return this.partNumbers;
			}

			else {
				return this.partNumbers.stream() // convert list to stream
						.filter(line -> line.contains(query.toUpperCase())) // filter with query
						.collect(Collectors.toList()); // collect the output and convert streams to
			}

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));	
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

		return new ArrayList<>();
	}

	/**
	 * Method Name: searchNodes
	 * 
	 * @Description: Method for auto completion of nodes
	 * @param :
	 *            String
	 * @return List<String>
	 */
	public List<String> searchNodes(String query) {

		final String METHOD_NAME = "searchNodes";
		log.entering(CLASS_NAME, METHOD_NAME);

		log.info("Query=" + query);

		try {

			if (CVDDMConstant.EMPTY_STRING.equals(query)) {
				return this.nodeList.stream().collect(Collectors.toList());
			}

			else {
				return this.nodeList.stream() // convert list to stream
						.filter(line -> line.contains(query)) // filter with query
						.collect(Collectors.toCollection(ArrayList::new)); // collect the output and convert streams to
			}

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		log.exiting(CLASS_NAME, METHOD_NAME);
		return new ArrayList<>();
	}

}