package com.ford.cvddm.inbound.common.pojo;

import java.util.List;

import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.domain.module.de.CvddmModuleDE;
import com.ford.cvddm.outbound.ivsu.rest.ValidateIVSFeedResponse;

/**
 * IO component for AddPartnumbers Screen
 * 
 * 
 * @author MJEYARAJ
 *
 */
public class PartNumbersSelection {

	// Selected Module
	private String node;

	// Object for Selected module
	private CvddmModuleDE cvddmModuleDE;

	// IVS Feed response for the selected module
	private List<ValidateIVSFeedResponse> validateIVSFeedResponse;

	// Selected IVS Feed response for the selected module - USER SELECTED OUTPUT
	private ValidateIVSFeedResponse vldteIvsFdRespSelected;
	
	// PartIISpec of selected IVS Feed Response
	private String partIISpec;

	// "Y" in case of IVS Feed Response Availability. "N" in case of
	// Non-Availability. In case of Non-Availability, node will not be considered
	// for further setup.
	private String disPnbrMdlLvlRespAvl = CVDDMConstant.STRING_N;

	private String disApplicationAvl = CVDDMConstant.STRING_N;	

	public String getPartIISpec() {
		return partIISpec;
	}

	public void setPartIISpec(String partIISpec) {
		this.partIISpec = partIISpec;
	}

	public CvddmModuleDE getCvddmModuleDE() {
		return cvddmModuleDE;
	}

	public void setCvddmModuleDE(CvddmModuleDE cvddmModuleDE) {
		this.cvddmModuleDE = cvddmModuleDE;
	}

	public ValidateIVSFeedResponse getVldteIvsFdRespSelected() {
		return vldteIvsFdRespSelected;
	}

	public void setVldteIvsFdRespSelected(ValidateIVSFeedResponse vldteIvsFdRespSelected) {
		this.vldteIvsFdRespSelected = vldteIvsFdRespSelected;
	}

	public String getDisApplicationAvl() {
		return disApplicationAvl;
	}

	public void setDisApplicationAvl(String disApplicationAvl) {
		this.disApplicationAvl = disApplicationAvl;
	}

	public String getDisPnbrMdlLvlRespAvl() {
		return disPnbrMdlLvlRespAvl;
	}

	public void setDisPnbrMdlLvlRespAvl(String disPnbrMdlLvlRespAvl) {
		this.disPnbrMdlLvlRespAvl = disPnbrMdlLvlRespAvl;
	}

	public String getNode() {
		return node;
	}

	public void setNode(String node) {
		this.node = node;
	}

	public List<ValidateIVSFeedResponse> getValidateIVSFeedResponse() {
		return validateIVSFeedResponse;
	}

	public void setValidateIVSFeedResponse(List<ValidateIVSFeedResponse> validateIVSFeedResponse) {
		this.validateIVSFeedResponse = validateIVSFeedResponse;
	}

}
