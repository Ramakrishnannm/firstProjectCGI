/**
 * 
 */
package com.ford.cvddm.inbound.datavalidation.ui.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.deltaspike.core.api.scope.GroupedConversationScoped;

import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.domain.env.de.CvddmEnvironmentDE;
import com.ford.cvddm.env.business.list.ListCvddmEnvironmentBF;
import com.ford.cvddm.gvms.business.GvmsGetCurrentLiteBF;
import com.ford.cvddm.history.business.HistoryUtilityBF;
import com.ford.cvddm.inbound.layer.base.CVDDMBaseBean;
import com.ford.cvddm.inbound.layer.util.BannersUtil;
import com.ford.cvddm.inbound.layer.util.PopupAlertUtil;
import com.ford.cvddm.outbound.gvms.getCurrentLite.GetCurrentLiteResponse;
import com.ford.cvddm.outbound.gvms.getCurrentLite.GetCurrentLiteResponseType;
import com.ford.cvddm.outbound.gvms.getCurrentLite.GvmsGetCurrentLiteParent;
import com.ford.cvddm.outbound.gvms.getCurrentLite.NodeDetail;
import com.ford.cvddm.outbound.gvms.getCurrentLite.StatusInfo;
import com.ford.cvddm.outbound.gvms.getCurrentLite.VehicleDetails;
import com.ford.cvddm.sob.business.layer.CVDDMBusinessException;
import com.ford.it.exception.FordExceptionAttributes;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;
import com.ford.it.util.TextUtil;

/**
 * @since US1076334
 * @author NGUPTA18
 * Description: This Bean contains method for GVMS Multi Vin Validation functionality.
 *
 */
@Named
@GroupedConversationScoped
public class GvmsVinValidationMultipleBean extends CVDDMBaseBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final String CLASS_NAME = GvmsVinValidationMultipleBean.class.getName();

	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	@Inject
	private GvmsGetCurrentLiteBF getCurrentLiteBF ;

	@Inject
	private ListCvddmEnvironmentBF listCvddmEnvironmentBF;

	@Inject
	private HistoryUtilityBF historyUtilityBF;


	private transient List<VehicleDetails> inputVinNumberLst = new ArrayList<VehicleDetails>();


	private String vinNumber;

	private String envType;

	private String isResponseDelivered;


	private  List<CvddmEnvironmentDE> environmentList;

	@Inject
	private  GvmsGetCurrentLiteParent currentLiteParent;

	private List<GvmsGetCurrentLiteParent> currentLiteParentList = new ArrayList<GvmsGetCurrentLiteParent>();


	private String disGVMSRespAvl = CVDDMConstant.STRING_N ;

	public String getDisGVMSRespAvl() {
		return disGVMSRespAvl;
	}

	public void setDisGVMSRespAvl(String disGVMSRespAvl) {
		this.disGVMSRespAvl = disGVMSRespAvl;
	}

	/**
	 * @return the environmentList
	 */
	public List<CvddmEnvironmentDE> getEnvironmentList() {
		return environmentList;
	}

	/**
	 * @param environmentList the environmentList to set
	 */
	public void setEnvironmentList(List<CvddmEnvironmentDE> environmentList) {
		this.environmentList = environmentList;
	}



	@Override
	protected void preRenderViewStartWorkflowTM() {

		log.exiting(CLASS_NAME, "preRenderViewStartWorkflowTM");

	}



	/**
	 * @return the envType
	 */
	public String getEnvType() {
		return envType;
	}

	/**
	 * @param envType the envType to set
	 */
	public void setEnvType(String envType) {
		this.envType = envType;
	}

	/**
	 * @return the isResponseDelivered
	 */
	public String getIsResponseDelivered() {
		return isResponseDelivered;
	}

	/**
	 * @param isResponseDelivered the isResponseDelivered to set
	 */
	public void setIsResponseDelivered(String isResponseDelivered) {
		this.isResponseDelivered = isResponseDelivered;
	}

	/**
	 * @return the vinNumber
	 */
	public String getVinNumber() {
		return vinNumber;
	}

	/**
	 * @param vinNumber the vinNumber to set
	 */
	public void setVinNumber(String vinNumber) {
		this.vinNumber = vinNumber;
	}

	/**
	 * @return the inputVinNumberLst
	 */
	public List<VehicleDetails> getInputVinNumberLst() {
		return inputVinNumberLst;
	}

	/**
	 * @param inputVinNumberLst the inputVinNumberLst to set
	 */
	public void setInputVinNumberLst(List<VehicleDetails> inputVinNumberLst) {	
		this.inputVinNumberLst = inputVinNumberLst;
	}

	private boolean disableAddVinButton;

	public boolean isDisableAddVinButton() {
		return disableAddVinButton;
	}

	public void setDisableAddVinButton(boolean disableAddVinButton) {
		this.disableAddVinButton = disableAddVinButton;
	}

	/**
	 * @return the currentLiteParentList
	 */
	public List<GvmsGetCurrentLiteParent> getCurrentLiteParentList() {
		return currentLiteParentList;
	}

	/**
	 * @param currentLiteParentList the currentLiteParentList to set
	 */
	public void setCurrentLiteParentList(List<GvmsGetCurrentLiteParent> currentLiteParentList) {
		this.currentLiteParentList = currentLiteParentList;
	}

	@Override
	protected void preRenderViewTM() {


		if(isNotPostBack()) {
			String popUpContent = PopupAlertUtil.prepareAlertsMsgDesc(CVDDMConstant.DATA_VALIDATION_SCRN_CD,
					CVDDMConstant.GVMS_DATA_VALIDATION_SCRN_CD);
			this.setPopUpContent(popUpContent);
			this.popUpContent = popUpContent;

			String bannerContent = BannersUtil.prepareBannerMsgDesc(CVDDMConstant.DATA_VALIDATION_SCRN_CD,
					CVDDMConstant.GVMS_DATA_VALIDATION_SCRN_CD);
			this.setBannerContent(bannerContent);
			this.bannerContent=bannerContent;

			getEnvironmentTypes();
		}
	}

	/**
	 * Method Name: getEnvironmentTypes
	 * 
	 * @Description: This method would load values for "Environment" Drop Down.
	 * @param :
	 *            none
	 * @return void
	 **/

	public void getEnvironmentTypes() {

		final String METHOD_NAME = "getEnvironmentTypes";

		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			List<CvddmEnvironmentDE> envList = listCvddmEnvironmentBF.fetchAllEnvRcrds();
			if(!CvddmUtil.isObjectEmpty(envList) && !envList.isEmpty()) {

				setEnvironmentList(envList);
			}

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * Method Name: getGVMSVinDtlsMultipleAll
	 * 
	 * @Description: This method would get values for particular VIN all Modules Code from GVMS System.
	 * @param :none
	 * @return void
	 **/

	public void getGVMSVinDtlsMultipleAll() {

		final String METHOD_NAME = "getGVMSVinDtlsMultipleAll";

		log.entering(CLASS_NAME, METHOD_NAME);


		List<VehicleDetails> vehicleDetailsLst = new ArrayList<VehicleDetails>();

		List<NodeDetail> nodeList = new ArrayList<NodeDetail>();

		VehicleDetails vehicleDetails = null;



		boolean isValidData = true;

		try {

			isValidData = isValidInputData() ;

			clearOldFormData(CVDDMConstant.STRING_Y);

			if(isValidData) {

				isResponseDelivered = CVDDMConstant.STRING_Y;
				setIsResponseDelivered(CVDDMConstant.STRING_Y);

				Iterator <VehicleDetails> listIterator = inputVinNumberLst.listIterator();

				while(listIterator.hasNext()) {

					VehicleDetails tempObj = listIterator.next();


					Map <String, Object> inputMap = new HashMap<String, Object>();

					disGVMSRespAvl = CVDDMConstant.STRING_N ;

					currentLiteParent = new GvmsGetCurrentLiteParent();

					currentLiteParent.setVinNumber(tempObj.getVin());


					vehicleDetails = new VehicleDetails();

					vehicleDetailsLst = new ArrayList<VehicleDetails>();

					nodeList = new ArrayList<NodeDetail>();



					GetCurrentLiteResponseType getCurrentLiteResponseType = null;

					GetCurrentLiteResponse getCurrentLiteResponse =  null;

					inputMap.put(CVDDMConstant.VIN_NUMBER,tempObj.getVin());

					inputMap.put(CVDDMConstant.ENV_TYPE,this.envType);

					getCurrentLiteResponseType = getCurrentLiteBF.getGetCurrentLiteResponseTypeForALL(inputMap);

					String overallMsg = null;

					if(!CvddmUtil.isObjectEmpty(getCurrentLiteResponseType) 
							&& !CvddmUtil.isObjectEmpty(getCurrentLiteResponseType.getGetCurrentLiteResponse())) {

						getCurrentLiteResponse = getCurrentLiteResponseType.getGetCurrentLiteResponse();

						vehicleDetails = getCurrentLiteResponseType.getGetCurrentLiteResponse().getVehicleDetails();
						vehicleDetailsLst.add(vehicleDetails);


						if(!CvddmUtil.isObjectEmpty(getCurrentLiteResponse.getNodeDetails()) &&
								!getCurrentLiteResponse.getNodeDetails().isEmpty()) {

							disGVMSRespAvl = CVDDMConstant.STRING_Y;
							nodeList = getCurrentLiteResponse.getNodeDetails();

						}
						else {

							disGVMSRespAvl = CVDDMConstant.STRING_N;
							overallMsg =prepareOverallStatusMsg(getCurrentLiteResponseType.getGetCurrentLiteResponse().getStatusInfo());

						}
					}


					currentLiteParent.setVehicleDetails(vehicleDetails);
					currentLiteParent.setVehicleDetailsLst(vehicleDetailsLst);
					currentLiteParent.setNodeList(nodeList);
					currentLiteParent.setOverallStatusMsg(overallMsg);

					currentLiteParent.setDisGVMSRespAvl(disGVMSRespAvl);
					currentLiteParentList.add(currentLiteParent);

					/** Start Change : User Story US1078610: ***/
					updateHistoryTable(nodeList,overallMsg,tempObj.getVin());
					/** End Change : User Story US1078610: ***/

				}
				// List will end here
				setCurrentLiteParentList(currentLiteParentList);
				this.setCurrentLiteParentList(currentLiteParentList);
			}
		}

		catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

	}

	/**
	 * Method Name: prepareOverallStatusMsg
	 * 
	 * @Description: Prepare GVMS Error Message when Node Details not available.
	 * @param :List <StatusInfo> statusInfosLst
	 * @return void
	 **/


	public String  prepareOverallStatusMsg(List <StatusInfo> statusInfosLst) {

		StringBuilder strBuilder = new StringBuilder();

		String hasNext = CVDDMConstant.STRING_N;

		for(StatusInfo  statusInfo : statusInfosLst) { 



			if(!CVDDMConstant.GVMS_SUCCESS_STATUS_CD.equalsIgnoreCase(statusInfo.getStatusCode())
					&& CVDDMConstant.GVMS_SOURCE.equalsIgnoreCase(statusInfo.getSource())) {

				if(CVDDMConstant.STRING_Y.equalsIgnoreCase(hasNext)) {
					strBuilder.append(statusInfo.getDetails()+" ; ");
					hasNext = CVDDMConstant.STRING_Y;
				}
				else {
					strBuilder.append(statusInfo.getDetails());
					hasNext = CVDDMConstant.STRING_Y;
				}

			}
		}

		return strBuilder.toString();

	}

	/**
	 * Method Name: clearOldFormData
	 * 
	 * @Description: This method would clear Old Form Data.
	 * @param :String value
	 * @return void
	 **/

	public void clearOldFormData(String value) {

		this.currentLiteParentList.clear();
		this.isResponseDelivered=null;
		setDisableAddVinButton(false);
		if(value.equalsIgnoreCase(CVDDMConstant.STRING_ALL)) {
			this.envType = null;
			this.inputVinNumberLst.clear();

		}
	}

	/**
	 * Method Name: addVinNumbers
	 * 
	 * @Description: This method would Add more Vin's.
	 * @param :None
	 * @return void
	 **/

	public void addVinNumbers() {

		log.info("addVinNumbers");

		Integer maxVinAllowed = Integer.valueOf(CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, 
				CVDDMConstant.NO_OF_VINS_ALLOWED));

		if(!CvddmUtil.isObjectEmpty(inputVinNumberLst) && 
				inputVinNumberLst.size() < maxVinAllowed) {

			inputVinNumberLst.add(new VehicleDetails());
		}
		else {
			setDisableAddVinButton(true);
			addLocalizedWarningMessage(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
					CVDDMConstant.NO_OF_VINS_VALID_MSG,maxVinAllowed.toString());
		}
	}

	/**
	 * Method Name: removeVinNumbers
	 * 
	 * @Description: This method would Delete Added VIN both from Input and Response.
	 * @param :None
	 * @return void
	 **/

	public void removeVinNumbers(VehicleDetails obj) {

		final String METHOD_NAME = "removeVinNumbers";

		try {

			log.info("removeVinNumbers");

			Integer maxVinAllowed = Integer.valueOf(CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, 
					CVDDMConstant.NO_OF_VINS_ALLOWED));

			boolean isVinAnotherIns = false;

			inputVinNumberLst.remove(obj);

			log.info("removeVinNumbers post response delete");

			Iterator<VehicleDetails> inputVINlst = inputVinNumberLst.iterator();

			while(inputVINlst.hasNext()) {

				VehicleDetails  details = inputVINlst.next();

				if(TextUtil.isNotBlankOrNull(obj.getVin()) && obj.getVin().equalsIgnoreCase(details.getVin())) {

					isVinAnotherIns = true;
					break;
				}	
			}

			if(!isVinAnotherIns) {

				Iterator<GvmsGetCurrentLiteParent> tempList = currentLiteParentList.iterator();

				while(tempList.hasNext()) {

					GvmsGetCurrentLiteParent liteParent = tempList.next();

					if(TextUtil.isNotBlankOrNull(obj.getVin()) && 
							obj.getVin().equalsIgnoreCase(liteParent.getVinNumber())) {
						tempList.remove();

					}
				}
			}

			if(!CvddmUtil.isObjectEmpty(inputVinNumberLst) && 
					inputVinNumberLst.size() < maxVinAllowed) {

				setDisableAddVinButton(false);
			}
		}
		catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}

	}

	/**
	 * Method Name: isValidInputData
	 * 
	 * @Description: This method would validate Data entered by User on Screen.
	 * @param :None
	 * @return boolean
	 **/

	public boolean isValidInputData() {

		StringBuilder vinErrorMsg = new StringBuilder();

		boolean isValidData = true;

		if(this.envType.equalsIgnoreCase(CVDDMConstant.STRING_N)) {

			isValidData = false;
			FacesContext.getCurrentInstance()
			.addMessage("gvmsVinValidationMultipleForm:envTypeId",
					new FacesMessage(FacesMessage.SEVERITY_ERROR,
							CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
									CVDDMConstant.ENV_REQUIRED_MSG),
							CVDDMConstant.VALIDATION_ERR));

		}

		if(inputVinNumberLst.isEmpty()) {

			isValidData = false;
			FacesContext.getCurrentInstance()
			.addMessage("gvmsVinValidationMultipleForm:vinsTable",
					new FacesMessage(FacesMessage.SEVERITY_ERROR,
							CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
									CVDDMConstant.ATLEAST_ONE_VIN_MSG),
							CVDDMConstant.VALIDATION_ERR));
		}

		if(isValidData) {

			Iterator <VehicleDetails> listIterator = inputVinNumberLst.listIterator();

			String vinValidMsg;

			while(listIterator.hasNext()) {

				VehicleDetails tempObj = listIterator.next();

				if(TextUtil.isBlankOrNull(tempObj.getVin())) {	
					isValidData = false;

					vinErrorMsg.append(CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
							CVDDMConstant.VIN_VALUE_NOT_AVAIL));
					vinErrorMsg.append(CVDDMConstant.BREAK_HTML);

					break;

				}
				else if(TextUtil.isNotBlankOrNull(tempObj.getVin())
						&& (tempObj.getVin().length() != Integer.valueOf(CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
								CVDDMConstant.VALID_VIN_LENGTH)) || !tempObj.getVin().matches(CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
										CVDDMConstant.VALID_VIN_FORMAT)))) {



					vinValidMsg = CVDDMConstant.VIN_NAME+tempObj.getVin()+" "+CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
							CVDDMConstant.MULTIVIN_VALID_MSG);

					vinErrorMsg.append(vinValidMsg);
					vinErrorMsg.append(CVDDMConstant.BREAK_HTML);
				}

			}

		}

		Set<String> setToReturn = findDuplicates(inputVinNumberLst);

		if(!setToReturn.isEmpty()) {

			String vinValidMsg;

			Iterator <String> setIterator = setToReturn.iterator();

			while(setIterator.hasNext()) {

				String tempVin = setIterator.next();
				if(!TextUtil.isBlankOrNull(tempVin)) {
					isValidData = false;
					vinValidMsg = CVDDMConstant.VIN_NAME+tempVin +" "+CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
							CVDDMConstant.DUPLICATE_VIN);

					vinErrorMsg.append(vinValidMsg);
					vinErrorMsg.append(CVDDMConstant.BREAK_HTML);
				}
			}	
		}

		if(!TextUtil.isBlankOrNull(vinErrorMsg.toString())) {

			isValidData = false;
			FacesContext.getCurrentInstance()
			.addMessage("gvmsVinValidationMultipleForm:vinsTable",
					new FacesMessage(FacesMessage.SEVERITY_ERROR,
							vinErrorMsg.toString(),
							CVDDMConstant.VALIDATION_ERR));
		}

		return isValidData;

	}
	/**
	 * Method Name: findDuplicates
	 * 
	 * @Description: This method would find Duplicate VIN's.
	 * @param :List<VehicleDetails> inputVinNumberLst
	 * @return Set<String>
	 **/

	public  Set<String> findDuplicates(List<VehicleDetails> inputVinNumberLst) {

		final Set<String> setToReturn = new HashSet<String>();
		final Set<String> uniqueSet = new HashSet<String>();

		Iterator <VehicleDetails> listIterator = inputVinNumberLst.listIterator();

		while(listIterator.hasNext()) {

			VehicleDetails tempObj = listIterator.next();

			if (!uniqueSet.add(tempObj.getVin().trim())) {
				setToReturn.add(tempObj.getVin());
			}
		}
		return setToReturn;
	}
	/** Start Change : User Story US1078610: ***/
	/**
	 * Method Name: updateHistoryTable
	 * 
	 * @Description: This method would updateHistoryTable
	 * @param :List<NodeDetail> nodeList, String overallMsg,String vinNumber
	 * @return void
	 **/

	public void updateHistoryTable(List<NodeDetail> nodeList, String overallMsg, String vinNumber) {

		final String METHOD_NAME = "updateHistoryTable";

		try {

			StringBuilder errorMsg = new StringBuilder();

			Map <String, String>inputMap = new HashMap<String,String>();

			String webServiceDesc = CVDDMConstant.STRING_Y;

			if(!TextUtil.isBlankOrNull(overallMsg)) {

				webServiceDesc = overallMsg;

			}

			else {

				Iterator<NodeDetail> nodeListItr = nodeList.iterator();

				while(nodeListItr.hasNext()) {

					NodeDetail nodeDtlObj = nodeListItr.next();

					Iterator <StatusInfo> statusInfosLst = nodeDtlObj.getStatusInfo().iterator();

					while(statusInfosLst.hasNext()) {

						StatusInfo statusInfo = statusInfosLst.next();

						if(!CVDDMConstant.GVMS_SUCCESS_STATUS_CD.equalsIgnoreCase(statusInfo.getStatusCode())) {

							errorMsg.append(nodeDtlObj.getNodeAddress()+CVDDMConstant.SEMI_COLON+statusInfo.getDetails());

							if(statusInfosLst.hasNext()){

								errorMsg.append(CVDDMConstant.COMMA_SYMBOL);
							}
						}		
					}	
				}

				if(!TextUtil.isBlankOrNull(errorMsg.toString())) {

					webServiceDesc = errorMsg.toString();	
				}
			}

			switch(this.envType) {

			case CVDDMConstant.ENV_QA1:
				inputMap.put(CVDDMConstant.HISTORY_UTILITY_ENVIRONMENT_ID, 
						CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, 
								CVDDMConstant.HISTORY_UTILITY_ENV_QA1));
				break;

			case CVDDMConstant.ENV_QA2:
				inputMap.put(CVDDMConstant.HISTORY_UTILITY_ENVIRONMENT_ID, 
						CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, 
								CVDDMConstant.HISTORY_UTILITY_ENV_QA2));
				break;
			default:
				inputMap.put(CVDDMConstant.HISTORY_UTILITY_ENVIRONMENT_ID, 
						CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, 
								CVDDMConstant.HISTORY_UTILITY_ENV_QA1));
				break;
			}

			inputMap.put(CVDDMConstant.HISTORY_UTILITY_APPLICATION_ID, 
					CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, 
							CVDDMConstant.HISTORY_UTILITY_APP_GVMS));

			inputMap.put(CVDDMConstant.HISTORY_UTILITY_VIN, vinNumber);


			if(CVDDMConstant.STRING_Y.equalsIgnoreCase(webServiceDesc)) {

				inputMap.put(CVDDMConstant.HISTORY_UTILITY_WEBSERVICE_STATUS, CVDDMConstant.STRING_Y);
				inputMap.put(CVDDMConstant.HISTORY_UTILITY_WEBSERVICE_ERROR, CVDDMConstant.SUCCESS);

				historyUtilityBF.saveVINHistoryRcrd(inputMap);	
			}
			else {

				inputMap.put(CVDDMConstant.HISTORY_UTILITY_WEBSERVICE_STATUS, CVDDMConstant.STRING_N);
				inputMap.put(CVDDMConstant.HISTORY_UTILITY_WEBSERVICE_ERROR, webServiceDesc);
				historyUtilityBF.saveVINHistoryRcrd(inputMap);
			}

		}

		catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}
	}
	
	/**
	 * Method Name: navigateToHistoryPage
	 * 
	 * @Description: This method would navigate to GVMS History Page.
	 * @return void
	 **/
	public void navigateToHistoryPage() {

		final String METHOD_NAME = "navigateToHistoryPage";

		log.entering(CLASS_NAME, METHOD_NAME);

		try {
			FacesContext context = FacesContext.getCurrentInstance();
			context.getExternalContext().redirect(CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, CVDDMConstant.GVMS_HISTORY_PAGE_PATH));
		}
		catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}
	}

	/** End Change : User Story US1078610: ***/

}
