package com.ford.cvddm.inbound.layer;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import com.ford.cvddm.common.layer.CVDDMRequestContext;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.it.context.BaseRequestContextFilter;
import com.ford.it.context.RequestContext;

/**
 * This class is necessary in order to support everyone being able to log in as
 * the CVDDM Agent (cvddmagent).
 */
public class CVDDMRequestContextFilter extends BaseRequestContextFilter {
    /**
     * Filter main method
     *
     * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
     *      javax.servlet.ServletResponse, javax.servlet.FilterChain)
     */
    public void doFilter(final ServletRequest request,
            final ServletResponse response, final FilterChain chain)
            throws IOException, ServletException {

        final HttpServletRequest req = (HttpServletRequest)request;
        if (excludedFromFilter(req.getServletPath()))
            chain.doFilter(request, response);
        else {
            chain.doFilter(request, response);
        }
    }

    /**
     * @see javax.servlet.Filter#destroy()
     */
    public void destroy() {
        // empty method
    }

    /**
     * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
     */
    public void init(final FilterConfig filterConfig) throws ServletException {
        // empty method
    }

}
