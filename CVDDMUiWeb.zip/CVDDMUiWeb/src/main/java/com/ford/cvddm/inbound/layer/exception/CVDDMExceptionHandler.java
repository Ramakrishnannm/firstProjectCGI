package com.ford.cvddm.inbound.layer.exception;

import javax.faces.context.ExceptionHandler;
import javax.faces.context.FacesContext;

import com.ford.cvddm.common.layer.exception.CVDDMAuthorizationException;
import com.ford.cvddm.sob.business.layer.CVDDMBusinessException;
import com.ford.it.jsfcore.exception.JcCommonExceptionHandler;
import com.ford.it.jsfcore.util.JcConstant;
import com.ford.it.persistencecore.exception.PcOptimisticLockException;

/**
 * Handler for CVDDM-specific exceptions. Extends the default handler for most
 * cases but intercepts CVDDM exceptions and displays appropriate error pages when
 * necessary.
 *
 * @since 6.0.
 */
public class CVDDMExceptionHandler extends JcCommonExceptionHandler {
    /**
     * Logging Setup
     */
    private static final String CLASS_NAME =
            CVDDMExceptionHandler.class.getName();

    /**
     * Logging Setup
     */
    private static final com.ford.it.logging.ILogger log =
            com.ford.it.logging.LogFactory.getInstance().getLogger(CLASS_NAME);

    CVDDMExceptionHandler(final ExceptionHandler exception) {
        super(exception);
    }

    /**
     * Handle PC Optimistic lock exceptions by adding more logic to default
     * JsfCore exception handler.
     *
     * @see com.ford.it.jsfcore.exception.JcCommonExceptionHandler#determineExceptionTypeAndHandle(java.lang.Throwable)
     */
    @Override
    protected boolean determineExceptionTypeAndHandle(final Throwable t) {
        final String METHOD_NAME = "determineExceptionTypeAndHandle";
        log.entering(CLASS_NAME, METHOD_NAME, t.getClass().toString());
        boolean handled = false;
        /** Start Change :User Story: US890085 ****/
        if (t instanceof CVDDMBusinessException && null != t.getCause()
            && t.getCause() instanceof PcOptimisticLockException) {
            // Optimistic lock exception wrapped inside a CVDDMBusinessException,
            // as is a standard in CVDDM.
            final PcOptimisticLockException e =
                    (PcOptimisticLockException)t.getCause();

            // set some extra information into a session parameter so it's
            // accessible from the error page. Session and not request
            // because session survives redirection.

            FacesContext.getCurrentInstance()
                    .getExternalContext()
                    .getSessionMap()
                    .put(JcConstant.EXCEPTION_NAME, e);

            handleSpecificException(e, 200,
                    "/error/optimisticLockException.xhtml");

            handled = true;
        } else if (t instanceof CVDDMAuthorizationException) {
            final CVDDMAuthorizationException e = (CVDDMAuthorizationException)t;

            FacesContext.getCurrentInstance()
                    .getExternalContext()
                    .getSessionMap()
                    .put(JcConstant.EXCEPTION_NAME, e);

            handleSpecificException(e, 200,
                    "/error/authorizationErrorPage.xhtml");
            handled = true;

        } 
        else if (t instanceof CVDDMBusinessException) {
            final CVDDMBusinessException e = (CVDDMBusinessException)t;

            FacesContext.getCurrentInstance()
                    .getExternalContext()
                    .getSessionMap()
                    .put(JcConstant.EXCEPTION_NAME, e);

            handleSpecificException(e, 200,
                    "/error/unrecoverableThrowable.xhtml");
            handled = true;

        }
        
        else
            handled = super.determineExceptionTypeAndHandle(t);
        
        /** End Change :User Story: US890085 ****/

        log.exiting(CLASS_NAME, METHOD_NAME, handled);
        return handled;
    }

}
