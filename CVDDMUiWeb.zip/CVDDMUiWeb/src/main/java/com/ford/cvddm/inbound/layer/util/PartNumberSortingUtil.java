package com.ford.cvddm.inbound.layer.util;

import java.util.List;

import com.ford.cvddm.outbound.ivsu.rest.ValidateIVSFeedResponse;

public class PartNumberSortingUtil {

	public List<ValidateIVSFeedResponse> sortPartNumbersByPartMatrixRef(List<ValidateIVSFeedResponse> inputResp) {
		return inputResp;

	}

}
