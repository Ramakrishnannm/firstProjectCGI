// ******************************************************************************
// * Copyright (c) 2008 Ford Motor Company. All Rights Reserved.
// * Original author: Ford Motor Company J2EE Center of Excellence
// *
// * $Workfile:   CVDDMApplicationInitializer.java  $
// * $Revision:   1.4  $
// * $Author:   jburnard  $
// * $Date:   Mar 04 2011 15:29:02  $
// ******************************************************************************
package com.ford.cvddm.inbound.layer;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;
import com.ford.it.properties.PropertyManager;
import com.ford.it.util.ApplicationInfoUtil;
import com.ford.it.util.oauth2.OAuth2CredentialsConfigInitializer;

/**
 *
 * This is an initializer for the CVDDM application. It loads the following
 * <ul>
 * <li>The property file for the CVDDM Menu.</li>
 * <li>The Namespaces from DynaProp that CVDDM requires.</li>
 * </ul>
 *
 * @since CVDDM 1.0
 */
public class CVDDMApplicationInitializer implements ServletContextListener {

    /**
     * Class Name used for logging
     */
    private static final String CLASS_NAME =
            CVDDMApplicationInitializer.class.getName();
    /**
     * Logging setup
     */
    private static final ILogger log = LogFactory.getInstance().getLogger(
            CLASS_NAME);

    /**
     * Menu Content Root group
     */
    public static final String MENU_CONTENT_MENUNAME =
            "com.ford.cvddm.context.cvddmMenu";

    /**
     * Life cycle method.
     *
     * @param contextEvent The Context Event
     */
    public void contextInitialized(final ServletContextEvent contextEvent) {
        final String METHOD_NAME = "contextInitialized";
        log.entering(CLASS_NAME, METHOD_NAME, contextEvent);

        // Initialize ApplicationInfoUtil
        ApplicationInfoUtil.getInstance().initialize(
                contextEvent.getServletContext());
        /** Start Change : User Story : US936992 and US947738 **/
        new OAuth2CredentialsConfigInitializer().contextInitialized(contextEvent);
        PropertyManager.getInstance().load("wscore-config.xml");
        /** End Change : User Story : US936992 and US947738 **/

        log.exiting(CLASS_NAME, METHOD_NAME);
        
        
    }

    /**
     * Life cycle method.
     *
     * @param contextEvent The Context Event
     */
    public void contextDestroyed(final ServletContextEvent contextEvent) {

        final String METHOD_NAME = "contextDestroyed";
        log.entering(CLASS_NAME, METHOD_NAME);

        log.exiting(CLASS_NAME, METHOD_NAME);
    }
}
