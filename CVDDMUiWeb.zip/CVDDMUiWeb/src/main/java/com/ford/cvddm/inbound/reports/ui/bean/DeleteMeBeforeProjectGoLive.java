/**
 * 
 */
package com.ford.cvddm.inbound.reports.ui.bean;

/**
 * @author NGUPTA18
 *
 */
public interface DeleteMeBeforeProjectGoLive {

}
