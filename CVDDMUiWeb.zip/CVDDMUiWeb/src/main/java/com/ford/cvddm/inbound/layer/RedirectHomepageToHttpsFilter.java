package com.ford.cvddm.inbound.layer;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet Filter implementation class RedirectHomepageToHttpsFilter
 * Author: NGUPTA18
 */
@WebFilter("/")  
public class RedirectHomepageToHttpsFilter implements Filter {  
  
    public void doFilter(final ServletRequest request, final ServletResponse response, final FilterChain chain)  
       throws IOException, ServletException {  
        final HttpServletRequest req = (HttpServletRequest)request;  
        final HttpServletResponse resp = (HttpServletResponse)response; 
        
        /** Start Change : PCF Secure Redirection */
        /** Do not remove below piece of Code while Deployment.
         For Local Use URL: https://localhost:17443/  
        and Continue**/
        if ("http".equalsIgnoreCase(req.getHeader("X-Forwarded-Proto")))  
        {  
            resp.sendRedirect("https://" + req.getHeader("Host"));  
        }
       
        else if ("http".equalsIgnoreCase(req.getScheme()))  
        {  
            resp.sendRedirect("https://" + req.getHeader("Host"));  
        }
      
        else { 
            chain.doFilter(request, response); 
        }
        /** End Change : PCF Secure Redirection */
    }  
  
    public void destroy() {  
        // Nothing to do here  
    }  
  
   public void init(final FilterConfig arg0) throws ServletException {  
        // Nothing to do here either  
    }  
}  
