package com.ford.cvddm.inbound.datavalidation.ui.bean;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import com.ford.cvddm.inbound.layer.base.CVDDMBaseBean;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;


/**
 * 
 * @author RPADI
 * This is used for External application validation page
 */
@ManagedBean
@ViewScoped
public class ExternalApplicationUrlsValidationBean extends CVDDMBaseBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private static final String CLASS_NAME = ExternalApplicationUrlsValidationBean.class.getName();

	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	@Override
	protected void preRenderViewStartWorkflowTM() {		

	}

}
