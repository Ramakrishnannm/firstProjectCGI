/**
 * 
 */
package com.ford.cvddm.inbound.datavalidation.ui.bean;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.deltaspike.core.api.scope.GroupedConversationScoped;

import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.common.util.ValidationUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.domain.env.de.CvddmEnvironmentDE;
import com.ford.cvddm.domain.history.de.CvddmPartIISpecHistoryDE;
import com.ford.cvddm.domain.history.de.CvddmVINHistoryDE;
import com.ford.cvddm.env.business.list.ListCvddmEnvironmentBF;
import com.ford.cvddm.history.business.HistoryUtilityBF;
import com.ford.cvddm.inbound.layer.base.CVDDMBaseBean;
import com.ford.cvddm.sob.business.layer.CVDDMBusinessException;
import com.ford.it.exception.FordExceptionAttributes;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;
import com.ford.it.util.TextUtil;

/**
 * @since US1107537
 * @author RPADI Description: This Bean contains method for PartIISpec
 *         Validation History.
 *
 */
@Named
@GroupedConversationScoped
public class PartIISpecValidationHistoryBean extends CVDDMBaseBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final String CLASS_NAME = PartIISpecValidationHistoryBean.class.getName();

	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	@Inject
	private HistoryUtilityBF historyUtilityBF;

	private List<CvddmPartIISpecHistoryDE> cvddmPartIISpecHistoryDEs;

	private Timestamp fromDate;

	private Timestamp toDate;

	public HistoryUtilityBF getHistoryUtilityBF() {
		return historyUtilityBF;
	}

	public void setHistoryUtilityBF(HistoryUtilityBF historyUtilityBF) {
		this.historyUtilityBF = historyUtilityBF;
	}

	public String getPartIISpec() {
		return partIISpec;
	}

	public void setPartIISpec(String partIISpec) {
		this.partIISpec = partIISpec;
	}

	public String getEnvType() {
		return envType;
	}

	public void setEnvType(String envType) {
		this.envType = envType;
	}

	private String partIISpec;

	private String envType;

	public ListCvddmEnvironmentBF getListCvddmEnvironmentBF() {
		return listCvddmEnvironmentBF;
	}

	public void setListCvddmEnvironmentBF(ListCvddmEnvironmentBF listCvddmEnvironmentBF) {
		this.listCvddmEnvironmentBF = listCvddmEnvironmentBF;
	}

	public List<CvddmEnvironmentDE> getEnvironmentList() {
		return environmentList;
	}

	public void setEnvironmentList(List<CvddmEnvironmentDE> environmentList) {
		this.environmentList = environmentList;
	}

	@Inject
	private ListCvddmEnvironmentBF listCvddmEnvironmentBF;

	private List<CvddmEnvironmentDE> environmentList;

	public Timestamp getFromDate() {
		return fromDate;
	}

	public void setFromDate(Timestamp fromDate) {
		this.fromDate = fromDate;
	}

	public Timestamp getToDate() {
		return toDate;
	}

	public void setToDate(Timestamp toDate) {
		this.toDate = toDate;
	}

	public List<CvddmPartIISpecHistoryDE> getCvddmPartIISpecHistoryDEs() {
		return cvddmPartIISpecHistoryDEs;
	}

	public void setCvddmPartIISpecHistoryDEs(List<CvddmPartIISpecHistoryDE> cvddmVINHistoryDEs) {
		this.cvddmPartIISpecHistoryDEs = cvddmVINHistoryDEs;
	}

	@Override
	protected void preRenderViewStartWorkflowTM() {
		log.exiting(CLASS_NAME, "preRenderViewStartWorkflowTM");
	}

	@Override
	protected void preRenderViewTM() {

		log.info("preRenderViewTM");
		if (isNotPostBack()) {
			this.fetchHistoryDetails();
			getEnvironmentTypes();
		}
	}

	/**
	 * Method Name: getEnvironmentTypes
	 * 
	 * @Description: This method would load values for "Environment" Drop Down.
	 * @param :
	 *            none
	 * @return void
	 **/
	public void getEnvironmentTypes() {

		final String METHOD_NAME = "getEnvironmentTypes";

		log.entering(CLASS_NAME, METHOD_NAME);

		try {

			List<CvddmEnvironmentDE> envList = listCvddmEnvironmentBF.fetchAllEnvRcrds();
			if (!CvddmUtil.isObjectEmpty(envList) && !envList.isEmpty()) {

				setEnvironmentList(envList);
			}

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
		}
		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * Method Name: fetchHistoryDetails
	 * 
	 * @Description:This method would fetch all partIIspec History from
	 *                   PCVDM08_VEH_DATA_VLDTN_REQ database table
	 * @return void
	 */
	public void fetchHistoryDetails() {

		cvddmPartIISpecHistoryDEs = historyUtilityBF.getValidationPartIISpecHistoryRcrds(CvddmUtil.getPropertiesValue(
				CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, CVDDMConstant.HISTORY_UTILITY_APP_AWS));

		if (!CvddmUtil.isObjectEmpty(cvddmPartIISpecHistoryDEs) && !cvddmPartIISpecHistoryDEs.isEmpty()) {

			log.info("fetchHistoryDetails");
			setCvddmPartIISpecHistoryDEs(cvddmPartIISpecHistoryDEs);
		}
	}

	public Date getFromDateRange() {
		return CvddmUtil.getLastYearDatePlusOneDay();
	}

	public Date getToDateRange() {
		return CvddmUtil.getTodaysDate();
	}

	public void updateRcrdsonPanelonEnv() {

		if (TextUtil.isBlankOrNull(this.envType)) {

			fetchHistoryDetails();

		}
	}
	/**
	 *  This method is used to filter the partIIspec history records based date range
	 * 
	 */

	public void filterByDateRange() {

		final String METHOD_NAME = "filterByDateRange";
		log.entering(CLASS_NAME, METHOD_NAME);

		List<CvddmPartIISpecHistoryDE> tempcvddmVINHistoryDEs = new ArrayList<>();

		Timestamp toEnDate = null;

		boolean isOktoSearch = true;

		try {

			if (TextUtil.isBlankOrNull(envType) && TextUtil.isBlankOrNull(partIISpec)
					&& CvddmUtil.isObjectEmpty(fromDate) && CvddmUtil.isObjectEmpty(toDate)) {

				isOktoSearch = false;

				FacesContext.getCurrentInstance().addMessage(null,
						new FacesMessage(FacesMessage.SEVERITY_ERROR,
								CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
										CVDDMConstant.EMPTY_FILTER_CRITERIA),
								CVDDMConstant.VALIDATION_ERR));
			}

			if (!isValidInputDate()) {

				isOktoSearch = false;
			}

			if (TextUtil.isNotBlankOrNull(partIISpec) && !ValidationUtil.validatePartIISpec(partIISpec)) {

				isOktoSearch = false;

				String vinErrorMsg = CVDDMConstant.PARTIISPEC_NAME + partIISpec + " " + CvddmUtil
						.getPropertiesValue(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY, CVDDMConstant.VALID_P2S_MSG);

				FacesContext.getCurrentInstance().addMessage(CVDDMConstant.PARTIISPEC_JSF_ID_HIST_VIN_NUMBER,
						new FacesMessage(FacesMessage.SEVERITY_ERROR, null, vinErrorMsg));

			}

			if (isOktoSearch) {

				if (!CvddmUtil.isObjectEmpty(toDate)) {

					/** Below logic is to include inclusive To Date in UTC Format **/
					Calendar calendar = Calendar.getInstance();
					TimeZone tz = TimeZone.getTimeZone(CVDDMConstant.TIMEZONE_UTC);
					calendar.setTimeZone(tz);
					calendar.setTimeInMillis(toDate.getTime());
					calendar.add(Calendar.DATE, 1);
					Date tempObj = calendar.getTime();

					toEnDate = new Timestamp(tempObj.getTime());

					/** Above logic is to include inclusive To Date in UTC Format **/
					log.info("toEnDate >>>" + toEnDate);
				}

				tempcvddmVINHistoryDEs = historyUtilityBF
						.getValidationHistoryPartIISpecRcrdsByOptions(
								CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
										CVDDMConstant.HISTORY_UTILITY_APP_AWS),
								fromDate, toEnDate, partIISpec, envType);

				if (!CvddmUtil.isObjectEmpty(tempcvddmVINHistoryDEs)) {

					this.cvddmPartIISpecHistoryDEs = tempcvddmVINHistoryDEs;
					this.setCvddmPartIISpecHistoryDEs(cvddmPartIISpecHistoryDEs);
				}
			}
		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}

		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	/**
	 * Method Name: isValidInputDate
	 * 
	 * @Description:This method would validate Input Date
	 * @return boolean
	 */
	public boolean isValidInputDate() {

		final String METHOD_NAME = "isValidInputDate";

		log.entering(CLASS_NAME, METHOD_NAME);

		boolean isValidInput = true;

		if (!CvddmUtil.isObjectEmpty(this.fromDate) && !CvddmUtil.isObjectEmpty(this.toDate)
				&& this.toDate.before(this.fromDate)) {

			isValidInput = false;

			FacesContext.getCurrentInstance().addMessage(CVDDMConstant.RVCM_JSF_ID_HIST_TO_DATE,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, null,
							getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_APPLICATION_RESOURCE_KEY,
									CVDDMConstant.LABEL_HIST_TO_DATE)
									+ " "
									+ getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
											CVDDMConstant.DATE_GREATER_THAN_MSG)
									+ " " + getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_APPLICATION_RESOURCE_KEY,
											CVDDMConstant.LABEL_HIST_FROM_DATE)));
		}
		return isValidInput;
	}

	public boolean isValidDateInput() {

		final String METHOD_NAME = "isValidDateInput";

		log.entering(CLASS_NAME, METHOD_NAME);

		boolean isValidInput = true;

		if (!CvddmUtil.isObjectEmpty(this.fromDate) && !CvddmUtil.isObjectEmpty(this.toDate)
				&& this.toDate.before(this.fromDate)) {

			isValidInput = false;

			FacesContext.getCurrentInstance().addMessage(CVDDMConstant.JSF_ID_HIST_TO_DATE,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, null,
							getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_APPLICATION_RESOURCE_KEY,
									CVDDMConstant.LABEL_HIST_TO_DATE)
									+ " "
									+ getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_VALIDATION_MSG_KEY,
											CVDDMConstant.DATE_GREATER_THAN_MSG)
									+ " " + getLocalizedStringFromBundle(CVDDMConstant.BUNDLE_APPLICATION_RESOURCE_KEY,
											CVDDMConstant.LABEL_HIST_FROM_DATE)));
		}

		return isValidInput;
	}

	public void processClearFilter() {

		final String METHOD_NAME = "processClearFilter";
		log.entering(CLASS_NAME, METHOD_NAME);

		this.fromDate = null;
		this.toDate = null;
		this.partIISpec = null;
		this.envType = null;
		this.fetchHistoryDetails();

		log.exiting(CLASS_NAME, METHOD_NAME);
	}

	public void navigateToValidationPage() {

		final String METHOD_NAME = "navigateToValidationPage";

		log.entering(CLASS_NAME, METHOD_NAME);

		try {
			FacesContext context = FacesContext.getCurrentInstance();
			context.getExternalContext().redirect(CvddmUtil.getPropertiesValue(
					CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, CVDDMConstant.PARTIISPEC_VALIDATION_PAGE_PATH));
		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMBusinessException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}
	}

}
