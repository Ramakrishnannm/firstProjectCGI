
package com.ford.cvddm.outbound.gvms.getCurrentLite;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "didValue",
        "didType",
        "didResponse",
        "isConfig",
        "reserverdElement1",
        "reserverdElement2",
        "reserverdElement3"
})
public class DidInfoDetail {

    private String didResponse;
    private String didType;
    private String didValue;
    private String isConfig;
    private List<FunctionTypeInfo> functionTypeInfoList;
    private List<Software> softwares = null;
    private String reserverdElement1;
    private String reserverdElement2;
    private String reserverdElement3;

    public String getDidResponse() {
        return didResponse;
    }

    public void setDidResponse(String didResponse) {
        this.didResponse = didResponse;
    }

    public String getDidType() {
        return didType;
    }

    public void setDidType(String didType) {
        this.didType = didType;
    }

    public String getDidValue() {
        return didValue;
    }

    public void setDidValue(String didValue) {
        this.didValue = didValue;
    }

    public String getIsConfig() {
        return isConfig;
    }

    public void setIsConfig(String isConfig) {
        this.isConfig = isConfig;
    }

    public List<FunctionTypeInfo> getFunctionTypeInfoList() {
        return functionTypeInfoList;
    }

    public void setFunctionTypeInfoList(List<FunctionTypeInfo> functionTypeInfoList) {
        this.functionTypeInfoList = functionTypeInfoList;
    }

    public List<Software> getSoftwares() {
        return softwares;
    }

    public void setSoftwares(List<Software> softwares) {
        this.softwares = softwares;
    }

    public String getReserverdElement1() {
        return reserverdElement1;
    }

    public void setReserverdElement1(String reserverdElement1) {
        this.reserverdElement1 = reserverdElement1;
    }

    public String getReserverdElement2() {
        return reserverdElement2;
    }

    public void setReserverdElement2(String reserverdElement2) {
        this.reserverdElement2 = reserverdElement2;
    }

    public String getReserverdElement3() {
        return reserverdElement3;
    }

    public void setReserverdElement3(String reserverdElement3) {
        this.reserverdElement3 = reserverdElement3;
    }

}
