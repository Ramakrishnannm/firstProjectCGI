package com.ford.cvddm.outbound.ivsu.rest;

public class ValidateIVSFeedRequest {

	private ValidateIVSFeed validateIVSFeed;

	public ValidateIVSFeed getValidateIVSFeed() {
		return validateIVSFeed;
	}

	public void setValidateIVSFeed(ValidateIVSFeed validateIVSFeed) {
		this.validateIVSFeed = validateIVSFeed;
	}

}
