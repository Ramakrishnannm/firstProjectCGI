package com.ford.cvddm.outbound.gvms.getCurrentLite;

import java.util.List;

public class Mfalinfo {

    private List<String> mfalCodes = null;

    public List<String> getmfalCodes() {
        return mfalCodes;
    }

    public void setmfalCodes(List<String> mfalCodes) {
        this.mfalCodes = mfalCodes;
    }

}