
package com.ford.cvddm.outbound.givis.soap.givismodulestate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RequestInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RequestInfoType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="getCurrent" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="getAvailable" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="getHistory" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="getLatest" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="getAsBuilt" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RequestInfoType")
public class RequestInfoType {

    @XmlAttribute(name = "getCurrent")
    protected Boolean getCurrent;
    @XmlAttribute(name = "getAvailable")
    protected Boolean getAvailable;
    @XmlAttribute(name = "getHistory")
    protected Boolean getHistory;
    @XmlAttribute(name = "getLatest")
    protected Boolean getLatest;
    @XmlAttribute(name = "getAsBuilt")
    protected Boolean getAsBuilt;

    /**
     * Gets the value of the getCurrent property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isGetCurrent() {
        return getCurrent;
    }

    /**
     * Sets the value of the getCurrent property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setGetCurrent(Boolean value) {
        this.getCurrent = value;
    }

    /**
     * Gets the value of the getAvailable property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isGetAvailable() {
        return getAvailable;
    }

    /**
     * Sets the value of the getAvailable property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setGetAvailable(Boolean value) {
        this.getAvailable = value;
    }

    /**
     * Gets the value of the getHistory property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isGetHistory() {
        return getHistory;
    }

    /**
     * Sets the value of the getHistory property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setGetHistory(Boolean value) {
        this.getHistory = value;
    }

    /**
     * Gets the value of the getLatest property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isGetLatest() {
        return getLatest;
    }

    /**
     * Sets the value of the getLatest property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setGetLatest(Boolean value) {
        this.getLatest = value;
    }

    /**
     * Gets the value of the getAsBuilt property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isGetAsBuilt() {
        return getAsBuilt;
    }

    /**
     * Sets the value of the getAsBuilt property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setGetAsBuilt(Boolean value) {
        this.getAsBuilt = value;
    }

}
