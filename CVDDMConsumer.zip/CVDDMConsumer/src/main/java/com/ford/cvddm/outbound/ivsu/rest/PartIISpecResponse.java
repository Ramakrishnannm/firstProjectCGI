package com.ford.cvddm.outbound.ivsu.rest;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PartIISpecResponse {

	@JsonProperty("PartIISpec")
	private String partIISPec;

	public String getPartIISPec() {
		return partIISPec;
	}

	public void setPartIISPec(String partIISPec) {
		this.partIISPec = partIISPec;
	}

}
