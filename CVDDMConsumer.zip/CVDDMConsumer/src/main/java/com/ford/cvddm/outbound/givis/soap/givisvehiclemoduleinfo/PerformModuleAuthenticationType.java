
package com.ford.cvddm.outbound.givis.soap.givisvehiclemoduleinfo;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PerformModuleAuthenticationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PerformModuleAuthenticationType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="RequestType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="VIN" type="{urn:ford/Vehicle/Module/Information/v4.0}VINType"/>
 *         &lt;element name="Role" type="{urn:ford/Vehicle/Module/Information/v4.0}StateUpdateRoleType"/>
 *         &lt;element name="Node" type="{urn:ford/Vehicle/Module/Information/v4.0}SimpleNodeAddressType"/>
 *         &lt;element name="OutCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ResponseCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Warning" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="IPAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TableIds" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PerformModuleAuthenticationType", namespace = "urn:ford/interface/Vehicle/Module/Information/v4.0", propOrder = {
    "requestType",
    "vin",
    "role",
    "node",
    "outCode",
    "responseCode",
    "warning",
    "ipAddress",
    "tableIds"
})
public class PerformModuleAuthenticationType {

    @XmlElement(name = "RequestType", required = true)
    protected String requestType;
    @XmlElement(name = "VIN", required = true)
    protected String vin;
    @XmlElement(name = "Role", required = true)
    protected StateUpdateRoleType role;
    @XmlElement(name = "Node", required = true)
    protected SimpleNodeAddressType node;
    @XmlElement(name = "OutCode", required = true)
    protected String outCode;
    @XmlElement(name = "ResponseCode")
    protected String responseCode;
    @XmlElement(name = "Warning")
    protected List<String> warning;
    @XmlElement(name = "IPAddress")
    protected String ipAddress;
    @XmlElement(name = "TableIds")
    protected List<String> tableIds;

    /**
     * Gets the value of the requestType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestType() {
        return requestType;
    }

    /**
     * Sets the value of the requestType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestType(String value) {
        this.requestType = value;
    }

    /**
     * Gets the value of the vin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVIN() {
        return vin;
    }

    /**
     * Sets the value of the vin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVIN(String value) {
        this.vin = value;
    }

    /**
     * Gets the value of the role property.
     * 
     * @return
     *     possible object is
     *     {@link StateUpdateRoleType }
     *     
     */
    public StateUpdateRoleType getRole() {
        return role;
    }

    /**
     * Sets the value of the role property.
     * 
     * @param value
     *     allowed object is
     *     {@link StateUpdateRoleType }
     *     
     */
    public void setRole(StateUpdateRoleType value) {
        this.role = value;
    }

    /**
     * Gets the value of the node property.
     * 
     * @return
     *     possible object is
     *     {@link SimpleNodeAddressType }
     *     
     */
    public SimpleNodeAddressType getNode() {
        return node;
    }

    /**
     * Sets the value of the node property.
     * 
     * @param value
     *     allowed object is
     *     {@link SimpleNodeAddressType }
     *     
     */
    public void setNode(SimpleNodeAddressType value) {
        this.node = value;
    }

    /**
     * Gets the value of the outCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOutCode() {
        return outCode;
    }

    /**
     * Sets the value of the outCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOutCode(String value) {
        this.outCode = value;
    }

    /**
     * Gets the value of the responseCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseCode() {
        return responseCode;
    }

    /**
     * Sets the value of the responseCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseCode(String value) {
        this.responseCode = value;
    }

    /**
     * Gets the value of the warning property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the warning property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getWarning().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getWarning() {
        if (warning == null) {
            warning = new ArrayList<String>();
        }
        return this.warning;
    }

    /**
     * Gets the value of the ipAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIPAddress() {
        return ipAddress;
    }

    /**
     * Sets the value of the ipAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIPAddress(String value) {
        this.ipAddress = value;
    }

    /**
     * Gets the value of the tableIds property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the tableIds property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTableIds().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getTableIds() {
        if (tableIds == null) {
            tableIds = new ArrayList<String>();
        }
        return this.tableIds;
    }

}
