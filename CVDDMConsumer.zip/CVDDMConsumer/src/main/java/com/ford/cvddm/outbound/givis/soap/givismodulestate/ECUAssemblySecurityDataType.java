
package com.ford.cvddm.outbound.givis.soap.givismodulestate;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlType;


/**
 * File security bytes information
 * 
 * <p>Java class for ECUAssemblySecurityDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ECUAssemblySecurityDataType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence maxOccurs="unbounded">
 *         &lt;element name="SecurityLevelRef" type="{urn:ford/Vehicle/Module/Information/v4.0}SecurityLevelRefType"/>
 *         &lt;choice>
 *           &lt;element name="SecurityBytes" type="{urn:ford/Vehicle/Module/Information/v4.0}SecurityBytesType"/>
 *           &lt;element name="ECUEncryptionInfo" type="{urn:ford/Vehicle/Module/Information/v4.0}ECUEncryptionInfoType"/>
 *         &lt;/choice>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ECUAssemblySecurityDataType", propOrder = {
    "securityLevelRefAndSecurityBytesOrECUEncryptionInfo"
})
public class ECUAssemblySecurityDataType {

    @XmlElements({
        @XmlElement(name = "SecurityLevelRef", required = true, type = String.class),
        @XmlElement(name = "SecurityBytes", required = true, type = SecurityBytesType.class),
        @XmlElement(name = "ECUEncryptionInfo", required = true, type = ECUEncryptionInfoType.class)
    })
    protected List<Object> securityLevelRefAndSecurityBytesOrECUEncryptionInfo;

    /**
     * Gets the value of the securityLevelRefAndSecurityBytesOrECUEncryptionInfo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the securityLevelRefAndSecurityBytesOrECUEncryptionInfo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSecurityLevelRefAndSecurityBytesOrECUEncryptionInfo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * {@link SecurityBytesType }
     * {@link ECUEncryptionInfoType }
     * 
     * 
     */
    public List<Object> getSecurityLevelRefAndSecurityBytesOrECUEncryptionInfo() {
        if (securityLevelRefAndSecurityBytesOrECUEncryptionInfo == null) {
            securityLevelRefAndSecurityBytesOrECUEncryptionInfo = new ArrayList<Object>();
        }
        return this.securityLevelRefAndSecurityBytesOrECUEncryptionInfo;
    }

}
