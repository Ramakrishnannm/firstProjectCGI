
package com.ford.cvddm.outbound.gvms.moduleState;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for HardwareType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="HardwareType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="MappedFeatures" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="hardwarePartNumber" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="didValue" type="{urn:ford/Vehicle/Module/Information/v4.0}DIDValueType" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "HardwareType", propOrder = {
    "mappedFeatures"
})
public class HardwareType
    implements Serializable
{

    @XmlElement(name = "MappedFeatures")
    protected String mappedFeatures;
    @XmlAttribute(name = "hardwarePartNumber")
    protected String hardwarePartNumber;
    @XmlAttribute(name = "didValue")
    protected String didValue;

    /**
     * Gets the value of the mappedFeatures property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMappedFeatures() {
        return mappedFeatures;
    }

    /**
     * Sets the value of the mappedFeatures property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMappedFeatures(String value) {
        this.mappedFeatures = value;
    }

    /**
     * Gets the value of the hardwarePartNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHardwarePartNumber() {
        return hardwarePartNumber;
    }

    /**
     * Sets the value of the hardwarePartNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHardwarePartNumber(String value) {
        this.hardwarePartNumber = value;
    }

    /**
     * Gets the value of the didValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDidValue() {
        return didValue;
    }

    /**
     * Sets the value of the didValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDidValue(String value) {
        this.didValue = value;
    }

}
