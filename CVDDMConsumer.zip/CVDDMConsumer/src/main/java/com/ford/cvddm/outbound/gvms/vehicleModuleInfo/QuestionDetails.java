
package com.ford.cvddm.outbound.gvms.vehicleModuleInfo;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for QuestionDetails complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="QuestionDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="questionID" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="questionValue" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "QuestionDetails")
public class QuestionDetails
    implements Serializable
{

    @XmlAttribute(name = "questionID")
    protected String questionID;
    @XmlAttribute(name = "questionValue")
    protected String questionValue;

    /**
     * Gets the value of the questionID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQuestionID() {
        return questionID;
    }

    /**
     * Sets the value of the questionID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQuestionID(String value) {
        this.questionID = value;
    }

    /**
     * Gets the value of the questionValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQuestionValue() {
        return questionValue;
    }

    /**
     * Sets the value of the questionValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQuestionValue(String value) {
        this.questionValue = value;
    }

}
