
package com.ford.cvddm.outbound.gvms.getCurrentLite;

import java.util.List;

public class DidInfoType {

    private List<String> didType = null;
    private List<String> didList = null;
    private String didInfoRequired;
    private String reservedElement;

    public List<String> getDidType() {
        return didType;
    }

    public void setDidType(List<String> didType) {
        this.didType = didType;
    }

    public List<String> getDidList() {
        return didList;
    }

    public void setDidList(List<String> didList) {
        this.didList = didList;
    }

    public String getDidInfoRequired() {
        return didInfoRequired;
    }

    public void setDidInfoRequired(String didInfoRequired) {
        this.didInfoRequired = didInfoRequired;
    }

    public String getReservedElement() {
        return reservedElement;
    }

    public void setReservedElement(String reservedElement) {
        this.reservedElement = reservedElement;
    }

}
