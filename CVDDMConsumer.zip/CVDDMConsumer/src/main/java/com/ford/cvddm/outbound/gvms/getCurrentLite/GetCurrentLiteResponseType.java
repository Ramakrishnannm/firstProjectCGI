package com.ford.cvddm.outbound.gvms.getCurrentLite;

import com.fasterxml.jackson.annotation.JsonInclude;


@JsonInclude(JsonInclude.Include.NON_NULL)
public class GetCurrentLiteResponseType {

    private GetCurrentLiteResponse getCurrentLiteResponse;

    public GetCurrentLiteResponse getGetCurrentLiteResponse ()
    {
        return getCurrentLiteResponse;
    }

    public void setGetCurrentLiteResponse (GetCurrentLiteResponse getCurrentLiteResponse)
    {
        this.getCurrentLiteResponse = getCurrentLiteResponse;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [getCurrentLiteResponse = "+getCurrentLiteResponse+"]";
    }
}
