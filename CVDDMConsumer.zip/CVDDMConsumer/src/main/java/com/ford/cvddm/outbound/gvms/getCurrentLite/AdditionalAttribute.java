package com.ford.cvddm.outbound.gvms.getCurrentLite;

import java.util.List;

public class AdditionalAttribute {

    private List<Response> response = null;

    public List<Response> getResponse() {
        return response;
    }

    public void setResponse(List<Response> response) {
        this.response = response;
    }

}
