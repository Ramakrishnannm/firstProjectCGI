package com.ford.cvddm.outbound.ivsu.rest;

public class RetrieveIVSFeed {

	private String programCode;

	private int modelYear;

	public String getProgramCode() {
		return programCode;
	}

	public void setProgramCode(String programCode) {
		this.programCode = programCode;
	}

	public int getModelYear() {
		return modelYear;
	}

	public void setModelYear(int modelYear) {
		this.modelYear = modelYear;
	}

}
