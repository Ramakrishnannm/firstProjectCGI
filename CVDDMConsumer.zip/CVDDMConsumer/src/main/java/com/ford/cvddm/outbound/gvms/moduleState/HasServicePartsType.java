
package com.ford.cvddm.outbound.gvms.moduleState;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for HasServicePartsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="HasServicePartsType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="didValue" type="{urn:ford/Vehicle/Module/Information/v4.0}DIDValueType" />
 *       &lt;attribute name="partNumber" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "HasServicePartsType")
public class HasServicePartsType
    implements Serializable
{

    @XmlAttribute(name = "didValue")
    protected String didValue;
    @XmlAttribute(name = "partNumber")
    protected String partNumber;

    /**
     * Gets the value of the didValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDidValue() {
        return didValue;
    }

    /**
     * Sets the value of the didValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDidValue(String value) {
        this.didValue = value;
    }

    /**
     * Gets the value of the partNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartNumber() {
        return partNumber;
    }

    /**
     * Sets the value of the partNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartNumber(String value) {
        this.partNumber = value;
    }

}
