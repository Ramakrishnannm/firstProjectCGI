
package com.ford.cvddm.outbound.gvms.getCurrentLite;

import java.util.List;

public class NodeInfo {

    private List<String> nodeAddress = null;

    public List<String> getNodeAddress() {
        return nodeAddress;
    }

    public void setNodeAddress(List<String> nodeAddress) {
        this.nodeAddress = nodeAddress;
    }

}
