
package com.ford.cvddm.outbound.gvms.vehicleModuleInfo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DIDInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DIDInfoType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Response" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsConfig" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="IsPrivateNetwork" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="IsVinSpecific" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="ComplianceDID" type="{urn:ford/Vehicle/Module/Information/v4.0}ComplianceDIDType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="Software" type="{urn:ford/Vehicle/Module/Information/v4.0}SoftwareMetaDataType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="ModifiedResponse" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="didValue" use="required" type="{urn:ford/Vehicle/Module/Information/v4.0}DIDValueType" />
 *       &lt;attribute name="didType" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="didFormat" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="responseLength" type="{http://www.w3.org/2001/XMLSchema}int" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DIDInfoType", propOrder = {
    "response",
    "isConfig",
    "isPrivateNetwork",
    "isVinSpecific",
    "complianceDID",
    "software",
    "modifiedResponse"
})
public class DIDInfoType
    implements Serializable
{

    @XmlElement(name = "Response")
    protected String response;
    @XmlElement(name = "IsConfig")
    protected Boolean isConfig;
    @XmlElement(name = "IsPrivateNetwork")
    protected Boolean isPrivateNetwork;
    @XmlElement(name = "IsVinSpecific")
    protected Boolean isVinSpecific;
    @XmlElement(name = "ComplianceDID")
    protected List<ComplianceDIDType> complianceDID;
    @XmlElement(name = "Software")
    protected List<SoftwareMetaDataType> software;
    @XmlElement(name = "ModifiedResponse")
    protected String modifiedResponse;
    @XmlAttribute(name = "didValue", required = true)
    protected String didValue;
    @XmlAttribute(name = "didType")
    protected String didType;
    @XmlAttribute(name = "didFormat")
    protected String didFormat;
    @XmlAttribute(name = "responseLength")
    protected Integer responseLength;

    /**
     * Gets the value of the response property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponse() {
        return response;
    }

    /**
     * Sets the value of the response property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponse(String value) {
        this.response = value;
    }

    /**
     * Gets the value of the isConfig property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsConfig() {
        return isConfig;
    }

    /**
     * Sets the value of the isConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsConfig(Boolean value) {
        this.isConfig = value;
    }

    /**
     * Gets the value of the isPrivateNetwork property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsPrivateNetwork() {
        return isPrivateNetwork;
    }

    /**
     * Sets the value of the isPrivateNetwork property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsPrivateNetwork(Boolean value) {
        this.isPrivateNetwork = value;
    }

    /**
     * Gets the value of the isVinSpecific property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsVinSpecific() {
        return isVinSpecific;
    }

    /**
     * Sets the value of the isVinSpecific property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsVinSpecific(Boolean value) {
        this.isVinSpecific = value;
    }

    /**
     * Gets the value of the complianceDID property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the complianceDID property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getComplianceDID().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ComplianceDIDType }
     * 
     * 
     */
    public List<ComplianceDIDType> getComplianceDID() {
        if (complianceDID == null) {
            complianceDID = new ArrayList<ComplianceDIDType>();
        }
        return this.complianceDID;
    }

    /**
     * Gets the value of the software property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the software property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSoftware().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SoftwareMetaDataType }
     * 
     * 
     */
    public List<SoftwareMetaDataType> getSoftware() {
        if (software == null) {
            software = new ArrayList<SoftwareMetaDataType>();
        }
        return this.software;
    }

    /**
     * Gets the value of the modifiedResponse property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModifiedResponse() {
        return modifiedResponse;
    }

    /**
     * Sets the value of the modifiedResponse property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModifiedResponse(String value) {
        this.modifiedResponse = value;
    }

    /**
     * Gets the value of the didValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDidValue() {
        return didValue;
    }

    /**
     * Sets the value of the didValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDidValue(String value) {
        this.didValue = value;
    }

    /**
     * Gets the value of the didType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDidType() {
        return didType;
    }

    /**
     * Sets the value of the didType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDidType(String value) {
        this.didType = value;
    }

    /**
     * Gets the value of the didFormat property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDidFormat() {
        return didFormat;
    }

    /**
     * Sets the value of the didFormat property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDidFormat(String value) {
        this.didFormat = value;
    }

    /**
     * Gets the value of the responseLength property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getResponseLength() {
        return responseLength;
    }

    /**
     * Sets the value of the responseLength property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setResponseLength(Integer value) {
        this.responseLength = value;
    }

}
