
package com.ford.cvddm.outbound.aps.entitlementGroup;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.ford.cvddm.outbound.aps.entitlementGroup package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Group_QNAME = new QName("http://www.sps.ford.com/EntitlementGroupService/data", "Group");
    private final static QName _CustomException_QNAME = new QName("http://www.sps.ford.com/EntitlementGroupService/data", "CustomException");
    private final static QName _Groups_QNAME = new QName("http://www.sps.ford.com/EntitlementGroupService/data", "Groups");
    private final static QName _Entitlements_QNAME = new QName("http://www.sps.ford.com/EntitlementGroupService/data", "Entitlements");
    private final static QName _EntitlementDetail_QNAME = new QName("http://www.sps.ford.com/EntitlementGroupService/data", "EntitlementDetail");
    private final static QName _GroupDetail_QNAME = new QName("http://www.sps.ford.com/EntitlementGroupService/data", "GroupDetail");
    private final static QName _UserDetail_QNAME = new QName("http://www.sps.ford.com/EntitlementGroupService/data", "UserDetail");
    private final static QName _SubjectEnt_QNAME = new QName("http://www.sps.ford.com/EntitlementGroupService/data", "SubjectEnt");
    private final static QName _Entitlement_QNAME = new QName("http://www.sps.ford.com/EntitlementGroupService/data", "Entitlement");
    private final static QName _GroupUsers_QNAME = new QName("http://www.sps.ford.com/EntitlementGroupService/data", "GroupUsers");
    private final static QName _EntitlementUsers_QNAME = new QName("http://www.sps.ford.com/EntitlementGroupService/data", "EntitlementUsers");
    private final static QName _Application_QNAME = new QName("http://www.sps.ford.com/EntitlementGroupService/data", "Application");
    private final static QName _ApplicationUsers_QNAME = new QName("http://www.sps.ford.com/EntitlementGroupService/data", "ApplicationUsers");
    private final static QName _SubjectGrp_QNAME = new QName("http://www.sps.ford.com/EntitlementGroupService/data", "SubjectGrp");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.ford.cvddm.outbound.aps.entitlementGroup
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link CustomExceptionType }
     * 
     */
    public CustomExceptionType createCustomExceptionType() {
        return new CustomExceptionType();
    }

    /**
     * Create an instance of {@link GroupDetailType }
     * 
     */
    public GroupDetailType createGroupDetailType() {
        return new GroupDetailType();
    }

    /**
     * Create an instance of {@link UserDetailType }
     * 
     */
    public UserDetailType createUserDetailType() {
        return new UserDetailType();
    }

    /**
     * Create an instance of {@link EntitlementDetailType }
     * 
     */
    public EntitlementDetailType createEntitlementDetailType() {
        return new EntitlementDetailType();
    }

    /**
     * Create an instance of {@link GroupsType }
     * 
     */
    public GroupsType createGroupsType() {
        return new GroupsType();
    }

    /**
     * Create an instance of {@link EntitlementsType }
     * 
     */
    public EntitlementsType createEntitlementsType() {
        return new EntitlementsType();
    }

    /**
     * Create an instance of {@link ApplicationUsersType }
     * 
     */
    public ApplicationUsersType createApplicationUsersType() {
        return new ApplicationUsersType();
    }

    /**
     * Create an instance of {@link GroupUsersType }
     * 
     */
    public GroupUsersType createGroupUsersType() {
        return new GroupUsersType();
    }

    /**
     * Create an instance of {@link EntitlementUsersType }
     * 
     */
    public EntitlementUsersType createEntitlementUsersType() {
        return new EntitlementUsersType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.sps.ford.com/EntitlementGroupService/data", name = "Group")
    public JAXBElement<String> createGroup(String value) {
        return new JAXBElement<String>(_Group_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CustomExceptionType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.sps.ford.com/EntitlementGroupService/data", name = "CustomException")
    public JAXBElement<CustomExceptionType> createCustomException(CustomExceptionType value) {
        return new JAXBElement<CustomExceptionType>(_CustomException_QNAME, CustomExceptionType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GroupsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.sps.ford.com/EntitlementGroupService/data", name = "Groups")
    public JAXBElement<GroupsType> createGroups(GroupsType value) {
        return new JAXBElement<GroupsType>(_Groups_QNAME, GroupsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EntitlementsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.sps.ford.com/EntitlementGroupService/data", name = "Entitlements")
    public JAXBElement<EntitlementsType> createEntitlements(EntitlementsType value) {
        return new JAXBElement<EntitlementsType>(_Entitlements_QNAME, EntitlementsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EntitlementDetailType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.sps.ford.com/EntitlementGroupService/data", name = "EntitlementDetail")
    public JAXBElement<EntitlementDetailType> createEntitlementDetail(EntitlementDetailType value) {
        return new JAXBElement<EntitlementDetailType>(_EntitlementDetail_QNAME, EntitlementDetailType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GroupDetailType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.sps.ford.com/EntitlementGroupService/data", name = "GroupDetail")
    public JAXBElement<GroupDetailType> createGroupDetail(GroupDetailType value) {
        return new JAXBElement<GroupDetailType>(_GroupDetail_QNAME, GroupDetailType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UserDetailType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.sps.ford.com/EntitlementGroupService/data", name = "UserDetail")
    public JAXBElement<UserDetailType> createUserDetail(UserDetailType value) {
        return new JAXBElement<UserDetailType>(_UserDetail_QNAME, UserDetailType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.sps.ford.com/EntitlementGroupService/data", name = "SubjectEnt")
    public JAXBElement<String> createSubjectEnt(String value) {
        return new JAXBElement<String>(_SubjectEnt_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.sps.ford.com/EntitlementGroupService/data", name = "Entitlement")
    public JAXBElement<String> createEntitlement(String value) {
        return new JAXBElement<String>(_Entitlement_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GroupUsersType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.sps.ford.com/EntitlementGroupService/data", name = "GroupUsers")
    public JAXBElement<GroupUsersType> createGroupUsers(GroupUsersType value) {
        return new JAXBElement<GroupUsersType>(_GroupUsers_QNAME, GroupUsersType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EntitlementUsersType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.sps.ford.com/EntitlementGroupService/data", name = "EntitlementUsers")
    public JAXBElement<EntitlementUsersType> createEntitlementUsers(EntitlementUsersType value) {
        return new JAXBElement<EntitlementUsersType>(_EntitlementUsers_QNAME, EntitlementUsersType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.sps.ford.com/EntitlementGroupService/data", name = "Application")
    public JAXBElement<String> createApplication(String value) {
        return new JAXBElement<String>(_Application_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ApplicationUsersType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.sps.ford.com/EntitlementGroupService/data", name = "ApplicationUsers")
    public JAXBElement<ApplicationUsersType> createApplicationUsers(ApplicationUsersType value) {
        return new JAXBElement<ApplicationUsersType>(_ApplicationUsers_QNAME, ApplicationUsersType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.sps.ford.com/EntitlementGroupService/data", name = "SubjectGrp")
    public JAXBElement<String> createSubjectGrp(String value) {
        return new JAXBElement<String>(_SubjectGrp_QNAME, String.class, null, value);
    }

}
