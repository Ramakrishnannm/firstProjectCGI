
package com.ford.cvddm.outbound.givis.soap.givismodulestate;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PrecedenceElementType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PrecedenceElementType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;choice minOccurs="0">
 *           &lt;element name="PrecedenceGroup" type="{urn:ford/Vehicle/Module/Information/v4.0}PrecedenceElementType" minOccurs="0"/>
 *           &lt;element name="FirstCondition" type="{urn:ford/Vehicle/Module/Information/v4.0}FirstConditionType" minOccurs="0"/>
 *         &lt;/choice>
 *         &lt;element name="AdditionalConditions" type="{urn:ford/Vehicle/Module/Information/v4.0}AdditionalConditionsType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="Negation" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PrecedenceElementType", propOrder = {
    "precedenceGroup",
    "firstCondition",
    "additionalConditions"
})
public class PrecedenceElementType {

    @XmlElement(name = "PrecedenceGroup")
    protected PrecedenceElementType precedenceGroup;
    @XmlElement(name = "FirstCondition")
    protected FirstConditionType firstCondition;
    @XmlElement(name = "AdditionalConditions")
    protected List<AdditionalConditionsType> additionalConditions;
    @XmlAttribute(name = "Negation")
    protected Boolean negation;

    /**
     * Gets the value of the precedenceGroup property.
     * 
     * @return
     *     possible object is
     *     {@link PrecedenceElementType }
     *     
     */
    public PrecedenceElementType getPrecedenceGroup() {
        return precedenceGroup;
    }

    /**
     * Sets the value of the precedenceGroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link PrecedenceElementType }
     *     
     */
    public void setPrecedenceGroup(PrecedenceElementType value) {
        this.precedenceGroup = value;
    }

    /**
     * Gets the value of the firstCondition property.
     * 
     * @return
     *     possible object is
     *     {@link FirstConditionType }
     *     
     */
    public FirstConditionType getFirstCondition() {
        return firstCondition;
    }

    /**
     * Sets the value of the firstCondition property.
     * 
     * @param value
     *     allowed object is
     *     {@link FirstConditionType }
     *     
     */
    public void setFirstCondition(FirstConditionType value) {
        this.firstCondition = value;
    }

    /**
     * Gets the value of the additionalConditions property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the additionalConditions property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAdditionalConditions().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AdditionalConditionsType }
     * 
     * 
     */
    public List<AdditionalConditionsType> getAdditionalConditions() {
        if (additionalConditions == null) {
            additionalConditions = new ArrayList<AdditionalConditionsType>();
        }
        return this.additionalConditions;
    }

    /**
     * Gets the value of the negation property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public boolean isNegation() {
        if (negation == null) {
            return false;
        } else {
            return negation;
        }
    }

    /**
     * Sets the value of the negation property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setNegation(Boolean value) {
        this.negation = value;
    }

}
