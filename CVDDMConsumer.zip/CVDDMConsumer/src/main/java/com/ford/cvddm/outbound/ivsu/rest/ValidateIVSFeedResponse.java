package com.ford.cvddm.outbound.ivsu.rest;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ValidateIVSFeedResponse {

	@JsonProperty("partLineageData")
	private String partLineageData;

	@JsonProperty("HardwareDescription")
	private String hardwareDescription;

	@JsonProperty("assembly")
	private String assembly;

	@JsonProperty("softwareParts")
	private String softwareParts;
	
	@JsonProperty("Applications")
	private String applications;

	@JsonProperty("serviceXMLType")
	private String serviceXMLType;

	@JsonProperty("hardwarePartNumber")
	private String hardwarePartNumber;

	@JsonProperty("nodeAdress")
	private String nodeAdress;

	@JsonProperty("ProgramCode")
	private String programCode;

	@JsonProperty("modelYear")
	private String modelYear;

	@JsonProperty("replacementModuleIsInOperation")
	private String replacementModuleIsInOperation;

	@JsonProperty("activeDataSet")
	private String activeDataSet;

	@JsonProperty("programInService")
	private String programInService;

	@JsonProperty("assemblyDescription")
	private String assemblyDescription;	

	public String getApplications() {
		return applications;
	}

	public void setApplications(String applications) {
		this.applications = applications;
	}

	public String getPartLineageData() {
		return partLineageData;
	}

	public void setPartLineageData(String partLineageData) {
		this.partLineageData = partLineageData;
	}

	public String getHardwareDescription() {
		return hardwareDescription;
	}

	public void setHardwareDescription(String hardwareDescription) {
		this.hardwareDescription = hardwareDescription;
	}

	public String getAssembly() {
		return assembly;
	}

	public void setAssembly(String assembly) {
		this.assembly = assembly;
	}

	public String getSoftwareParts() {
		return softwareParts;
	}

	public void setSoftwareParts(String softwareParts) {
		this.softwareParts = softwareParts;
	}

	public String getServiceXMLType() {
		return serviceXMLType;
	}

	public void setServiceXMLType(String serviceXMLType) {
		this.serviceXMLType = serviceXMLType;
	}

	public String getHardwarePartNumber() {
		return hardwarePartNumber;
	}

	public void setHardwarePartNumber(String hardwarePartNumber) {
		this.hardwarePartNumber = hardwarePartNumber;
	}

	public String getNodeAdress() {
		return nodeAdress;
	}

	public void setNodeAdress(String nodeAdress) {
		this.nodeAdress = nodeAdress;
	}

	public String getProgramCode() {
		return programCode;
	}

	public void setProgramCode(String programCode) {
		this.programCode = programCode;
	}

	public String getModelYear() {
		return modelYear;
	}

	public void setModelYear(String modelYear) {
		this.modelYear = modelYear;
	}

	public String getReplacementModuleIsInOperation() {
		return replacementModuleIsInOperation;
	}

	public void setReplacementModuleIsInOperation(String replacementModuleIsInOperation) {
		this.replacementModuleIsInOperation = replacementModuleIsInOperation;
	}

	public String getActiveDataSet() {
		return activeDataSet;
	}

	public void setActiveDataSet(String activeDataSet) {
		this.activeDataSet = activeDataSet;
	}

	public String getProgramInService() {
		return programInService;
	}

	public void setProgramInService(String programInService) {
		this.programInService = programInService;
	}

	public String getAssemblyDescription() {
		return assemblyDescription;
	}

	public void setAssemblyDescription(String assemblyDescription) {
		this.assemblyDescription = assemblyDescription;
	}

}
