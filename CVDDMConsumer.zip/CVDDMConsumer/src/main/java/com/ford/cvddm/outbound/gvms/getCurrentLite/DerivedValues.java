
package com.ford.cvddm.outbound.gvms.getCurrentLite;


public class DerivedValues {

    private String isDerivedAssembly;
    private String isPart2Spec;
    private String reservedElement;

    public String getIsDerivedAssembly() {
        return isDerivedAssembly;
    }

    public void setIsDerivedAssembly(String isDerivedAssembly) {
        this.isDerivedAssembly = isDerivedAssembly;
    }

    public String getIsPart2Spec() {
        return isPart2Spec;
    }

    public void setIsPart2Spec(String isPart2Spec) {
        this.isPart2Spec = isPart2Spec;
    }

    public String getReservedElement() {
        return reservedElement;
    }

    public void setReservedElement(String reservedElement) {
        this.reservedElement = reservedElement;
    }

}
