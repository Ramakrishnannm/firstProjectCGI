
package com.ford.cvddm.outbound.givis.soap.givismodulestate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConditionSegmentType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConditionSegmentType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ConditionType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Format" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ECUAcronym" type="{urn:ford/Vehicle/Module/Information/v4.0}ECUAcronymType" minOccurs="0"/>
 *         &lt;element name="NodeAddr" type="{urn:ford/Vehicle/Module/Information/v4.0}NodeAddrType" minOccurs="0"/>
 *         &lt;element name="GatewayNodeID" type="{urn:ford/Vehicle/Module/Information/v4.0}GatewayNodeIDType" minOccurs="0"/>
 *         &lt;element name="DIDValue" type="{urn:ford/Vehicle/Module/Information/v4.0}DIDType" minOccurs="0"/>
 *         &lt;element name="Question" type="{urn:ford/Vehicle/Module/Information/v4.0}QuestionType" minOccurs="0"/>
 *         &lt;choice minOccurs="0">
 *           &lt;group ref="{urn:ford/Vehicle/Module/Information/v4.0}HexGroup"/>
 *           &lt;group ref="{urn:ford/Vehicle/Module/Information/v4.0}ASCIIGroup"/>
 *         &lt;/choice>
 *         &lt;element name="LogicalOperator" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;choice>
 *           &lt;element name="Target" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *           &lt;sequence>
 *             &lt;element name="MinimumTarget" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *             &lt;element name="MaximumTarget" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *           &lt;/sequence>
 *         &lt;/choice>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConditionSegmentType", propOrder = {
    "conditionType",
    "format",
    "ecuAcronym",
    "nodeAddr",
    "gatewayNodeID",
    "didValue",
    "question",
    "shift",
    "mask",
    "start",
    "length",
    "logicalOperator",
    "target",
    "minimumTarget",
    "maximumTarget"
})
@XmlSeeAlso({
    ConditionSegment.class
})
public class ConditionSegmentType {

    @XmlElement(name = "ConditionType", required = true)
    protected String conditionType;
    @XmlElement(name = "Format", required = true)
    protected String format;
    @XmlElement(name = "ECUAcronym")
    protected ECUAcronymType ecuAcronym;
    @XmlElement(name = "NodeAddr")
    protected String nodeAddr;
    @XmlElement(name = "GatewayNodeID")
    protected String gatewayNodeID;
    @XmlElement(name = "DIDValue")
    protected String didValue;
    @XmlElement(name = "Question")
    protected QuestionType question;
    @XmlElement(name = "Shift")
    protected String shift;
    @XmlElement(name = "Mask")
    protected String mask;
    @XmlElement(name = "Start")
    protected String start;
    @XmlElement(name = "Length")
    protected String length;
    @XmlElement(name = "LogicalOperator", required = true)
    protected String logicalOperator;
    @XmlElement(name = "Target")
    protected String target;
    @XmlElement(name = "MinimumTarget")
    protected String minimumTarget;
    @XmlElement(name = "MaximumTarget")
    protected String maximumTarget;

    /**
     * Gets the value of the conditionType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConditionType() {
        return conditionType;
    }

    /**
     * Sets the value of the conditionType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConditionType(String value) {
        this.conditionType = value;
    }

    /**
     * Gets the value of the format property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormat() {
        return format;
    }

    /**
     * Sets the value of the format property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormat(String value) {
        this.format = value;
    }

    /**
     * Gets the value of the ecuAcronym property.
     * 
     * @return
     *     possible object is
     *     {@link ECUAcronymType }
     *     
     */
    public ECUAcronymType getECUAcronym() {
        return ecuAcronym;
    }

    /**
     * Sets the value of the ecuAcronym property.
     * 
     * @param value
     *     allowed object is
     *     {@link ECUAcronymType }
     *     
     */
    public void setECUAcronym(ECUAcronymType value) {
        this.ecuAcronym = value;
    }

    /**
     * Gets the value of the nodeAddr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNodeAddr() {
        return nodeAddr;
    }

    /**
     * Sets the value of the nodeAddr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNodeAddr(String value) {
        this.nodeAddr = value;
    }

    /**
     * Gets the value of the gatewayNodeID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGatewayNodeID() {
        return gatewayNodeID;
    }

    /**
     * Sets the value of the gatewayNodeID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGatewayNodeID(String value) {
        this.gatewayNodeID = value;
    }

    /**
     * Gets the value of the didValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDIDValue() {
        return didValue;
    }

    /**
     * Sets the value of the didValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDIDValue(String value) {
        this.didValue = value;
    }

    /**
     * Gets the value of the question property.
     * 
     * @return
     *     possible object is
     *     {@link QuestionType }
     *     
     */
    public QuestionType getQuestion() {
        return question;
    }

    /**
     * Sets the value of the question property.
     * 
     * @param value
     *     allowed object is
     *     {@link QuestionType }
     *     
     */
    public void setQuestion(QuestionType value) {
        this.question = value;
    }

    /**
     * Gets the value of the shift property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShift() {
        return shift;
    }

    /**
     * Sets the value of the shift property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShift(String value) {
        this.shift = value;
    }

    /**
     * Gets the value of the mask property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMask() {
        return mask;
    }

    /**
     * Sets the value of the mask property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMask(String value) {
        this.mask = value;
    }

    /**
     * Gets the value of the start property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStart() {
        return start;
    }

    /**
     * Sets the value of the start property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStart(String value) {
        this.start = value;
    }

    /**
     * Gets the value of the length property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLength() {
        return length;
    }

    /**
     * Sets the value of the length property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLength(String value) {
        this.length = value;
    }

    /**
     * Gets the value of the logicalOperator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLogicalOperator() {
        return logicalOperator;
    }

    /**
     * Sets the value of the logicalOperator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLogicalOperator(String value) {
        this.logicalOperator = value;
    }

    /**
     * Gets the value of the target property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTarget() {
        return target;
    }

    /**
     * Sets the value of the target property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTarget(String value) {
        this.target = value;
    }

    /**
     * Gets the value of the minimumTarget property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMinimumTarget() {
        return minimumTarget;
    }

    /**
     * Sets the value of the minimumTarget property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMinimumTarget(String value) {
        this.minimumTarget = value;
    }

    /**
     * Gets the value of the maximumTarget property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaximumTarget() {
        return maximumTarget;
    }

    /**
     * Sets the value of the maximumTarget property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaximumTarget(String value) {
        this.maximumTarget = value;
    }

}
