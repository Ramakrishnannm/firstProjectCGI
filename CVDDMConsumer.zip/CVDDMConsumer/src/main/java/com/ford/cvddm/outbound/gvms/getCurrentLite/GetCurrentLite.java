
package com.ford.cvddm.outbound.gvms.getCurrentLite;

import java.util.List;

public class GetCurrentLite {

    private List<AdditionalAttribute> additionalAttributes = null;
    private DerivedValues derivedValues;
    private DidInfoType didInfoType;
    private String isPgmyRequired;
    private String isMfalInfoRequired;
    private Mfalinfo mfalInfo;
    private String isBlemProvisioned;
    private String isNodeInfoRequired;
    private NodeInfo nodeInfo;
    private String role;
    private String roleDesc;
    private String roleID;
    private String roleSource;
    private Sync sync;
    private String traceID;
    private String vin;

    public List<AdditionalAttribute> getAdditionalAttributes() {
        return additionalAttributes;
    }

    public void setAdditionalAttributes(List<AdditionalAttribute> additionalAttributes) {
        this.additionalAttributes = additionalAttributes;
    }

    public DerivedValues getDerivedValues() {
        return derivedValues;
    }

    public void setDerivedValues(DerivedValues derivedValues) {
        this.derivedValues = derivedValues;
    }

    public DidInfoType getDidInfoType() {
        return didInfoType;
    }

    public void setDidInfoType(DidInfoType didInfoType) {
        this.didInfoType = didInfoType;
    }

    public String getIsPgmyRequired() {
        return isPgmyRequired;
    }

    public void setIsPgmyRequired(String isPgmyRequired) {
        this.isPgmyRequired = isPgmyRequired;
    }

    public String getisMfalInfoRequired() {
        return this.isMfalInfoRequired; }

    public void setisMfalInfoRequired(String isMfalInfoRequired) {
        this.isMfalInfoRequired = isMfalInfoRequired;
    }

    public Mfalinfo getMfalInfo () { return  mfalInfo; }

    public void setMfalinfo(Mfalinfo mfalInfo) {
        this.mfalInfo = mfalInfo;
    }

    public String getIsNodeInfoRequired() {
        return isNodeInfoRequired;
    }

    public void setIsNodeInfoRequired(String isNodeInfoRequired) {
        this.isNodeInfoRequired = isNodeInfoRequired;
    }

    public NodeInfo getNodeInfo() {
        return nodeInfo;
    }

    public void setNodeInfo(NodeInfo nodeInfo) {
        this.nodeInfo = nodeInfo;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getRoleDesc() {
        return roleDesc;
    }

    public void setRoleDesc(String roleDesc) {
        this.roleDesc = roleDesc;
    }

    public String getRoleID() {
        return roleID;
    }

    public void setRoleID(String roleID) {
        this.roleID = roleID;
    }

    public String getRoleSource() {
        return roleSource;
    }

    public void setRoleSource(String roleSource) {
        this.roleSource = roleSource;
    }

    public Sync getSync() {
        return sync;
    }

    public void setSync(Sync sync) {
        this.sync = sync;
    }

    public String getTraceID() {
        return traceID;
    }

    public void setTraceID(String traceID) {
        this.traceID = traceID;
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

}
