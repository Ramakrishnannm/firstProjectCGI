
package com.ford.cvddm.outbound.givis.soap.givismodulestate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for AdditionalNodePropertiesType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AdditionalNodePropertiesType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PartitionHealth" type="{urn:ford/Vehicle/Module/Information/v4.0}PartitionHealthType" minOccurs="0"/>
 *         &lt;element name="InstallationLog" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SyncData" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="logGeneratedDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" />
 *       &lt;attribute name="RAM" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="vmcuVersion" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AdditionalNodePropertiesType", propOrder = {
    "partitionHealth",
    "installationLog",
    "syncData"
})
public class AdditionalNodePropertiesType {

    @XmlElement(name = "PartitionHealth")
    protected PartitionHealthType partitionHealth;
    @XmlElement(name = "InstallationLog")
    protected String installationLog;
    @XmlElement(name = "SyncData")
    protected String syncData;
    @XmlAttribute(name = "logGeneratedDateTime")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar logGeneratedDateTime;
    @XmlAttribute(name = "RAM")
    protected String ram;
    @XmlAttribute(name = "vmcuVersion")
    protected String vmcuVersion;

    /**
     * Gets the value of the partitionHealth property.
     * 
     * @return
     *     possible object is
     *     {@link PartitionHealthType }
     *     
     */
    public PartitionHealthType getPartitionHealth() {
        return partitionHealth;
    }

    /**
     * Sets the value of the partitionHealth property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartitionHealthType }
     *     
     */
    public void setPartitionHealth(PartitionHealthType value) {
        this.partitionHealth = value;
    }

    /**
     * Gets the value of the installationLog property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInstallationLog() {
        return installationLog;
    }

    /**
     * Sets the value of the installationLog property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInstallationLog(String value) {
        this.installationLog = value;
    }

    /**
     * Gets the value of the syncData property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSyncData() {
        return syncData;
    }

    /**
     * Sets the value of the syncData property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSyncData(String value) {
        this.syncData = value;
    }

    /**
     * Gets the value of the logGeneratedDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getLogGeneratedDateTime() {
        return logGeneratedDateTime;
    }

    /**
     * Sets the value of the logGeneratedDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setLogGeneratedDateTime(XMLGregorianCalendar value) {
        this.logGeneratedDateTime = value;
    }

    /**
     * Gets the value of the ram property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRAM() {
        return ram;
    }

    /**
     * Sets the value of the ram property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRAM(String value) {
        this.ram = value;
    }

    /**
     * Gets the value of the vmcuVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVmcuVersion() {
        return vmcuVersion;
    }

    /**
     * Sets the value of the vmcuVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVmcuVersion(String value) {
        this.vmcuVersion = value;
    }

}
