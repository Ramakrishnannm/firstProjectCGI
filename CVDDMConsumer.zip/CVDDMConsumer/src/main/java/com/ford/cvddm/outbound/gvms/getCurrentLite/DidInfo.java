package com.ford.cvddm.outbound.gvms.getCurrentLite;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Created by BVENKA10 on 9/13/2017.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DidInfo
{
    private String didResponse;

    private String didType;

    private String did;

    public String getDidResponse ()
    {
        return didResponse;
    }

    public void setDidResponse (String didResponse)
    {
        this.didResponse = didResponse;
    }

    public String getDidType ()
    {
        return didType;
    }

    public void setDidType (String didType)
    {
        this.didType = didType;
    }

    public String getDid ()
    {
        return did;
    }

    public void setDid (String did)
    {
        this.did = did;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [didResponse = "+didResponse+", didType = "+didType+", did = "+did+"]";
    }
}