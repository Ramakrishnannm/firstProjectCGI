
package com.ford.cvddm.outbound.gvms.vehicleModuleInfo;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RoleSourceENUMType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="RoleSourceENUMType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="PTS"/>
 *     &lt;enumeration value="IDS"/>
 *     &lt;enumeration value="ETIS"/>
 *     &lt;enumeration value="SMR"/>
 *     &lt;enumeration value="CKS"/>
 *     &lt;enumeration value="LCS"/>
 *     &lt;enumeration value="ECATS"/>
 *     &lt;enumeration value="EOL"/>
 *     &lt;enumeration value="VHR"/>
 *     &lt;enumeration value="FCS"/>
 *     &lt;enumeration value="OTA"/>
 *     &lt;enumeration value="FIMCO"/>
 *     &lt;enumeration value="MODULE"/>
 *     &lt;enumeration value="RVCM"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "RoleSourceENUMType")
@XmlEnum
public enum RoleSourceENUMType {

    PTS,
    IDS,
    ETIS,
    SMR,
    CKS,
    LCS,
    ECATS,
    EOL,
    VHR,
    FCS,
    OTA,
    FIMCO,
    MODULE,
    RVCM;

    public String value() {
        return name();
    }

    public static RoleSourceENUMType fromValue(String v) {
        return valueOf(v);
    }

}
