/**
 * 
 */
package com.ford.cvddm.outbound.gvms.getCurrentLite;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import com.ford.cvddm.constant.CVDDMConstant;

/**
 * US1076334
 * This Class would be used for GVMS Multi VIN Functionality.
 * @author NGUPTA18
 *
 */
public class GvmsGetCurrentLiteParent implements Serializable {
	
	
	
	private static final long serialVersionUID = 1L;
	
	private String vinNumber;
	
	private transient VehicleDetails vehicleDetails = new VehicleDetails();
	
	private transient List<VehicleDetails> vehicleDetailsLst = new ArrayList<VehicleDetails>();
	
	private transient List<NodeDetail> nodeList = new ArrayList<NodeDetail>();
	
	private transient NodeDetail nodeDetail = new NodeDetail();
	
	private transient List<DidInfoDetail> didList = new ArrayList<DidInfoDetail>();
	
	private transient DidInfoDetail didInfoDetail = new DidInfoDetail();
	
	private  transient List <StatusInfo> statusInfosLst = new ArrayList<StatusInfo>();
	
	private transient StatusInfo  statusInfo = new StatusInfo();

	private String disGVMSRespAvl = CVDDMConstant.STRING_N ;
	
	private String overallStatusMsg = CVDDMConstant.EMPTY_STRING ;
	
	/**
	 * @return the overallStatusMsg
	 */
	public String getOverallStatusMsg() {
		return overallStatusMsg;
	}

	/**
	 * @param overallStatusMsg the overallStatusMsg to set
	 */
	public void setOverallStatusMsg(String overallStatusMsg) {
		this.overallStatusMsg = overallStatusMsg;
	}

	public String getDisGVMSRespAvl() {
		return disGVMSRespAvl;
	}

	public void setDisGVMSRespAvl(String disGVMSRespAvl) {
		this.disGVMSRespAvl = disGVMSRespAvl;
	}

	
	/**
	 * @return the vinNumber
	 */
	public String getVinNumber() {
		return vinNumber;
	}

	/**
	 * @param vinNumber the vinNumber to set
	 */
	public void setVinNumber(String vinNumber) {
		this.vinNumber = vinNumber;
	}

	/**
	 * @return the nodeList
	 */
	public List<NodeDetail> getNodeList() {
		return nodeList;
	}

	/**
	 * @param nodeList the nodeList to set
	 */
	public void setNodeList(List<NodeDetail> nodeList) {
		this.nodeList = nodeList;
	}



	/**
	 * @return the didList
	 */
	public List<DidInfoDetail> getDidList() {
		return didList;
	}

	/**
	 * @param didList the didList to set
	 */
	public void setDidList(List<DidInfoDetail> didList) {
		this.didList = didList;
	}

	/**
	 * @return the statusInfosLst
	 */
	public List <StatusInfo> getStatusInfosLst() {
		return statusInfosLst;
	}

	/**
	 * @param statusInfosLst the statusInfosLst to set
	 */
	public void setStatusInfosLst(List <StatusInfo> statusInfosLst) {
		this.statusInfosLst = statusInfosLst;
	}

	/**
	 * @return the vehicleDetailsLst
	 */
	public List<VehicleDetails> getVehicleDetailsLst() {
		return vehicleDetailsLst;
	}

	/**
	 * @param vehicleDetailsLst the vehicleDetailsLst to set
	 */
	public void setVehicleDetailsLst(List<VehicleDetails> vehicleDetailsLst) {
		this.vehicleDetailsLst = vehicleDetailsLst;
	}

	/**
	 * @return the vehicleDetails
	 */
	public VehicleDetails getVehicleDetails() {
		return vehicleDetails;
	}

	/**
	 * @param vehicleDetails the vehicleDetails to set
	 */
	public void setVehicleDetails(VehicleDetails vehicleDetails) {
		this.vehicleDetails = vehicleDetails;
	}

	/**
	 * @return the nodeDetail
	 */
	public NodeDetail getNodeDetail() {
		return nodeDetail;
	}

	/**
	 * @param nodeDetail the nodeDetail to set
	 */
	public void setNodeDetail(NodeDetail nodeDetail) {
		this.nodeDetail = nodeDetail;
	}

	/**
	 * @return the didInfoDetail
	 */
	public DidInfoDetail getDidInfoDetail() {
		return didInfoDetail;
	}

	/**
	 * @param didInfoDetail the didInfoDetail to set
	 */
	public void setDidInfoDetail(DidInfoDetail didInfoDetail) {
		this.didInfoDetail = didInfoDetail;
	}

	/**
	 * @return the statusInfo
	 */
	public StatusInfo getStatusInfo() {
		return statusInfo;
	}

	/**
	 * @param statusInfo the statusInfo to set
	 */
	public void setStatusInfo(StatusInfo statusInfo) {
		this.statusInfo = statusInfo;
	}

}
