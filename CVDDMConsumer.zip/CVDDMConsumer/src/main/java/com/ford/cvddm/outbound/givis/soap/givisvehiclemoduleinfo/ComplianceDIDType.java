
package com.ford.cvddm.outbound.givis.soap.givisvehiclemoduleinfo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ComplianceDIDType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ComplianceDIDType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="didValue" type="{urn:ford/Vehicle/Module/Information/v4.0}DIDValueType" />
 *       &lt;attribute name="response" type="{urn:ford/Vehicle/Module/Information/v4.0}ComplianceDIDResponseType" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ComplianceDIDType")
public class ComplianceDIDType {

    @XmlAttribute(name = "didValue")
    protected String didValue;
    @XmlAttribute(name = "response")
    protected String response;

    /**
     * Gets the value of the didValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDidValue() {
        return didValue;
    }

    /**
     * Sets the value of the didValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDidValue(String value) {
        this.didValue = value;
    }

    /**
     * Gets the value of the response property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponse() {
        return response;
    }

    /**
     * Sets the value of the response property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponse(String value) {
        this.response = value;
    }

}
