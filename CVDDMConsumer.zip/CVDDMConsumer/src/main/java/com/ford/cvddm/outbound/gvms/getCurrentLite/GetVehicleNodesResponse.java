package com.ford.cvddm.outbound.gvms.getCurrentLite;

import java.util.Map;

/**
 * Created by vm4 on 10/04/2018.
 */
public class GetVehicleNodesResponse {

    private Map<String, Long> latestNodeSnapshotMap;
    private Long ivsXMLInfoKey;

    public Map<String, Long> getLatestNodeSnapshotMap() {
        return latestNodeSnapshotMap;
    }

    public void setLatestNodeSnapshotMap(Map<String, Long> latestNodeSnapshotMap) {
        this.latestNodeSnapshotMap = latestNodeSnapshotMap;
    }

    public Long getIvsXMLInfoKey() {
        return ivsXMLInfoKey;
    }

    public void setIvsXMLInfoKey(Long ivsXMLInfoKey) {
        this.ivsXMLInfoKey = ivsXMLInfoKey;
    }
}
