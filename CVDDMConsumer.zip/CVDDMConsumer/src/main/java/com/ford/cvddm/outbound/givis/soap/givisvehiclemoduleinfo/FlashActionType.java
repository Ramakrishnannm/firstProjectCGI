
package com.ford.cvddm.outbound.givis.soap.givisvehiclemoduleinfo;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * 				Container type for service actions and available
 * 				assemblies for node(s) requested
 * 			
 * 
 * <p>Java class for FlashActionType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FlashActionType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="TSB" type="{urn:ford/Vehicle/Module/Information/v4.0}TSBType" minOccurs="0"/>
 *         &lt;element name="Assembly" type="{urn:ford/Vehicle/Module/Information/v4.0}ECUAssemblyType" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *       &lt;attribute name="parser" type="{urn:ford/Vehicle/Module/Information/v4.0}ParserENUMType" />
 *       &lt;attribute name="targetNode" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="description" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="rationalMnemonicGroupName" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="revision" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="wersConcern" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FlashActionType", propOrder = {
    "tsb",
    "assembly"
})
public class FlashActionType {

    @XmlElement(name = "TSB")
    protected TSBType tsb;
    @XmlElement(name = "Assembly", required = true)
    protected List<ECUAssemblyType> assembly;
    @XmlAttribute(name = "parser")
    protected ParserENUMType parser;
    @XmlAttribute(name = "targetNode")
    protected String targetNode;
    @XmlAttribute(name = "description")
    protected String description;
    @XmlAttribute(name = "rationalMnemonicGroupName")
    protected String rationalMnemonicGroupName;
    @XmlAttribute(name = "id")
    protected String id;
    @XmlAttribute(name = "revision")
    protected String revision;
    @XmlAttribute(name = "wersConcern")
    protected String wersConcern;

    /**
     * Gets the value of the tsb property.
     * 
     * @return
     *     possible object is
     *     {@link TSBType }
     *     
     */
    public TSBType getTSB() {
        return tsb;
    }

    /**
     * Sets the value of the tsb property.
     * 
     * @param value
     *     allowed object is
     *     {@link TSBType }
     *     
     */
    public void setTSB(TSBType value) {
        this.tsb = value;
    }

    /**
     * Gets the value of the assembly property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the assembly property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAssembly().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ECUAssemblyType }
     * 
     * 
     */
    public List<ECUAssemblyType> getAssembly() {
        if (assembly == null) {
            assembly = new ArrayList<ECUAssemblyType>();
        }
        return this.assembly;
    }

    /**
     * Gets the value of the parser property.
     * 
     * @return
     *     possible object is
     *     {@link ParserENUMType }
     *     
     */
    public ParserENUMType getParser() {
        return parser;
    }

    /**
     * Sets the value of the parser property.
     * 
     * @param value
     *     allowed object is
     *     {@link ParserENUMType }
     *     
     */
    public void setParser(ParserENUMType value) {
        this.parser = value;
    }

    /**
     * Gets the value of the targetNode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTargetNode() {
        return targetNode;
    }

    /**
     * Sets the value of the targetNode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTargetNode(String value) {
        this.targetNode = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the rationalMnemonicGroupName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRationalMnemonicGroupName() {
        return rationalMnemonicGroupName;
    }

    /**
     * Sets the value of the rationalMnemonicGroupName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRationalMnemonicGroupName(String value) {
        this.rationalMnemonicGroupName = value;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * Gets the value of the revision property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRevision() {
        return revision;
    }

    /**
     * Sets the value of the revision property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRevision(String value) {
        this.revision = value;
    }

    /**
     * Gets the value of the wersConcern property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWersConcern() {
        return wersConcern;
    }

    /**
     * Sets the value of the wersConcern property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWersConcern(String value) {
        this.wersConcern = value;
    }

}
