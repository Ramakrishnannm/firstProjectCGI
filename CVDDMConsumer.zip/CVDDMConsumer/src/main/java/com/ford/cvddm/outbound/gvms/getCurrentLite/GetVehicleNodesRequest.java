package com.ford.cvddm.outbound.gvms.getCurrentLite;

import java.util.List;

/**
 * Created by vm4 on 10/04/2018.
 */
public class GetVehicleNodesRequest {

    private String vin;
    private int vinHash;
    private List<String> nodeList = null;
    private boolean ivsXMLInfoKey;

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public int getVinHash() {
        return vinHash;
    }

    public void setVinHash(int vinHash) {
        this.vinHash = vinHash;
    }

    public List<String> getNodeList() {
        return nodeList;
    }

    public void setNodeList(List<String> nodeList) {
        this.nodeList = nodeList;
    }

    public boolean getIvsXMLInfoKey() {
        return ivsXMLInfoKey;
    }

    public void setIvsXMLInfoKey(boolean ivsXMLInfoKey) {
        this.ivsXMLInfoKey = ivsXMLInfoKey;
    }
}
