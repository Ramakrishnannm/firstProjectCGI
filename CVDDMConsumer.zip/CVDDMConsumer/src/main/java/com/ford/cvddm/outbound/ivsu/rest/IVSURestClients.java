package com.ford.cvddm.outbound.ivsu.rest;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.IOUtils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.outbound.layer.CVDDMConsumerException;
import com.ford.it.exception.FordExceptionAttributes;
import com.ford.it.http.HttpPoster;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;

/**
 * 
 * @author MJEYARAJ
 *
 */
public class IVSURestClients {

	/** The Class Name used for Logging */
	private static final String CLASS_NAME = IVSURestClients.class.getName();

	/** The Logger instance used for Logging */
	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	private ObjectMapper mapper = new ObjectMapper();

	/**
	 * Method Name: getWhitelistedPartIISpecFromIVSU
	 * 
	 * @Description: Rest client to retrieve the whitelisted Part II Spec details
	 *               from Cloud.
	 * @param :
	 *            None
	 * @return List<PartIISpecResponse>
	 */
	public List<PartIISpecResponse> getWhitelistedPartIISpecFromIVSU(String enviroinment) {

		final String METHOD_NAME = "getPartIISpecFromIVSU";
		log.entering(CLASS_NAME, METHOD_NAME);

		String outputJson = null;
		String outputJsonUpdated = null;
		List<PartIISpecResponse> outputList = new ArrayList<>();

		try {

			String partIISpecURL = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
					CVDDMConstant.IVSU_END_POINT_PARTIISPEC);

			log.info("PartIISPec url: " + partIISpecURL);
			URL posterURL = new URL(partIISpecURL);

			/** Start Change :User Story: US1028146 ****/
			HttpPoster poster = getHttpPosterWithOauthAuthentication(enviroinment);
			/** End Change :User Story: US1028146 ****/

			poster.setUrl(posterURL);
			poster.useFordInternetProxy();

			String jsonRequestString = "{}";
			InputStream requestInStream = IOUtils.toInputStream(jsonRequestString, "UTF-8");
			InputStream respStream = poster.post(requestInStream);

			StringWriter writer = new StringWriter();
			IOUtils.copy(respStream, writer, "UTF-8");
			outputJson = writer.toString();

			if (outputJson != null) {
				outputJsonUpdated = outputJson.replace("{\"Properties\":", "").replaceAll("}]}", "}]");
			}

			log.info("Output JSON PartIISpec: " + outputJsonUpdated);
			outputList = convertOutputJSONPartIISpec(outputJsonUpdated);
			log.info("Output PartIISpec List: " + outputList.toString());

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMConsumerException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

		return outputList;
	}

	/**
	 * Method Name: retrieveIVSFeed
	 * 
	 * @Description: Client to retrieve IVS Feed details from IVSU
	 * @param :
	 *            RetrieveIVSFeedRequest
	 * @return List<RetrieveIVSFeedResponse>
	 */
	public List<RetrieveIVSFeedResponse> retrieveIVSFeed(RetrieveIVSFeedRequest request, String enviroinment) {

		final String METHOD_NAME = "retrieveIVSFeed";
		log.entering(CLASS_NAME, METHOD_NAME);

		String outputJson = null;
		String outputJsonUpdated = null;
		List<RetrieveIVSFeedResponse> outputList = new ArrayList<>();

		String jsonRequestString = null;
		String updatedJsonRequestString = null;

		try {
			jsonRequestString = mapper.writeValueAsString(request);
		} catch (IOException e) {
			e.printStackTrace();
		}

		log.info("JsonRequestString value is :" + jsonRequestString);
		updatedJsonRequestString = jsonRequestString.replace("retrieveIVSFeed", "properties");
		log.info("Updated JsonRequestString value is :" + updatedJsonRequestString);

		try {

			String endPointURL = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
					CVDDMConstant.IVSU_END_POINT_TO_RETRIVE_IVS_FEED);
			URL posterURL = new URL(endPointURL);

			/** Start Change :User Story: US1028146 ****/
			HttpPoster poster = getHttpPosterWithOauthAuthentication(enviroinment);
			/** End Change :User Story: US1028146 ****/
			poster.setUrl(posterURL);
			poster.useFordInternetProxy();

			InputStream requestInStream = IOUtils.toInputStream(updatedJsonRequestString, "UTF-8");
			InputStream respStream = poster.post(requestInStream);

			StringWriter writer = new StringWriter();
			IOUtils.copy(respStream, writer, "UTF-8");
			outputJson = writer.toString();

			if (outputJson != null) {
				outputJsonUpdated = outputJson.replace("{\"Properties\":", "").replaceAll("}]}", "}]");
			}

			log.info("Output JSON IVS Feed details : " + outputJsonUpdated);
			outputList = convertOutputJSONIvsFeedDetails(outputJsonUpdated);
			log.info("Output IVS Feed details List: " + outputList.toString());

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMConsumerException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}

		return outputList;
	}

	/**
	 * Method Name: validateIVSFeed
	 * 
	 * @Description: Client to Validate IVS Feed details from IVSU
	 * @param :
	 *            ValidateIVSFeedRequest
	 * @return List<ValidateIVSFeedResponse>
	 */
	public List<ValidateIVSFeedResponse> validateIVSFeed(ValidateIVSFeedRequest request, String enviroinment) {

		final String METHOD_NAME = "ValidateIVSFeed";
		log.entering(CLASS_NAME, METHOD_NAME);

		String outputJson = null;
		String outputJsonUpdated = null;
		List<ValidateIVSFeedResponse> outputList = new ArrayList<>();
		String endPointURL = null;

		String jsonRequestString = null;
		String updatedJsonRequestString = null;

		try {
			jsonRequestString = mapper.writeValueAsString(request);
		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		log.info("JsonRequestString value is :" + jsonRequestString);
		updatedJsonRequestString = jsonRequestString.replace("validateIVSFeed", "properties");
		log.info("Updated JsonRequestString value is :" + updatedJsonRequestString);

		try {

			/*** Start Change: User Story : US1107518 ***/
			if (CVDDMConstant.ENV_QA1.equalsIgnoreCase(enviroinment)) {
				endPointURL = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
						CVDDMConstant.IVSU_END_POINT_TO_VALIDATE_IVS_FEED);
			} else if (CVDDMConstant.ENV_QA2.equalsIgnoreCase(enviroinment)) {
				endPointURL = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
						CVDDMConstant.IVSU_END_POINT_TO_VALIDATE_IVS_FEED_QA2);
			}
			/*** Start Change: User Story : US1107518 ***/

			URL posterURL = new URL(endPointURL);

			/** Start Change :User Story: US1028146 ****/
			HttpPoster poster = getHttpPosterWithOauthAuthentication(enviroinment);
			/** End Change :User Story: US1028146 ****/
			poster.setUrl(posterURL);
			poster.useFordInternetProxy();

			InputStream requestInStream = IOUtils.toInputStream(updatedJsonRequestString,
					StandardCharsets.UTF_8.toString());
			InputStream respStream = poster.post(requestInStream);

			StringWriter writer = new StringWriter();
			IOUtils.copy(respStream, writer, "UTF-8");
			outputJson = writer.toString();

			if (outputJson != null) {
				outputJsonUpdated = outputJson.replace("{\"Properties\":", "").replaceAll("}]}", "}]");
			}

			log.info("Output JSON IVS Feed details : " + outputJsonUpdated);
			outputList = convertOutputJSONValidateIvsFeed(outputJsonUpdated);
			log.info("Output IVS Feed details List: " + outputList.toString());

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
			throw new CVDDMConsumerException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(e), e);
		}

		return outputList;
	}

	/** Start Change :User Story: US1028146 ****/
	/**
	 * Method Name: getHttpPosterWithOauthAuthentication
	 * 
	 * @Description: HttpPoster For OAuth authentication
	 * @param :
	 *            none
	 * @return HttpPoster
	 */
	private HttpPoster getHttpPosterWithOauthAuthentication(String enviroinment) {

		System.setProperty("http.proxyHost", CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
				CVDDMConstant.HTTP_PROXY_FOR_AZURE));
		System.setProperty("http.proxyPort", CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
				CVDDMConstant.IVSU_HTTP_POSTER_PROXY_PORT));
		System.setProperty("https.proxyHost", CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
				CVDDMConstant.HTTPS_PROXY_FOR_AZURE));
		System.setProperty("https.proxyPort", CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
				CVDDMConstant.IVSU_HTTP_POSTER_PROXY_PORT));

		HttpPoster poster = new HttpPoster();

		poster.setContentType(CVDDMConstant.CONTENT_TYPE);

		try {

			/*** Start Change: User Story : US1107518 ***/
			if (CVDDMConstant.ENV_QA1.equalsIgnoreCase(enviroinment)) {
				poster.addOauth2Credentials(CVDDMConstant.IVSU_OAUTH_CREDENTIALS);
			} else if (CVDDMConstant.ENV_QA2.equalsIgnoreCase(enviroinment)) {
				poster.addOauth2Credentials(CVDDMConstant.IVSU_OAUTH_CREDENTIALS_QA2);
			}
			/*** Start Change: User Story : US1107518 ***/

		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		return poster;
	}

	/** End Change :User Story: US1028146 ****/

	/**
	 * Method Name: convertOutputJSONPartIISpec
	 * 
	 * @Description: To convert the output JSON to POJO
	 * @param :
	 *            String
	 * @return List<PartIISpecResponse>
	 */
	private List<PartIISpecResponse> convertOutputJSONPartIISpec(String jsonOutputString) {

		List<PartIISpecResponse> participantJsonList = null;

		try {
			participantJsonList = mapper.readValue(jsonOutputString, new TypeReference<List<PartIISpecResponse>>() {
			});
		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		return participantJsonList;
	}

	/**
	 * Method Name: convertOutputJSONIvsFeedDetails
	 * 
	 * @Description: To convert the output JSON to POJO
	 * @param :
	 *            String
	 * @return List<RetrieveIVSFeedResponse>
	 */
	private List<RetrieveIVSFeedResponse> convertOutputJSONIvsFeedDetails(String jsonOutputString) {

		List<RetrieveIVSFeedResponse> participantJsonList = null;

		try {
			participantJsonList = mapper.readValue(jsonOutputString,
					new TypeReference<List<RetrieveIVSFeedResponse>>() {
					});
		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		return participantJsonList;
	}

	/**
	 * Method Name: convertOutputJSONValidateIvsFeed
	 * 
	 * @Description: To convert the output JSON to POJO
	 * @param :
	 *            String
	 * @return List<ValidateIVSFeedResponse>
	 */
	private List<ValidateIVSFeedResponse> convertOutputJSONValidateIvsFeed(String jsonOutputString) {

		List<ValidateIVSFeedResponse> participantJsonList = null;

		try {
			participantJsonList = mapper.readValue(jsonOutputString,
					new TypeReference<List<ValidateIVSFeedResponse>>() {
					});
		} catch (Exception e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		return participantJsonList;
	}
}