
package com.ford.cvddm.outbound.givis.soap.givisvehiclemoduleinfo;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for LicensedPartHistoryResponseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LicensedPartHistoryResponseType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="vin" type="{urn:ford/Vehicle/Module/Information/v4.0}VINType"/>
 *         &lt;element name="isNavigationAvailable" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="LicensedPartHistory" type="{urn:ford/Vehicle/Module/Information/v4.0}LicensedPartHistoryType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LicensedPartHistoryResponseType", namespace = "urn:ford/interface/Vehicle/Module/Information/v4.0", propOrder = {
    "vin",
    "isNavigationAvailable",
    "licensedPartHistory"
})
public class LicensedPartHistoryResponseType {

    @XmlElement(required = true)
    protected String vin;
    protected boolean isNavigationAvailable;
    @XmlElement(name = "LicensedPartHistory")
    protected List<LicensedPartHistoryType> licensedPartHistory;

    /**
     * Gets the value of the vin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVin() {
        return vin;
    }

    /**
     * Sets the value of the vin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVin(String value) {
        this.vin = value;
    }

    /**
     * Gets the value of the isNavigationAvailable property.
     * 
     */
    public boolean isIsNavigationAvailable() {
        return isNavigationAvailable;
    }

    /**
     * Sets the value of the isNavigationAvailable property.
     * 
     */
    public void setIsNavigationAvailable(boolean value) {
        this.isNavigationAvailable = value;
    }

    /**
     * Gets the value of the licensedPartHistory property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the licensedPartHistory property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLicensedPartHistory().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link LicensedPartHistoryType }
     * 
     * 
     */
    public List<LicensedPartHistoryType> getLicensedPartHistory() {
        if (licensedPartHistory == null) {
            licensedPartHistory = new ArrayList<LicensedPartHistoryType>();
        }
        return this.licensedPartHistory;
    }

}
