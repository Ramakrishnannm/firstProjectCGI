
package com.ford.cvddm.outbound.gvms.vehicleModuleInfo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DerivedAssemblyType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DerivedAssemblyType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DID" type="{urn:ford/Vehicle/Module/Information/v4.0}DIDInfoType" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DerivedAssemblyType", propOrder = {
    "did"
})
public class DerivedAssemblyType
    implements Serializable
{

    @XmlElement(name = "DID", required = true)
    protected List<DIDInfoType> did;

    /**
     * Gets the value of the did property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the did property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDID().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DIDInfoType }
     * 
     * 
     */
    public List<DIDInfoType> getDID() {
        if (did == null) {
            did = new ArrayList<DIDInfoType>();
        }
        return this.did;
    }

}
