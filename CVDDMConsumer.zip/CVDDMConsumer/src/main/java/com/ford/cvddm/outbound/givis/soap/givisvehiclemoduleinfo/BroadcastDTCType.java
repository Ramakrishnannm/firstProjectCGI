
package com.ford.cvddm.outbound.givis.soap.givisvehiclemoduleinfo;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BroadcastDTCType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BroadcastDTCType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DTC" type="{urn:ford/Vehicle/Module/Information/v4.0}DTCDetails" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BroadcastDTCType", propOrder = {
    "dtc"
})
public class BroadcastDTCType {

    @XmlElement(name = "DTC")
    protected List<DTCDetails> dtc;

    /**
     * Gets the value of the dtc property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the dtc property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDTC().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DTCDetails }
     * 
     * 
     */
    public List<DTCDetails> getDTC() {
        if (dtc == null) {
            dtc = new ArrayList<DTCDetails>();
        }
        return this.dtc;
    }

}
