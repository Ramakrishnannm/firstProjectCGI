
package com.ford.cvddm.outbound.gvms.moduleState;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ModuleSnapshot" type="{urn:ford/com/productdesign/ipp/ModuleSnapshot/v2.1}ModuleSnapshotType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "moduleSnapshot"
})
@XmlRootElement(name = "ModuleStateRequest", namespace = "urn:ford/com/productdesign/ipp/ModuleState/interface/v2.1")
public class ModuleStateRequest
    implements Serializable
{

    @XmlElement(name = "ModuleSnapshot", namespace = "urn:ford/com/productdesign/ipp/ModuleState/interface/v2.1", required = true)
    protected ModuleSnapshotType moduleSnapshot;

    /**
     * Gets the value of the moduleSnapshot property.
     * 
     * @return
     *     possible object is
     *     {@link ModuleSnapshotType }
     *     
     */
    public ModuleSnapshotType getModuleSnapshot() {
        return moduleSnapshot;
    }

    /**
     * Sets the value of the moduleSnapshot property.
     * 
     * @param value
     *     allowed object is
     *     {@link ModuleSnapshotType }
     *     
     */
    public void setModuleSnapshot(ModuleSnapshotType value) {
        this.moduleSnapshot = value;
    }

}
