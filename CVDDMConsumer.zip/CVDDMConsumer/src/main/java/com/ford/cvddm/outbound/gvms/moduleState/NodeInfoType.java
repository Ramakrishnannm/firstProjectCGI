
package com.ford.cvddm.outbound.gvms.moduleState;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for NodeInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="NodeInfoType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Software" type="{urn:ford/Vehicle/Module/Information/v4.0}ECUSoftwareType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="ModifiedConfig" type="{urn:ford/Vehicle/Module/Information/v4.0}ModifiedConfigDIDInfoType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="SpecCategory" type="{urn:ford/Vehicle/Module/Information/v4.0}SpecCategoryType" minOccurs="0"/>
 *         &lt;element name="DiagnosticNetworkInterface" type="{urn:ford/Vehicle/Module/Information/v4.0}NodeNetworkInterfaceDetailType" minOccurs="0"/>
 *         &lt;element name="ProgrammingNetworkInterface" type="{urn:ford/Vehicle/Module/Information/v4.0}NodeNetworkInterfaceDetailType" maxOccurs="3" minOccurs="0"/>
 *         &lt;element name="CentralConfigurationInfo" type="{urn:ford/Vehicle/Module/Information/v4.0}CentralConfigInfoType" minOccurs="0"/>
 *         &lt;element name="TesterAccessInterface" type="{urn:ford/Vehicle/Module/Information/v4.0}NetworkInterfaceDetailType" minOccurs="0"/>
 *         &lt;element name="ECUAssemblySecurityData" type="{urn:ford/Vehicle/Module/Information/v4.0}ECUAssemblySecurityDataType" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="RplcmntModuleIsInop" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="progInSvc" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="leadNode" type="{urn:ford/Vehicle/Module/Information/v4.0}NodeAddressType" />
 *       &lt;attribute name="gatewayNodeID" type="{urn:ford/Vehicle/Module/Information/v4.0}NodeAddressType" />
 *       &lt;attribute name="gatewayType" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="cpuType" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "NodeInfoType", propOrder = {
    "software",
    "modifiedConfig",
    "specCategory",
    "diagnosticNetworkInterface",
    "programmingNetworkInterface",
    "centralConfigurationInfo",
    "testerAccessInterface",
    "ecuAssemblySecurityData"
})
public class NodeInfoType
    implements Serializable
{

    @XmlElement(name = "Software")
    protected List<ECUSoftwareType> software;
    @XmlElement(name = "ModifiedConfig")
    protected List<ModifiedConfigDIDInfoType> modifiedConfig;
    @XmlElement(name = "SpecCategory")
    protected SpecCategoryType specCategory;
    @XmlElement(name = "DiagnosticNetworkInterface")
    protected NodeNetworkInterfaceDetailType diagnosticNetworkInterface;
    @XmlElement(name = "ProgrammingNetworkInterface")
    protected List<NodeNetworkInterfaceDetailType> programmingNetworkInterface;
    @XmlElement(name = "CentralConfigurationInfo")
    protected CentralConfigInfoType centralConfigurationInfo;
    @XmlElement(name = "TesterAccessInterface")
    protected NetworkInterfaceDetailType testerAccessInterface;
    @XmlElement(name = "ECUAssemblySecurityData")
    protected ECUAssemblySecurityDataType ecuAssemblySecurityData;
    @XmlAttribute(name = "RplcmntModuleIsInop")
    protected Boolean rplcmntModuleIsInop;
    @XmlAttribute(name = "progInSvc")
    protected Boolean progInSvc;
    @XmlAttribute(name = "leadNode")
    protected String leadNode;
    @XmlAttribute(name = "gatewayNodeID")
    protected String gatewayNodeID;
    @XmlAttribute(name = "gatewayType")
    protected String gatewayType;
    @XmlAttribute(name = "cpuType")
    protected String cpuType;

    /**
     * Gets the value of the software property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the software property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSoftware().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ECUSoftwareType }
     * 
     * 
     */
    public List<ECUSoftwareType> getSoftware() {
        if (software == null) {
            software = new ArrayList<ECUSoftwareType>();
        }
        return this.software;
    }

    /**
     * Gets the value of the modifiedConfig property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the modifiedConfig property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getModifiedConfig().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ModifiedConfigDIDInfoType }
     * 
     * 
     */
    public List<ModifiedConfigDIDInfoType> getModifiedConfig() {
        if (modifiedConfig == null) {
            modifiedConfig = new ArrayList<ModifiedConfigDIDInfoType>();
        }
        return this.modifiedConfig;
    }

    /**
     * Gets the value of the specCategory property.
     * 
     * @return
     *     possible object is
     *     {@link SpecCategoryType }
     *     
     */
    public SpecCategoryType getSpecCategory() {
        return specCategory;
    }

    /**
     * Sets the value of the specCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link SpecCategoryType }
     *     
     */
    public void setSpecCategory(SpecCategoryType value) {
        this.specCategory = value;
    }

    /**
     * Gets the value of the diagnosticNetworkInterface property.
     * 
     * @return
     *     possible object is
     *     {@link NodeNetworkInterfaceDetailType }
     *     
     */
    public NodeNetworkInterfaceDetailType getDiagnosticNetworkInterface() {
        return diagnosticNetworkInterface;
    }

    /**
     * Sets the value of the diagnosticNetworkInterface property.
     * 
     * @param value
     *     allowed object is
     *     {@link NodeNetworkInterfaceDetailType }
     *     
     */
    public void setDiagnosticNetworkInterface(NodeNetworkInterfaceDetailType value) {
        this.diagnosticNetworkInterface = value;
    }

    /**
     * Gets the value of the programmingNetworkInterface property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the programmingNetworkInterface property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProgrammingNetworkInterface().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link NodeNetworkInterfaceDetailType }
     * 
     * 
     */
    public List<NodeNetworkInterfaceDetailType> getProgrammingNetworkInterface() {
        if (programmingNetworkInterface == null) {
            programmingNetworkInterface = new ArrayList<NodeNetworkInterfaceDetailType>();
        }
        return this.programmingNetworkInterface;
    }

    /**
     * Gets the value of the centralConfigurationInfo property.
     * 
     * @return
     *     possible object is
     *     {@link CentralConfigInfoType }
     *     
     */
    public CentralConfigInfoType getCentralConfigurationInfo() {
        return centralConfigurationInfo;
    }

    /**
     * Sets the value of the centralConfigurationInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link CentralConfigInfoType }
     *     
     */
    public void setCentralConfigurationInfo(CentralConfigInfoType value) {
        this.centralConfigurationInfo = value;
    }

    /**
     * Gets the value of the testerAccessInterface property.
     * 
     * @return
     *     possible object is
     *     {@link NetworkInterfaceDetailType }
     *     
     */
    public NetworkInterfaceDetailType getTesterAccessInterface() {
        return testerAccessInterface;
    }

    /**
     * Sets the value of the testerAccessInterface property.
     * 
     * @param value
     *     allowed object is
     *     {@link NetworkInterfaceDetailType }
     *     
     */
    public void setTesterAccessInterface(NetworkInterfaceDetailType value) {
        this.testerAccessInterface = value;
    }

    /**
     * Gets the value of the ecuAssemblySecurityData property.
     * 
     * @return
     *     possible object is
     *     {@link ECUAssemblySecurityDataType }
     *     
     */
    public ECUAssemblySecurityDataType getECUAssemblySecurityData() {
        return ecuAssemblySecurityData;
    }

    /**
     * Sets the value of the ecuAssemblySecurityData property.
     * 
     * @param value
     *     allowed object is
     *     {@link ECUAssemblySecurityDataType }
     *     
     */
    public void setECUAssemblySecurityData(ECUAssemblySecurityDataType value) {
        this.ecuAssemblySecurityData = value;
    }

    /**
     * Gets the value of the rplcmntModuleIsInop property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isRplcmntModuleIsInop() {
        return rplcmntModuleIsInop;
    }

    /**
     * Sets the value of the rplcmntModuleIsInop property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setRplcmntModuleIsInop(Boolean value) {
        this.rplcmntModuleIsInop = value;
    }

    /**
     * Gets the value of the progInSvc property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isProgInSvc() {
        return progInSvc;
    }

    /**
     * Sets the value of the progInSvc property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setProgInSvc(Boolean value) {
        this.progInSvc = value;
    }

    /**
     * Gets the value of the leadNode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLeadNode() {
        return leadNode;
    }

    /**
     * Sets the value of the leadNode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLeadNode(String value) {
        this.leadNode = value;
    }

    /**
     * Gets the value of the gatewayNodeID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGatewayNodeID() {
        return gatewayNodeID;
    }

    /**
     * Sets the value of the gatewayNodeID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGatewayNodeID(String value) {
        this.gatewayNodeID = value;
    }

    /**
     * Gets the value of the gatewayType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGatewayType() {
        return gatewayType;
    }

    /**
     * Sets the value of the gatewayType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGatewayType(String value) {
        this.gatewayType = value;
    }

    /**
     * Gets the value of the cpuType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCpuType() {
        return cpuType;
    }

    /**
     * Sets the value of the cpuType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCpuType(String value) {
        this.cpuType = value;
    }

}
