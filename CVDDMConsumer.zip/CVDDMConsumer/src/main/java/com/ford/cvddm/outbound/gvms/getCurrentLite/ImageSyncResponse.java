package com.ford.cvddm.outbound.gvms.getCurrentLite;

/**
 * Created by MDEVARA3 on 1/9/2018.
 */
public class ImageSyncResponse {

    private String imageVersion;
    private String syncGen;

    public String getImageVersion() {
        return imageVersion;
    }

    public void setImageVersion(String imageVersion) {
        this.imageVersion = imageVersion;
    }

    public String getSyncGen() {
        return syncGen;
    }

    public void setSyncGen(String syncGen) {
        this.syncGen = syncGen;
    }
}
