
package com.ford.cvddm.outbound.givis.soap.givismodulestate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Gateway Information
 * 
 * <p>Java class for GatewayInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GatewayInfoType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="GatewayNodeID" type="{urn:ford/Vehicle/Module/Information/v4.0}GatewayNodeIDType" minOccurs="0"/>
 *         &lt;element name="GatewayType" type="{urn:ford/Vehicle/Module/Information/v4.0}GatewayInterfaceType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GatewayInfoType", propOrder = {
    "gatewayNodeID",
    "gatewayType"
})
public class GatewayInfoType {

    @XmlElement(name = "GatewayNodeID")
    protected String gatewayNodeID;
    @XmlElement(name = "GatewayType", required = true)
    protected String gatewayType;

    /**
     * Gets the value of the gatewayNodeID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGatewayNodeID() {
        return gatewayNodeID;
    }

    /**
     * Sets the value of the gatewayNodeID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGatewayNodeID(String value) {
        this.gatewayNodeID = value;
    }

    /**
     * Gets the value of the gatewayType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGatewayType() {
        return gatewayType;
    }

    /**
     * Sets the value of the gatewayType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGatewayType(String value) {
        this.gatewayType = value;
    }

}
