
package com.ford.cvddm.outbound.gvms.vehicleModuleInfo;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for NetworkInterfaceDetailType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="NetworkInterfaceDetailType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="NetworkInterface">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;attGroup ref="{urn:ford/Vehicle/Module/Information/v4.0}NetworkParameters"/>
 *                 &lt;attGroup ref="{urn:ford/Vehicle/Module/Information/v4.0}NetworkConnector"/>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "NetworkInterfaceDetailType", propOrder = {
    "networkInterface"
})
public class NetworkInterfaceDetailType
    implements Serializable
{

    @XmlElement(name = "NetworkInterface", required = true)
    protected NetworkInterfaceDetailType.NetworkInterface networkInterface;

    /**
     * Gets the value of the networkInterface property.
     * 
     * @return
     *     possible object is
     *     {@link NetworkInterfaceDetailType.NetworkInterface }
     *     
     */
    public NetworkInterfaceDetailType.NetworkInterface getNetworkInterface() {
        return networkInterface;
    }

    /**
     * Sets the value of the networkInterface property.
     * 
     * @param value
     *     allowed object is
     *     {@link NetworkInterfaceDetailType.NetworkInterface }
     *     
     */
    public void setNetworkInterface(NetworkInterfaceDetailType.NetworkInterface value) {
        this.networkInterface = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;attGroup ref="{urn:ford/Vehicle/Module/Information/v4.0}NetworkParameters"/>
     *       &lt;attGroup ref="{urn:ford/Vehicle/Module/Information/v4.0}NetworkConnector"/>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class NetworkInterface
        implements Serializable
    {

        @XmlAttribute(name = "NetworkName", namespace = "urn:ford/Vehicle/Module/Information/v4.0", required = true)
        protected String networkName;
        @XmlAttribute(name = "NetworkProtocol", namespace = "urn:ford/Vehicle/Module/Information/v4.0", required = true)
        protected String networkProtocol;
        @XmlAttribute(name = "NetworkDataRate", namespace = "urn:ford/Vehicle/Module/Information/v4.0", required = true)
        protected String networkDataRate;
        @XmlAttribute(name = "DLCName", namespace = "urn:ford/Vehicle/Module/Information/v4.0")
        protected String dlcName;
        @XmlAttribute(name = "Pins", namespace = "urn:ford/Vehicle/Module/Information/v4.0")
        protected String pins;

        /**
         * Gets the value of the networkName property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getNetworkName() {
            return networkName;
        }

        /**
         * Sets the value of the networkName property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setNetworkName(String value) {
            this.networkName = value;
        }

        /**
         * Gets the value of the networkProtocol property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getNetworkProtocol() {
            return networkProtocol;
        }

        /**
         * Sets the value of the networkProtocol property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setNetworkProtocol(String value) {
            this.networkProtocol = value;
        }

        /**
         * Gets the value of the networkDataRate property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getNetworkDataRate() {
            return networkDataRate;
        }

        /**
         * Sets the value of the networkDataRate property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setNetworkDataRate(String value) {
            this.networkDataRate = value;
        }

        /**
         * Gets the value of the dlcName property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getDLCName() {
            return dlcName;
        }

        /**
         * Sets the value of the dlcName property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setDLCName(String value) {
            this.dlcName = value;
        }

        /**
         * Gets the value of the pins property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPins() {
            return pins;
        }

        /**
         * Sets the value of the pins property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPins(String value) {
            this.pins = value;
        }

    }

}
