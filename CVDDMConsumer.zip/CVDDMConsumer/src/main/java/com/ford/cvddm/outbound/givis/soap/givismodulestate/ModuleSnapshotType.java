
package com.ford.cvddm.outbound.givis.soap.givismodulestate;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ModuleSnapshotType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ModuleSnapshotType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="VIN" type="{urn:ford/Vehicle/Module/Information/v4.0}VINType"/>
 *         &lt;element name="ModuleName" type="{urn:ford/com/productdesign/ipp/ModuleSnapshot/v2.1}ModuleNameENUMType"/>
 *         &lt;element name="RequestRole" type="{urn:ford/Vehicle/Module/Information/v4.0}StateUpdateRoleType"/>
 *         &lt;element name="Node" type="{urn:ford/Vehicle/Module/Information/v4.0}ModuleNodeType" maxOccurs="unbounded"/>
 *         &lt;element name="FeatureCodes" type="{urn:ford/Vehicle/Module/Information/v4.0}FeatureCodeType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ModuleSnapshotType", namespace = "urn:ford/com/productdesign/ipp/ModuleSnapshot/v2.1", propOrder = {
    "vin",
    "moduleName",
    "requestRole",
    "node",
    "featureCodes"
})
public class ModuleSnapshotType {

    @XmlElement(name = "VIN", required = true)
    protected String vin;
    @XmlElement(name = "ModuleName", required = true)
    @XmlSchemaType(name = "string")
    protected ModuleNameENUMType moduleName;
    @XmlElement(name = "RequestRole", required = true)
    protected StateUpdateRoleType requestRole;
    @XmlElement(name = "Node", required = true)
    protected List<ModuleNodeType> node;
    @XmlElement(name = "FeatureCodes")
    protected FeatureCodeType featureCodes;

    /**
     * Gets the value of the vin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVIN() {
        return vin;
    }

    /**
     * Sets the value of the vin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVIN(String value) {
        this.vin = value;
    }

    /**
     * Gets the value of the moduleName property.
     * 
     * @return
     *     possible object is
     *     {@link ModuleNameENUMType }
     *     
     */
    public ModuleNameENUMType getModuleName() {
        return moduleName;
    }

    /**
     * Sets the value of the moduleName property.
     * 
     * @param value
     *     allowed object is
     *     {@link ModuleNameENUMType }
     *     
     */
    public void setModuleName(ModuleNameENUMType value) {
        this.moduleName = value;
    }

    /**
     * Gets the value of the requestRole property.
     * 
     * @return
     *     possible object is
     *     {@link StateUpdateRoleType }
     *     
     */
    public StateUpdateRoleType getRequestRole() {
        return requestRole;
    }

    /**
     * Sets the value of the requestRole property.
     * 
     * @param value
     *     allowed object is
     *     {@link StateUpdateRoleType }
     *     
     */
    public void setRequestRole(StateUpdateRoleType value) {
        this.requestRole = value;
    }

    /**
     * Gets the value of the node property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the node property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNode().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ModuleNodeType }
     * 
     * 
     */
    public List<ModuleNodeType> getNode() {
        if (node == null) {
            node = new ArrayList<ModuleNodeType>();
        }
        return this.node;
    }

    /**
     * Gets the value of the featureCodes property.
     * 
     * @return
     *     possible object is
     *     {@link FeatureCodeType }
     *     
     */
    public FeatureCodeType getFeatureCodes() {
        return featureCodes;
    }

    /**
     * Sets the value of the featureCodes property.
     * 
     * @param value
     *     allowed object is
     *     {@link FeatureCodeType }
     *     
     */
    public void setFeatureCodes(FeatureCodeType value) {
        this.featureCodes = value;
    }

}
