
package com.ford.cvddm.outbound.gvms.vehicleModuleInfo;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for LicensedPartResponseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LicensedPartResponseType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="esn" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="vin" type="{urn:ford/Vehicle/Module/Information/v4.0}VINType" />
 *       &lt;attribute name="fordPartNo" type="{urn:ford/productdesign/vis/common/v1.0}FPNType" />
 *       &lt;attribute name="signedPartURL" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LicensedPartResponseType", namespace = "urn:ford/interface/Vehicle/Module/Information/v4.0")
public class LicensedPartResponseType
    implements Serializable
{

    @XmlAttribute(name = "esn")
    protected String esn;
    @XmlAttribute(name = "vin")
    protected String vin;
    @XmlAttribute(name = "fordPartNo")
    protected String fordPartNo;
    @XmlAttribute(name = "signedPartURL")
    protected String signedPartURL;

    /**
     * Gets the value of the esn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEsn() {
        return esn;
    }

    /**
     * Sets the value of the esn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEsn(String value) {
        this.esn = value;
    }

    /**
     * Gets the value of the vin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVin() {
        return vin;
    }

    /**
     * Sets the value of the vin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVin(String value) {
        this.vin = value;
    }

    /**
     * Gets the value of the fordPartNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFordPartNo() {
        return fordPartNo;
    }

    /**
     * Sets the value of the fordPartNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFordPartNo(String value) {
        this.fordPartNo = value;
    }

    /**
     * Gets the value of the signedPartURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSignedPartURL() {
        return signedPartURL;
    }

    /**
     * Sets the value of the signedPartURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSignedPartURL(String value) {
        this.signedPartURL = value;
    }

}
