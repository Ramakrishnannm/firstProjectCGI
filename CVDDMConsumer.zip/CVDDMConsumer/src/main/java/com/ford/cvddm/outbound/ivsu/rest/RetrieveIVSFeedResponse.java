package com.ford.cvddm.outbound.ivsu.rest;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RetrieveIVSFeedResponse {
	
	@JsonProperty("FileProcessingInfoKey")
	private String fileProcessingInfoKey;
	
	@JsonProperty("ProgramCode")
	private String programCode;
	
	@JsonProperty("ModelYear")
	private String modelYear;
	
	@JsonProperty("LoadProcessStartTime")
	private String loadProcessStartTime;
	
	@JsonProperty("LoadProcessEndTime")
	private String loadProcessEndTime;
	
	@JsonProperty("FileProcessingStatus")
	private String fileProcessingStatus;
	
	@JsonProperty("GivisCoreCloudIndicator")
	private String givisCoreCloudIndicator;
	
	@JsonProperty("XmlFileName")
	private String xmlFileName;
	
	@JsonProperty("XmlFileReceivedTime")
	private String xmlFileReceivedTime;
	
	@JsonProperty("XmlBODID")
	private String xmlBODID;
	
	@JsonProperty("createdUser")
	private String createdUser;
	
	@JsonProperty("lastUpdatedUser")
	private String lastUpdatedUser;
	
	@JsonProperty("createdTime")
	private String createdTime;
	
	@JsonProperty("lastUpdatedTime")
	private String lastUpdatedTime;
	
	public String getFileProcessingInfoKey() {
		return fileProcessingInfoKey;
	}
	public void setFileProcessingInfoKey(String fileProcessingInfoKey) {
		this.fileProcessingInfoKey = fileProcessingInfoKey;
	}
	public String getProgramCode() {
		return programCode;
	}
	public void setProgramCode(String programCode) {
		this.programCode = programCode;
	}
	public String getModelYear() {
		return modelYear;
	}
	public void setModelYear(String modelYear) {
		this.modelYear = modelYear;
	}
	public String getLoadProcessStartTime() {
		return loadProcessStartTime;
	}
	public void setLoadProcessStartTime(String loadProcessStartTime) {
		this.loadProcessStartTime = loadProcessStartTime;
	}
	public String getLoadProcessEndTime() {
		return loadProcessEndTime;
	}
	public void setLoadProcessEndTime(String loadProcessEndTime) {
		this.loadProcessEndTime = loadProcessEndTime;
	}
	public String getFileProcessingStatus() {
		return fileProcessingStatus;
	}
	public void setFileProcessingStatus(String fileProcessingStatus) {
		this.fileProcessingStatus = fileProcessingStatus;
	}
	public String getGivisCoreCloudIndicator() {
		return givisCoreCloudIndicator;
	}
	public void setGivisCoreCloudIndicator(String givisCoreCloudIndicator) {
		this.givisCoreCloudIndicator = givisCoreCloudIndicator;
	}
	public String getXmlFileName() {
		return xmlFileName;
	}
	public void setXmlFileName(String xmlFileName) {
		this.xmlFileName = xmlFileName;
	}
	public String getXmlFileReceivedTime() {
		return xmlFileReceivedTime;
	}
	public void setXmlFileReceivedTime(String xmlFileReceivedTime) {
		this.xmlFileReceivedTime = xmlFileReceivedTime;
	}
	public String getXmlBODID() {
		return xmlBODID;
	}
	public void setXmlBODID(String xmlBODID) {
		this.xmlBODID = xmlBODID;
	}
	public String getCreatedUser() {
		return createdUser;
	}
	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}
	public String getLastUpdatedUser() {
		return lastUpdatedUser;
	}
	public void setLastUpdatedUser(String lastUpdatedUser) {
		this.lastUpdatedUser = lastUpdatedUser;
	}
	public String getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(String createdTime) {
		this.createdTime = createdTime;
	}
	public String getLastUpdatedTime() {
		return lastUpdatedTime;
	}
	public void setLastUpdatedTime(String lastUpdatedTime) {
		this.lastUpdatedTime = lastUpdatedTime;
	}
	
	
}
