/**
 * 
 */
package com.ford.cvddm.outbound.gvms.getCurrentLite;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.SocketAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLConnection;
import java.security.Provider;
import java.security.Security;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;

import javax.xml.bind.DatatypeConverter;

import com.ford.cvddm.common.util.OAuth2CvddmCredentialProvider;
import com.ford.it.exception.FordExceptionAttributes;
import com.ford.it.exception.FordSelfLoggingRuntimeException;
import com.ford.it.http.HttpPosterException;
import com.ford.it.http.HttpPosterInputStream;
import com.ford.it.http.ProxySelector;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.Level;
import com.ford.it.logging.LogFactory;
import com.ford.it.properties.PropertyManager;
import com.ford.it.util.ClassLoaderUtil;
import com.ford.it.util.TextUtil;
import com.ford.it.util.wsl.WSLCredentialsProvider;
import com.ford.it.util.wsl.WSLCredentialsProviderException;

/**
 * 
 * This is HttpPoster class is to be used to consume Rest 
 * services/api/product which are Hosted in IBM API Connect Portal
 * and CVDDM Application has subscribed to their Product.
 * This aligned with it-core HTTP Poster class.
 * @author NGUPTA18
 *
 */
public class CvddmHttpPoster {
	
	/**
     * http response headers constants
     */
    public static final int MAX_HTTTP_HEADERS = 100;

    /**
     * Logging Setup
     */
    private static final String CLASS_NAME = CvddmHttpPoster.class.getName();
    /**
     * Logging Setup
     */
    private static final ILogger log =
            LogFactory.getInstance().getLogger(CLASS_NAME);

    private final static ProxySelector proxySelector = new ProxySelector();

    /**
     * lock
     */
    protected static String lock = new String();
    /**
     * Constant for WSL Cookie
     */
    public static final String WSL = "Ford-WSL";

    /**
     * Constant for WSLx Cookie
     */
    public static final String WSLX = "WSLX";

    /**
     * Reference to the HTTP url.
     */
    private URL url;

    /**
     * Reference to the resulting response code.
     */
    private int responseCode;

    /**
     * Reference to the Http Proxy Port.
     */
    private String proxyPort;

    /**
     * Reference to the Http Proxy IP.
     */
    private String proxyIP;

    /**
     * Reference to the Http Proxy user id.
     */
    private String proxyUserID;

    /**
     * Reference to the Http Proxy password.
     */
    private String proxyPassword;

    /**
     * Value to be used for the "Content-Type" request header
     */
    private String contentType;

    /**
     * HTTP Cookie HashMap
     */
    private HashMap<String, String> cookieMap = new HashMap<String, String>();

    /**
     * The default size of the buffer stream if no size is specified.
     *
     * 
     */
    public static int DEFAULT_BUFFER_SIZE = 4096;

    /**
     * The size of the stream buffer.
     *
     * 
     */
    private int bufferSize = DEFAULT_BUFFER_SIZE;

    /**
     * Sets headers on the url. Duplicates are overwritten.
     */
    private HashMap<String, String> customHeaders =
            new HashMap<String, String>();

    /**
     * the Provider object created via reflection - cache so only have to go
     * through the reflection process once
     */
    private static Provider configJSSEProvider = null;

    /**
     * The timeout of the connection attempt. Default 1hr.
     */
    private int timeOut = 3600000;

    /**
     * default verb for the HTTP operation.
     */
    private String method = "POST";
    /**
     * flags usage of proxy selector
     */
    private boolean useFordInternetProxy = false;

    /**
     *
     * vreifies whether proxy selector is used
     *
     * @return , boolean
     */
    public boolean isUseFordInternetProxy() {
        return this.useFordInternetProxy;
    }

    /**
     *
     * sets use of proxy selector Used only to restore non proxy access
     *
     * @param useFordInternetProxy , boolean - proxy selector usage
     *
     */
    public void setUseFordInternetProxy(final boolean useFordInternetProxy) {
        this.useFordInternetProxy = useFordInternetProxy;
    }

    private Map<String, String> responseHeadersMap =
            new HashMap<String, String>();

    /**
     * Default class constructor.
     */
    public CvddmHttpPoster() {
        final String METHOD_NAME = "CvddmHttpPoster()";
        log.entering(CLASS_NAME, METHOD_NAME);
        this.useFordInternetProxy = false;
        log.exiting(CLASS_NAME, METHOD_NAME);
    }

    /**
     * Constructor that allows the buffer size to be set.
     *
     * @param bufferSize The buffer size to be used when streaming input &
     *        output.
     * @throws HttpPosterException If an invalid buffer size is passed in. The
     *         buffer size must be greater than zero.
     */
    public CvddmHttpPoster(final int bufferSize) throws HttpPosterException {
        final String METHOD_NAME = "CvddmHttpPoster(int)";
        log.entering(CLASS_NAME, METHOD_NAME);

        setBufferSize(bufferSize);
        this.useFordInternetProxy = false;
        log.exiting(CLASS_NAME, METHOD_NAME);
    }

    /**
     * Gets the response code resulting from the post.
     *
     * @return int - The HTTP response code.
     */
    public int getResponseCode() {
        final String METHOD_NAME = "getResponseCode";
        log.entering(CLASS_NAME, METHOD_NAME);
        log.exiting(CLASS_NAME, METHOD_NAME);
        return this.responseCode;
    }

    /**
     * Due to Java Bug Id 4160499, this method is used to access the result
     * code.
     *
     * @param conn The HTTP url connection.
     * @return int - The HTTP response code.
     */
    protected static int getResponseCode(final HttpURLConnection conn) {
        final String METHOD_NAME = "getResponseCode";
        log.entering(CLASS_NAME, METHOD_NAME);
        String status = "0";
        final String header = conn.getHeaderField(0);
        if ((header != null) && (!header.equals(""))) {
            final StringTokenizer st = new StringTokenizer(header, " ");

            if (st.hasMoreTokens()) {
                st.nextToken();
                if (st.hasMoreTokens()) {
                    status = st.nextToken();
                }
            }
        }

        log.exiting(CLASS_NAME, METHOD_NAME, "responseCode=" + status);
        return Integer.parseInt(status);
    }

    /**
     * Adds a header on the http request of the form: <br>
     * <code>key: value</code><br>
     * <br>
     * <b>NOTE: </b> This key/value pair is not edited. It is up to the calling
     * application to set valid headers.
     *
     * @param key A unique key to the map of custom request headers. A duplicate
     *        key already in the map will result in its value being overridden.
     * @param value The value of the header.
     *
     * 
     */
    public void addHeader(final String key, final String value) {
        final String METHOD_NAME = "addHeader";
        log.entering(CLASS_NAME, METHOD_NAME);

        this.customHeaders.put(key, value);

        log.exiting(CLASS_NAME, METHOD_NAME);
    }

    /**
     * Removes the specified header from being set on the request.
     *
     * @param key The unique key of the header to remove.
     * @return String - The value of the header that was removed or
     *         <code>null</code> if it was not found.
     *
     * 
     */
    public String removeHeader(final String key) {
        final String METHOD_NAME = "removeHeader";
        log.entering(CLASS_NAME, METHOD_NAME);

        final String removedHeader = this.customHeaders.remove(key);

        log.exiting(CLASS_NAME, METHOD_NAME);
        return removedHeader;
    }

    /**
     * Returns the value of the request header associated with the key.
     *
     * @param key The unique key in the header map that is being requested.
     * @return String - The value of the header or <code>null</code> if either
     *         no header is found for the specified key or that the key is
     *         actually mapped to <code>null</code>.
     *
     * 
     */
    public String getHeader(final String key) {
        final String METHOD_NAME = "getHeader";
        log.entering(CLASS_NAME, METHOD_NAME);

        final String value = this.customHeaders.get(key);

        log.exiting(CLASS_NAME, METHOD_NAME);
        return value;
    }

    /**
     * Gets the url.
     *
     * @return URL - Returns a URL.
     */
    public URL getUrl() {
        final String METHOD_NAME = "getUrl";
        log.entering(CLASS_NAME, METHOD_NAME);
        log.exiting(CLASS_NAME, METHOD_NAME);
        return this.url;
    }

    /**
     * Sets the url.
     *
     * @param url The url to set.
     */
    public void setUrl(final URL url) {
        final String METHOD_NAME = "setUrl";
        log.entering(CLASS_NAME, METHOD_NAME);

        this.url = url;

        log.exiting(CLASS_NAME, METHOD_NAME);
    }

    /**
     * Checks to see if the application has loaded the httpposster.ssl
     * property-group. If so, will use the values found to set the https
     * Protocol Handler and JSSE provider specified.
     *
     * <pre>
     * &lt;h3&gt;
     *  Example property-group
     * &lt;/h3&gt;
     *   &lt;property-group name=&quot;httpposter&quot;&gt;
     *       &lt;property-group name=&quot;ssl&quot;&gt;
     *           &lt;property name=&quot;protocolHandlerPkg&quot;&gt;com.ibm.net.ssl.internal.www.protocol&lt;/property&gt;
     *           &lt;property name=&quot;jsseProviderClass&quot;&gt;com.ibm.jsse.IBMJSSEProvider&lt;/property&gt;
     *       &lt;/property-group&gt;
     *   &lt;/property-group&gt;
     * </pre>
     *
     * @throws HttpPosterException If there was a problem setting the system
     *         property or instantiating the JSSE provider.
     *
     * 
     */
    public static void setHTTPSProperties() throws HttpPosterException {
        final String METHOD_NAME = "setHTTPSProperties";
        log.entering(CLASS_NAME, METHOD_NAME);

        final PropertyManager pm = PropertyManager.getInstance();

        if (pm.containsGroup("httpposter.ssl")) {
            setOverrideProtocolHandler();
            setOverrideJSSEProvider();
        }

        log.exiting(CLASS_NAME, METHOD_NAME);
    }

    /**
     * Sets the SSL protocol handler specified by the
     * https.ssl.protocolHandlerPkg property for the currently running JVM.
     *
     * 
     */
    private static void setOverrideProtocolHandler() {
        final String METHOD_NAME = "setProtocolHandler()";
        log.entering(CLASS_NAME, METHOD_NAME);

        final PropertyManager pm = PropertyManager.getInstance();
        final String protocolHandlerKey = "java.protocol.handler.pkgs";
        String protocolHandlerValue = null;

        protocolHandlerValue =
                pm.getString("httpposter.ssl.protocolHandlerPkg", null);

        if (protocolHandlerValue != null) {
            final String pkgs = System.getProperty(protocolHandlerKey);
            // No protocol.handler.pkgs have been set yet. Go ahead
            // and set the property for our protocolHandlerValue
            if (pkgs == null) {
                System.setProperty(protocolHandlerKey, protocolHandlerValue);

                // Otherwise there are other values already set. We don't want
                // to overlay any values or set-up our value if it has already
                // been set.
            } else if (!pkgs.contains(protocolHandlerValue)) {
                final StringBuilder pkgsBuff = new StringBuilder(pkgs);
                pkgsBuff.append("|");
                pkgsBuff.append(protocolHandlerValue);
                System.setProperty(protocolHandlerKey, pkgsBuff.toString());
            }
        }

        log.exiting(CLASS_NAME, METHOD_NAME);
    }

    /**
     * Adds the JSSE provider specified in the httpposter.ssl.jsseProviderClass
     * property file to the running JVM.
     *
     * @return int - The preference position in which the provider was added, or
     *         -1 if the provider was not added because it is already installed.
     * @throws HttpPosterException If there is a problem instantiating a JSSE
     *         provider.
     *
     * 
     * @see java.security.Security#addProvider(java.security.Provider)
     */
    public static int setOverrideJSSEProvider() throws HttpPosterException {
        final String METHOD_NAME = "setJSSEProvider()";
        log.entering(CLASS_NAME, METHOD_NAME);

        final PropertyManager pm = PropertyManager.getInstance();

        final String jsseObjectName =
                pm.getString("httpposter.ssl.jsseProviderClass", null);

        int providerPosition = -1;
        if (jsseObjectName != null) {
            final Provider jsseProvider = getConfigJSSEProvider(jsseObjectName);
            providerPosition = setJSSEProvider(jsseProvider);
        }

        log.exiting(CLASS_NAME, METHOD_NAME, "Provider Position = "
                                             + providerPosition);
        return providerPosition;
    }

    /**
     * Adds the specified JSSE provider to the running JVM.
     *
     * @param jsseObjectName The Provider (with full path name) to add. <br>
     *        For example: <code>com.ibm.jsse.IBMJSSEProvider</code>
     * @return int - The preference position in which the provider was added, or
     *         -1 if the provider was not added because it is already installed.
     * @throws HttpPosterException If there is a problem instantiating the JSSE
     *         provider class through reflection.
     *
     * 
     * @see java.security.Security#addProvider(java.security.Provider)
     */

    private static Provider getConfigJSSEProvider(final String jsseObjectName)
            throws HttpPosterException {
        final String METHOD_NAME = "getJSSEProvider(String)";
        log.entering(CLASS_NAME, METHOD_NAME);

        if (configJSSEProvider != null) {
            log.exiting(CLASS_NAME, METHOD_NAME);
            return configJSSEProvider;
        }

        Class<?> jsseProviderClass = null;
        try {
            jsseProviderClass = ClassLoaderUtil.classForName(jsseObjectName);

        } catch (final ClassNotFoundException cnfe) {
            final StringBuilder msg = new StringBuilder();
            msg.append("JSSE Provider class [");
            msg.append(jsseObjectName);
            msg.append("] not found!  Please verify settings in the ");
            msg.append("httpposter-config.xml property file!");

            final HttpPosterException hpe =
                    new HttpPosterException(msg.toString(), cnfe);
            log.logp(Level.SEVERE, CLASS_NAME, METHOD_NAME, msg.toString(), hpe);
            log.throwing(CLASS_NAME, METHOD_NAME, hpe);
            throw hpe;
        }

        try {
            configJSSEProvider = (Provider)jsseProviderClass.newInstance();

        } catch (final InstantiationException ie) {
            final StringBuilder msg = new StringBuilder();
            msg.append("Error getting constructor instance for JSSE Provider ");
            msg.append("class [");
            msg.append(jsseObjectName);
            msg.append("]!");

            final HttpPosterException hpe =
                    new HttpPosterException(msg.toString(), ie);
            log.logp(Level.SEVERE, CLASS_NAME, METHOD_NAME, msg.toString(), hpe);
            log.throwing(CLASS_NAME, METHOD_NAME, hpe);
            throw hpe;

        } catch (final IllegalAccessException illAccEx) {
            final StringBuilder msg = new StringBuilder();
            msg.append("Error getting constructor instance for JSSE Provider ");
            msg.append("class [");
            msg.append(jsseObjectName);
            msg.append("] due to illegal access!");

            final HttpPosterException hpe =
                    new HttpPosterException(msg.toString(), illAccEx);
            log.logp(Level.SEVERE, CLASS_NAME, METHOD_NAME, msg.toString(), hpe);
            log.throwing(CLASS_NAME, METHOD_NAME, hpe);
            throw hpe;

        } catch (final ClassCastException cce) {
            final StringBuilder msg = new StringBuilder();
            msg.append("The defined class [");
            msg.append(jsseObjectName);
            msg.append("] is not an instance of java.security.Provider!");

            final HttpPosterException hpe =
                    new HttpPosterException(msg.toString(), cce);
            log.logp(Level.SEVERE, CLASS_NAME, METHOD_NAME, msg.toString(), hpe);
            log.throwing(CLASS_NAME, METHOD_NAME, hpe);
            throw hpe;
        }

        log.exiting(CLASS_NAME, METHOD_NAME);
        return configJSSEProvider;
    }

    /**
     * Adds the specified JSSE provider to the running JVM.
     *
     * @param jsseProvider The Provider to add.
     * @return int - The preference position in which the provider was added, or
     *         -1 if the provider was not added because it is already installed.
     *
     * 
     * @see java.security.Security#addProvider(java.security.Provider)
     */
    public static int setJSSEProvider(final Provider jsseProvider) {
        final String METHOD_NAME = "setJSSEProvider(Provider)";
        log.entering(CLASS_NAME, METHOD_NAME);

        final int providerPosition = Security.addProvider(jsseProvider);

        log.exiting(CLASS_NAME, METHOD_NAME, "Provider Position = "
                                             + providerPosition);
        return providerPosition;
    }

    /**
     * Gets the value that will be used for the "Content-Type" request header.
     *
     * @return String - Returns the value that will be used for the
     *         "Content-Type" request header. Will return null if the
     *         <code>setType(String)</code> method was never called.
     *
     * 
     */
    public String getContentType() {
        final String METHOD_NAME = "getContentType";
        log.entering(CLASS_NAME, METHOD_NAME);
        log.exiting(CLASS_NAME, METHOD_NAME);
        return this.contentType;
    }

    /**
     * Sets the value that will be used for the "Content-Type" request header.
     *
     * @param contentType The value to use for the "Content-Type" request
     *        header.
     *
     * 
     */
    public void setContentType(final String contentType) {
        final String METHOD_NAME = "setType";
        log.entering(CLASS_NAME, METHOD_NAME);

        this.contentType = contentType;

        log.exiting(CLASS_NAME, METHOD_NAME);
    }

    /**
     * Add a cookie to the HTTP post. This method supports adding multiple
     * cookies to the HTTP post. It stores all the cookies in an internal Map
     * object. So if you use the same cookieName on multiple calls to this
     * method, it will override the cookieValue for that cookieName.
     *
     * @param cookieName The cookie name.
     * @param cookieValue The cookie Value.
     *
     * @since itcore-v2.1
     */
    public void addCookie(final String cookieName, final String cookieValue) {
        final String METHOD_NAME = "addCookie";
        log.entering(CLASS_NAME, METHOD_NAME);

        this.cookieMap.put(cookieName, cookieValue);

        log.exiting(CLASS_NAME, METHOD_NAME);
    }

    /**
     * Remove an HTTP cookie.
     *
     * @param cookieName The name of the cookie to remove from the internal Map
     *        of cookies.
     * @return Object - The object that was removed from the internal Map of
     *         cookies.
     *
     * @since itcore-v2.1
     */
    public Object removeCookie(final String cookieName) {
        final String METHOD_NAME = "removeCookie";
        log.entering(CLASS_NAME, METHOD_NAME);

        final Object removedObj = this.cookieMap.remove(cookieName);

        log.exiting(CLASS_NAME, METHOD_NAME);
        return removedObj;
    }

    /**
     * Returns the HashMap of cookies added through the addCookie() method.
     *
     * @return HashMap - A Map of the the cookies and their values.
     *
     * @since itcore-v2.1
     */
    public HashMap<String, String> getCookies() {
        final String METHOD_NAME = "getCookies";
        log.entering(CLASS_NAME, METHOD_NAME);
        log.exiting(CLASS_NAME, METHOD_NAME);
        return this.cookieMap;
    }

    /**
     * Returns the formatted cookie string that will be used on the call to
     * <code>post(byte[])</code>.
     *
     * @return String - A formatted string of all the cookies that were added
     *         via <code>addCookie(String, String)</code> or
     *         <code>setCookie(String)</code>.
     *
     * @since itcore-v2.1
     */
    public String getCookieString() {
        final String METHOD_NAME = "getCookieString";
        log.entering(CLASS_NAME, METHOD_NAME);

        String cookieString = null;

        if (!this.cookieMap.isEmpty()) {
            final Set<Map.Entry<String, String>> cookieSet =
                    this.cookieMap.entrySet();
            for (final Map.Entry<String, String> cookieObject : cookieSet) {
                if (cookieString != null) {
                    cookieString += ";" + cookieObject.toString();
                } else {
                    cookieString = cookieObject.toString();
                }
            }
        }

        log.exiting(CLASS_NAME, METHOD_NAME);
        return cookieString;
    }

    /**
     * Returns the HTTP Proxy IP address.
     *
     * @return String - The Proxy IP address that was set via
     *         <code>setProxyIP(String)</code>.
     *
     * @since itcore-v2.1
     */
    public String getProxyIP() {
        final String METHOD_NAME = "getProxyIP";
        log.entering(CLASS_NAME, METHOD_NAME);
        log.exiting(CLASS_NAME, METHOD_NAME);
        return this.proxyIP;
    }

    /**
     * Sets the HTTP Proxy IP Address.
     *
     * To use Ford Proxy Selector with balanced proxies call setUseFordInternetProxy()
     * method on you HttpPoster object HttpPoster object before use post().
     *
     * @param proxyIP The Proxy IP to use when issuing a
     *        <code>post(byte[])</code>.
     *
     * @since itcore-v2.1
     */
    public void setProxyIP(final String proxyIP) {
        final String METHOD_NAME = "setProxyIP";
        log.entering(CLASS_NAME, METHOD_NAME);

        if (proxyIP.equals("12.12.2.101")
            || proxyIP.equalsIgnoreCase("internet.ford.com")) {
            log.info(CLASS_NAME
                     + "."
                     + METHOD_NAME
                     + ": Warning: Internet Proxy ["
                     + proxyIP
                     + "] is decommissioned. Redirected to new Internet Proxy.  "
                     + "To avoid this message in the future, use " + CLASS_NAME
                     + ".useFordInternetProxy() method instead.");

            this.useFordInternetProxy();
        } else {
            this.proxyIP = proxyIP;

        }

        log.exiting(CLASS_NAME, METHOD_NAME);
    }

    /**
     * Returns the Proxy Port.
     *
     * @return String - The Proxy Port that was set via
     *         <code>setProxyPort(String)</code>.
     *
     * @since itcore-v2.1
     */
    public String getProxyPort() {
        final String METHOD_NAME = "getProxyPort";
        log.entering(CLASS_NAME, METHOD_NAME);
        log.exiting(CLASS_NAME, METHOD_NAME);
        return this.proxyPort;
    }

    /**
     * Sets the HTTP Proxy Port.
     *
     * @param proxyPort The Proxy Port to use when issuing a
     *        <code>post(byte[])</code>.
     *
     * @since itcore-v2.1
     */
    public void setProxyPort(final String proxyPort) {
        final String METHOD_NAME = "setProxyPort";
        log.entering(CLASS_NAME, METHOD_NAME);

        this.proxyPort = proxyPort;

        log.exiting(CLASS_NAME, METHOD_NAME);
    }

    /**
     * Returns the HTTP Proxy Password.
     *
     * @return String - The Proxy Password that was set via
     *         <code>setProxyPassword(String)</code>.
     *
     * @since itcore-v2.1
     */
    public String getProxyPassword() {
        final String METHOD_NAME = "getProxyPassword";
        log.entering(CLASS_NAME, METHOD_NAME);
        log.exiting(CLASS_NAME, METHOD_NAME);
        return this.proxyPassword;
    }

    /**
     * Sets the Password for the HTTP Proxy Server.
     *
     * @param proxyPassword The Proxy Password to use when issuing a
     *        <code>post(byte[])</code>.
     *
     * @since itcore-v2.1
     */
    public void setProxyPassword(final String proxyPassword) {
        final String METHOD_NAME = "setProxyPassword";
        log.entering(CLASS_NAME, METHOD_NAME);

        this.proxyPassword = proxyPassword;

        log.exiting(CLASS_NAME, METHOD_NAME);
    }

    /**
     * Returns the HTTP Proxy User ID.
     *
     * @return String - The Proxy User ID that was set via
     *         <code>setProxyUserID(String)</code>.
     *
     * @since itcore-v2.1
     */
    public String getProxyUserID() {
        final String METHOD_NAME = "getProxyUserID";
        log.entering(CLASS_NAME, METHOD_NAME);
        log.exiting(CLASS_NAME, METHOD_NAME);
        return this.proxyUserID;
    }

    /**
     * Sets the User ID for the HTTP Proxy Server.
     *
     * @param proxyUserID The Proxy UserID to use when issuing a
     *        <code>post(byte[])</code>.
     *
     * @since itcore-v2.1
     */
    public void setProxyUserID(final String proxyUserID) {
        final String METHOD_NAME = "setProxyUserID";
        log.entering(CLASS_NAME, METHOD_NAME);

        this.proxyUserID = proxyUserID;

        log.exiting(CLASS_NAME, METHOD_NAME);
    }

    /**
     * <p>
     * Adds cookies provided in the
     * {@link com.ford.it.util.wsl.WSLCredentialsProvider} configuration to the
     * http post using the default userId associated with the server hosting the
     * application
     * </p>
     *
     * <p>
     * Cookie information is obtained using the
     * {@link com.ford.it.util.wsl.WSLCredentialsProvider} utility and the
     * following configuration format:
     * </p>
     *
     * <PRE>
     *
     * &lt;property-group name=&quot;WSLPersistentCookiesConfig&quot;&gt;
     * &lt;property-group name=&quot;serverHostName&quot;&gt; &lt;property-group
     * name=&quot;default&quot;&gt; &lt;property name=&quot;Ford-WSL&quot;&gt;[Default cookie
     * string]&lt;/property&gt; &lt;/property-group&gt; &lt;property-group
     * name=&quot;userName&quot;&gt; &lt;property name=&quot;WSL-credential&quot;&gt;[WSL-credential
     * cookie string]&lt;/property&gt; &lt;property
     * name=&quot;WSLX-credential&quot;&gt;[WSLX-credential cookie
     * string]&lt;/property&gt; &lt;property name=&quot;Ford-WSL&quot;&gt;[Ford-WSL cookie
     * string]&lt;/property&gt; &lt;property name=&quot;WSLX&quot;&gt;[WSLX cookie
     * string]&lt;/property&gt; &lt;/property-group&gt; &lt;/property-group&gt;
     *
     * </PRE>
     *
     * If more than one cookie type is found for the default user, each cookie
     * will be added to the http post.
     * </p>
     *
     * @throws HttpPosterException Thrown if:
     *         <ul>
     *         <li>default user configuration is not found</li>
     *         <li>current server hostname is not found in
     *         {@link com.ford.it.util.wsl.WSLCredentialsProvider}config</li>
     *         <li>cookies property group contents in
     *         {@link com.ford.it.util.wsl.WSLCredentialsProvider}configuration
     *         not found or invalid</li>
     *         </ul>
     *
     * @see com.ford.it.util.wsl.WSLCredentialsProvider
     * @since itcore-v2.7
     */
    public void addWSLCredentials() throws HttpPosterException {
        final String METHOD_NAME = "addWSLCredentials()";
        log.entering(CLASS_NAME, METHOD_NAME);

        addWSLCredentials(WSLCredentialsProvider.DEFAULT_COOKIE_CONFIGURATION);

        log.exiting(CLASS_NAME, METHOD_NAME);
    }

    /**
     * <p>
     * Adds cookies provided in the
     * {@link com.ford.it.util.wsl.WSLCredentialsProvider}configuration to the
     * http post using the specified userId associated with the server hosting
     * the application
     * </p>
     *
     * <p>
     * Cookie information is obtained using the
     * {@link com.ford.it.util.wsl.WSLCredentialsProvider}utility and the
     * following configuration format:
     * </p>
     *
     * <pre>
     * &lt;property-group name=&quot;WSLPersistentCookiesConfig&quot;&gt;
     *      &lt;property-group name=&quot;serverHostName&quot;&gt;
     *          &lt;property-group name=&quot;default&quot;&gt;
     *              &lt;property name=&quot;Ford-WSL&quot;&gt;[Default cookie string]&lt;/property&gt;
     *          &lt;/property-group&gt;
     *      &lt;property-group name=&quot;userName&quot;&gt;
     *          &lt;property name=&quot;WSL-credential&quot;&gt;[WSL-credential cookie string]&lt;/property&gt;
     *          &lt;property name=&quot;WSLX-credential&quot;&gt;[WSLX-credential cookie string]&lt;/property&gt;
     *          &lt;property name=&quot;Ford-WSL&quot;&gt;[Ford-WSL cookie string]&lt;/property&gt;
     *          &lt;property name=&quot;WSLX&quot;&gt;[WSLX cookie string]&lt;/property&gt;
     *      &lt;/property-group&gt;
     * &lt;/property-group&gt;
     * </pre>
     *
     * If more than one cookie type is found for the default user, each cookie
     * will be added to the http post.
     * </p>
     *
     * @param userId The userId used by the
     *        {@link com.ford.it.util.wsl.WSLCredentialsProvider}to obtain
     *        userId specific cookie information
     *
     * @throws HttpPosterException Thrown if:
     *         <ul>
     *         <li>userId configuration is not found</li>
     *         <li>current server hostname is not found in
     *         {@link com.ford.it.util.wsl.WSLCredentialsProvider}config</li>
     *         <li>cookies property group contents in
     *         {@link com.ford.it.util.wsl.WSLCredentialsProvider}configuration
     *         not found or invalid</li>
     *         </ul>
     *
     * @see com.ford.it.util.wsl.WSLCredentialsProvider
     * @since itcore-v2.7
     */
    public void addWSLCredentials(final String userId)
            throws HttpPosterException {
        final String METHOD_NAME = "addWSLCredentials(String)";
        log.entering(CLASS_NAME, METHOD_NAME);

        // Use the WSLCredentialsProvider to obtain the cookie(s)
        String cookies = null;
        final WSLCredentialsProvider wcp = WSLCredentialsProvider.getInstance();
        try {
            cookies = wcp.getCookieString(userId);
        } catch (final WSLCredentialsProviderException wcpe) {
            final StringBuilder msg = new StringBuilder();
            msg.append("An error occurred while getting WSL Cookie ");
            msg.append("configuration. Check HttpPoster and ");
            msg.append("WSLCredentialsProvider configurations for source");
            msg.append(" of failure. ");
            final String expMsg = msg.toString();
            final HttpPosterException hpe =
                    new HttpPosterException(expMsg, wcpe);
            log.logp(Level.SEVERE, CLASS_NAME, METHOD_NAME, expMsg, hpe);
            log.throwing(CLASS_NAME, METHOD_NAME, hpe);
            throw hpe;
        }

        WSLCredentialsProvider.addCookieString(cookies, this.cookieMap);

        log.exiting(CLASS_NAME, METHOD_NAME);
    }

    /**
     * <p>
     * Adds headers provided by OAUTH2 provider specified in OAUTH2 configuration file
     * to the http post using the default config id associated with the **default**
     * configuration.
     * </p>
     *
     * <p>
     * Header information is obtained using the OAUTH2 utility and the
     * following configuration format:
     * </p>
     *
     * <PRE>
     &lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;
     &lt;!DOCTYPE property-group PUBLIC &quot;PropertyGroup.dtd&quot; &quot;PropertyGroup.dtd&quot;&gt;
     &lt;property-group name=&quot;OAuth2CredentialsConfig&quot;&gt;
       &lt;property-group name=&quot;default&quot;&gt;
         &lt;property name=&quot;app_id&quot;&gt;d250cd1b-8e13-application-id-guid&lt;/property&gt;
         &lt;property name=&quot;app_secret&quot;&gt;c7e71844-21b7-secret-stuff&lt;/property&gt;
         &lt;property name=&quot;oauth_token_url&quot;&gt;https://fd-leg-sso.login.sys-pcf02.cf.ford.com/oauth/token&lt;/property&gt;
       &lt;/property-group&gt;
     &lt;/property-group&gt;
     * </PRE>
     *
     * </p>
     *
     * @throws HttpPosterException Thrown if:
     *         <ul>
     *         <li>default configuration name (&quot;default&quot;) is not found</li>
     *         <li>attributes property group contents in the configuration are
     *         not found or invalid</li>
     *         </ul>
     *
     * @see com.ford.it.util.oauth2.OAuth2CredentialsConfigHelper
     * 0
     */
    public void addOauth2Credentials() throws HttpPosterException {
        final String METHOD_NAME = "addOauth2Credentials()";
        log.entering(CLASS_NAME, METHOD_NAME);

        addOauth2Credentials(WSLCredentialsProvider.DEFAULT_COOKIE_CONFIGURATION);

        log.exiting(CLASS_NAME, METHOD_NAME);
    }

    /**
     * <p>
     * Adds headers provided by OAUTH2 provider specified in OAUTH2 configuration file
     * to the http post using the default config id associated with the given
     * configuration name.
     * </p>
     *
     * <p>
     * Header information is obtained using the OAUTH2 utility and the
     * following configuration format:
     * </p>
     *
     * <PRE>
     &lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;
     &lt;!DOCTYPE property-group PUBLIC &quot;PropertyGroup.dtd&quot; &quot;PropertyGroup.dtd&quot;&gt;
     &lt;property-group name=&quot;OAuth2CredentialsConfig&quot;&gt;
       &lt;property-group name=&quot;configurationname&quot;&gt;
         &lt;property name=&quot;app_id&quot;&gt;d250cd1b-8e13-application-id-guid&lt;/property&gt;
         &lt;property name=&quot;app_secret&quot;&gt;c7e71844-21b7-secret-stuff&lt;/property&gt;
         &lt;property name=&quot;oauth_token_url&quot;&gt;https://fd-leg-sso.login.sys-pcf02.cf.ford.com/oauth/token&lt;/property&gt;
       &lt;/property-group&gt;
     &lt;/property-group&gt;
     * </PRE>
     *
     * </p>
     *
     * @throws HttpPosterException Thrown if:
     *         <ul>
     *         <li>given configuration name is not found in the OAuth2CredentialsConfig
     *         property group</li>
     *         <li>attributes property group contents in the configuration are
     *         not found or invalid</li>
     *         </ul>
     *
     * @see com.ford.it.util.oauth2.OAuth2CredentialsConfigHelper
     * 0
     */
    public void addOauth2Credentials(final String configurationName)
        throws HttpPosterException {
        final String METHOD_NAME = "addOauth2Credentials(String)";
        log.entering(CLASS_NAME, METHOD_NAME, configurationName);

        String token;
        final String cookie;
        try {
            // Use the OAuth2CvddmUtil to obtain the cookie(s)
            final OAuth2CvddmCredentialProvider provider = OAuth2CvddmCredentialProvider.getInstance();
            token = provider.getOauth2BearerToken(configurationName);
            cookie = provider.getOauth2TokenText(configurationName);
            this.customHeaders.put("Authorization", token);
            this.addCookie("ADFS-credential", cookie);
        } catch (final Exception wcpe) {
            final StringBuilder msg = new StringBuilder();
            msg.append("An error occurred while getting OAUTH2 token from ");
            msg.append("credential provider for configuration [" + configurationName + "]. ");
            msg.append("Check CVDDMHttpPoster and OAuth2CvddmCredentialProvider configurations for source");
            msg.append(" of failure. ");

            throw new HttpPosterException(
                new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
                msg.toString(), wcpe);
        }

        log.exiting(CLASS_NAME, METHOD_NAME, token != null ? token.substring(0, 20) : "null");
    }

    /**
     * Returns the buffer size used for streaming information.
     *
     * @return int - The buffer size in bytes.
     */
    public int getBufferSize() {
        final String METHOD_NAME = "getBufferSize";
        log.entering(CLASS_NAME, METHOD_NAME);
        log.exiting(CLASS_NAME, METHOD_NAME, "bufferSize=" + this.bufferSize);
        return this.bufferSize;
    }

    /**
     * Sets the buffer size that will be used for streaming information.
     *
     * @param bufferSize The buffer size in bytes (i.e., 1024 = 1 kilobyte).
     * @throws HttpPosterException If an invalid buffer size is passed into the
     *         method.
     * 
     */
    public void setBufferSize(final int bufferSize) throws HttpPosterException {
        final String METHOD_NAME = "setBufferSize";
        log.entering(CLASS_NAME, METHOD_NAME);

        // Since this is a public method, verify that the buffer size is valid
        // before trying to set it.
        if (bufferSize <= 0) {
            final StringBuilder msg = new StringBuilder();
            msg.append("Invalid buffer size defined [");
            msg.append(bufferSize);
            msg.append("]! Value must be greater than zero...");

            final HttpPosterException hpe =
                    new HttpPosterException(msg.toString());

            log.logp(Level.WARNING, CLASS_NAME, METHOD_NAME, msg.toString(),
                    hpe);
            log.throwing(CLASS_NAME, METHOD_NAME, hpe);
            throw hpe;
        }

        this.bufferSize = bufferSize;

        log.exiting(CLASS_NAME, METHOD_NAME);
    }

    /**
     * Sets the user credentials in the basic auth headers for the post.
     *
     * @param userID The user ID to use for the basic auth header.
     * @param password The password to use for the basic auth header.
     * 
     */
    public void setBasicAuthCredentials(final String userID,
            final String password) {
        final String METHOD_NAME = "setBasicAuthCredentials";
        log.entering(CLASS_NAME, METHOD_NAME);

        final byte[] credentials = (userID + ":" + password).getBytes();

        addHeader("Connection", "Keep-Alive");
        addHeader("Keep-Alive", "header");
        addHeader("Authorization", "Basic "
                                   + DatatypeConverter.printBase64Binary(credentials));

        log.exiting(CLASS_NAME, METHOD_NAME);
    }

    /**
     * Sets the required settings for the URLConnection and actually opens an
     * active connection to the URL set via <code>setUrl(URL)</code>.
     *
     * @throws IOException If a problem was encountered opening the connection
     *         on the URL.
     * @return HttpURLConnection - The connection being opened.
     * @see #setUrl(URL)
     * @see URL#openConnection()
     * 
     */
    protected HttpURLConnection openConnection() throws IOException {
        final String METHOD_NAME = "openConnection";
        log.entering(CLASS_NAME, METHOD_NAME);

        if (this.url == null) {
            final StringBuilder msg = new StringBuilder();
            msg.append("Failure trying to open URL connection because URL ");
            msg.append("was not previously set!  Call the setUrl(URL) method ");
            msg.append("before trying to post.");

            final IOException ioe = new IOException(msg.toString());
            log.logp(Level.SEVERE, CLASS_NAME, METHOD_NAME, msg.toString(), ioe);
            log.throwing(CLASS_NAME, METHOD_NAME, ioe);
            throw ioe;
        }

        final HttpURLConnection conn = this.establishConnection(null);

        log.exiting(CLASS_NAME, METHOD_NAME);
        return conn;
    }

    /**
     *
     * cretes new connection for an url set and proxy method choosen (tries to
     * create in this order: 1.preset proxy, otherwise using ford proxy selector,
     * otherwise no proxy)
     *
     * @return HttpURLConnection
     * @throws IOException
     */
    protected HttpURLConnection getNewConnection() throws IOException {
        final String METHOD_NAME = "getNewConnection";
        log.entering(CLASS_NAME, METHOD_NAME);

        HttpURLConnection conn = null;

        try {

            if (TextUtil.isNotBlankOrNull(getProxyIP())) {

                // if a proxy is required, create a per-connection proxy
                // object.
                final SocketAddress addr =
                        new InetSocketAddress(getProxyIP(),
                                Integer.valueOf(getProxyPort()));
                final Proxy proxy = new Proxy(Proxy.Type.HTTP, addr);
                conn = (HttpURLConnection)this.url.openConnection(proxy);

                log.logp(Level.FINE, CLASS_NAME, METHOD_NAME,
                        "Proxy: " + proxy.toString() + " and " + "URL: " + this.url);

            } else if (this.isUseFordInternetProxy()) {

                List<Proxy> proxy;

                final URI uri = new URI(this.url.getProtocol(), this.url.getUserInfo(), this.url.getHost(),
                        this.url.getPort(), this.url.getPath(), this.url.getQuery(), this.url.getRef());

                proxy = proxySelector.select(uri);

                conn = (HttpURLConnection)this.url.openConnection(proxy.get(0));
                conn.setRequestProperty("X-VIA-PROXY", proxy.get(0).address().toString());

                log.logp(Level.FINE, CLASS_NAME, METHOD_NAME,
                        "Ford Internet Proxy: " + proxy.get(0).toString() + " and " + "URL: " + this.url);


            } else {
                conn = (HttpURLConnection)this.url.openConnection(Proxy.NO_PROXY);

                log.logp(Level.FINE, CLASS_NAME, METHOD_NAME,
                        "No Proxy" + " and " + "URL: " + this.url);

            }

        } catch (final URISyntaxException e) {

            final FordExceptionAttributes fordExceptionAttributes =
                    new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build();
            final StringBuilder builder = new StringBuilder();

           
                  throw  new FordSelfLoggingRuntimeException(
                            fordExceptionAttributes,
                            builder.toString(), e);

        }

        log.exiting(CLASS_NAME, METHOD_NAME);
        return conn;
    }

    /**
     * (overloaded) Setup all of the properties on the URL connection before
     * actually connecting.
     *
     * @param connection , HttpURLConnection
     * @return HttpURLConnection
     * @throws IOException
     */
    protected HttpURLConnection establishConnection(
            final HttpURLConnection connection)
            throws IOException {
        final String METHOD_NAME =
                "establishConnection(HttpURLConnection )";
        log.entering(CLASS_NAME, METHOD_NAME, connection);

        HttpURLConnection conn = connection;

        if (conn == null) {

            conn = this.getNewConnection();
        }

        conn.setDoOutput(true);
        conn.setDoInput(true);
        conn.setRequestMethod(getRequestMethod());

        if (this.contentType != null) {
            conn.setRequestProperty("Content-Type", this.contentType);
        }
        if (this.timeOut >= 0) {
            conn.setConnectTimeout(this.timeOut);
            conn.setReadTimeout(this.timeOut);
        } else {
            log.logp(Level.WARNING, CLASS_NAME, METHOD_NAME,
                    "Connection timeout must be >= 0");
        }

        final String cookieString = getCookieString();
        if (cookieString != null) {
            conn.setRequestProperty("Cookie", cookieString);
        }

        if ("https".equalsIgnoreCase(conn.getURL().getProtocol())) {
            try {
                setHTTPSProperties();
            } catch (final HttpPosterException e) {
                // in order to provide backward compatibility and not cause
                // users of this class to re-factor to catch a different
                // exception type, we'll wrap the HttpPosterException in an
                // IOException and throw it. We can re-visit this later.
                final IOException ioe = new IOException(e.toString());
                log.logp(Level.SEVERE, CLASS_NAME, METHOD_NAME, e.toString(),
                        ioe);
                log.throwing(CLASS_NAME, METHOD_NAME, ioe);
                throw ioe;

            }
        }

        setHeadersAndConnect(conn);

        log.exiting(CLASS_NAME, METHOD_NAME);
        return conn;
    }

    /**
     *
     * due to Java bug 4463345
     * (http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=4463345), setting of
     * properties to null is not allowed. The following code compensates for it
     * by setting properties to a fallback value or clearing them from the
     * system property collection.
     *
     * @param property which property to set
     * @param value what to to set to
     * @param whatToUseInCaseOfNull fallback in case value is null (fallback
     *        could still be null, in which case the property would be deleted).
     */

    protected void setSystemProperty(final String property, final String value,
            final String whatToUseInCaseOfNull) {
        final String METHOD_NAME = "setSystemProperty";
        log.entering(CLASS_NAME, METHOD_NAME);

        if (null != value)
            System.setProperty(property, value);
        else if (null == value && null != whatToUseInCaseOfNull)
            System.setProperty(property, whatToUseInCaseOfNull);
        else {
            // if old value is null and what to use is also null, need to clear
            // the property
            final Properties p = System.getProperties();
            p.remove(property);
            System.setProperties(p);
        }

        log.exiting(CLASS_NAME, METHOD_NAME);
    }

    /**
     * Set connection headers (authentication, etc) and open the connection
     *
     * @param conn
     * @throws IOException
     */

    protected void setHeadersAndConnect(final HttpURLConnection conn)
            throws IOException {
        // Sets the basic auth headers for the proxy connection.
        if (getProxyUserID() != null && getProxyPassword() != null) {
            final String credString =
                    getProxyUserID() + ":" + getProxyPassword();

            final byte[] credentials = credString.getBytes();
            conn.setRequestProperty("Proxy-Authorization",
                    "Basic " + DatatypeConverter.printBase64Binary(credentials));
        }

        // Now, put all the custom headers onto the request.
        final Set<Map.Entry<String, String>> entrySet =
                this.customHeaders.entrySet();

        for (final Map.Entry<String, String> mapEntry : entrySet) {
            // The Map.Entry inner class maintains the name / value pair
            // relationship and contains helper methods to retrieve data.
            final String key = mapEntry.getKey();
            final String value = mapEntry.getValue();

            conn.setRequestProperty(key, value);
        }

        // Open connection.
        try {
            conn.connect();

            conn.getDoOutput();
        } catch (final IOException e) {
            try {
                if (socketAddress(conn) != null) {
                    proxySelector.connectFailed(new URI(conn.getURL().toString()), socketAddress(conn), e);
                }
            } catch (final URISyntaxException e1) {
                // ignore, won't happen
            }
            throw e;
        }

    }

    private SocketAddress socketAddress(final HttpURLConnection conn) {
        final String socketAsString = conn.getRequestProperty("X-VIA-PROXY");
        String host = null;
        int port = 0;
        SocketAddress socketAddress = null;

        if (TextUtil.isNotBlankOrNull(socketAsString)) {

            host = socketAsString.substring(0, socketAsString.indexOf("/"));
            port =
            Integer.parseInt(socketAsString.substring(socketAsString.indexOf(":") + 1, socketAsString.length()));


            socketAddress = new InetSocketAddress(host, port);
        }

        return socketAddress;
    }

    /**
     * Posts the supplied input stream via HTTP/S using the URL provided in the
     * <code>setURL(URL)</code> method. The input and output streams for the
     * POST are processed with a buffer size as defined by the
     * <code>setBufferSize(int)</code> method. <br>
     * <br>
     * This method calls <code>initateConnection()</code> which also adds any
     * cookies that were set via the <code>addCookie(String, String)</code> or
     * <code>setCookie(String)</code> methods. <br>
     * <br>
     * If a Proxy IP was set via the <code>setProxyIP(String)</code> method, the
     * proper system properties will be set to ensure that the proxyIP and
     * proxyPort are used on this post. If neither proxyUserID nor the
     * proxyPassword are <code>null</code>, then the proxy-authorization headers
     * are set. If the basicAuthCredentials are not null, then the basic
     * authorization headers are set. <br>
     * <br>
     * <b>Note: </b> the code block that sets the system properties is
     * synchronized in order to be thread safe. Additionally since this firewall
     * proxy authentication configuration requires that system properties are
     * set, this method clears the system properties upon exiting. <br>
     * If you are using other mechanisms to get HTTP connections be aware that
     * this code could effect how they operate. <br>
     * <br>
     * <i><b>NOTE: </b> It is the responsibility of the caller to ensure that
     * the returned <code>InputStream</code> is closed via a call to the
     * <code>close()</code> method! </i>
     *
     * @param data The InputStream containing the data to POST.
     * @return InputStream - The response stream containing the results from the
     *         POST.
     * @throws HttpPosterException If there are any other non-I/O related issues
     *         with the post.
     * @throws IOException If any issues are encountered either opening the
     *         connection, making the connection, sending the post data, or
     *         getting the results.
     *
     * @see #setBufferSize(int)
     * @see HttpPosterInputStream#close()
     * 
     */
    public InputStream post(final InputStream data) throws IOException,
            HttpPosterException {
        final String METHOD_NAME = "post(InputStream)";
        log.entering(CLASS_NAME, METHOD_NAME);

        // First step is to initalize the connection parameters. This
        // initialization process is a separate method to facilitate
        // the DeployedServersPoster as the initialization and post
        // need to be done in different ways.
        final HttpURLConnection conn = openConnection();

        final InputStream returnStream = post(data, conn);

        log.exiting(CLASS_NAME, METHOD_NAME);
        return returnStream;
    }

    /**
     * Completes the actual posting of byte array data. This is called from the
     * <code>post(byte[])</code> method.
     *
     * @param data The InputStream containing the data to POST.
     * @param conn The HttpURLConnection to use for the POST.
     * @return InputStream - The response stream containing the results from the
     *         POST.
     * @throws HttpPosterException If there are any other non-I/O related issues
     *         with the post.
     * @throws IOException If any issues are encountered either opening the
     *         connection, making the connection, sending the post data, or
     *         getting the results.
     *
     * @see #post(InputStream)
     * @see #setBufferSize(int)
     * @see HttpPosterInputStream#close()
     * 
     */
    protected InputStream post(final InputStream data,
            final HttpURLConnection conn) throws IOException,
            HttpPosterException {
        final String METHOD_NAME = "post(InputStream, HttpURLConnection)";
        log.entering(CLASS_NAME, METHOD_NAME);

        if (null != data) {
            final OutputStream out = conn.getOutputStream();
            final byte[] buffer = new byte[this.bufferSize];

            // Read bytes into memory
            int bytesRead = data.read(buffer);
            while (bytesRead != -1) {
                out.write(buffer, 0, bytesRead);
                bytesRead = data.read(buffer);
            }

            // Flush out the buffer to ensure everything is written
            out.flush();
        }

        HttpPosterInputStream returnStream = null;
        try {
            // Need to put the stream data into a stream that is separate
            // from the connection's stream. This is because, once the
            // connection is disconnected, the InputStream is closed as
            // well and is left "empty" on the response to the caller.
            final InputStream in = conn.getInputStream();
            returnStream = new HttpPosterInputStream(in, conn);
            // set response headers map
            this.setReponseHeaderMap(conn);
            // Debug statements
            if (log.isLoggable(Level.FINEST)) {
                // There have been differences in behavior when reading the
                // InputStream between the desktop and deployed environments.
                // We discovered that different InputStream types were being
                // returned. This trace statement helps us debug problems
                // if they occur.
                final String streamClassName = in.getClass().getName();
                final int length = conn.getContentLength();

                log.logp(Level.FINEST, CLASS_NAME, METHOD_NAME,
                        "Using Stream Class: " + streamClassName);

                log.logp(Level.FINEST, CLASS_NAME, METHOD_NAME,
                        "The response from the HTTP post had a ContentLength = "
                                                                + length);
            }

        } catch (final IOException ioe) {
            // If an IOException is throw, let it bubble up to the caller.
            log.throwing(CLASS_NAME, METHOD_NAME, ioe);
            throw ioe;

        } catch (final Exception e) {
            // If any other exception is thrown, try to get the error stream
            // from the connection and pass that back instead.
            final StringBuilder msg = new StringBuilder();
            msg.append("Exception thrown when trying to get the ");
            msg.append("InputStream.  Trying to read the error stream instead.");

            final HttpPosterException hpe =
                    new HttpPosterException(msg.toString(), e);

            final InputStream errorStream = conn.getErrorStream();
            if (errorStream == null) {
                msg.append("  \n\nNo error found--error stream is null!");
                log.logp(Level.SEVERE, CLASS_NAME, METHOD_NAME, msg.toString(),
                        hpe);
                log.throwing(CLASS_NAME, METHOD_NAME, hpe);
                throw hpe;
            }

            log.logp(Level.WARNING, CLASS_NAME, METHOD_NAME, msg.toString(),
                    hpe);

            returnStream = new HttpPosterInputStream(errorStream, conn);

        } finally {
            if (conn != null) {
                // Load status code only if we received a response
                this.responseCode = getResponseCode(conn);

                // NOTE: The caller now needs to be responsible for
                // disconnecting the connection by calling
                // the close() method on the HttpPosterInputStream
                // being returned.
            }
        }

        log.exiting(CLASS_NAME, METHOD_NAME);
        return returnStream;
    }

    /**
     * Posts the supplied byte array via HTTP/S using the URL provided in the
     * <code>setURL(URL)</code> method. <br>
     * <br>
     * This method calls <code>openConnection()</code> which also adds any
     * cookies that were set via the <code>addCookie(String, String)</code> or
     * <code>setCookie(String)</code> methods. <br>
     * <br>
     * If a Proxy IP was set via the <code>setProxyIP(String)</code> method, the
     * proper system properties will be set to ensure that the proxyIP and
     * proxyPort are used on this post. If neither proxyUserID nor the
     * proxyPassword are <code>null</code>, then the proxy-authorization headers
     * are set. If the basicAuthCredentials are not null, then the basic
     * authorization headers are set. <br>
     * <br>
     * <b>Note: </b> the code block that sets the system properties is
     * synchronized in order to be thread safe. Additionally since this firewall
     * proxy authentication configuration requires that system properties are
     * set, this method clears the system properties upon exiting. <br>
     * If you are using other mechanisms to get HTTP connections be aware that
     * this code could effect how they operate.
     *
     * @param data The data to POST.
     * @return byte[] - The HTTP response containing the results from the POST.
     * @throws IOException If any issues are encountered either opening the
     *         connection, making the connection, sending the post data, or
     *         getting the results.
     */
    public byte[] post(final byte[] data) throws IOException {
        final String METHOD_NAME = "post(byte[])";
        log.entering(CLASS_NAME, METHOD_NAME);

        // First step is to initalize the connection parameters. This
        // initialization process is a separate method to facilitate
        // the DeployedServersPoster as the initialization and post
        // need to be done in different ways.

        final HttpURLConnection conn = this.openConnection();

        final byte[] returnArray = post(data, conn);

        log.exiting(CLASS_NAME, METHOD_NAME);
        return returnArray;
    }

    /**
     * Completes the actual posting of byte array data. This is called from the
     * <code>post(byte[])</code> method.
     *
     * @param data The data to POST.
     * @param conn The HttpURLConnection to use for the POST.
     * @return byte[] - The HTTP response containing the results from the POST.
     * @throws IOException If any issues are encountered either opening the
     *         connection, making the connection, sending the post data, or
     *         getting the results.
     *
     * @see #post(byte[])
     *
     * 
     */
    protected byte[] post(final byte[] data, final HttpURLConnection conn)
            throws IOException {
        final String METHOD_NAME = "post(byte[], HttpURLConnection)";
        log.entering(CLASS_NAME, METHOD_NAME);

        byte[] returnArray;
        try {
            // // Create output stream
            if (null != data) {
                final OutputStream out = conn.getOutputStream();
                // Send data
                out.write(data);
                out.flush();
            }

            // Read the results back and store in the byte stream. If
            // and IOException is thrown on this line, then something
            // is wrong that should be propagated back up to the caller.
            // If some other exception is thrown, it is possible that
            // the remote servlet encountered an exception and that
            // information is sent back via the getErrorStream() method.
            final InputStream in = conn.getInputStream();
            final int length = conn.getContentLength();

            // Debug statements
            if (log.isLoggable(Level.FINEST)) {
                // There have been differences in behavior when reading the
                // InputStream between the desktop and deployed environments.
                // We discovered that different InputStream types were being
                // returned. This trace statement helps us debug problems
                // if they occur.
                final String streamClassName = in.getClass().getName();

                log.logp(Level.FINEST, CLASS_NAME, METHOD_NAME,
                        "Using Stream Class: " + streamClassName);

                log.logp(Level.FINEST, CLASS_NAME, METHOD_NAME,
                        "The response from the HTTP post had a ContentLength = "
                                                                + length);
            }

            returnArray = readStream(in, length);
            // set response headers map
            this.setReponseHeaderMap(conn);
        } finally {
            if (conn != null) {
                // Load status code only if we received a response
                this.responseCode = getResponseCode(conn);

                // Disconnect
                conn.disconnect();
            }
        }

        // Return the response
        log.exiting(CLASS_NAME, METHOD_NAME);
        return returnArray;
    }

    /**
     * Convenience method to read an InputStream and return a byte array. This
     * method is used by the <code>byte[] post(byte[])</code> method in a couple
     * of spots--one to read the <code>URLConnection.getInputStream</code> and
     * if that throws an exception, to read the the
     * <code>HttpURLConnection.getErrorStream()</code>.
     *
     * @param in The InputStream to read the contents from.
     * @param length The content length coming back from the connection.
     * @return byte[] - A byte array consisting of the contents from the
     *         InputStream.
     * @throws IOException If an error occurs while reading the InputStream
     *         contents.
     *
     * 
     * @see URLConnection#getInputStream()
     * @see HttpURLConnection#getErrorStream()
     */
    private byte[] readStream(final InputStream in, final int length)
            throws IOException {
        final String METHOD_NAME = "readStream";
        log.entering(CLASS_NAME, METHOD_NAME);

        final ByteArrayOutputStream out = new ByteArrayOutputStream();

        // There have been differences in behavior when reading the
        // InputStream between the desktop and deployed environments.
        // We discovered that different InputStream types were being
        // returned. This takes into account the different ways
        // these may need to be read.
        if (length >= 0) {
            for (int index = 0; index < length; index++) {
                out.write(in.read());
            }
        } else {
            // else no Content-Length header found.
            // try to read content until end of stream.
            int c = in.read();

            while (c != -1) {
                out.write(c);
                c = in.read();
            }
        }

        final byte[] returnArray = out.toByteArray();
        out.close();

        log.exiting(CLASS_NAME, METHOD_NAME);
        return returnArray;
    }

    /**
     *
     * Get the current connection timeout setting.
     *
     * @return int - the timeout in milliseconds
     */
    public int getTimeOut() {
        final String METHOD_NAME = "getTimeOut";
        log.entering(CLASS_NAME, METHOD_NAME);
        log.exiting(CLASS_NAME, METHOD_NAME);
        return this.timeOut;
    }

    /**
     *
     * Set the connection timeout in milliseconds. Default is 0 (no timeout).
     *
     * @param timeOut timeout to set, in milliseconds
     */
    public void setTimeOut(final int timeOut) {
        final String METHOD_NAME = "setTimeOut";
        log.entering(CLASS_NAME, METHOD_NAME, timeOut);

        this.timeOut = timeOut;

        log.exiting(CLASS_NAME, METHOD_NAME);
    }

    /**
     * Allows user of the class to change the verb that HTTP Poster will use to
     * invoke the service. "POST" is default but "GET", "HEAD", etc are allowed.
     *
     * @param method The HTTP method to set.
     * @throws HttpPosterException if the verb is empty or null.
     */
    protected void setRequestMethod(final String method)
            throws HttpPosterException {
        final String METHOD_NAME = "setRequestMethod";
        if (null == method || 0 == method.length())
            throw new HttpPosterException(new FordExceptionAttributes.Builder(
                    CLASS_NAME, METHOD_NAME).build(),
                    "Null or empty HTTP method is not allowed");

        this.method = method;

    }

    /**
     * @return Returns the request method.
     */
    protected String getRequestMethod() {
        return this.method;
    }

    /**
     * Sets use proxy selector.
     *
     * To use Proxy Selector with balanced proxies call this method on your
     * HttpPoster object before use post(). After calling this method you may
     * use post() many times.
     *
     *
     */
    public void useFordInternetProxy() {

        final String METHOD_NAME = "openConnection";
        log.entering(CLASS_NAME, METHOD_NAME);

        this.useFordInternetProxy = true;
        ProxySelector.initializeProxySelector();

        log.exiting(CLASS_NAME, METHOD_NAME);

    }

    /**
     * creates response headers map
     *
     * @param conn , HttpURLConnection - current connection
     */
    private void setReponseHeaderMap(final HttpURLConnection conn) {
        final String METHOD_NAME = "setReponseHeaderMap";
        log.entering(CLASS_NAME, METHOD_NAME, conn);

        this.responseHeadersMap.clear();
        for (int i = 0; i < MAX_HTTTP_HEADERS; i++) {

            final String headerKey = conn.getHeaderFieldKey(i);

            final String header = conn.getHeaderField(i);
            if (TextUtil.isBlankOrNull(header)) {
                break;
            }
            this.responseHeadersMap.put(headerKey, header);
        }
        log.exiting(CLASS_NAME, METHOD_NAME);
    }

    /**
     *
     * returnd http response header map
     *
     * @return , String - response header or null
     */
    public Map<String, String> getResponseHeaderMap() {
        final String METHOD_NAME = "getResponseHeader";
        log.entering(CLASS_NAME, METHOD_NAME);

        log.exiting(CLASS_NAME, METHOD_NAME);
        return this.responseHeadersMap;
    }}
