package com.ford.cvddm.outbound.gvms.getCurrentLite;

/**
 * Created by TANBUCHE on 9/17/2018.
 */
public class StatusResponse {

        private String Status;

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }
}
