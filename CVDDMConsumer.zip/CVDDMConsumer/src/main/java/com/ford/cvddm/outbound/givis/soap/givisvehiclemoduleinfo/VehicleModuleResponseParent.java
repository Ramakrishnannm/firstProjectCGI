package com.ford.cvddm.outbound.givis.soap.givisvehiclemoduleinfo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.ford.cvddm.constant.CVDDMConstant;

public class VehicleModuleResponseParent implements Serializable {

	private static final long serialVersionUID = 1L;

	private String vinNumber;

	private transient VehicleModelYearType vehicleModelYears = new VehicleModelYearType();
	private transient List<VehicleModelYearType> vehicleModelYearsList = new ArrayList<>();

	private transient List<NodeList> nodeList = new ArrayList<>();

	private String overallStatusMsg;

	private String disGIVISRespAvl = CVDDMConstant.STRING_N;

	public String getOverallStatusMsg() {
		return overallStatusMsg;
	}

	public void setOverallStatusMsg(String overallStatusMsg) {
		this.overallStatusMsg = overallStatusMsg;
	}

	public String getDisGIVISRespAvl() {
		return disGIVISRespAvl;
	}

	public void setDisGIVISRespAvl(String disGIVISRespAvl) {
		this.disGIVISRespAvl = disGIVISRespAvl;
	}

	public String getVinNumber() {
		return vinNumber;
	}

	public void setVinNumber(String vinNumber) {
		this.vinNumber = vinNumber;
	}

	public VehicleModelYearType getVehicleModelYears() {
		return vehicleModelYears;
	}

	public void setVehicleModelYears(VehicleModelYearType vehicleModelYears) {
		this.vehicleModelYears = vehicleModelYears;
	}

	public List<VehicleModelYearType> getVehicleModelYearsList() {
		return vehicleModelYearsList;
	}

	public void setVehicleModelYearsList(List<VehicleModelYearType> vehicleModelYearsList) {
		this.vehicleModelYearsList = vehicleModelYearsList;
	}

	public List<NodeList> getNodeList() {
		return nodeList;
	}

	public void setNodeList(List<NodeList> nodeList) {
		this.nodeList = nodeList;
	}

}
