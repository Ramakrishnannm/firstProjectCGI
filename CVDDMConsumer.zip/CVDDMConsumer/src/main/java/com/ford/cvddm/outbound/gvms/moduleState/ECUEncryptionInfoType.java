
package com.ford.cvddm.outbound.gvms.moduleState;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Encryption information containing the algorithm and the encrypted bytes
 * 
 * <p>Java class for ECUEncryptionInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ECUEncryptionInfoType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ECUEncryptionAlgorithm" type="{urn:ford/Vehicle/Module/Information/v4.0}ECUEncryptionAlgorithmType"/>
 *         &lt;element name="EncryptedBytes" type="{urn:ford/Vehicle/Module/Information/v4.0}EncryptedBytesType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ECUEncryptionInfoType", propOrder = {
    "ecuEncryptionAlgorithm",
    "encryptedBytes"
})
public class ECUEncryptionInfoType implements Serializable
{

    @XmlElement(name = "ECUEncryptionAlgorithm", required = true)
    protected String ecuEncryptionAlgorithm;
    @XmlElement(name = "EncryptedBytes", required = true)
    protected String encryptedBytes;

    /**
     * Gets the value of the ecuEncryptionAlgorithm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getECUEncryptionAlgorithm() {
        return ecuEncryptionAlgorithm;
    }

    /**
     * Sets the value of the ecuEncryptionAlgorithm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setECUEncryptionAlgorithm(String value) {
        this.ecuEncryptionAlgorithm = value;
    }

    /**
     * Gets the value of the encryptedBytes property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEncryptedBytes() {
        return encryptedBytes;
    }

    /**
     * Sets the value of the encryptedBytes property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEncryptedBytes(String value) {
        this.encryptedBytes = value;
    }

}
