
package com.ford.cvddm.outbound.gvms.vehicleModuleInfo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for HistoricType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="HistoricType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="StateUpdateRole" type="{urn:ford/Vehicle/Module/Information/v4.0}StateUpdateRoleType" minOccurs="0"/>
 *         &lt;element name="StateChangeDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="GatewayListState" type="{urn:ford/Vehicle/Module/Information/v4.0}GatewayListENUMType" minOccurs="0"/>
 *         &lt;element name="Gateway" type="{urn:ford/Vehicle/Module/Information/v4.0}GatewayType" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "HistoricType", propOrder = {
    "stateUpdateRole",
    "stateChangeDateTime",
    "gatewayListState",
    "gateway"
})
public class HistoricType
    implements Serializable
{

    @XmlElement(name = "StateUpdateRole")
    protected StateUpdateRoleType stateUpdateRole;
    @XmlElement(name = "StateChangeDateTime")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar stateChangeDateTime;
    @XmlElement(name = "GatewayListState")
    @XmlSchemaType(name = "string")
    protected GatewayListENUMType gatewayListState;
    @XmlElement(name = "Gateway", required = true)
    protected List<GatewayType> gateway;

    /**
     * Gets the value of the stateUpdateRole property.
     * 
     * @return
     *     possible object is
     *     {@link StateUpdateRoleType }
     *     
     */
    public StateUpdateRoleType getStateUpdateRole() {
        return stateUpdateRole;
    }

    /**
     * Sets the value of the stateUpdateRole property.
     * 
     * @param value
     *     allowed object is
     *     {@link StateUpdateRoleType }
     *     
     */
    public void setStateUpdateRole(StateUpdateRoleType value) {
        this.stateUpdateRole = value;
    }

    /**
     * Gets the value of the stateChangeDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getStateChangeDateTime() {
        return stateChangeDateTime;
    }

    /**
     * Sets the value of the stateChangeDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setStateChangeDateTime(XMLGregorianCalendar value) {
        this.stateChangeDateTime = value;
    }

    /**
     * Gets the value of the gatewayListState property.
     * 
     * @return
     *     possible object is
     *     {@link GatewayListENUMType }
     *     
     */
    public GatewayListENUMType getGatewayListState() {
        return gatewayListState;
    }

    /**
     * Sets the value of the gatewayListState property.
     * 
     * @param value
     *     allowed object is
     *     {@link GatewayListENUMType }
     *     
     */
    public void setGatewayListState(GatewayListENUMType value) {
        this.gatewayListState = value;
    }

    /**
     * Gets the value of the gateway property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the gateway property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGateway().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GatewayType }
     * 
     * 
     */
    public List<GatewayType> getGateway() {
        if (gateway == null) {
            gateway = new ArrayList<GatewayType>();
        }
        return this.gateway;
    }

}
