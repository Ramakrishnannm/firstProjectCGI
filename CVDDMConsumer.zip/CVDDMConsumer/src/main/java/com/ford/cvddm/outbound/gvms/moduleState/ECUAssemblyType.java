
package com.ford.cvddm.outbound.gvms.moduleState;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Encapsulates ECU assembly
 *                 information,Node,SpecCategory(GDS,GGDS),Hardware this assembly is
 *                 compatible,softwares and other meta
 *                 com.ford.cloudnative.gvms.moduleinfo.com.ford.cloudnative.gvms.moduleupdate.data.
 * 
 * <p>Java class for ECUAssemblyType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ECUAssemblyType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="HasActionID" type="{urn:ford/Vehicle/Module/Information/v4.0}HasActionIDType" minOccurs="0"/>
 *         &lt;element name="VSCSSoftware" type="{urn:ford/Vehicle/Module/Information/v4.0}UsedByVSCSSpecificationsType" minOccurs="0"/>
 *         &lt;element name="CAGCondition" type="{urn:ford/Vehicle/Module/Information/v4.0}PrecedenceElementType" minOccurs="0"/>
 *         &lt;element name="HasActionCondition" type="{urn:ford/Vehicle/Module/Information/v4.0}PrecedenceElementType" minOccurs="0"/>
 *         &lt;element name="ServiceActionCondition" type="{urn:ford/Vehicle/Module/Information/v4.0}PrecedenceElementType" minOccurs="0"/>
 *         &lt;element name="NodeInfo" type="{urn:ford/Vehicle/Module/Information/v4.0}NodeInfoType" maxOccurs="unbounded"/>
 *         &lt;element name="Hardware" type="{urn:ford/Vehicle/Module/Information/v4.0}HardwareType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="ServiceParts" type="{urn:ford/Vehicle/Module/Information/v4.0}HasServicePartsType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="MappedFeatures" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PreInstallSoftware" type="{urn:ford/Vehicle/Module/Information/v4.0}PreInstallSoftwareType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="PostInstallSoftware" type="{urn:ford/Vehicle/Module/Information/v4.0}PostInstallSoftwareType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="CoordinatedAssemblies" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="ecuAcronym" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="assemblyPartNumberDID" type="{urn:ford/Vehicle/Module/Information/v4.0}DIDValueType" />
 *       &lt;attribute name="currentAssy" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="availableAssy" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="isUniqueBootloader" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="description" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="rationalMnemonicGroupName" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="configMethod" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="isPartDiscontinued" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="esn" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="DirectivesFileDownloadId" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ECUAssemblyType", propOrder = {
    "hasActionID",
    "vscsSoftware",
    "cagCondition",
    "hasActionCondition",
    "serviceActionCondition",
    "nodeInfo",
    "hardware",
    "serviceParts",
    "mappedFeatures",
    "preInstallSoftware",
    "postInstallSoftware",
    "coordinatedAssemblies"
})
public class ECUAssemblyType
    implements Serializable
{

    @XmlElement(name = "HasActionID")
    protected HasActionIDType hasActionID;
    @XmlElement(name = "VSCSSoftware")
    protected UsedByVSCSSpecificationsType vscsSoftware;
    @XmlElement(name = "CAGCondition")
    protected PrecedenceElementType cagCondition;
    @XmlElement(name = "HasActionCondition")
    protected PrecedenceElementType hasActionCondition;
    @XmlElement(name = "ServiceActionCondition")
    protected PrecedenceElementType serviceActionCondition;
    @XmlElement(name = "NodeInfo", required = true)
    protected List<NodeInfoType> nodeInfo;
    @XmlElement(name = "Hardware")
    protected List<HardwareType> hardware;
    @XmlElement(name = "ServiceParts")
    protected List<HasServicePartsType> serviceParts;
    @XmlElement(name = "MappedFeatures")
    protected String mappedFeatures;
    @XmlElement(name = "PreInstallSoftware")
    protected List<PreInstallSoftwareType> preInstallSoftware;
    @XmlElement(name = "PostInstallSoftware")
    protected List<PostInstallSoftwareType> postInstallSoftware;
    @XmlElement(name = "CoordinatedAssemblies")
    protected List<String> coordinatedAssemblies;
    @XmlAttribute(name = "ecuAcronym")
    protected String ecuAcronym;
    @XmlAttribute(name = "assemblyPartNumberDID")
    protected String assemblyPartNumberDID;
    @XmlAttribute(name = "currentAssy")
    protected String currentAssy;
    @XmlAttribute(name = "availableAssy")
    protected String availableAssy;
    @XmlAttribute(name = "isUniqueBootloader")
    protected Boolean isUniqueBootloader;
    @XmlAttribute(name = "description")
    protected String description;
    @XmlAttribute(name = "rationalMnemonicGroupName")
    protected String rationalMnemonicGroupName;
    @XmlAttribute(name = "configMethod")
    protected String configMethod;
    @XmlAttribute(name = "isPartDiscontinued")
    protected Boolean isPartDiscontinued;
    @XmlAttribute(name = "esn")
    protected String esn;
    @XmlAttribute(name = "DirectivesFileDownloadId")
    protected String directivesFileDownloadId;

    /**
     * Gets the value of the hasActionID property.
     * 
     * @return
     *     possible object is
     *     {@link HasActionIDType }
     *     
     */
    public HasActionIDType getHasActionID() {
        return hasActionID;
    }

    /**
     * Sets the value of the hasActionID property.
     * 
     * @param value
     *     allowed object is
     *     {@link HasActionIDType }
     *     
     */
    public void setHasActionID(HasActionIDType value) {
        this.hasActionID = value;
    }

    /**
     * Gets the value of the vscsSoftware property.
     * 
     * @return
     *     possible object is
     *     {@link UsedByVSCSSpecificationsType }
     *     
     */
    public UsedByVSCSSpecificationsType getVSCSSoftware() {
        return vscsSoftware;
    }

    /**
     * Sets the value of the vscsSoftware property.
     * 
     * @param value
     *     allowed object is
     *     {@link UsedByVSCSSpecificationsType }
     *     
     */
    public void setVSCSSoftware(UsedByVSCSSpecificationsType value) {
        this.vscsSoftware = value;
    }

    /**
     * Gets the value of the cagCondition property.
     * 
     * @return
     *     possible object is
     *     {@link PrecedenceElementType }
     *     
     */
    public PrecedenceElementType getCAGCondition() {
        return cagCondition;
    }

    /**
     * Sets the value of the cagCondition property.
     * 
     * @param value
     *     allowed object is
     *     {@link PrecedenceElementType }
     *     
     */
    public void setCAGCondition(PrecedenceElementType value) {
        this.cagCondition = value;
    }

    /**
     * Gets the value of the hasActionCondition property.
     * 
     * @return
     *     possible object is
     *     {@link PrecedenceElementType }
     *     
     */
    public PrecedenceElementType getHasActionCondition() {
        return hasActionCondition;
    }

    /**
     * Sets the value of the hasActionCondition property.
     * 
     * @param value
     *     allowed object is
     *     {@link PrecedenceElementType }
     *     
     */
    public void setHasActionCondition(PrecedenceElementType value) {
        this.hasActionCondition = value;
    }

    /**
     * Gets the value of the serviceActionCondition property.
     * 
     * @return
     *     possible object is
     *     {@link PrecedenceElementType }
     *     
     */
    public PrecedenceElementType getServiceActionCondition() {
        return serviceActionCondition;
    }

    /**
     * Sets the value of the serviceActionCondition property.
     * 
     * @param value
     *     allowed object is
     *     {@link PrecedenceElementType }
     *     
     */
    public void setServiceActionCondition(PrecedenceElementType value) {
        this.serviceActionCondition = value;
    }

    /**
     * Gets the value of the nodeInfo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the nodeInfo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNodeInfo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link NodeInfoType }
     * 
     * 
     */
    public List<NodeInfoType> getNodeInfo() {
        if (nodeInfo == null) {
            nodeInfo = new ArrayList<NodeInfoType>();
        }
        return this.nodeInfo;
    }

    /**
     * Gets the value of the hardware property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the hardware property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getHardware().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link HardwareType }
     * 
     * 
     */
    public List<HardwareType> getHardware() {
        if (hardware == null) {
            hardware = new ArrayList<HardwareType>();
        }
        return this.hardware;
    }

    /**
     * Gets the value of the serviceParts property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the serviceParts property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getServiceParts().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link HasServicePartsType }
     * 
     * 
     */
    public List<HasServicePartsType> getServiceParts() {
        if (serviceParts == null) {
            serviceParts = new ArrayList<HasServicePartsType>();
        }
        return this.serviceParts;
    }

    /**
     * Gets the value of the mappedFeatures property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMappedFeatures() {
        return mappedFeatures;
    }

    /**
     * Sets the value of the mappedFeatures property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMappedFeatures(String value) {
        this.mappedFeatures = value;
    }

    /**
     * Gets the value of the preInstallSoftware property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the preInstallSoftware property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPreInstallSoftware().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PreInstallSoftwareType }
     * 
     * 
     */
    public List<PreInstallSoftwareType> getPreInstallSoftware() {
        if (preInstallSoftware == null) {
            preInstallSoftware = new ArrayList<PreInstallSoftwareType>();
        }
        return this.preInstallSoftware;
    }

    /**
     * Gets the value of the postInstallSoftware property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the postInstallSoftware property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPostInstallSoftware().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PostInstallSoftwareType }
     * 
     * 
     */
    public List<PostInstallSoftwareType> getPostInstallSoftware() {
        if (postInstallSoftware == null) {
            postInstallSoftware = new ArrayList<PostInstallSoftwareType>();
        }
        return this.postInstallSoftware;
    }

    /**
     * Gets the value of the coordinatedAssemblies property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the coordinatedAssemblies property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCoordinatedAssemblies().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getCoordinatedAssemblies() {
        if (coordinatedAssemblies == null) {
            coordinatedAssemblies = new ArrayList<String>();
        }
        return this.coordinatedAssemblies;
    }

    /**
     * Gets the value of the ecuAcronym property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEcuAcronym() {
        return ecuAcronym;
    }

    /**
     * Sets the value of the ecuAcronym property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEcuAcronym(String value) {
        this.ecuAcronym = value;
    }

    /**
     * Gets the value of the assemblyPartNumberDID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssemblyPartNumberDID() {
        return assemblyPartNumberDID;
    }

    /**
     * Sets the value of the assemblyPartNumberDID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssemblyPartNumberDID(String value) {
        this.assemblyPartNumberDID = value;
    }

    /**
     * Gets the value of the currentAssy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrentAssy() {
        return currentAssy;
    }

    /**
     * Sets the value of the currentAssy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrentAssy(String value) {
        this.currentAssy = value;
    }

    /**
     * Gets the value of the availableAssy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAvailableAssy() {
        return availableAssy;
    }

    /**
     * Sets the value of the availableAssy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAvailableAssy(String value) {
        this.availableAssy = value;
    }

    /**
     * Gets the value of the isUniqueBootloader property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsUniqueBootloader() {
        return isUniqueBootloader;
    }

    /**
     * Sets the value of the isUniqueBootloader property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsUniqueBootloader(Boolean value) {
        this.isUniqueBootloader = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the rationalMnemonicGroupName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRationalMnemonicGroupName() {
        return rationalMnemonicGroupName;
    }

    /**
     * Sets the value of the rationalMnemonicGroupName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRationalMnemonicGroupName(String value) {
        this.rationalMnemonicGroupName = value;
    }

    /**
     * Gets the value of the configMethod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConfigMethod() {
        return configMethod;
    }

    /**
     * Sets the value of the configMethod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConfigMethod(String value) {
        this.configMethod = value;
    }

    /**
     * Gets the value of the isPartDiscontinued property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsPartDiscontinued() {
        return isPartDiscontinued;
    }

    /**
     * Sets the value of the isPartDiscontinued property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsPartDiscontinued(Boolean value) {
        this.isPartDiscontinued = value;
    }

    /**
     * Gets the value of the esn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEsn() {
        return esn;
    }

    /**
     * Sets the value of the esn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEsn(String value) {
        this.esn = value;
    }

    /**
     * Gets the value of the directivesFileDownloadId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDirectivesFileDownloadId() {
        return directivesFileDownloadId;
    }

    /**
     * Sets the value of the directivesFileDownloadId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDirectivesFileDownloadId(String value) {
        this.directivesFileDownloadId = value;
    }

}
