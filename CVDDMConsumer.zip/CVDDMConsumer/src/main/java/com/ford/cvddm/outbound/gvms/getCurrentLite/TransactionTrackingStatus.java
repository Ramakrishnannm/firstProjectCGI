package com.ford.cvddm.outbound.gvms.getCurrentLite;


import java.sql.Timestamp;

public class TransactionTrackingStatus {

    private int transactionId;
    private int transactionDetailId;
    private String externalTransactionId;

    private String vin;
    private String transactionStatusCode;
    private String sourceSystem;

    private String ecuAcronym;

    private String esn;
    private String nodeAddress;

    private String errorCode;
    private String errorDescription;
    private String messageCode;
    private String messageDescription;

    private Timestamp transactionTime;

    private String micServiceName;

    private String transactionType;

    private String newTransaction;

    private String tranceId;

    public String getTranceId() {
        return tranceId;
    }

    public void setTranceId(String tranceId) {
        this.tranceId = tranceId;
    }

    public String getMicServiceName() {
        return micServiceName;
    }

    public void setMicServiceName(String micServiceName) {
        this.micServiceName = micServiceName;
    }

    public int getTransactionDetailId() {
        return transactionDetailId;
    }

    public void setTransactionDetailId(int transactionDetailId) {
        this.transactionDetailId = transactionDetailId;
    }

    public String getEcuAcronym() {
        return ecuAcronym;
    }

    public void setEcuAcronym(String ecuAcronym) {
        this.ecuAcronym = ecuAcronym;
    }

    public String getEsn() {
        return esn;
    }

    public void setEsn(String esn) {
        this.esn = esn;
    }

    public String getNodeAddress() {
        return nodeAddress;
    }

    public void setNodeAddress(String nodeAddress) {
        this.nodeAddress = nodeAddress;
    }

    public Timestamp getTransactionTime() {
        return transactionTime;
    }

    public void setTransactionTime(Timestamp transactionTime) {
        this.transactionTime = transactionTime;
    }


    public int getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(int transactionId) {
        this.transactionId = transactionId;
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public String getTransactionStatusCode() {
        return transactionStatusCode;
    }

    public void setTransactionStatusCode(String transactionStatusCode) {
        this.transactionStatusCode = transactionStatusCode;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorDescription() {
        return errorDescription;
    }

    public void setErrorDescription(String errorDescription) {
        this.errorDescription = errorDescription;
    }

    public String getMessageCode() {
        return messageCode;
    }

    public void setMessageCode(String messageCode) {
        this.messageCode = messageCode;
    }

    public String getMessageDescription() {
        return messageDescription;
    }

    public void setMessageDescription(String messageDescription) {
        this.messageDescription = messageDescription;
    }

    public String getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    public String getExternalTransactionId() {
        return externalTransactionId;
    }

    public void setExternalTransactionId(String externalTransactionId) {
        this.externalTransactionId = externalTransactionId;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getNewTransaction() {
        return newTransaction;
    }

    public void setNewTransaction(String newTransaction) {
        this.newTransaction = newTransaction;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder("TransactionTrackingStatus: ");
        stringBuilder.append("TransactionId: ").append(this.transactionId + ", ")
                .append("TransactionDetailId: ").append(this.transactionDetailId)
                .append("ExternalTransactionId: ").append(this.externalTransactionId)
                .append("Vin: ").append(this.vin)
                .append("SourceSystem: ").append(this.sourceSystem)
                .append("EcyAcronym: ").append(this.ecuAcronym)
                .append("ESN: ").append(this.esn)
                .append("NodeAddress: ").append(this.nodeAddress);

        return stringBuilder.toString();
    }
}
