package com.ford.cvddm.outbound.gvms.getCurrentLite;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Created by BVENKA10 on 11/2/2017.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DidInfoDetails {

    private String didResponse;

    private String didType;

    private String didValue;

    private String reserverdElement1;

    private String isConfig;

    private String reserverdElement3;

    private String reserverdElement2;

    public String getDidResponse ()
    {
        return didResponse;
    }

    public void setDidResponse (String didResponse)
    {
        this.didResponse = didResponse;
    }

    public String getDidType ()
    {
        return didType;
    }

    public void setDidType (String didType)
    {
        this.didType = didType;
    }

    public String getDidValue ()
    {
        return didValue;
    }

    public void setDidValue (String didValue)
    {
        this.didValue = didValue;
    }

    public String getReserverdElement1 ()
    {
        return reserverdElement1;
    }

    public void setReserverdElement1 (String reserverdElement1)
    {
        this.reserverdElement1 = reserverdElement1;
    }

    public String getIsConfig ()
    {
        return isConfig;
    }

    public void setIsConfig (String isConfig)
    {
        this.isConfig = isConfig;
    }

    public String getReserverdElement3 ()
    {
        return reserverdElement3;
    }

    public void setReserverdElement3 (String reserverdElement3)
    {
        this.reserverdElement3 = reserverdElement3;
    }

    public String getReserverdElement2 ()
    {
        return reserverdElement2;
    }

    public void setReserverdElement2 (String reserverdElement2)
    {
        this.reserverdElement2 = reserverdElement2;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [didResponse = "+didResponse+", didType = "+didType+", didValue = "+didValue+", reserverdElement1 = "+reserverdElement1+", isConfig = "+isConfig+", reserverdElement3 = "+reserverdElement3+", reserverdElement2 = "+reserverdElement2+"]";
    }
}
