package com.ford.cvddm.outbound.givis.soap;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import org.apache.commons.io.IOUtils;

import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.outbound.gvms.getCurrentLite.CvddmHttpPoster;
import com.ford.it.http.HttpPosterException;

public class TestGivisHttpPost {

	public String testGivisHttpPostThroughCookies() {
		CvddmHttpPoster cvddmHttpPoster = new CvddmHttpPoster();
		String output = null;

		try {
			cvddmHttpPoster.setUrl(new URL("https://wwwqa.ivis2.ford.com/VisServicesWeb/VehicleModuleInfoService"));
			String cookie = CvddmUtil
					.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY, CVDDMConstant.GIVIS_COOKIE);
			cvddmHttpPoster.addHeader("cookie", "WSL-credential-V2=" + cookie);
			cvddmHttpPoster.addHeader("Content-Type", "application/xml");

			InputStream requestInStream = IOUtils.toInputStream("", StandardCharsets.UTF_8.toString());
			InputStream respStream;

			respStream = cvddmHttpPoster.post(requestInStream);

			StringWriter writer = new StringWriter();
			IOUtils.copy(respStream, writer, "UTF-8");
			output = writer.toString();
			System.out.println(output);

		} catch (MalformedURLException e) {

			e.printStackTrace();
		} catch (HttpPosterException | IOException e) {

			e.printStackTrace();
		}

		return output;
	}

}
