
package com.ford.cvddm.outbound.givis.soap.givismodulestate;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RoleENUMType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="RoleENUMType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="CONSUMER"/>
 *     &lt;enumeration value="DEALER"/>
 *     &lt;enumeration value="AFTERMARKET"/>
 *     &lt;enumeration value="MODCENTER"/>
 *     &lt;enumeration value="EOL"/>
 *     &lt;enumeration value="ECATS"/>
 *     &lt;enumeration value="VHR"/>
 *     &lt;enumeration value="MFR"/>
 *     &lt;enumeration value="ENGINEER"/>
 *     &lt;enumeration value="PLANT TECHNICIAN"/>
 *     &lt;enumeration value="TESTCONSUMER"/>
 *     &lt;enumeration value="OTA"/>
 *     &lt;enumeration value="TESTOTA"/>
 *     &lt;enumeration value="ENGINEER TESTER"/>
 *     &lt;enumeration value="SUPPLIER"/>
 *     &lt;enumeration value="SUPPLIER TESTER"/>
 *     &lt;enumeration value="FCS"/>
 *     &lt;enumeration value="FDSP"/>
 *     &lt;enumeration value="RVCM"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "RoleENUMType")
@XmlEnum
public enum RoleENUMType {

    CONSUMER("CONSUMER"),
    DEALER("DEALER"),
    AFTERMARKET("AFTERMARKET"),
    MODCENTER("MODCENTER"),
    EOL("EOL"),
    ECATS("ECATS"),
    VHR("VHR"),
    MFR("MFR"),
    ENGINEER("ENGINEER"),
    @XmlEnumValue("PLANT TECHNICIAN")
    PLANT_TECHNICIAN("PLANT TECHNICIAN"),
    TESTCONSUMER("TESTCONSUMER"),
    OTA("OTA"),
    TESTOTA("TESTOTA"),
    @XmlEnumValue("ENGINEER TESTER")
    ENGINEER_TESTER("ENGINEER TESTER"),
    SUPPLIER("SUPPLIER"),
    @XmlEnumValue("SUPPLIER TESTER")
    SUPPLIER_TESTER("SUPPLIER TESTER"),
    FCS("FCS"),
    FDSP("FDSP"),
    RVCM("RVCM");
    private final String value;

    RoleENUMType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static RoleENUMType fromValue(String v) {
        for (RoleENUMType c: RoleENUMType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
