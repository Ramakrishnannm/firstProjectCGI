package com.ford.cvddm.outbound.gvms.getCurrentLite;


public class Sync {

    private String isGeneration;
    private String isVersion;
    private String isFunctionType;
    private String reservedElement;


    public String getIsGeneration() {
        return isGeneration;
    }

    public void setIsGeneration(String isGeneration) {
        this.isGeneration = isGeneration;
    }

    public String getIsVersion() {
        return isVersion;
    }

    public void setIsVersion(String isVersion) {
        this.isVersion = isVersion;
    }

    public String getReservedElement() {
        return reservedElement;
    }

    public void setReservedElement(String reservedElement) {
        this.reservedElement = reservedElement;
    }

    public String getIsFunctionType() {
        return isFunctionType;
    }

    public void setIsFunctionType(String isFunctionType) {
        this.isFunctionType = isFunctionType;
    }
}
