
package com.ford.cvddm.outbound.gvms.vehicleModuleInfo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The Network Name of the Network
 * 
 * <p>Java class for ODLNetworkType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ODLNetworkType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SpecificationCategory" type="{urn:ford/Vehicle/Module/Information/v4.0}ODLDiagnosticSpecType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attGroup ref="{urn:ford/Vehicle/Module/Information/v4.0}NetworkConnector"/>
 *       &lt;attribute ref="{urn:ford/Vehicle/Module/Information/v4.0}NetworkName use="required""/>
 *       &lt;attribute ref="{urn:ford/Vehicle/Module/Information/v4.0}NetworkProtocol use="required""/>
 *       &lt;attribute ref="{urn:ford/Vehicle/Module/Information/v4.0}NetworkDataRate use="required""/>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ODLNetworkType", propOrder = {
    "specificationCategory"
})
public class ODLNetworkType
    implements Serializable
{

    @XmlElement(name = "SpecificationCategory")
    protected List<ODLDiagnosticSpecType> specificationCategory;
    @XmlAttribute(name = "NetworkName", namespace = "urn:ford/Vehicle/Module/Information/v4.0", required = true)
    protected String networkName;
    @XmlAttribute(name = "NetworkProtocol", namespace = "urn:ford/Vehicle/Module/Information/v4.0", required = true)
    protected String networkProtocol;
    @XmlAttribute(name = "NetworkDataRate", namespace = "urn:ford/Vehicle/Module/Information/v4.0", required = true)
    protected String networkDataRate;
    @XmlAttribute(name = "DLCName", namespace = "urn:ford/Vehicle/Module/Information/v4.0")
    protected String dlcName;
    @XmlAttribute(name = "Pins", namespace = "urn:ford/Vehicle/Module/Information/v4.0")
    protected String pins;

    /**
     * Gets the value of the specificationCategory property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the specificationCategory property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSpecificationCategory().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ODLDiagnosticSpecType }
     * 
     * 
     */
    public List<ODLDiagnosticSpecType> getSpecificationCategory() {
        if (specificationCategory == null) {
            specificationCategory = new ArrayList<ODLDiagnosticSpecType>();
        }
        return this.specificationCategory;
    }

    /**
     * Gets the value of the networkName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNetworkName() {
        return networkName;
    }

    /**
     * Sets the value of the networkName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNetworkName(String value) {
        this.networkName = value;
    }

    /**
     * Gets the value of the networkProtocol property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNetworkProtocol() {
        return networkProtocol;
    }

    /**
     * Sets the value of the networkProtocol property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNetworkProtocol(String value) {
        this.networkProtocol = value;
    }

    /**
     * Gets the value of the networkDataRate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNetworkDataRate() {
        return networkDataRate;
    }

    /**
     * Sets the value of the networkDataRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNetworkDataRate(String value) {
        this.networkDataRate = value;
    }

    /**
     * Gets the value of the dlcName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDLCName() {
        return dlcName;
    }

    /**
     * Sets the value of the dlcName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDLCName(String value) {
        this.dlcName = value;
    }

    /**
     * Gets the value of the pins property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPins() {
        return pins;
    }

    /**
     * Sets the value of the pins property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPins(String value) {
        this.pins = value;
    }

}
