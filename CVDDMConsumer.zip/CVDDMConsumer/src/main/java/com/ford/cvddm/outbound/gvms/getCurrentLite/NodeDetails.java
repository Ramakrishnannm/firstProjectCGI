package com.ford.cvddm.outbound.gvms.getCurrentLite;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Created by BVENKA10 on 11/2/2017.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class NodeDetails {
    private String nodeAddress;

    private String protoFileVersion;

    private String reservedElement;

    private String isECUPresent;

    private String ecuAcronym;

    private String snapshotRecordTimeStamp;

    private DerivedValuesResponse derivedValuesResponse;

    private StatusInfo[] statusInfo;

    private DidInfoDetails[] didInfoDetails;

    public String getNodeAddress ()
    {
        return nodeAddress;
    }

    public void setNodeAddress (String nodeAddress)
    {
        this.nodeAddress = nodeAddress;
    }

    public String getProtoFileVersion ()
    {
        return protoFileVersion;
    }

    public void setProtoFileVersion (String protoFileVersion)
    {
        this.protoFileVersion = protoFileVersion;
    }

    public String getReservedElement ()
    {
        return reservedElement;
    }

    public void setReservedElement (String reservedElement)
    {
        this.reservedElement = reservedElement;
    }

    public String getIsECUPresent ()
    {
        return isECUPresent;
    }

    public void setIsECUPresent (String isECUPresent)
    {
        this.isECUPresent = isECUPresent;
    }

    public String getEcuAcronym ()
    {
        return ecuAcronym;
    }

    public void setEcuAcronym (String ecuAcronym)
    {
        this.ecuAcronym = ecuAcronym;
    }

    public String getSnapshotRecordTimeStamp ()
    {
        return snapshotRecordTimeStamp;
    }

    public void setSnapshotRecordTimeStamp (String snapshotRecordTimeStamp)
    {
        this.snapshotRecordTimeStamp = snapshotRecordTimeStamp;
    }

    public DerivedValuesResponse getDerivedValuesResponse ()
    {
        return derivedValuesResponse;
    }

    public void setDerivedValuesResponse (DerivedValuesResponse derivedValuesResponse)
    {
        this.derivedValuesResponse = derivedValuesResponse;
    }

    public StatusInfo[] getStatusInfo() {
        return statusInfo;
    }

    public void setStatusInfo(StatusInfo[] statusInfo) {
        this.statusInfo = statusInfo;
    }

    public DidInfoDetails[] getDidInfoDetails ()
    {
        return didInfoDetails;
    }

    public void setDidInfoDetails (DidInfoDetails[] didInfoDetails)
    {
        this.didInfoDetails = didInfoDetails;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [nodeAddress = "+nodeAddress+", protoFileVersion = "+protoFileVersion+", reservedElement = "+reservedElement+", isECUPresent = "+isECUPresent+", ecuAcronym = "+ecuAcronym+", snapshotRecordTimeStamp = "+snapshotRecordTimeStamp+", derivedValuesResponse = "+derivedValuesResponse+", statusInfo = "+statusInfo+", didInfoDetails = "+didInfoDetails+"]";
    }
}
