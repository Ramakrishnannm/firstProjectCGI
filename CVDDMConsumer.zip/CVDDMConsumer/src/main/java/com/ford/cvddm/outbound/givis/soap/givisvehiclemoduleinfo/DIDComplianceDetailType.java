
package com.ford.cvddm.outbound.givis.soap.givisvehiclemoduleinfo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Detailed Data about DID deviations.
 * 			
 * 
 * <p>Java class for DIDComplianceDetailType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DIDComplianceDetailType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="ComplianceDID" type="{urn:ford/Vehicle/Module/Information/v4.0}ComplianceDIDType" minOccurs="0"/>
 *         &lt;element name="ComplianceResponse" type="{urn:ford/Vehicle/Module/Information/v4.0}ComplianceResponseType" minOccurs="0"/>
 *         &lt;element name="ActualResponseLength" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DIDComplianceDetailType", propOrder = {

})
public class DIDComplianceDetailType {

    @XmlElement(name = "ComplianceDID")
    protected ComplianceDIDType complianceDID;
    @XmlElement(name = "ComplianceResponse")
    protected String complianceResponse;
    @XmlElement(name = "ActualResponseLength")
    protected String actualResponseLength;

    /**
     * Gets the value of the complianceDID property.
     * 
     * @return
     *     possible object is
     *     {@link ComplianceDIDType }
     *     
     */
    public ComplianceDIDType getComplianceDID() {
        return complianceDID;
    }

    /**
     * Sets the value of the complianceDID property.
     * 
     * @param value
     *     allowed object is
     *     {@link ComplianceDIDType }
     *     
     */
    public void setComplianceDID(ComplianceDIDType value) {
        this.complianceDID = value;
    }

    /**
     * Gets the value of the complianceResponse property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComplianceResponse() {
        return complianceResponse;
    }

    /**
     * Sets the value of the complianceResponse property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComplianceResponse(String value) {
        this.complianceResponse = value;
    }

    /**
     * Gets the value of the actualResponseLength property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActualResponseLength() {
        return actualResponseLength;
    }

    /**
     * Sets the value of the actualResponseLength property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActualResponseLength(String value) {
        this.actualResponseLength = value;
    }

}
