package com.ford.cvddm.outbound.gvms.getCurrentLite;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder({
        "mfalCode",
        "mfalStatus",
})
public class MfalDetails {

    private String mfalCode;
    private String mFalStatus;


    public String getMfalCode() {
        return this.mfalCode;
    }

    public void setMfalCode(String mfalCode) {
        this.mfalCode = mfalCode;
    }

    public String getMfalStatus() {
        return this.mFalStatus;
    }

    public void setMfalStatus(String mFalStatus) {
        this.mFalStatus = mFalStatus;
    }

}
