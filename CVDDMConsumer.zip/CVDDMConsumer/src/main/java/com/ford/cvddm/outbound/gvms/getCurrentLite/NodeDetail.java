
package com.ford.cvddm.outbound.gvms.getCurrentLite;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;


@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder({
        "nodeAddress",
        "ecuAcronym",
        "isECUPresent",
        "isProvisioned",
        "protoFileVersion",
        "reservedElement",
        "snapshotRecordTimeStamp",
        "syncGeneration",
        "syncVersion",
        "derivedValuesResponse",
        "didInfoDetails"
})
public class NodeDetail {

    private DerivedValuesResponse derivedValuesResponse;
    private List<DidInfoDetail> didInfoDetails = null;
    private String ecuAcronym;
    private String isECUPresent;
    private String isProvisioned;
    private String protoFileVersion;
    private String syncGeneration;
    private String syncVersion;
    private String nodeAddress;
    private String reservedElement;
    private String snapshotRecordTimeStamp;
    private List<StatusInfo> statusInfo = null;

    public DerivedValuesResponse getDerivedValuesResponse() {
        return derivedValuesResponse;
    }

    public void setDerivedValuesResponse(DerivedValuesResponse derivedValuesResponse) {
        this.derivedValuesResponse = derivedValuesResponse;
    }

    public List<DidInfoDetail> getDidInfoDetails() {
        return didInfoDetails;
    }

    public void setDidInfoDetails(List<DidInfoDetail> didInfoDetails) {
        this.didInfoDetails = didInfoDetails;
    }

    public String getEcuAcronym() {
        return ecuAcronym;
    }

    public void setEcuAcronym(String ecuAcronym) {
        this.ecuAcronym = ecuAcronym;
    }

    public String getIsECUPresent() {
        return isECUPresent;
    }

    public void setIsECUPresent(String isECUPresent) {
        this.isECUPresent = isECUPresent;
    }

    public String getProtoFileVersion() {
        return protoFileVersion;
    }

    public void setProtoFileVersion(String protoFileVersion) {
        this.protoFileVersion = protoFileVersion;
    }

    public String getSyncGeneration() {
        return syncGeneration;
    }

    public void setSyncGeneration(String syncGeneration) {
        this.syncGeneration = syncGeneration;
    }

    public String getSyncVersion() {
        return syncVersion;
    }

    public void setSyncVersion(String syncVersion) {
        this.syncVersion = syncVersion;
    }

    public String getNodeAddress() {
        return nodeAddress;
    }

    public void setNodeAddress(String nodeAddress) {
        this.nodeAddress = nodeAddress;
    }

    public String getReservedElement() {
        return reservedElement;
    }

    public void setReservedElement(String reservedElement) {
        this.reservedElement = reservedElement;
    }

    public String getSnapshotRecordTimeStamp() {
        return snapshotRecordTimeStamp;
    }

    public void setSnapshotRecordTimeStamp(String snapshotRecordTimeStamp) {
        this.snapshotRecordTimeStamp = snapshotRecordTimeStamp;
    }

    public List<StatusInfo> getStatusInfo() {
        return statusInfo;
    }

    public void setStatusInfo(List<StatusInfo> statusInfo) {
        this.statusInfo = statusInfo;
    }



    public String getIsProvisionedFlag() {
        return this.isProvisioned;
    }

    public void setIsProvisionedFlag(String isProvisionedFlag) {
        this.isProvisioned = isProvisionedFlag;
    }

}
