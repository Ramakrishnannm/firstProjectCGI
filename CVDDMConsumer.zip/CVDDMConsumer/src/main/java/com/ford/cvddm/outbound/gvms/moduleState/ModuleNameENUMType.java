
package com.ford.cvddm.outbound.gvms.moduleState;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ModuleNameENUMType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ModuleNameENUMType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="ECU"/>
 *     &lt;enumeration value="APIM"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ModuleNameENUMType", namespace = "urn:ford/com/productdesign/ipp/ModuleSnapshot/v2.1")
@XmlEnum
public enum ModuleNameENUMType {

    ECU,
    APIM;

    public String value() {
        return name();
    }

    public static ModuleNameENUMType fromValue(String v) {
        return valueOf(v);
    }

}
