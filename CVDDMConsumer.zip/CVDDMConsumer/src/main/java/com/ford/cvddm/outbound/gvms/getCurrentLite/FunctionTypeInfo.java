package com.ford.cvddm.outbound.gvms.getCurrentLite;

import java.util.List;

/**
 * Created by tanbuche on 4/5/2018.
 */
public class FunctionTypeInfo {

    private String partNumber;

    private List<String> functionType;

    public String getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    public List<String> getFunctionType() {
        return functionType;
    }

    public void setFunctionType(List<String> functionType) {
        this.functionType = functionType;
    }
}
