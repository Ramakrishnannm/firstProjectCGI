
package com.ford.cvddm.outbound.gvms.moduleState;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SpecCategoryType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SpecCategoryType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="type" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="diagnosticSpecDidValue" type="{urn:ford/Vehicle/Module/Information/v4.0}DIDValueType" />
 *       &lt;attribute name="diagnosticSpecDidResponse" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="progSpecDidValue" type="{urn:ford/Vehicle/Module/Information/v4.0}DIDValueType" />
 *       &lt;attribute name="progSpecDidResponse" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SpecCategoryType")
public class SpecCategoryType
    implements Serializable
{

    @XmlAttribute(name = "type")
    protected String type;
    @XmlAttribute(name = "diagnosticSpecDidValue")
    protected String diagnosticSpecDidValue;
    @XmlAttribute(name = "diagnosticSpecDidResponse")
    protected String diagnosticSpecDidResponse;
    @XmlAttribute(name = "progSpecDidValue")
    protected String progSpecDidValue;
    @XmlAttribute(name = "progSpecDidResponse")
    protected String progSpecDidResponse;

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Gets the value of the diagnosticSpecDidValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDiagnosticSpecDidValue() {
        return diagnosticSpecDidValue;
    }

    /**
     * Sets the value of the diagnosticSpecDidValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDiagnosticSpecDidValue(String value) {
        this.diagnosticSpecDidValue = value;
    }

    /**
     * Gets the value of the diagnosticSpecDidResponse property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDiagnosticSpecDidResponse() {
        return diagnosticSpecDidResponse;
    }

    /**
     * Sets the value of the diagnosticSpecDidResponse property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDiagnosticSpecDidResponse(String value) {
        this.diagnosticSpecDidResponse = value;
    }

    /**
     * Gets the value of the progSpecDidValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProgSpecDidValue() {
        return progSpecDidValue;
    }

    /**
     * Sets the value of the progSpecDidValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProgSpecDidValue(String value) {
        this.progSpecDidValue = value;
    }

    /**
     * Gets the value of the progSpecDidResponse property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProgSpecDidResponse() {
        return progSpecDidResponse;
    }

    /**
     * Sets the value of the progSpecDidResponse property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProgSpecDidResponse(String value) {
        this.progSpecDidResponse = value;
    }

}
