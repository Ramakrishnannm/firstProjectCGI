package com.ford.cvddm.outbound.givis.rest;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.cvddm.common.util.CvddmUtil;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.cvddm.outbound.layer.CVDDMConsumerException;
import com.ford.it.exception.FordExceptionAttributes;
import com.ford.it.http.HttpGetter;
import com.ford.it.logging.ILogger;
import com.ford.it.logging.LogFactory;

/**
 * 
 * @author MJEYARAJ
 *
 */
public class GIVISRestClients {

	/** The Class Name used for Logging */
	private static final String CLASS_NAME = GIVISRestClients.class.getName();

	/** The Logger instance used for Logging */
	private static final ILogger log = LogFactory.getInstance().getLogger(CLASS_NAME);

	private ObjectMapper mapper = new ObjectMapper();

	/**
	 * Rest client to retrieve the PartNumbers from Givis
	 * 
	 * @return
	 */
	public List<ProgramCodeTO> getPartNumbersFromGivis(String enviroinment) {

		final String METHOD_NAME = "getPartNumbersFromGivis";
		log.entering(CLASS_NAME, METHOD_NAME);

		String outputJson = null;
		List<ProgramCodeTO> outputList = new ArrayList<>();

		try {

			String partNumbersURL = CvddmUtil.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
					CVDDMConstant.GIVIS_GET_PARTNUMBERS_ENDPOINT).replace("{ENV}", enviroinment);

			log.info("PartNumbers URL: " + partNumbersURL);
			URL posterURL = new URL(partNumbersURL);

			HttpGetter httpGetter = new HttpGetter();
			httpGetter.setUrl(posterURL);

			byte[] responseByteArr = httpGetter.get();

			outputJson = new String(responseByteArr);

			log.info("Output JSON partNumbers: " + outputJson);

			outputList = convertOutputJSONPartIISpec(outputJson);

		} catch (Exception ie) {
			throw new CVDDMConsumerException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(ie), ie);
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

		return outputList;
	}

	/**
	 * Rest client to retrieve AWS Modified date from Givis
	 * 
	 * @return
	 */
	public String getAWSModifiedDateFromGivis(String key, String enviroinment) {

		final String METHOD_NAME = "getAWSModifiedDateFromGivis";
		log.entering(CLASS_NAME, METHOD_NAME);

		String outputJson = null;
		HttpGetter httpGetter = new HttpGetter();

		try {

			String awsURL = CvddmUtil
					.getPropertiesValue(CVDDMConstant.BUNDLE_APPLICATION_CONFIG_KEY,
							CVDDMConstant.GIVIS_GET_AWS_MODIFIED_DATE_ENDPOINT)
					.replace("{ENV}", enviroinment).replace("{KEY}", key);

			log.info("AWS modifed date URL: " + awsURL);
			URL posterURL = new URL(awsURL);

			httpGetter.setUrl(posterURL);

			byte[] responseByteArr = httpGetter.get();

			outputJson = new String(responseByteArr);

			log.info("Output JSON Modified date: " + outputJson);

		} catch (Exception ie) {
			throw new CVDDMConsumerException(new FordExceptionAttributes.Builder(CLASS_NAME, METHOD_NAME).build(),
					CvddmUtil.getStackTraceContent(ie), ie);
		}

		log.exiting(CLASS_NAME, METHOD_NAME);

		return outputJson;
	}

	// Private methods

	/**
	 * Private method to covert JSON into POJO
	 * 
	 * @param jsonOutputString
	 * @return
	 */
	private List<ProgramCodeTO> convertOutputJSONPartIISpec(String jsonOutputString) {

		List<ProgramCodeTO> participantJsonList = null;

		try {
			participantJsonList = mapper.readValue(jsonOutputString, new TypeReference<List<ProgramCodeTO>>() {
			});
		} catch (IOException e) {
			log.severe(CvddmUtil.getStackTraceContent(e));
		}

		return participantJsonList;
	}

}