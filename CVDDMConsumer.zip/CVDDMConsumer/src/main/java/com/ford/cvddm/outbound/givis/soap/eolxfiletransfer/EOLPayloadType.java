
package com.ford.cvddm.outbound.givis.soap.eolxfiletransfer;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for EOLPayloadType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EOLPayloadType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PlantDetail" type="{urn:ford/pd/eol/v1.0}PlantDetailType"/>
 *         &lt;element name="Datetime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="BatchDetail" type="{urn:ford/pd/eol/v1.0}BatchDetailType"/>
 *         &lt;element name="FileList" type="{urn:ford/pd/eol/v1.0}EOLFileListType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EOLPayloadType", propOrder = {
    "plantDetail",
    "datetime",
    "batchDetail",
    "fileList"
})
public class EOLPayloadType {

    @XmlElement(name = "PlantDetail", required = true)
    protected PlantDetailType plantDetail;
    @XmlElement(name = "Datetime", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar datetime;
    @XmlElement(name = "BatchDetail", required = true)
    protected BatchDetailType batchDetail;
    @XmlElement(name = "FileList", required = true)
    protected EOLFileListType fileList;

    /**
     * Gets the value of the plantDetail property.
     * 
     * @return
     *     possible object is
     *     {@link PlantDetailType }
     *     
     */
    public PlantDetailType getPlantDetail() {
        return plantDetail;
    }

    /**
     * Sets the value of the plantDetail property.
     * 
     * @param value
     *     allowed object is
     *     {@link PlantDetailType }
     *     
     */
    public void setPlantDetail(PlantDetailType value) {
        this.plantDetail = value;
    }

    /**
     * Gets the value of the datetime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDatetime() {
        return datetime;
    }

    /**
     * Sets the value of the datetime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDatetime(XMLGregorianCalendar value) {
        this.datetime = value;
    }

    /**
     * Gets the value of the batchDetail property.
     * 
     * @return
     *     possible object is
     *     {@link BatchDetailType }
     *     
     */
    public BatchDetailType getBatchDetail() {
        return batchDetail;
    }

    /**
     * Sets the value of the batchDetail property.
     * 
     * @param value
     *     allowed object is
     *     {@link BatchDetailType }
     *     
     */
    public void setBatchDetail(BatchDetailType value) {
        this.batchDetail = value;
    }

    /**
     * Gets the value of the fileList property.
     * 
     * @return
     *     possible object is
     *     {@link EOLFileListType }
     *     
     */
    public EOLFileListType getFileList() {
        return fileList;
    }

    /**
     * Sets the value of the fileList property.
     * 
     * @param value
     *     allowed object is
     *     {@link EOLFileListType }
     *     
     */
    public void setFileList(EOLFileListType value) {
        this.fileList = value;
    }

}
