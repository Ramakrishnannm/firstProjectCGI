package com.ford.cvddm.outbound.givis.rest;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({ "programCode", "modelYear", "vehicleName" })
public class ProgramCodeTO {

	@JsonProperty("programCode")
	private String programCode;

	@JsonProperty("modelYear")
	private int modelYear;

	@JsonProperty("vehicleName")
	private String vehicleName;

	public String getProgramCode() {
		return programCode;
	}

	public void setProgramCode(String programCode) {
		this.programCode = programCode;
	}

	public int getModelYear() {
		return modelYear;
	}

	public void setModelYear(int modelYear) {
		this.modelYear = modelYear;
	}

	public String getVehicleName() {
		return vehicleName;
	}

	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}

}