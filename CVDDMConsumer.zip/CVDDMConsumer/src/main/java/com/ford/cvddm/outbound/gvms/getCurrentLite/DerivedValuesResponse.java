
package com.ford.cvddm.outbound.gvms.getCurrentLite;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder({
        "derivedAssembly",
        "part2Spec",
        "reservedElement"
})
public class DerivedValuesResponse {

    private String derivedAssembly;
    private String part2Spec;
    private String reservedElement;

    public String getDerivedAssembly() {
        return derivedAssembly;
    }

    public void setDerivedAssembly(String derivedAssembly) {
        this.derivedAssembly = derivedAssembly;
    }

    public String getPart2Spec() {
        return part2Spec;
    }

    public void setPart2Spec(String part2Spec) {
        this.part2Spec = part2Spec;
    }

    public String getReservedElement() {
        return reservedElement;
    }

    public void setReservedElement(String reservedElement) {
        this.reservedElement = reservedElement;
    }

}
