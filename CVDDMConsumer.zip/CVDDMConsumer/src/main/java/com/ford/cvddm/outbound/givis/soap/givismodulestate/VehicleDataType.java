
package com.ford.cvddm.outbound.givis.soap.givismodulestate;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for VehicleDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="VehicleDataType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CurrentDIDList" type="{urn:ford/Vehicle/Module/Information/v4.0}CurrentDIDListType" minOccurs="0"/>
 *         &lt;element name="FeatureList" type="{urn:ford/Vehicle/Module/Information/v4.0}FeatureCodeInfoType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "VehicleDataType", propOrder = {
    "currentDIDList",
    "featureList"
})
public class VehicleDataType {

    @XmlElement(name = "CurrentDIDList")
    protected CurrentDIDListType currentDIDList;
    @XmlElement(name = "FeatureList")
    protected List<FeatureCodeInfoType> featureList;

    /**
     * Gets the value of the currentDIDList property.
     * 
     * @return
     *     possible object is
     *     {@link CurrentDIDListType }
     *     
     */
    public CurrentDIDListType getCurrentDIDList() {
        return currentDIDList;
    }

    /**
     * Sets the value of the currentDIDList property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrentDIDListType }
     *     
     */
    public void setCurrentDIDList(CurrentDIDListType value) {
        this.currentDIDList = value;
    }

    /**
     * Gets the value of the featureList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the featureList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFeatureList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FeatureCodeInfoType }
     * 
     * 
     */
    public List<FeatureCodeInfoType> getFeatureList() {
        if (featureList == null) {
            featureList = new ArrayList<FeatureCodeInfoType>();
        }
        return this.featureList;
    }

}
