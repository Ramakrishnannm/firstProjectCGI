package com.ford.cvddm.outbound.gvms.getCurrentLite;

import java.util.*;

public class GetCurrentLiteStatusCodes {

    public static final String APPNAME_GVMS = "GVMS";
    public static final String VALUE_YES = "Y";
    public static final String VALUE_NO = "N";
    public static final String SYNC_NODE_ADDRESS = "7D0";
    public static final String GETCURRENT_LITE_SVC_NAME = "GetCurrentLite";
    public static final String GETCURRENT_LITE_TRANS_TYPE = "RECVGCL";
    public static final String STATUS_SUCCESS = "0";
    public static final String VALUE_ALL = "ALL";
    public static final int MAX_ERR_MSG_LEN = 1000;
    public static final String ACTIVE_FLAG = "A";
    public static final String APPLICATION_8060 = "8060";
    public static final String APPLICATION_8061 = "8061";

    public static List<String> ASY_PRTDID_TYPES = Arrays.asList("F113", "E21X");
    public static List<String> HW_PRTDID_TYPES = Arrays.asList("F111", "F191", "E610");
    public static List<String> SW_PRTDID_TYPES = Arrays.asList("F188", "F10A", "E611");


    private static Map<String, String> errorCodeMap = new HashMap<>();
    private static Map<String, String> valErrorCodeMap = new HashMap<>();

    private static List<String> validRequestRoleList = new ArrayList<>();

    private static List<String> validRequestRoleSourceList = new ArrayList<>();

    private static List<String> validDIDInfoTypes = new ArrayList<>();

    /**
     * Error and Success status codes
     **/
    public enum ErrorCodes {
        SUCCESS("0", "Success"),
        ERROR_VIN_NOTFOUND("10", "VIN Not Found in GVMS"),
        ERROR_PGMY_NOTFOUND("20", "Program Code / Model Year not found in GVMS"),
        ERROR_VINNODE_NOTFOUND("30", "Node not found in GVMS"),
        ERROR_NODE_NOTPRESENT("40", "Node not present in vehicle"),
        ERROR_ASYPRT_NOT_FOUND("50", "Assembly part number not found"),
        ERROR_HWPRT_NOT_FOUND("51", "Hardware part number not found"),
        ERROR_SWPRT_NOT_FOUND("52", "Software part number not found"),
        ERROR_INVLID_INPUT("60", "Invalid input. "),
        ERROR_DID_NOTAVLBL("70", "Requested DID is Not available"),
        ERROR_FUNCTION_TYPE_NOTAVLBL("80", "Function Type(s) Not available"),
        ERROR_DA_NOT_FOUND("90", "Derived Assembly not found"),
        ERROR_UNHNLD_EXCEPTION("999", "Unhandled Exceptions"),
        // Code for MFAL CR - 11 Oct 2018
        ERROR_MFAL_CODE_NOT_ACTIVE("100","MFAL Code details are not available");


        private final String code;
        private final String description;

        ErrorCodes(String aCode, String desc) {
            this.code = aCode;
            this.description = desc;
        }

        public String code() {
            return this.code;
        }

        public String description() {
            return this.description;
        }

    }

    public enum ValErrorCodes {
        ERR_INVLD_VIN("1", "VIN is empty / Not a valid format"),
        ERR_INVLD_NODE("2", "Node is empty / Not a valid format"),
        ERR_INVLD_ROLE("3", "Role is empty / Not in valid format"),
        ERROR_INVLD_ROLESRC("4", "Role Source is empty / Not a valid format"),
        ERROR_INVLD_DIDINFOTYPE("5", "didType or didList is mandatory, if the didInfoRequired element flag is Y "),
        ERROR_INVLD_DRVASYPARTII("6", "isDerivedAssembly and isPart2Spec both the elements flag should be Y to get the part2Spec part"),
        ERROR_INVLD_DIDVALUE("7", "Invalid DID in the didList element."),
        ERROR_INVLD_DIDTYPE("8", "Invalid DID in the didType element.");;

        private final String code;
        private final String description;

        ValErrorCodes(String aCode, String desc) {
            this.code = aCode;
            this.description = desc;
        }

        public String code() {
            return this.code;
        }

        public String description() {
            return this.description;
        }
    }

    public enum DIDTypesRequested {


        ALL_DID_TYPES("ALL"), CONFIG_DID_TYPES("M2"), PART_DID_TYPES("M3");

        private final String didType;

        DIDTypesRequested(String didType) {
            this.didType = didType;
        }

        public String didType() {
            return this.didType;
        }

    }

    public enum RequestRoles {
        CONSUMER("CONSUMER"), DEALER("DEALER");

        private final String role;

        RequestRoles(String role) {
            this.role = role;
        }

        public String role() {
            return this.role;
        }
    }

    public enum RequestRoleSource {
        CVFMA("CVFMA"), CVBOP("CVBOP"), VSDN("VSDN"), CVDA("CVDA");

        private final String roleSource;

        RequestRoleSource(String roleSource) {
            this.roleSource = roleSource;
        }

        public String roleSource() {
            return this.roleSource;
        }
    }

    public enum DIDInfoTypes {
        ALL("ALL"), M2("M2"), M3("M3");

        private final String didType;

        DIDInfoTypes(String didType) {
            this.didType = didType;
        }

        public String didType() {
            return this.didType;
        }
    }

    static {

        for (ErrorCodes error : ErrorCodes.values()) {
            errorCodeMap.put(error.code(), error.description());
        }

        for (ValErrorCodes valError : ValErrorCodes.values()) {
            valErrorCodeMap.put(valError.code(), valError.description());
        }

        for (RequestRoles requestRole : RequestRoles.values()) {
            validRequestRoleList.add(requestRole.role());
        }

        for (RequestRoleSource requestRoleSource : RequestRoleSource.values()) {
            validRequestRoleSourceList.add(requestRoleSource.roleSource());
        }

        for (DIDInfoTypes didInfoType : DIDInfoTypes.values()) {
            validDIDInfoTypes.add(didInfoType.didType());
        }
    }

    public static List<String> getValidRequestRoleList() {
        return validRequestRoleList;
    }

    public static List<String> getValidRequestRoleSourceList() {
        return validRequestRoleSourceList;
    }

    public static List<String> getValidDIDInfoTypes() {
        return validDIDInfoTypes;
    }

    public static String getMessageByCode(String errorCdoe) {
        return errorCodeMap.get(errorCdoe);
    }

    public static String getValMessageByCode(String code) {
        return valErrorCodeMap.get(code);
    }

}
