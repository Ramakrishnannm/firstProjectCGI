
package com.ford.cvddm.outbound.gvms.moduleState;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SimpleDIDInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SimpleDIDInfoType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DidValue" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="DidResponse" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SimpleDIDInfoType", propOrder = {
    "didValue",
    "didResponse"
})
public class SimpleDIDInfoType
    implements Serializable
{

    @XmlElement(name = "DidValue", required = true)
    protected String didValue;
    @XmlElement(name = "DidResponse", required = true)
    protected String didResponse;

    /**
     * Gets the value of the didValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDidValue() {
        return didValue;
    }

    /**
     * Sets the value of the didValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDidValue(String value) {
        this.didValue = value;
    }

    /**
     * Gets the value of the didResponse property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDidResponse() {
        return didResponse;
    }

    /**
     * Sets the value of the didResponse property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDidResponse(String value) {
        this.didResponse = value;
    }

}
