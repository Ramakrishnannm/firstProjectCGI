
package com.ford.cvddm.outbound.gvms.moduleState;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * 				Encapsulates instructions for post-install steps for a software part
 * 			
 * 
 * <p>Java class for PostInstallSoftwareType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PostInstallSoftwareType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Software" type="{urn:ford/Vehicle/Module/Information/v4.0}SoftwareMetaDataType" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="stepType" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="stepOrder" type="{http://www.w3.org/2001/XMLSchema}int" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PostInstallSoftwareType", propOrder = {
    "software"
})
public class PostInstallSoftwareType
    implements Serializable
{

    @XmlElement(name = "Software")
    protected SoftwareMetaDataType software;
    @XmlAttribute(name = "stepType")
    protected String stepType;
    @XmlAttribute(name = "stepOrder")
    protected Integer stepOrder;

    /**
     * Gets the value of the software property.
     * 
     * @return
     *     possible object is
     *     {@link SoftwareMetaDataType }
     *     
     */
    public SoftwareMetaDataType getSoftware() {
        return software;
    }

    /**
     * Sets the value of the software property.
     * 
     * @param value
     *     allowed object is
     *     {@link SoftwareMetaDataType }
     *     
     */
    public void setSoftware(SoftwareMetaDataType value) {
        this.software = value;
    }

    /**
     * Gets the value of the stepType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStepType() {
        return stepType;
    }

    /**
     * Sets the value of the stepType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStepType(String value) {
        this.stepType = value;
    }

    /**
     * Gets the value of the stepOrder property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getStepOrder() {
        return stepOrder;
    }

    /**
     * Sets the value of the stepOrder property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setStepOrder(Integer value) {
        this.stepOrder = value;
    }

}
