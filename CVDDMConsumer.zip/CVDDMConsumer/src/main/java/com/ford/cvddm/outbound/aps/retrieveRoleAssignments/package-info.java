@javax.xml.bind.annotation.XmlSchema(namespace = "urn:ford/interface/Application/RetrieveRoleAssignments/v1")
package com.ford.cvddm.outbound.aps.retrieveRoleAssignments;
