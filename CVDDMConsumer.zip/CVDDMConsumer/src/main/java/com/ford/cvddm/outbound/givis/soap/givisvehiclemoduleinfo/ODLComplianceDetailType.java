
package com.ford.cvddm.outbound.givis.soap.givisvehiclemoduleinfo;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ODLComplianceDetailType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ODLComplianceDetailType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ComplianceDID" type="{urn:ford/Vehicle/Module/Information/v4.0}DIDComplianceDetailType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ODLComplianceDetailType", propOrder = {
    "complianceDID"
})
public class ODLComplianceDetailType {

    @XmlElement(name = "ComplianceDID")
    protected List<DIDComplianceDetailType> complianceDID;

    /**
     * Gets the value of the complianceDID property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the complianceDID property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getComplianceDID().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DIDComplianceDetailType }
     * 
     * 
     */
    public List<DIDComplianceDetailType> getComplianceDID() {
        if (complianceDID == null) {
            complianceDID = new ArrayList<DIDComplianceDetailType>();
        }
        return this.complianceDID;
    }

}
