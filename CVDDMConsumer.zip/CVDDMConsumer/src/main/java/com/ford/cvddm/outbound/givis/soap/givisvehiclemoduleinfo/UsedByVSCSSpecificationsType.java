
package com.ford.cvddm.outbound.givis.soap.givisvehiclemoduleinfo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * 				Lists the VSCS Specifications that uses the
 * 				Assembly.
 * 			
 * 
 * <p>Java class for UsedByVSCSSpecificationsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UsedByVSCSSpecificationsType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SoftwareURL" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="VSCSID" type="{urn:ford/Vehicle/Module/Information/v4.0}VSCSIDType" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UsedByVSCSSpecificationsType", propOrder = {
    "softwareURL"
})
public class UsedByVSCSSpecificationsType {

    @XmlElement(name = "SoftwareURL")
    protected String softwareURL;
    @XmlAttribute(name = "VSCSID")
    protected String vscsid;

    /**
     * Gets the value of the softwareURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSoftwareURL() {
        return softwareURL;
    }

    /**
     * Sets the value of the softwareURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSoftwareURL(String value) {
        this.softwareURL = value;
    }

    /**
     * Gets the value of the vscsid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVSCSID() {
        return vscsid;
    }

    /**
     * Sets the value of the vscsid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVSCSID(String value) {
        this.vscsid = value;
    }

}
