package com.ford.cvddm.outbound.layer;

import com.ford.it.wscore.consumer.as.WscBaseGenericConsumerAS;

/**
 * Base class for consumers.
 * 
 * @since v. 3.1
 */
public class CVDDMConsumerAS extends WscBaseGenericConsumerAS {

    /**
     * Comment for <code>serialVersionUID</code>
     */
    private static final long serialVersionUID = 1L;

    /**
     * Constructor
     * 
     * @param serviceConfigurationKey the configuration key.
     */
    public CVDDMConsumerAS(final String serviceConfigurationKey) {
        super(serviceConfigurationKey);

    }

}
