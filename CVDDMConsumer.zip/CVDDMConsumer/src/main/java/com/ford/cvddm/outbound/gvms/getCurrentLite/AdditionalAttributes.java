package com.ford.cvddm.outbound.gvms.getCurrentLite;


import java.util.List;



public class AdditionalAttributes {


    private List<Resposne> resposne = null;

    public List<Resposne> getResposne() {
        return resposne;
    }

    public void setResposne(List<Resposne> resposne) {
        this.resposne = resposne;
    }
}

