@javax.xml.bind.annotation.XmlSchema(namespace = "urn:ford/Vehicle/Module/Information/v4.0", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.ford.cvddm.outbound.givis.soap.givisvehiclemoduleinfo;
