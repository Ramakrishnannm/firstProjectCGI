/**
 * 
 */
package com.ford.cvddm.outbound.aps.entitlementGroup;
import com.ford.it.ws.handlers.authorization.OAuth2Configuration;
import com.ford.it.ws.handlers.authorization.OAuth2BearerTokenHandler;

/**
 * @author NGUPTA18
 *
 */
@OAuth2Configuration(configName = "apsEntitlementGroupEdu")
public class OAuth2EntitlementGroupBearerTokenHandler extends OAuth2BearerTokenHandler {

}
