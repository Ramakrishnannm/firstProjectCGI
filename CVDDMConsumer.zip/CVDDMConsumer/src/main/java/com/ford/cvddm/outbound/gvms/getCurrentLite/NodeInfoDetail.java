package com.ford.cvddm.outbound.gvms.getCurrentLite;


public class NodeInfoDetail {

    String node;


    public String getNode() {
        return node;
    }

    public void setNode(String node) {
        this.node = node;
    }


}
