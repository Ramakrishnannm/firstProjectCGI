package com.ford.cvddm.outbound.gvms.getCurrentLite;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder({
        "vin",
        "pgmCode",
        "serviceModelYear",
        "saveModelYear",
        "manufacturingModelYear",
        "reservedElement"
})
public class VehicleDetails {

    private String pgmCode;
    private String reservedElement;
    private String serviceModelYear;
    private String saveModelYear;
    private String manufacturingModelYear;
    private String vin;
    private String vehicleBuiltDate;

    public String getPgmCode() {
        return pgmCode;
    }

    public void setPgmCode(String pgmCode) {
        this.pgmCode = pgmCode;
    }

    public String getReservedElement() {
        return reservedElement;
    }

    public void setReservedElement(String reservedElement) {
        this.reservedElement = reservedElement;
    }

    public String getServiceModelYear() {
        return serviceModelYear;
    }

    public void setServiceModelYear(String serviceModelYear) {
        this.serviceModelYear = serviceModelYear;
    }

    public String getSaveModelYear() {
        return saveModelYear;
    }

    public void setSaveModelYear(String saveModelYear) {
        this.saveModelYear = saveModelYear;
    }

    public String getManufacturingModelYear() {
        return manufacturingModelYear;
    }

    public void setManufacturingModelYear(String manufacturingModelYear) {
        this.manufacturingModelYear = manufacturingModelYear;
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public String getVehicleBuiltDate() {
        return vehicleBuiltDate;
    }

    public void setVehicleBuiltDate(String vehicleBuiltDate) {
        this.vehicleBuiltDate = vehicleBuiltDate;
    }
}
