
package com.ford.cvddm.outbound.gvms.vehicleModuleInfo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ODLECUType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ODLECUType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Gateway" type="{urn:ford/Vehicle/Module/Information/v4.0}GatewayInfoType"/>
 *         &lt;element name="OptimizedDID" type="{urn:ford/Vehicle/Module/Information/v4.0}OptimizedDIDType" maxOccurs="unbounded"/>
 *         &lt;element name="IgnoreDIDs" type="{urn:ford/Vehicle/Module/Information/v4.0}IgnoreThisDIDType" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="Acronym" use="required" type="{urn:ford/Vehicle/Module/Information/v4.0}ODLECUAcronymType" />
 *       &lt;attribute name="DiagnosticSpecificationResponse" type="{urn:ford/Vehicle/Module/Information/v4.0}SpecificationResponseType" />
 *       &lt;attribute name="HasConditionBasedOnDTC" use="required" type="{urn:ford/Vehicle/Module/Information/v4.0}HasConditionBasedOnDTCType" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ODLECUType", propOrder = {
    "gateway",
    "optimizedDID",
    "ignoreDIDs"
})
public class ODLECUType
    implements Serializable
{

    @XmlElement(name = "Gateway", required = true)
    protected GatewayInfoType gateway;
    @XmlElement(name = "OptimizedDID", required = true)
    protected List<OptimizedDIDType> optimizedDID;
    @XmlElement(name = "IgnoreDIDs")
    protected IgnoreThisDIDType ignoreDIDs;
    @XmlAttribute(name = "Acronym", required = true)
    protected String acronym;
    @XmlAttribute(name = "DiagnosticSpecificationResponse")
    protected String diagnosticSpecificationResponse;
    @XmlAttribute(name = "HasConditionBasedOnDTC", required = true)
    protected String hasConditionBasedOnDTC;

    /**
     * Gets the value of the gateway property.
     * 
     * @return
     *     possible object is
     *     {@link GatewayInfoType }
     *     
     */
    public GatewayInfoType getGateway() {
        return gateway;
    }

    /**
     * Sets the value of the gateway property.
     * 
     * @param value
     *     allowed object is
     *     {@link GatewayInfoType }
     *     
     */
    public void setGateway(GatewayInfoType value) {
        this.gateway = value;
    }

    /**
     * Gets the value of the optimizedDID property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the optimizedDID property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOptimizedDID().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link OptimizedDIDType }
     * 
     * 
     */
    public List<OptimizedDIDType> getOptimizedDID() {
        if (optimizedDID == null) {
            optimizedDID = new ArrayList<OptimizedDIDType>();
        }
        return this.optimizedDID;
    }

    /**
     * Gets the value of the ignoreDIDs property.
     * 
     * @return
     *     possible object is
     *     {@link IgnoreThisDIDType }
     *     
     */
    public IgnoreThisDIDType getIgnoreDIDs() {
        return ignoreDIDs;
    }

    /**
     * Sets the value of the ignoreDIDs property.
     * 
     * @param value
     *     allowed object is
     *     {@link IgnoreThisDIDType }
     *     
     */
    public void setIgnoreDIDs(IgnoreThisDIDType value) {
        this.ignoreDIDs = value;
    }

    /**
     * Gets the value of the acronym property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcronym() {
        return acronym;
    }

    /**
     * Sets the value of the acronym property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcronym(String value) {
        this.acronym = value;
    }

    /**
     * Gets the value of the diagnosticSpecificationResponse property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDiagnosticSpecificationResponse() {
        return diagnosticSpecificationResponse;
    }

    /**
     * Sets the value of the diagnosticSpecificationResponse property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDiagnosticSpecificationResponse(String value) {
        this.diagnosticSpecificationResponse = value;
    }

    /**
     * Gets the value of the hasConditionBasedOnDTC property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHasConditionBasedOnDTC() {
        return hasConditionBasedOnDTC;
    }

    /**
     * Sets the value of the hasConditionBasedOnDTC property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHasConditionBasedOnDTC(String value) {
        this.hasConditionBasedOnDTC = value;
    }

}
