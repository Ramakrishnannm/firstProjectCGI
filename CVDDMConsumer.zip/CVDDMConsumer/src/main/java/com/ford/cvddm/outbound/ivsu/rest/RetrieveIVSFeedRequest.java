package com.ford.cvddm.outbound.ivsu.rest;

public class RetrieveIVSFeedRequest {

	private RetrieveIVSFeed retrieveIVSFeed;

	public RetrieveIVSFeed getRetrieveIVSFeed() {
		return retrieveIVSFeed;
	}

	public void setRetrieveIVSFeed(RetrieveIVSFeed retrieveIVSFeed) {
		this.retrieveIVSFeed = retrieveIVSFeed;
	}
	
}
