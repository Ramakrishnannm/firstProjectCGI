
package com.ford.cvddm.outbound.aps.appResourcePolicyRole;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FunctionType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="FunctionType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="APPLICATION"/>
 *     &lt;enumeration value="BUSINESS_FUNCTION"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "FunctionType", namespace = "urn:ford/Application/ResourcePolicy/Role/v1.0")
@XmlEnum
public enum FunctionType {

    APPLICATION,
    BUSINESS_FUNCTION;

    public String value() {
        return name();
    }

    public static FunctionType fromValue(String v) {
        return valueOf(v);
    }

}
