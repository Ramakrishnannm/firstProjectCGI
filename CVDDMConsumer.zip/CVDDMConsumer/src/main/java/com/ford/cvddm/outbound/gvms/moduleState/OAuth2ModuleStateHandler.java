package com.ford.cvddm.outbound.gvms.moduleState;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.enterprise.context.ApplicationScoped;
import javax.xml.namespace.QName;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;

import com.ford.cvddm.common.layer.CVDDMRequestContext;
import com.ford.cvddm.common.util.OAuth2CvddmCredentialProvider;
import com.ford.cvddm.constant.CVDDMConstant;
import com.ford.it.logging.Level;
import com.ford.it.util.oauth2.OAuth2Constants;
import com.ford.it.ws.handlers.authorization.OAuth2HandlerException;

/**
* OAuth2ModuleStateHandler will get OAuth2 access token and set it in the
* Authorization HTTP header for ongoing JAX-WS Web service call for Module State Info Service.
* @author NGUPTA18
* User Story: US947738
*/
@ApplicationScoped
public class OAuth2ModuleStateHandler implements SOAPHandler<SOAPMessageContext> {
  /**
   * Logging Setup
   */
  private static final String CLASS_NAME =
		  OAuth2ModuleStateHandler.class.getName();

  /**
   * Logging Setup
   */
  private static final com.ford.it.logging.ILogger log =
      com.ford.it.logging.LogFactory.getInstance().getLogger(CLASS_NAME);

  /**
   * Construct a OAuth2BearerTokenHandler instance
   *
   */
  public OAuth2ModuleStateHandler() {
	  
	  log.exiting(CLASS_NAME, "OAuth2ModuleStateHandler");
  }

  /**
   * @see javax.xml.ws.handler.Handler#handleMessage(javax.xml.ws.handler.MessageContext)
   */
  @Override
  @SuppressWarnings("unchecked")
  public boolean handleMessage(final SOAPMessageContext context) {
      final String METHOD_NAME = "handleMessage";
      log.entering(CLASS_NAME, METHOD_NAME);

       String env = CVDDMRequestContext.getInstance().getEnvironment();
      
      final Boolean outboundProperty =
          (Boolean)context.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);

      if (outboundProperty.booleanValue()) {
          final String propertyGrp = getPropertyGrpName(env);

          log.logp(Level.FINER, CLASS_NAME, METHOD_NAME, "OAuth2Configration Name: [" + propertyGrp + "]");

          final OAuth2CvddmCredentialProvider provider = OAuth2CvddmCredentialProvider.getInstance();
          final String bearerToken = provider.getOauth2BearerToken(propertyGrp);

          if (null == bearerToken || bearerToken.length() < 20) {
              // No access token is found (Bearer null)

              final StringBuilder sb = new StringBuilder();
              sb.append(CLASS_NAME)
                  .append(" could not load the access token for the config of ")
                  .append(propertyGrp)
                  .append("\n");
              sb.append("Please check: \n");
              sb.append("1. The OAuth2CredentialsConfig property group must be loaded from oauth2-credentials-config.xml or dynaprop.\n");
              sb.append("2. If the property Group Name is not 'default', you need to create the customized  OAuth2ModuleStateHandler.\n");
              sb.append("3. All the required values are provided: app_id, app_secret, and oauth_token_url, plus resource for ADFS created token.\n");

              final String message = sb.toString();
              log.logp(Level.FINER, CLASS_NAME, METHOD_NAME, message);

              throw new OAuth2HandlerException(message);
          }

          final List<String> authorizationHeader = new ArrayList<String>();
          authorizationHeader.add(bearerToken);

          Map<String, List<String>> headers =
              (Map<String, List<String>>)context.get(MessageContext.HTTP_REQUEST_HEADERS);
          if (null == headers) {
              headers = new HashMap<String, List<String>>();
          }

          headers.put(OAuth2Constants.AUTHORIZATION, authorizationHeader);

          final String adfsCookieText = provider.getOauth2Cookie(propertyGrp);

          List<String> cookies;
          cookies = headers.get("Cookie");
          if (null == cookies) {
              cookies = new ArrayList<String>(1);
              cookies.add(adfsCookieText);
          } else {
              // Merge the Cookie
              final String prevCookie = cookies.get(0);
              cookies.set(0, prevCookie + ";" + adfsCookieText);
          }

          headers.put("Cookie", cookies);

          context.put(MessageContext.HTTP_REQUEST_HEADERS, headers);
      }

      log.exiting(CLASS_NAME, METHOD_NAME);
      return true;
  }


  private String getPropertyGrpName(String env) {
	  
	  String propertyGrp = "";
	  
	  if(CVDDMConstant.ENV_QA1.equalsIgnoreCase(env)) {
		  
		  propertyGrp = CVDDMConstant.GVMS_PRODUCT_OAUTH_CONFIG_QA1;
		  
	  }
	  else {
		  
		  propertyGrp = CVDDMConstant.GVMS_PRODUCT_OAUTH_CONFIG_QA2;
	  }
      return propertyGrp;
  }
  /**
   * @see javax.xml.ws.handler.Handler#handleFault(javax.xml.ws.handler.MessageContext)
   */
  @Override
  public boolean handleFault(final SOAPMessageContext context) {
      final String METHOD_NAME = "handleFault";
      log.entering(CLASS_NAME, METHOD_NAME);
      log.exiting(CLASS_NAME, METHOD_NAME);
      return false;
  }

  /**
   * @see javax.xml.ws.handler.Handler#close(javax.xml.ws.handler.MessageContext)
   */
  @Override
  public void close(final MessageContext context) {
      final String METHOD_NAME = "close";
      log.entering(CLASS_NAME, METHOD_NAME);

      log.exiting(CLASS_NAME, METHOD_NAME);
  }

	@Override
	public Set<QName> getHeaders() {
		return null;
	}

}
