
package com.ford.cvddm.outbound.givis.soap.givismodulestate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AdditionalConditionsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AdditionalConditionsType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Conjunction">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="AND"/>
 *               &lt;enumeration value="OR"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;choice>
 *           &lt;element name="ConditionSegment" type="{urn:ford/Vehicle/Module/Information/v4.0}ConditionSegmentType" minOccurs="0"/>
 *           &lt;element name="PrecedenceGroup" type="{urn:ford/Vehicle/Module/Information/v4.0}PrecedenceElementType" minOccurs="0"/>
 *         &lt;/choice>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AdditionalConditionsType", propOrder = {
    "conjunction",
    "conditionSegment",
    "precedenceGroup"
})
public class AdditionalConditionsType {

    @XmlElement(name = "Conjunction", required = true)
    protected String conjunction;
    @XmlElement(name = "ConditionSegment")
    protected ConditionSegmentType conditionSegment;
    @XmlElement(name = "PrecedenceGroup")
    protected PrecedenceElementType precedenceGroup;

    /**
     * Gets the value of the conjunction property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConjunction() {
        return conjunction;
    }

    /**
     * Sets the value of the conjunction property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConjunction(String value) {
        this.conjunction = value;
    }

    /**
     * Gets the value of the conditionSegment property.
     * 
     * @return
     *     possible object is
     *     {@link ConditionSegmentType }
     *     
     */
    public ConditionSegmentType getConditionSegment() {
        return conditionSegment;
    }

    /**
     * Sets the value of the conditionSegment property.
     * 
     * @param value
     *     allowed object is
     *     {@link ConditionSegmentType }
     *     
     */
    public void setConditionSegment(ConditionSegmentType value) {
        this.conditionSegment = value;
    }

    /**
     * Gets the value of the precedenceGroup property.
     * 
     * @return
     *     possible object is
     *     {@link PrecedenceElementType }
     *     
     */
    public PrecedenceElementType getPrecedenceGroup() {
        return precedenceGroup;
    }

    /**
     * Sets the value of the precedenceGroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link PrecedenceElementType }
     *     
     */
    public void setPrecedenceGroup(PrecedenceElementType value) {
        this.precedenceGroup = value;
    }

}
