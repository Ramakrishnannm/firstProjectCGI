
package com.ford.cvddm.outbound.givis.soap.givismodulestate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FeatureCodeType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FeatureCodeType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Add" type="{urn:ford/Vehicle/Module/Information/v4.0}AddFeatureType" minOccurs="0"/>
 *         &lt;element name="Remove" type="{urn:ford/Vehicle/Module/Information/v4.0}RemoveFeatureType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FeatureCodeType", propOrder = {
    "add",
    "remove"
})
public class FeatureCodeType {

    @XmlElement(name = "Add")
    protected AddFeatureType add;
    @XmlElement(name = "Remove")
    protected RemoveFeatureType remove;

    /**
     * Gets the value of the add property.
     * 
     * @return
     *     possible object is
     *     {@link AddFeatureType }
     *     
     */
    public AddFeatureType getAdd() {
        return add;
    }

    /**
     * Sets the value of the add property.
     * 
     * @param value
     *     allowed object is
     *     {@link AddFeatureType }
     *     
     */
    public void setAdd(AddFeatureType value) {
        this.add = value;
    }

    /**
     * Gets the value of the remove property.
     * 
     * @return
     *     possible object is
     *     {@link RemoveFeatureType }
     *     
     */
    public RemoveFeatureType getRemove() {
        return remove;
    }

    /**
     * Sets the value of the remove property.
     * 
     * @param value
     *     allowed object is
     *     {@link RemoveFeatureType }
     *     
     */
    public void setRemove(RemoveFeatureType value) {
        this.remove = value;
    }

}
