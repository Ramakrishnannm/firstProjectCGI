
package com.ford.cvddm.outbound.givis.soap.givisvehiclemoduleinfo;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ModuleType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ModuleType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="APIM"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ModuleType", namespace = "urn:ford/productdesign/vis/common/v1.0")
@XmlEnum
public enum ModuleType {

    APIM;

    public String value() {
        return name();
    }

    public static ModuleType fromValue(String v) {
        return valueOf(v);
    }

}
