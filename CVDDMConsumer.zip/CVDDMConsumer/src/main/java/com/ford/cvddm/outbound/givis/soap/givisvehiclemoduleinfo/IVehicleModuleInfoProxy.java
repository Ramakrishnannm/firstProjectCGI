package com.ford.cvddm.outbound.givis.soap.givisvehiclemoduleinfo;

import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.transform.Source;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Dispatch;
import javax.xml.ws.Service;
import javax.xml.ws.soap.SOAPBinding;
import java.util.concurrent.Future;
import javax.xml.ws.AsyncHandler;
import javax.xml.ws.Response;

public class IVehicleModuleInfoProxy{

    protected Descriptor _descriptor;

    public class Descriptor {
        private com.ford.cvddm.outbound.givis.soap.givisvehiclemoduleinfo.VehicleModuleInfoService _service = null;
        private com.ford.cvddm.outbound.givis.soap.givisvehiclemoduleinfo.IVehicleModuleInfo _proxy = null;
        private Dispatch<Source> _dispatch = null;

        public Descriptor() {
            init();
        }

        public Descriptor(URL wsdlLocation, QName serviceName) {
            _service = new com.ford.cvddm.outbound.givis.soap.givisvehiclemoduleinfo.VehicleModuleInfoService(wsdlLocation, serviceName);
            initCommon();
        }

        public void init() {
            _service = null;
            _proxy = null;
            _dispatch = null;
            _service = new com.ford.cvddm.outbound.givis.soap.givisvehiclemoduleinfo.VehicleModuleInfoService();
            initCommon();
        }

        private void initCommon() {
            _proxy = _service.getIVehicleModuleInfo();
        }

        public com.ford.cvddm.outbound.givis.soap.givisvehiclemoduleinfo.IVehicleModuleInfo getProxy() {
            return _proxy;
        }

        public Dispatch<Source> getDispatch() {
            if (_dispatch == null ) {
                QName portQName = new QName("", "IVehicleModuleInfo");
                _dispatch = _service.createDispatch(portQName, Source.class, Service.Mode.MESSAGE);

                String proxyEndpointUrl = getEndpoint();
                BindingProvider bp = (BindingProvider) _dispatch;
                String dispatchEndpointUrl = (String) bp.getRequestContext().get(BindingProvider.ENDPOINT_ADDRESS_PROPERTY);
                if (!dispatchEndpointUrl.equals(proxyEndpointUrl))
                    bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, proxyEndpointUrl);
            }
            return _dispatch;
        }

        public String getEndpoint() {
            BindingProvider bp = (BindingProvider) _proxy;
            return (String) bp.getRequestContext().get(BindingProvider.ENDPOINT_ADDRESS_PROPERTY);
        }

        public void setEndpoint(String endpointUrl) {
            BindingProvider bp = (BindingProvider) _proxy;
            bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointUrl);

            if (_dispatch != null ) {
                bp = (BindingProvider) _dispatch;
                bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointUrl);
            }
        }

        public void setMTOMEnabled(boolean enable) {
            SOAPBinding binding = (SOAPBinding) ((BindingProvider) _proxy).getBinding();
            binding.setMTOMEnabled(enable);
        }
    }

    public IVehicleModuleInfoProxy() {
        _descriptor = new Descriptor();
        _descriptor.setMTOMEnabled(false);
    }

    public IVehicleModuleInfoProxy(URL wsdlLocation, QName serviceName) {
        _descriptor = new Descriptor(wsdlLocation, serviceName);
        _descriptor.setMTOMEnabled(false);
    }

    public Descriptor _getDescriptor() {
        return _descriptor;
    }

    public Response<VehicleModuleResponseType> getModulesAsync(VehicleModuleRequestType msgInputPart) {
        return _getDescriptor().getProxy().getModulesAsync(msgInputPart);
    }

    public Future<?> getModulesAsync(VehicleModuleRequestType msgInputPart, AsyncHandler<VehicleModuleResponseType> asyncHandler) {
        return _getDescriptor().getProxy().getModulesAsync(msgInputPart,asyncHandler);
    }

    public VehicleModuleResponseType getModules(VehicleModuleRequestType msgInputPart) {
        return _getDescriptor().getProxy().getModules(msgInputPart);
    }

    public Response<VehicleModuleResponseType> getRestoreModulesAsync(VehicleModuleRequestType restoreInputPart) {
        return _getDescriptor().getProxy().getRestoreModulesAsync(restoreInputPart);
    }

    public Future<?> getRestoreModulesAsync(VehicleModuleRequestType restoreInputPart, AsyncHandler<VehicleModuleResponseType> asyncHandler) {
        return _getDescriptor().getProxy().getRestoreModulesAsync(restoreInputPart,asyncHandler);
    }

    public VehicleModuleResponseType getRestoreModules(VehicleModuleRequestType restoreInputPart) {
        return _getDescriptor().getProxy().getRestoreModules(restoreInputPart);
    }

    public Response<ModulesExistType> doModulesExistAsync(ModulesExistType modulesExistRequest) {
        return _getDescriptor().getProxy().doModulesExistAsync(modulesExistRequest);
    }

    public Future<?> doModulesExistAsync(ModulesExistType modulesExistRequest, AsyncHandler<ModulesExistType> asyncHandler) {
        return _getDescriptor().getProxy().doModulesExistAsync(modulesExistRequest,asyncHandler);
    }

    public ModulesExistType doModulesExist(ModulesExistType modulesExistRequest) {
        return _getDescriptor().getProxy().doModulesExist(modulesExistRequest);
    }

    public Response<PerformModuleAuthenticationType> performModuleAuthenticationAsync(PerformModuleAuthenticationType parameters) {
        return _getDescriptor().getProxy().performModuleAuthenticationAsync(parameters);
    }

    public Future<?> performModuleAuthenticationAsync(PerformModuleAuthenticationType parameters, AsyncHandler<PerformModuleAuthenticationType> asyncHandler) {
        return _getDescriptor().getProxy().performModuleAuthenticationAsync(parameters,asyncHandler);
    }

    public PerformModuleAuthenticationType performModuleAuthentication(PerformModuleAuthenticationType parameters) {
        return _getDescriptor().getProxy().performModuleAuthentication(parameters);
    }

    public Response<LicensedPartResponseType> getLicensedPartAsync(LicensedPartRequestType parameters) {
        return _getDescriptor().getProxy().getLicensedPartAsync(parameters);
    }

    public Future<?> getLicensedPartAsync(LicensedPartRequestType parameters, AsyncHandler<LicensedPartResponseType> asyncHandler) {
        return _getDescriptor().getProxy().getLicensedPartAsync(parameters,asyncHandler);
    }

    public LicensedPartResponseType getLicensedPart(LicensedPartRequestType parameters) {
        return _getDescriptor().getProxy().getLicensedPart(parameters);
    }

    public Response<LicensedPartHistoryResponseType> getLicensedPartHistoryAsync(LicensedPartHistoryRequestType parameters) {
        return _getDescriptor().getProxy().getLicensedPartHistoryAsync(parameters);
    }

    public Future<?> getLicensedPartHistoryAsync(LicensedPartHistoryRequestType parameters, AsyncHandler<LicensedPartHistoryResponseType> asyncHandler) {
        return _getDescriptor().getProxy().getLicensedPartHistoryAsync(parameters,asyncHandler);
    }

    public LicensedPartHistoryResponseType getLicensedPartHistory(LicensedPartHistoryRequestType parameters) {
        return _getDescriptor().getProxy().getLicensedPartHistory(parameters);
    }

}