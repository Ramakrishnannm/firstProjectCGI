
package com.ford.cvddm.outbound.gvms.getCurrentLite;


public class GetCurrentLiteRequest {

    private GetCurrentLite getCurrentLite;

    public GetCurrentLite getGetCurrentLite() {
        return getCurrentLite;
    }

    public void setGetCurrentLite(GetCurrentLite getCurrentLite) {
        this.getCurrentLite = getCurrentLite;
    }

}
