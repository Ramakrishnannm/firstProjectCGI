package com.ford.cvddm.outbound.gvms.getCurrentLite;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;
/**
 * Created by vm4 on 10/04/2018.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProcessGetCurrentLiteResponse {

    private GetCurrentLiteRequest getCurrentLiteRequest;

    private List<NodeDetail> nodeDetails;

    public GetCurrentLiteRequest getGetCurrentLiteRequest() {
        return getCurrentLiteRequest;
    }

    public void setGetCurrentLiteRequest(GetCurrentLiteRequest getCurrentLiteRequest) {
        this.getCurrentLiteRequest = getCurrentLiteRequest;
    }

    public List<NodeDetail> getNodeDetails() {
        return nodeDetails;
    }

    public void setNodeDetails(List<NodeDetail> nodeDetails) {
        this.nodeDetails = nodeDetails;
    }
}
