package com.ford.cvddm.outbound.givis.soap.givisvehiclemoduleinfo;

import java.util.List;

import com.ford.cvddm.constant.CVDDMConstant;

public class NodeList {

	private String address;
	private String ecuAcronym;
	private List<DIDInfoType> didInfo;
	private WarningType warning;
	private String isECUPresent;
	private String lastUpdatedTime;

	private String disGIVISWarningpAvl = CVDDMConstant.STRING_N;

	public String getDisGIVISWarningpAvl() {
		return disGIVISWarningpAvl;
	}

	public void setDisGIVISWarningpAvl(String disGIVISWarningpAvl) {
		this.disGIVISWarningpAvl = disGIVISWarningpAvl;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEcuAcronym() {
		return ecuAcronym;
	}

	public void setEcuAcronym(String ecuAcronym) {
		this.ecuAcronym = ecuAcronym;
	}

	public List<DIDInfoType> getDidInfo() {
		return didInfo;
	}

	public void setDidInfo(List<DIDInfoType> didInfo) {
		this.didInfo = didInfo;
	}

	public WarningType getWarning() {
		return warning;
	}

	public void setWarning(WarningType warning) {
		this.warning = warning;
	}

	public String getIsECUPresent() {
		return isECUPresent;
	}

	public void setIsECUPresent(String isECUPresent) {
		this.isECUPresent = isECUPresent;
	}

	public String getLastUpdatedTime() {
		return lastUpdatedTime;
	}

	public void setLastUpdatedTime(String lastUpdatedTime) {
		this.lastUpdatedTime = lastUpdatedTime;
	}

}
