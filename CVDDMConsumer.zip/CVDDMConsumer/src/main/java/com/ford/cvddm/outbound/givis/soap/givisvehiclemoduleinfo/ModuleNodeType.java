
package com.ford.cvddm.outbound.givis.soap.givisvehiclemoduleinfo;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ModuleNodeType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ModuleNodeType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Address" type="{urn:ford/Vehicle/Module/Information/v4.0}NodeAddressType"/>
 *         &lt;element name="ECUAcronym" type="{urn:ford/Vehicle/Module/Information/v4.0}ECUAcronymType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="ESNMetadata" type="{urn:ford/Vehicle/Module/Information/v4.0}ESNMetadataType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="ODLNetwork" type="{urn:ford/Vehicle/Module/Information/v4.0}ModuleODLNetworkType"/>
 *         &lt;element name="DTC" type="{urn:ford/Vehicle/Module/Information/v4.0}DTCDetails" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="AdditionalAttributes" type="{urn:ford/Vehicle/Module/Information/v4.0}AdditionalNodePropertiesType" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="specificationCategory" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="isFlashed" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ModuleNodeType", propOrder = {
    "address",
    "ecuAcronym",
    "esnMetadata",
    "odlNetwork",
    "dtc",
    "additionalAttributes"
})
public class ModuleNodeType {

    @XmlElement(name = "Address", required = true)
    protected String address;
    @XmlElement(name = "ECUAcronym")
    protected List<ECUAcronymType> ecuAcronym;
    @XmlElement(name = "ESNMetadata")
    protected List<ESNMetadataType> esnMetadata;
    @XmlElement(name = "ODLNetwork", required = true)
    protected ModuleODLNetworkType odlNetwork;
    @XmlElement(name = "DTC")
    protected List<DTCDetails> dtc;
    @XmlElement(name = "AdditionalAttributes")
    protected AdditionalNodePropertiesType additionalAttributes;
    @XmlAttribute(name = "specificationCategory")
    protected String specificationCategory;
    @XmlAttribute(name = "isFlashed")
    protected Boolean isFlashed;

    /**
     * Gets the value of the address property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress() {
        return address;
    }

    /**
     * Sets the value of the address property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress(String value) {
        this.address = value;
    }

    /**
     * Gets the value of the ecuAcronym property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the ecuAcronym property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getECUAcronym().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ECUAcronymType }
     * 
     * 
     */
    public List<ECUAcronymType> getECUAcronym() {
        if (ecuAcronym == null) {
            ecuAcronym = new ArrayList<ECUAcronymType>();
        }
        return this.ecuAcronym;
    }

    /**
     * Gets the value of the esnMetadata property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the esnMetadata property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getESNMetadata().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ESNMetadataType }
     * 
     * 
     */
    public List<ESNMetadataType> getESNMetadata() {
        if (esnMetadata == null) {
            esnMetadata = new ArrayList<ESNMetadataType>();
        }
        return this.esnMetadata;
    }

    /**
     * Gets the value of the odlNetwork property.
     * 
     * @return
     *     possible object is
     *     {@link ModuleODLNetworkType }
     *     
     */
    public ModuleODLNetworkType getODLNetwork() {
        return odlNetwork;
    }

    /**
     * Sets the value of the odlNetwork property.
     * 
     * @param value
     *     allowed object is
     *     {@link ModuleODLNetworkType }
     *     
     */
    public void setODLNetwork(ModuleODLNetworkType value) {
        this.odlNetwork = value;
    }

    /**
     * Gets the value of the dtc property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the dtc property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDTC().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DTCDetails }
     * 
     * 
     */
    public List<DTCDetails> getDTC() {
        if (dtc == null) {
            dtc = new ArrayList<DTCDetails>();
        }
        return this.dtc;
    }

    /**
     * Gets the value of the additionalAttributes property.
     * 
     * @return
     *     possible object is
     *     {@link AdditionalNodePropertiesType }
     *     
     */
    public AdditionalNodePropertiesType getAdditionalAttributes() {
        return additionalAttributes;
    }

    /**
     * Sets the value of the additionalAttributes property.
     * 
     * @param value
     *     allowed object is
     *     {@link AdditionalNodePropertiesType }
     *     
     */
    public void setAdditionalAttributes(AdditionalNodePropertiesType value) {
        this.additionalAttributes = value;
    }

    /**
     * Gets the value of the specificationCategory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSpecificationCategory() {
        return specificationCategory;
    }

    /**
     * Sets the value of the specificationCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSpecificationCategory(String value) {
        this.specificationCategory = value;
    }

    /**
     * Gets the value of the isFlashed property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsFlashed() {
        return isFlashed;
    }

    /**
     * Sets the value of the isFlashed property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsFlashed(Boolean value) {
        this.isFlashed = value;
    }

}
