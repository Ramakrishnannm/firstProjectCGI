
package com.ford.cvddm.outbound.givis.soap.eolxfiletransfer;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PlantDetail" type="{urn:ford/pd/eol/v1.0}PlantDetailType"/>
 *         &lt;element name="Datetime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="BatchDetail" type="{urn:ford/pd/eol/v1.0}BatchDetailType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "plantDetail",
    "datetime",
    "batchDetail"
})
@XmlRootElement(name = "InitiateTransferRequest", namespace = "urn:ford/pd/interface/eol/v1.0")
public class InitiateTransferRequest {

    @XmlElement(name = "PlantDetail", namespace = "", required = true)
    protected PlantDetailType plantDetail;
    @XmlElement(name = "Datetime", namespace = "", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar datetime;
    @XmlElement(name = "BatchDetail", namespace = "", required = true)
    protected BatchDetailType batchDetail;

    /**
     * Gets the value of the plantDetail property.
     * 
     * @return
     *     possible object is
     *     {@link PlantDetailType }
     *     
     */
    public PlantDetailType getPlantDetail() {
        return plantDetail;
    }

    /**
     * Sets the value of the plantDetail property.
     * 
     * @param value
     *     allowed object is
     *     {@link PlantDetailType }
     *     
     */
    public void setPlantDetail(PlantDetailType value) {
        this.plantDetail = value;
    }

    /**
     * Gets the value of the datetime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDatetime() {
        return datetime;
    }

    /**
     * Sets the value of the datetime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDatetime(XMLGregorianCalendar value) {
        this.datetime = value;
    }

    /**
     * Gets the value of the batchDetail property.
     * 
     * @return
     *     possible object is
     *     {@link BatchDetailType }
     *     
     */
    public BatchDetailType getBatchDetail() {
        return batchDetail;
    }

    /**
     * Sets the value of the batchDetail property.
     * 
     * @param value
     *     allowed object is
     *     {@link BatchDetailType }
     *     
     */
    public void setBatchDetail(BatchDetailType value) {
        this.batchDetail = value;
    }

}
