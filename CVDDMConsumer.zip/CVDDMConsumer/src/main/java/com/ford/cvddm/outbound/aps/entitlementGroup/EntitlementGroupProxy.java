package com.ford.cvddm.outbound.aps.entitlementGroup;

import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.transform.Source;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Dispatch;
import javax.xml.ws.Service;
import javax.xml.ws.soap.SOAPBinding;
import java.util.concurrent.Future;
import javax.xml.ws.AsyncHandler;
import javax.xml.ws.Response;

public class EntitlementGroupProxy{

    protected Descriptor _descriptor;

    public class Descriptor {
        private com.ford.cvddm.outbound.aps.entitlementGroup.EntitlementGroupService _service = null;
        private com.ford.cvddm.outbound.aps.entitlementGroup.IEntitlementGroupService _proxy = null;
        private Dispatch<Source> _dispatch = null;

        public Descriptor() {
            init();
        }

        public Descriptor(URL wsdlLocation, QName serviceName) {
            _service = new com.ford.cvddm.outbound.aps.entitlementGroup.EntitlementGroupService(wsdlLocation, serviceName);
            initCommon();
        }

        public void init() {
            _service = null;
            _proxy = null;
            _dispatch = null;
            _service = new com.ford.cvddm.outbound.aps.entitlementGroup.EntitlementGroupService();
            initCommon();
        }

        private void initCommon() {
            _proxy = _service.getEntitlementGroup();
        }

        public com.ford.cvddm.outbound.aps.entitlementGroup.IEntitlementGroupService getProxy() {
            return _proxy;
        }

        public Dispatch<Source> getDispatch() {
            if (_dispatch == null ) {
                QName portQName = new QName("", "EntitlementGroup");
                _dispatch = _service.createDispatch(portQName, Source.class, Service.Mode.MESSAGE);

                String proxyEndpointUrl = getEndpoint();
                BindingProvider bp = (BindingProvider) _dispatch;
                String dispatchEndpointUrl = (String) bp.getRequestContext().get(BindingProvider.ENDPOINT_ADDRESS_PROPERTY);
                if (!dispatchEndpointUrl.equals(proxyEndpointUrl))
                    bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, proxyEndpointUrl);
            }
            return _dispatch;
        }

        public String getEndpoint() {
            BindingProvider bp = (BindingProvider) _proxy;
            return (String) bp.getRequestContext().get(BindingProvider.ENDPOINT_ADDRESS_PROPERTY);
        }

        public void setEndpoint(String endpointUrl) {
            BindingProvider bp = (BindingProvider) _proxy;
            bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointUrl);

            if (_dispatch != null ) {
                bp = (BindingProvider) _dispatch;
                bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointUrl);
            }
        }

        public void setMTOMEnabled(boolean enable) {
            SOAPBinding binding = (SOAPBinding) ((BindingProvider) _proxy).getBinding();
            binding.setMTOMEnabled(enable);
        }
    }

    public EntitlementGroupProxy() {
        _descriptor = new Descriptor();
        _descriptor.setMTOMEnabled(false);
    }

    public EntitlementGroupProxy(URL wsdlLocation, QName serviceName) {
        _descriptor = new Descriptor(wsdlLocation, serviceName);
        _descriptor.setMTOMEnabled(false);
    }

    public Descriptor _getDescriptor() {
        return _descriptor;
    }

    public Response<EntitlementsType> getEntitlementsForUserAsync(String subjectEnt) {
        return _getDescriptor().getProxy().getEntitlementsForUserAsync(subjectEnt);
    }

    public Future<?> getEntitlementsForUserAsync(String subjectEnt, AsyncHandler<EntitlementsType> asyncHandler) {
        return _getDescriptor().getProxy().getEntitlementsForUserAsync(subjectEnt,asyncHandler);
    }

    public EntitlementsType getEntitlementsForUser(String subjectEnt) throws CustomExceptionFault {
        return _getDescriptor().getProxy().getEntitlementsForUser(subjectEnt);
    }

    public Response<GroupsType> getGroupsForUserAsync(String subjectGrp) {
        return _getDescriptor().getProxy().getGroupsForUserAsync(subjectGrp);
    }

    public Future<?> getGroupsForUserAsync(String subjectGrp, AsyncHandler<GroupsType> asyncHandler) {
        return _getDescriptor().getProxy().getGroupsForUserAsync(subjectGrp,asyncHandler);
    }

    public GroupsType getGroupsForUser(String subjectGrp) throws CustomExceptionFault {
        return _getDescriptor().getProxy().getGroupsForUser(subjectGrp);
    }

    public Response<EntitlementUsersType> getUsersForEntitlementAsync(String entitlement) {
        return _getDescriptor().getProxy().getUsersForEntitlementAsync(entitlement);
    }

    public Future<?> getUsersForEntitlementAsync(String entitlement, AsyncHandler<EntitlementUsersType> asyncHandler) {
        return _getDescriptor().getProxy().getUsersForEntitlementAsync(entitlement,asyncHandler);
    }

    public EntitlementUsersType getUsersForEntitlement(String entitlement) throws CustomExceptionFault {
        return _getDescriptor().getProxy().getUsersForEntitlement(entitlement);
    }

    public Response<ApplicationUsersType> getUsersForApplicationAsync(String application) {
        return _getDescriptor().getProxy().getUsersForApplicationAsync(application);
    }

    public Future<?> getUsersForApplicationAsync(String application, AsyncHandler<ApplicationUsersType> asyncHandler) {
        return _getDescriptor().getProxy().getUsersForApplicationAsync(application,asyncHandler);
    }

    public ApplicationUsersType getUsersForApplication(String application) throws CustomExceptionFault {
        return _getDescriptor().getProxy().getUsersForApplication(application);
    }

    public Response<GroupUsersType> getGroupMembersAsync(String group) {
        return _getDescriptor().getProxy().getGroupMembersAsync(group);
    }

    public Future<?> getGroupMembersAsync(String group, AsyncHandler<GroupUsersType> asyncHandler) {
        return _getDescriptor().getProxy().getGroupMembersAsync(group,asyncHandler);
    }

    public GroupUsersType getGroupMembers(String group) throws CustomExceptionFault {
        return _getDescriptor().getProxy().getGroupMembers(group);
    }

}