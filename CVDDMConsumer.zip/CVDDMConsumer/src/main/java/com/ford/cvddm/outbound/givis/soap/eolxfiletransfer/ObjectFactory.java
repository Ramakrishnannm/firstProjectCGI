
package com.ford.cvddm.outbound.givis.soap.eolxfiletransfer;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.ford.cvddm.outbound.givis.soap.eolxfiletransfer package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _EOLPayload_QNAME = new QName("urn:ford/pd/eol/v1.0", "EOLPayload");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.ford.cvddm.outbound.givis.soap.eolxfiletransfer
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link EOLFileTransferRequest }
     * 
     */
    public EOLFileTransferRequest createEOLFileTransferRequest() {
        return new EOLFileTransferRequest();
    }

    /**
     * Create an instance of {@link EOLPayloadType }
     * 
     */
    public EOLPayloadType createEOLPayloadType() {
        return new EOLPayloadType();
    }

    /**
     * Create an instance of {@link InitiateTransferResponse }
     * 
     */
    public InitiateTransferResponse createInitiateTransferResponse() {
        return new InitiateTransferResponse();
    }

    /**
     * Create an instance of {@link InitiateTransferRequest }
     * 
     */
    public InitiateTransferRequest createInitiateTransferRequest() {
        return new InitiateTransferRequest();
    }

    /**
     * Create an instance of {@link PlantDetailType }
     * 
     */
    public PlantDetailType createPlantDetailType() {
        return new PlantDetailType();
    }

    /**
     * Create an instance of {@link BatchDetailType }
     * 
     */
    public BatchDetailType createBatchDetailType() {
        return new BatchDetailType();
    }

    /**
     * Create an instance of {@link EOLFileListType }
     * 
     */
    public EOLFileListType createEOLFileListType() {
        return new EOLFileListType();
    }

    /**
     * Create an instance of {@link EOLFileType }
     * 
     */
    public EOLFileType createEOLFileType() {
        return new EOLFileType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EOLPayloadType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:ford/pd/eol/v1.0", name = "EOLPayload")
    public JAXBElement<EOLPayloadType> createEOLPayload(EOLPayloadType value) {
        return new JAXBElement<EOLPayloadType>(_EOLPayload_QNAME, EOLPayloadType.class, null, value);
    }

}
