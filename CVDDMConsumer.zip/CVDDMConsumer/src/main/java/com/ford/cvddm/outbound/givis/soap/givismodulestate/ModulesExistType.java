
package com.ford.cvddm.outbound.givis.soap.givismodulestate;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ModulesExistType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ModulesExistType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="NodeExists" type="{urn:ford/Vehicle/Module/Information/v4.0}NodeExistsType" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *       &lt;attribute name="vin" type="{urn:ford/Vehicle/Module/Information/v4.0}VINType" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ModulesExistType", propOrder = {
    "nodeExists"
})
public class ModulesExistType {

    @XmlElement(name = "NodeExists", required = true)
    protected List<NodeExistsType> nodeExists;
    @XmlAttribute(name = "vin")
    protected String vin;

    /**
     * Gets the value of the nodeExists property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the nodeExists property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNodeExists().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link NodeExistsType }
     * 
     * 
     */
    public List<NodeExistsType> getNodeExists() {
        if (nodeExists == null) {
            nodeExists = new ArrayList<NodeExistsType>();
        }
        return this.nodeExists;
    }

    /**
     * Gets the value of the vin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVin() {
        return vin;
    }

    /**
     * Sets the value of the vin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVin(String value) {
        this.vin = value;
    }

}
