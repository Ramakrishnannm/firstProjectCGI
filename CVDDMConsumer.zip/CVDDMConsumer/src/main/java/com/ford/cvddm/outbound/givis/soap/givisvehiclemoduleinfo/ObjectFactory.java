
package com.ford.cvddm.outbound.givis.soap.givisvehiclemoduleinfo;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.ford.cvddm.outbound.givis.soap.givisvehiclemoduleinfo package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _RestoreModuleInfoResponse_QNAME = new QName("urn:ford/interface/Vehicle/Module/Information/v4.0", "RestoreModuleInfoResponse");
    private final static QName _RestoreModuleInfoRequest_QNAME = new QName("urn:ford/interface/Vehicle/Module/Information/v4.0", "RestoreModuleInfoRequest");
    private final static QName _FirstCondition_QNAME = new QName("urn:ford/Vehicle/Module/Information/v4.0", "FirstCondition");
    private final static QName _GetLicensedPartHistoryResponse_QNAME = new QName("urn:ford/interface/Vehicle/Module/Information/v4.0", "GetLicensedPartHistoryResponse");
    private final static QName _PerformModuleAuthenticationRequest_QNAME = new QName("urn:ford/interface/Vehicle/Module/Information/v4.0", "PerformModuleAuthenticationRequest");
    private final static QName _VehicleModuleInfoRequest_QNAME = new QName("urn:ford/interface/Vehicle/Module/Information/v4.0", "VehicleModuleInfoRequest");
    private final static QName _PrecedenceGroup_QNAME = new QName("urn:ford/Vehicle/Module/Information/v4.0", "PrecedenceGroup");
    private final static QName _ModulesExist_QNAME = new QName("urn:ford/interface/Vehicle/Module/Information/v4.0", "ModulesExist");
    private final static QName _GetLicensedPart_QNAME = new QName("urn:ford/interface/Vehicle/Module/Information/v4.0", "GetLicensedPart");
    private final static QName _PerformModuleAuthenticationResponse_QNAME = new QName("urn:ford/interface/Vehicle/Module/Information/v4.0", "PerformModuleAuthenticationResponse");
    private final static QName _VehicleModuleInfoResponse_QNAME = new QName("urn:ford/interface/Vehicle/Module/Information/v4.0", "VehicleModuleInfoResponse");
    private final static QName _GetLicensedPartResponse_QNAME = new QName("urn:ford/interface/Vehicle/Module/Information/v4.0", "GetLicensedPartResponse");
    private final static QName _GetLicensedPartHistory_QNAME = new QName("urn:ford/interface/Vehicle/Module/Information/v4.0", "GetLicensedPartHistory");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.ford.cvddm.outbound.givis.soap.givisvehiclemoduleinfo
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link NodeNetworkInterfaceDetailType }
     * 
     */
    public NodeNetworkInterfaceDetailType createNodeNetworkInterfaceDetailType() {
        return new NodeNetworkInterfaceDetailType();
    }

    /**
     * Create an instance of {@link NetworkInterfaceDetailType }
     * 
     */
    public NetworkInterfaceDetailType createNetworkInterfaceDetailType() {
        return new NetworkInterfaceDetailType();
    }

    /**
     * Create an instance of {@link VehicleModuleResponseType }
     * 
     */
    public VehicleModuleResponseType createVehicleModuleResponseType() {
        return new VehicleModuleResponseType();
    }

    /**
     * Create an instance of {@link VehicleModuleRequestType }
     * 
     */
    public VehicleModuleRequestType createVehicleModuleRequestType() {
        return new VehicleModuleRequestType();
    }

    /**
     * Create an instance of {@link ModulesExistType }
     * 
     */
    public ModulesExistType createModulesExistType() {
        return new ModulesExistType();
    }

    /**
     * Create an instance of {@link LicensedPartRequestType }
     * 
     */
    public LicensedPartRequestType createLicensedPartRequestType() {
        return new LicensedPartRequestType();
    }

    /**
     * Create an instance of {@link PerformModuleAuthenticationType }
     * 
     */
    public PerformModuleAuthenticationType createPerformModuleAuthenticationType() {
        return new PerformModuleAuthenticationType();
    }

    /**
     * Create an instance of {@link LicensedPartHistoryRequestType }
     * 
     */
    public LicensedPartHistoryRequestType createLicensedPartHistoryRequestType() {
        return new LicensedPartHistoryRequestType();
    }

    /**
     * Create an instance of {@link LicensedPartHistoryResponseType }
     * 
     */
    public LicensedPartHistoryResponseType createLicensedPartHistoryResponseType() {
        return new LicensedPartHistoryResponseType();
    }

    /**
     * Create an instance of {@link LicensedPartResponseType }
     * 
     */
    public LicensedPartResponseType createLicensedPartResponseType() {
        return new LicensedPartResponseType();
    }

    /**
     * Create an instance of {@link PrecedenceElementType }
     * 
     */
    public PrecedenceElementType createPrecedenceElementType() {
        return new PrecedenceElementType();
    }

    /**
     * Create an instance of {@link FirstConditionType }
     * 
     */
    public FirstConditionType createFirstConditionType() {
        return new FirstConditionType();
    }

    /**
     * Create an instance of {@link OTAOptimizedDIDList }
     * 
     */
    public OTAOptimizedDIDList createOTAOptimizedDIDList() {
        return new OTAOptimizedDIDList();
    }

    /**
     * Create an instance of {@link OptimizedDIDListType }
     * 
     */
    public OptimizedDIDListType createOptimizedDIDListType() {
        return new OptimizedDIDListType();
    }

    /**
     * Create an instance of {@link ODLNetworkType }
     * 
     */
    public ODLNetworkType createODLNetworkType() {
        return new ODLNetworkType();
    }

    /**
     * Create an instance of {@link ConditionSegment }
     * 
     */
    public ConditionSegment createConditionSegment() {
        return new ConditionSegment();
    }

    /**
     * Create an instance of {@link ConditionSegmentType }
     * 
     */
    public ConditionSegmentType createConditionSegmentType() {
        return new ConditionSegmentType();
    }

    /**
     * Create an instance of {@link ECUAcronymType }
     * 
     */
    public ECUAcronymType createECUAcronymType() {
        return new ECUAcronymType();
    }

    /**
     * Create an instance of {@link QuestionType }
     * 
     */
    public QuestionType createQuestionType() {
        return new QuestionType();
    }

    /**
     * Create an instance of {@link SoftwareStateType }
     * 
     */
    public SoftwareStateType createSoftwareStateType() {
        return new SoftwareStateType();
    }

    /**
     * Create an instance of {@link VehicleModelYearType }
     * 
     */
    public VehicleModelYearType createVehicleModelYearType() {
        return new VehicleModelYearType();
    }

    /**
     * Create an instance of {@link CentralConfigInfoType }
     * 
     */
    public CentralConfigInfoType createCentralConfigInfoType() {
        return new CentralConfigInfoType();
    }

    /**
     * Create an instance of {@link GatewayInfoType }
     * 
     */
    public GatewayInfoType createGatewayInfoType() {
        return new GatewayInfoType();
    }

    /**
     * Create an instance of {@link VehicleDataType }
     * 
     */
    public VehicleDataType createVehicleDataType() {
        return new VehicleDataType();
    }

    /**
     * Create an instance of {@link GatewayType }
     * 
     */
    public GatewayType createGatewayType() {
        return new GatewayType();
    }

    /**
     * Create an instance of {@link UsedByVSCSSpecificationsType }
     * 
     */
    public UsedByVSCSSpecificationsType createUsedByVSCSSpecificationsType() {
        return new UsedByVSCSSpecificationsType();
    }

    /**
     * Create an instance of {@link StateUpdateRoleType }
     * 
     */
    public StateUpdateRoleType createStateUpdateRoleType() {
        return new StateUpdateRoleType();
    }

    /**
     * Create an instance of {@link OptimizedDIDType }
     * 
     */
    public OptimizedDIDType createOptimizedDIDType() {
        return new OptimizedDIDType();
    }

    /**
     * Create an instance of {@link NodeInfoType }
     * 
     */
    public NodeInfoType createNodeInfoType() {
        return new NodeInfoType();
    }

    /**
     * Create an instance of {@link AdditionalConditionsType }
     * 
     */
    public AdditionalConditionsType createAdditionalConditionsType() {
        return new AdditionalConditionsType();
    }

    /**
     * Create an instance of {@link BroadcastDTCType }
     * 
     */
    public BroadcastDTCType createBroadcastDTCType() {
        return new BroadcastDTCType();
    }

    /**
     * Create an instance of {@link FeatureCodeInfoType }
     * 
     */
    public FeatureCodeInfoType createFeatureCodeInfoType() {
        return new FeatureCodeInfoType();
    }

    /**
     * Create an instance of {@link LicensedPartHistoryType }
     * 
     */
    public LicensedPartHistoryType createLicensedPartHistoryType() {
        return new LicensedPartHistoryType();
    }

    /**
     * Create an instance of {@link IgnoreThisDIDType }
     * 
     */
    public IgnoreThisDIDType createIgnoreThisDIDType() {
        return new IgnoreThisDIDType();
    }

    /**
     * Create an instance of {@link WrapperDocType }
     * 
     */
    public WrapperDocType createWrapperDocType() {
        return new WrapperDocType();
    }

    /**
     * Create an instance of {@link NetworkViewFilesType }
     * 
     */
    public NetworkViewFilesType createNetworkViewFilesType() {
        return new NetworkViewFilesType();
    }

    /**
     * Create an instance of {@link ECUEncryptionInfoType }
     * 
     */
    public ECUEncryptionInfoType createECUEncryptionInfoType() {
        return new ECUEncryptionInfoType();
    }

    /**
     * Create an instance of {@link ModuleNodeType }
     * 
     */
    public ModuleNodeType createModuleNodeType() {
        return new ModuleNodeType();
    }

    /**
     * Create an instance of {@link FeatureCodeType }
     * 
     */
    public FeatureCodeType createFeatureCodeType() {
        return new FeatureCodeType();
    }

    /**
     * Create an instance of {@link LicenseFulfillmentStatusType }
     * 
     */
    public LicenseFulfillmentStatusType createLicenseFulfillmentStatusType() {
        return new LicenseFulfillmentStatusType();
    }

    /**
     * Create an instance of {@link HardwareType }
     * 
     */
    public HardwareType createHardwareType() {
        return new HardwareType();
    }

    /**
     * Create an instance of {@link SecurityBytesType }
     * 
     */
    public SecurityBytesType createSecurityBytesType() {
        return new SecurityBytesType();
    }

    /**
     * Create an instance of {@link ODLDiagnosticSpecType }
     * 
     */
    public ODLDiagnosticSpecType createODLDiagnosticSpecType() {
        return new ODLDiagnosticSpecType();
    }

    /**
     * Create an instance of {@link ECUAssemblySecurityDataType }
     * 
     */
    public ECUAssemblySecurityDataType createECUAssemblySecurityDataType() {
        return new ECUAssemblySecurityDataType();
    }

    /**
     * Create an instance of {@link NodeExistsType }
     * 
     */
    public NodeExistsType createNodeExistsType() {
        return new NodeExistsType();
    }

    /**
     * Create an instance of {@link WarningType }
     * 
     */
    public WarningType createWarningType() {
        return new WarningType();
    }

    /**
     * Create an instance of {@link FeatureCodeInfoALType }
     * 
     */
    public FeatureCodeInfoALType createFeatureCodeInfoALType() {
        return new FeatureCodeInfoALType();
    }

    /**
     * Create an instance of {@link ECUSoftwareType }
     * 
     */
    public ECUSoftwareType createECUSoftwareType() {
        return new ECUSoftwareType();
    }

    /**
     * Create an instance of {@link SimpleDIDInfoType }
     * 
     */
    public SimpleDIDInfoType createSimpleDIDInfoType() {
        return new SimpleDIDInfoType();
    }

    /**
     * Create an instance of {@link SpecCategoryType }
     * 
     */
    public SpecCategoryType createSpecCategoryType() {
        return new SpecCategoryType();
    }

    /**
     * Create an instance of {@link ModuleODLNetworkType }
     * 
     */
    public ModuleODLNetworkType createModuleODLNetworkType() {
        return new ModuleODLNetworkType();
    }

    /**
     * Create an instance of {@link PostInstallSoftwareType }
     * 
     */
    public PostInstallSoftwareType createPostInstallSoftwareType() {
        return new PostInstallSoftwareType();
    }

    /**
     * Create an instance of {@link TSBType }
     * 
     */
    public TSBType createTSBType() {
        return new TSBType();
    }

    /**
     * Create an instance of {@link SimpleNodeAddressType }
     * 
     */
    public SimpleNodeAddressType createSimpleNodeAddressType() {
        return new SimpleNodeAddressType();
    }

    /**
     * Create an instance of {@link CoordinatedNodeType }
     * 
     */
    public CoordinatedNodeType createCoordinatedNodeType() {
        return new CoordinatedNodeType();
    }

    /**
     * Create an instance of {@link PartitionHealthType }
     * 
     */
    public PartitionHealthType createPartitionHealthType() {
        return new PartitionHealthType();
    }

    /**
     * Create an instance of {@link FlashActionType }
     * 
     */
    public FlashActionType createFlashActionType() {
        return new FlashActionType();
    }

    /**
     * Create an instance of {@link PreInstallSoftwareType }
     * 
     */
    public PreInstallSoftwareType createPreInstallSoftwareType() {
        return new PreInstallSoftwareType();
    }

    /**
     * Create an instance of {@link ODLNodeType }
     * 
     */
    public ODLNodeType createODLNodeType() {
        return new ODLNodeType();
    }

    /**
     * Create an instance of {@link SoftwareMetaDataType }
     * 
     */
    public SoftwareMetaDataType createSoftwareMetaDataType() {
        return new SoftwareMetaDataType();
    }

    /**
     * Create an instance of {@link ODLECUType }
     * 
     */
    public ODLECUType createODLECUType() {
        return new ODLECUType();
    }

    /**
     * Create an instance of {@link PODProgrammingManagementDataType }
     * 
     */
    public PODProgrammingManagementDataType createPODProgrammingManagementDataType() {
        return new PODProgrammingManagementDataType();
    }

    /**
     * Create an instance of {@link NodeType }
     * 
     */
    public NodeType createNodeType() {
        return new NodeType();
    }

    /**
     * Create an instance of {@link LicensedPartInfoType }
     * 
     */
    public LicensedPartInfoType createLicensedPartInfoType() {
        return new LicensedPartInfoType();
    }

    /**
     * Create an instance of {@link ModifiedConfigDIDInfoType }
     * 
     */
    public ModifiedConfigDIDInfoType createModifiedConfigDIDInfoType() {
        return new ModifiedConfigDIDInfoType();
    }

    /**
     * Create an instance of {@link CurrentDIDListType }
     * 
     */
    public CurrentDIDListType createCurrentDIDListType() {
        return new CurrentDIDListType();
    }

    /**
     * Create an instance of {@link HasActionIDType }
     * 
     */
    public HasActionIDType createHasActionIDType() {
        return new HasActionIDType();
    }

    /**
     * Create an instance of {@link FeatureStateType }
     * 
     */
    public FeatureStateType createFeatureStateType() {
        return new FeatureStateType();
    }

    /**
     * Create an instance of {@link DerivedAssemblyType }
     * 
     */
    public DerivedAssemblyType createDerivedAssemblyType() {
        return new DerivedAssemblyType();
    }

    /**
     * Create an instance of {@link DIDInfoType }
     * 
     */
    public DIDInfoType createDIDInfoType() {
        return new DIDInfoType();
    }

    /**
     * Create an instance of {@link DIDComplianceDetailType }
     * 
     */
    public DIDComplianceDetailType createDIDComplianceDetailType() {
        return new DIDComplianceDetailType();
    }

    /**
     * Create an instance of {@link AddFeatureType }
     * 
     */
    public AddFeatureType createAddFeatureType() {
        return new AddFeatureType();
    }

    /**
     * Create an instance of {@link QuestionDetails }
     * 
     */
    public QuestionDetails createQuestionDetails() {
        return new QuestionDetails();
    }

    /**
     * Create an instance of {@link AdditionalNodePropertiesType }
     * 
     */
    public AdditionalNodePropertiesType createAdditionalNodePropertiesType() {
        return new AdditionalNodePropertiesType();
    }

    /**
     * Create an instance of {@link RequestNode }
     * 
     */
    public RequestNode createRequestNode() {
        return new RequestNode();
    }

    /**
     * Create an instance of {@link ODLComplianceDetailType }
     * 
     */
    public ODLComplianceDetailType createODLComplianceDetailType() {
        return new ODLComplianceDetailType();
    }

    /**
     * Create an instance of {@link AsBuiltDataType }
     * 
     */
    public AsBuiltDataType createAsBuiltDataType() {
        return new AsBuiltDataType();
    }

    /**
     * Create an instance of {@link RequestInfoType }
     * 
     */
    public RequestInfoType createRequestInfoType() {
        return new RequestInfoType();
    }

    /**
     * Create an instance of {@link HasServicePartsType }
     * 
     */
    public HasServicePartsType createHasServicePartsType() {
        return new HasServicePartsType();
    }

    /**
     * Create an instance of {@link HistoricType }
     * 
     */
    public HistoricType createHistoricType() {
        return new HistoricType();
    }

    /**
     * Create an instance of {@link ComplianceDIDType }
     * 
     */
    public ComplianceDIDType createComplianceDIDType() {
        return new ComplianceDIDType();
    }

    /**
     * Create an instance of {@link ISDataAvailableType }
     * 
     */
    public ISDataAvailableType createISDataAvailableType() {
        return new ISDataAvailableType();
    }

    /**
     * Create an instance of {@link ESNMetadataType }
     * 
     */
    public ESNMetadataType createESNMetadataType() {
        return new ESNMetadataType();
    }

    /**
     * Create an instance of {@link ECUAssemblyType }
     * 
     */
    public ECUAssemblyType createECUAssemblyType() {
        return new ECUAssemblyType();
    }

    /**
     * Create an instance of {@link RemoveFeatureType }
     * 
     */
    public RemoveFeatureType createRemoveFeatureType() {
        return new RemoveFeatureType();
    }

    /**
     * Create an instance of {@link DTCDetails }
     * 
     */
    public DTCDetails createDTCDetails() {
        return new DTCDetails();
    }

    /**
     * Create an instance of {@link FlashActionListType }
     * 
     */
    public FlashActionListType createFlashActionListType() {
        return new FlashActionListType();
    }

    /**
     * Create an instance of {@link AssemblyPNDetailsType }
     * 
     */
    public AssemblyPNDetailsType createAssemblyPNDetailsType() {
        return new AssemblyPNDetailsType();
    }

    /**
     * Create an instance of {@link NodeNetworkInterfaceDetailType.NetworkInterface }
     * 
     */
    public NodeNetworkInterfaceDetailType.NetworkInterface createNodeNetworkInterfaceDetailTypeNetworkInterface() {
        return new NodeNetworkInterfaceDetailType.NetworkInterface();
    }

    /**
     * Create an instance of {@link NetworkInterfaceDetailType.NetworkInterface }
     * 
     */
    public NetworkInterfaceDetailType.NetworkInterface createNetworkInterfaceDetailTypeNetworkInterface() {
        return new NetworkInterfaceDetailType.NetworkInterface();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link VehicleModuleResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:ford/interface/Vehicle/Module/Information/v4.0", name = "RestoreModuleInfoResponse")
    public JAXBElement<VehicleModuleResponseType> createRestoreModuleInfoResponse(VehicleModuleResponseType value) {
        return new JAXBElement<VehicleModuleResponseType>(_RestoreModuleInfoResponse_QNAME, VehicleModuleResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link VehicleModuleRequestType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:ford/interface/Vehicle/Module/Information/v4.0", name = "RestoreModuleInfoRequest")
    public JAXBElement<VehicleModuleRequestType> createRestoreModuleInfoRequest(VehicleModuleRequestType value) {
        return new JAXBElement<VehicleModuleRequestType>(_RestoreModuleInfoRequest_QNAME, VehicleModuleRequestType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FirstConditionType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:ford/Vehicle/Module/Information/v4.0", name = "FirstCondition")
    public JAXBElement<FirstConditionType> createFirstCondition(FirstConditionType value) {
        return new JAXBElement<FirstConditionType>(_FirstCondition_QNAME, FirstConditionType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LicensedPartHistoryResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:ford/interface/Vehicle/Module/Information/v4.0", name = "GetLicensedPartHistoryResponse")
    public JAXBElement<LicensedPartHistoryResponseType> createGetLicensedPartHistoryResponse(LicensedPartHistoryResponseType value) {
        return new JAXBElement<LicensedPartHistoryResponseType>(_GetLicensedPartHistoryResponse_QNAME, LicensedPartHistoryResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PerformModuleAuthenticationType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:ford/interface/Vehicle/Module/Information/v4.0", name = "PerformModuleAuthenticationRequest")
    public JAXBElement<PerformModuleAuthenticationType> createPerformModuleAuthenticationRequest(PerformModuleAuthenticationType value) {
        return new JAXBElement<PerformModuleAuthenticationType>(_PerformModuleAuthenticationRequest_QNAME, PerformModuleAuthenticationType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link VehicleModuleRequestType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:ford/interface/Vehicle/Module/Information/v4.0", name = "VehicleModuleInfoRequest")
    public JAXBElement<VehicleModuleRequestType> createVehicleModuleInfoRequest(VehicleModuleRequestType value) {
        return new JAXBElement<VehicleModuleRequestType>(_VehicleModuleInfoRequest_QNAME, VehicleModuleRequestType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PrecedenceElementType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:ford/Vehicle/Module/Information/v4.0", name = "PrecedenceGroup")
    public JAXBElement<PrecedenceElementType> createPrecedenceGroup(PrecedenceElementType value) {
        return new JAXBElement<PrecedenceElementType>(_PrecedenceGroup_QNAME, PrecedenceElementType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ModulesExistType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:ford/interface/Vehicle/Module/Information/v4.0", name = "ModulesExist")
    public JAXBElement<ModulesExistType> createModulesExist(ModulesExistType value) {
        return new JAXBElement<ModulesExistType>(_ModulesExist_QNAME, ModulesExistType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LicensedPartRequestType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:ford/interface/Vehicle/Module/Information/v4.0", name = "GetLicensedPart")
    public JAXBElement<LicensedPartRequestType> createGetLicensedPart(LicensedPartRequestType value) {
        return new JAXBElement<LicensedPartRequestType>(_GetLicensedPart_QNAME, LicensedPartRequestType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PerformModuleAuthenticationType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:ford/interface/Vehicle/Module/Information/v4.0", name = "PerformModuleAuthenticationResponse")
    public JAXBElement<PerformModuleAuthenticationType> createPerformModuleAuthenticationResponse(PerformModuleAuthenticationType value) {
        return new JAXBElement<PerformModuleAuthenticationType>(_PerformModuleAuthenticationResponse_QNAME, PerformModuleAuthenticationType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link VehicleModuleResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:ford/interface/Vehicle/Module/Information/v4.0", name = "VehicleModuleInfoResponse")
    public JAXBElement<VehicleModuleResponseType> createVehicleModuleInfoResponse(VehicleModuleResponseType value) {
        return new JAXBElement<VehicleModuleResponseType>(_VehicleModuleInfoResponse_QNAME, VehicleModuleResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LicensedPartResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:ford/interface/Vehicle/Module/Information/v4.0", name = "GetLicensedPartResponse")
    public JAXBElement<LicensedPartResponseType> createGetLicensedPartResponse(LicensedPartResponseType value) {
        return new JAXBElement<LicensedPartResponseType>(_GetLicensedPartResponse_QNAME, LicensedPartResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LicensedPartHistoryRequestType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:ford/interface/Vehicle/Module/Information/v4.0", name = "GetLicensedPartHistory")
    public JAXBElement<LicensedPartHistoryRequestType> createGetLicensedPartHistory(LicensedPartHistoryRequestType value) {
        return new JAXBElement<LicensedPartHistoryRequestType>(_GetLicensedPartHistory_QNAME, LicensedPartHistoryRequestType.class, null, value);
    }

}
