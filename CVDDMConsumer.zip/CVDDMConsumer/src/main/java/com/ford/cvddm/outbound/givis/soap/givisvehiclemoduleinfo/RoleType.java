
package com.ford.cvddm.outbound.givis.soap.givisvehiclemoduleinfo;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RoleType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="RoleType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="CONSUMER"/>
 *     &lt;enumeration value="DEALER"/>
 *     &lt;enumeration value="AFTERMARKET"/>
 *     &lt;enumeration value="MODCENTER"/>
 *     &lt;enumeration value="ENGINEER"/>
 *     &lt;enumeration value="TESTCONSUMER"/>
 *     &lt;enumeration value="OTA"/>
 *     &lt;enumeration value="TESTOTA"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "RoleType", namespace = "urn:ford/productdesign/vis/common/v1.0")
@XmlEnum
public enum RoleType {

    CONSUMER,
    DEALER,
    AFTERMARKET,
    MODCENTER,
    ENGINEER,
    TESTCONSUMER,
    OTA,
    TESTOTA;

    public String value() {
        return name();
    }

    public static RoleType fromValue(String v) {
        return valueOf(v);
    }

}
