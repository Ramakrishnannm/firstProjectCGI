
package com.ford.cvddm.outbound.aps.entitlementGroup;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GroupsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GroupsType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.sps.ford.com/EntitlementGroupService/data}SubjectGrp"/>
 *         &lt;element ref="{http://www.sps.ford.com/EntitlementGroupService/data}GroupDetail" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GroupsType", propOrder = {
    "subjectGrp",
    "groupDetail"
})
public class GroupsType
    implements Serializable
{

    @XmlElement(name = "SubjectGrp", required = true)
    protected String subjectGrp;
    @XmlElement(name = "GroupDetail")
    protected List<GroupDetailType> groupDetail;

    /**
     * Gets the value of the subjectGrp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubjectGrp() {
        return subjectGrp;
    }

    /**
     * Sets the value of the subjectGrp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubjectGrp(String value) {
        this.subjectGrp = value;
    }

    /**
     * Gets the value of the groupDetail property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the groupDetail property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGroupDetail().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GroupDetailType }
     * 
     * 
     */
    public List<GroupDetailType> getGroupDetail() {
        if (groupDetail == null) {
            groupDetail = new ArrayList<GroupDetailType>();
        }
        return this.groupDetail;
    }

}
