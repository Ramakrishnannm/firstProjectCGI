
package com.ford.cvddm.outbound.gvms.vehicleModuleInfo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for VehicleModuleRequestType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="VehicleModuleRequestType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="VIN" type="{urn:ford/Vehicle/Module/Information/v4.0}VINType"/>
 *         &lt;element name="DownloadType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RequestRole" type="{urn:ford/Vehicle/Module/Information/v4.0}StateUpdateRoleType"/>
 *         &lt;element name="RequestNode" type="{urn:ford/Vehicle/Module/Information/v4.0}RequestNode" maxOccurs="unbounded"/>
 *         &lt;element name="RequestInfo" type="{urn:ford/Vehicle/Module/Information/v4.0}RequestInfoType" minOccurs="0"/>
 *         &lt;element name="Language" type="{urn:ford/productdesign/vis/common/v1.0}LanguageType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "VehicleModuleRequestType", namespace = "urn:ford/interface/Vehicle/Module/Information/v4.0", propOrder = {
    "vin",
    "downloadType",
    "requestRole",
    "requestNode",
    "requestInfo",
    "language"
})
public class VehicleModuleRequestType
    implements Serializable
{

    @XmlElement(name = "VIN", required = true)
    protected String vin;
    @XmlElement(name = "DownloadType")
    protected String downloadType;
    @XmlElement(name = "RequestRole", required = true)
    protected StateUpdateRoleType requestRole;
    @XmlElement(name = "RequestNode", required = true)
    protected List<RequestNode> requestNode;
    @XmlElement(name = "RequestInfo")
    protected RequestInfoType requestInfo;
    @XmlElement(name = "Language")
    protected String language;

    /**
     * Gets the value of the vin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVIN() {
        return vin;
    }

    /**
     * Sets the value of the vin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVIN(String value) {
        this.vin = value;
    }

    /**
     * Gets the value of the downloadType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDownloadType() {
        return downloadType;
    }

    /**
     * Sets the value of the downloadType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDownloadType(String value) {
        this.downloadType = value;
    }

    /**
     * Gets the value of the requestRole property.
     * 
     * @return
     *     possible object is
     *     {@link StateUpdateRoleType }
     *     
     */
    public StateUpdateRoleType getRequestRole() {
        return requestRole;
    }

    /**
     * Sets the value of the requestRole property.
     * 
     * @param value
     *     allowed object is
     *     {@link StateUpdateRoleType }
     *     
     */
    public void setRequestRole(StateUpdateRoleType value) {
        this.requestRole = value;
    }

    /**
     * Gets the value of the requestNode property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the requestNode property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRequestNode().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RequestNode }
     * 
     * 
     */
    public List<RequestNode> getRequestNode() {
        if (requestNode == null) {
            requestNode = new ArrayList<RequestNode>();
        }
        return this.requestNode;
    }

    /**
     * Gets the value of the requestInfo property.
     * 
     * @return
     *     possible object is
     *     {@link RequestInfoType }
     *     
     */
    public RequestInfoType getRequestInfo() {
        return requestInfo;
    }

    /**
     * Sets the value of the requestInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link RequestInfoType }
     *     
     */
    public void setRequestInfo(RequestInfoType value) {
        this.requestInfo = value;
    }

    /**
     * Gets the value of the language property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLanguage() {
        return language;
    }

    /**
     * Sets the value of the language property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLanguage(String value) {
        this.language = value;
    }

}
