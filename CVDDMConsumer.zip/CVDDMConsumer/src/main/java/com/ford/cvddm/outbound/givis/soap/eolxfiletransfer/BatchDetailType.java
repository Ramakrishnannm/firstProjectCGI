
package com.ford.cvddm.outbound.givis.soap.eolxfiletransfer;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * 			Determines batch metadata i.e Total# of batches to transfer,
 * 			files by batch, and batch count. 
 * 			Note: When BatchDetailType is sent as part of header request,
 * 			fileCount is used for sending total file count.
 * 		
 * 
 * <p>Java class for BatchDetailType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BatchDetailType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="batchCount" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="fileCount" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="batchNumber" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="batchCorrelationId" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BatchDetailType")
public class BatchDetailType {

    @XmlAttribute(name = "batchCount")
    protected Integer batchCount;
    @XmlAttribute(name = "fileCount")
    protected Integer fileCount;
    @XmlAttribute(name = "batchNumber")
    protected Integer batchNumber;
    @XmlAttribute(name = "batchCorrelationId")
    protected String batchCorrelationId;

    /**
     * Gets the value of the batchCount property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getBatchCount() {
        return batchCount;
    }

    /**
     * Sets the value of the batchCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setBatchCount(Integer value) {
        this.batchCount = value;
    }

    /**
     * Gets the value of the fileCount property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getFileCount() {
        return fileCount;
    }

    /**
     * Sets the value of the fileCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setFileCount(Integer value) {
        this.fileCount = value;
    }

    /**
     * Gets the value of the batchNumber property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getBatchNumber() {
        return batchNumber;
    }

    /**
     * Sets the value of the batchNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setBatchNumber(Integer value) {
        this.batchNumber = value;
    }

    /**
     * Gets the value of the batchCorrelationId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBatchCorrelationId() {
        return batchCorrelationId;
    }

    /**
     * Sets the value of the batchCorrelationId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBatchCorrelationId(String value) {
        this.batchCorrelationId = value;
    }

}
