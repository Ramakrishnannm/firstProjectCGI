
package com.ford.cvddm.outbound.gvms.vehicleModuleInfo;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ISDataAvailableType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ISDataAvailableType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="VehicleData" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="AsBuiltData" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="VehicleModelYearData" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="OptimizedDIDListData" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ISDataAvailableType", propOrder = {
    "vehicleData",
    "asBuiltData",
    "vehicleModelYearData",
    "optimizedDIDListData"
})
public class ISDataAvailableType
    implements Serializable
{

    @XmlElement(name = "VehicleData")
    protected boolean vehicleData;
    @XmlElement(name = "AsBuiltData")
    protected boolean asBuiltData;
    @XmlElement(name = "VehicleModelYearData")
    protected boolean vehicleModelYearData;
    @XmlElement(name = "OptimizedDIDListData")
    protected boolean optimizedDIDListData;

    /**
     * Gets the value of the vehicleData property.
     * 
     */
    public boolean isVehicleData() {
        return vehicleData;
    }

    /**
     * Sets the value of the vehicleData property.
     * 
     */
    public void setVehicleData(boolean value) {
        this.vehicleData = value;
    }

    /**
     * Gets the value of the asBuiltData property.
     * 
     */
    public boolean isAsBuiltData() {
        return asBuiltData;
    }

    /**
     * Sets the value of the asBuiltData property.
     * 
     */
    public void setAsBuiltData(boolean value) {
        this.asBuiltData = value;
    }

    /**
     * Gets the value of the vehicleModelYearData property.
     * 
     */
    public boolean isVehicleModelYearData() {
        return vehicleModelYearData;
    }

    /**
     * Sets the value of the vehicleModelYearData property.
     * 
     */
    public void setVehicleModelYearData(boolean value) {
        this.vehicleModelYearData = value;
    }

    /**
     * Gets the value of the optimizedDIDListData property.
     * 
     */
    public boolean isOptimizedDIDListData() {
        return optimizedDIDListData;
    }

    /**
     * Sets the value of the optimizedDIDListData property.
     * 
     */
    public void setOptimizedDIDListData(boolean value) {
        this.optimizedDIDListData = value;
    }

}
