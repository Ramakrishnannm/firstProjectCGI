@javax.xml.bind.annotation.XmlSchema(namespace = "urn:ford/interface/Application/ResourcePolicy/Role/v1", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.ford.cvddm.outbound.aps.appResourcePolicyRole;
