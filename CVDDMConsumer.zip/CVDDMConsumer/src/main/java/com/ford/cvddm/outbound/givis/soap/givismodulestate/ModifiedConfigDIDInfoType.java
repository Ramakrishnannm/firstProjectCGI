
package com.ford.cvddm.outbound.givis.soap.givismodulestate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ModifiedConfigDIDInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ModifiedConfigDIDInfoType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Response" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="didValue" use="required" type="{urn:ford/Vehicle/Module/Information/v4.0}DIDValueType" />
 *       &lt;attribute name="didType" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ModifiedConfigDIDInfoType", propOrder = {
    "response"
})
public class ModifiedConfigDIDInfoType {

    @XmlElement(name = "Response")
    protected String response;
    @XmlAttribute(name = "didValue", required = true)
    protected String didValue;
    @XmlAttribute(name = "didType")
    protected String didType;

    /**
     * Gets the value of the response property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponse() {
        return response;
    }

    /**
     * Sets the value of the response property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponse(String value) {
        this.response = value;
    }

    /**
     * Gets the value of the didValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDidValue() {
        return didValue;
    }

    /**
     * Sets the value of the didValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDidValue(String value) {
        this.didValue = value;
    }

    /**
     * Gets the value of the didType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDidType() {
        return didType;
    }

    /**
     * Sets the value of the didType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDidType(String value) {
        this.didType = value;
    }

}
