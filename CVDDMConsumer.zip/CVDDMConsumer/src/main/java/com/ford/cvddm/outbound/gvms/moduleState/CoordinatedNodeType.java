
package com.ford.cvddm.outbound.gvms.moduleState;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CoordinatedNodeType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CoordinatedNodeType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Node" type="{urn:ford/Vehicle/Module/Information/v4.0}NodeAddressType"/>
 *         &lt;element name="DTC" type="{urn:ford/Vehicle/Module/Information/v4.0}DTCDetails" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="Question" type="{urn:ford/Vehicle/Module/Information/v4.0}QuestionDetails" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CoordinatedNodeType", propOrder = {
    "node",
    "dtc",
    "question"
})
public class CoordinatedNodeType
    implements Serializable
{

    @XmlElement(name = "Node", required = true)
    protected String node;
    @XmlElement(name = "DTC")
    protected List<DTCDetails> dtc;
    @XmlElement(name = "Question")
    protected List<QuestionDetails> question;

    /**
     * Gets the value of the node property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNode() {
        return node;
    }

    /**
     * Sets the value of the node property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNode(String value) {
        this.node = value;
    }

    /**
     * Gets the value of the dtc property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the dtc property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDTC().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DTCDetails }
     * 
     * 
     */
    public List<DTCDetails> getDTC() {
        if (dtc == null) {
            dtc = new ArrayList<DTCDetails>();
        }
        return this.dtc;
    }

    /**
     * Gets the value of the question property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the question property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getQuestion().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link QuestionDetails }
     * 
     * 
     */
    public List<QuestionDetails> getQuestion() {
        if (question == null) {
            question = new ArrayList<QuestionDetails>();
        }
        return this.question;
    }

}
