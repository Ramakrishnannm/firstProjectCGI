
package com.ford.cvddm.outbound.gvms.getCurrentLite;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.List;
import java.util.Vector;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder({
        "srcTransID",
        "traceID",
        "vehicleDetails",
        "mfalDetails",
        "nodeDetails",
        "statusInfo"
})
public class GetCurrentLiteResponse {

    private List<NodeDetail> nodeDetails = null;
    private AdditionalAttribute additionalAttribute;
    private String srcTransID;
    private List<StatusInfo> statusInfo = null;
    private String traceID;
    private VehicleDetails vehicleDetails;
    private Vector<MfalDetails> mfalDetails;

    public List<NodeDetail> getNodeDetails() {
        return nodeDetails;
    }

    public void setNodeDetails(List<NodeDetail> nodeDetails) {
        this.nodeDetails = nodeDetails;
    }

    public AdditionalAttribute getAdditionalAttribute() {
        return additionalAttribute;
    }

    public void setAdditionalAttribute(AdditionalAttribute additionalAttribute) {
        this.additionalAttribute = additionalAttribute;
    }

    public String getSrcTransID() {
        return srcTransID;
    }

    public void setSrcTransID(String srcTransID) {
        this.srcTransID = srcTransID;
    }

    public List<StatusInfo> getStatusInfo() {
        return statusInfo;
    }

    public void setStatusInfo(List<StatusInfo> statusInfo) {
        this.statusInfo = statusInfo;
    }

    public String getTraceID() {
        return traceID;
    }

    public void setTraceID(String traceID) {
        this.traceID = traceID;
    }

    public VehicleDetails getVehicleDetails() {
        return vehicleDetails;
    }

    public void setVehicleDetails(VehicleDetails vehicleDetails) {
        this.vehicleDetails = vehicleDetails;
    }

    public Vector<MfalDetails> getMfalDetails () { return  mfalDetails; }

    public void setMfalDetails(Vector<MfalDetails> mfalDetails) {
        this.mfalDetails = mfalDetails;
    }

}
