
package com.ford.cvddm.outbound.gvms.vehicleModuleInfo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for NodeType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="NodeType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Address" type="{urn:ford/Vehicle/Module/Information/v4.0}NodeAddressType"/>
 *         &lt;element name="ECUAcronym" type="{urn:ford/Vehicle/Module/Information/v4.0}ECUAcronymType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="ESNMetadata" type="{urn:ford/Vehicle/Module/Information/v4.0}ESNMetadataType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="TesterAccessInterface" type="{urn:ford/Vehicle/Module/Information/v4.0}NetworkInterfaceDetailType" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="specificationCategory" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="isFlashed" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "NodeType", propOrder = {
    "address",
    "ecuAcronym",
    "esnMetadata",
    "testerAccessInterface"
})
public class NodeType
    implements Serializable
{

    @XmlElement(name = "Address", required = true)
    protected String address;
    @XmlElement(name = "ECUAcronym")
    protected List<ECUAcronymType> ecuAcronym;
    @XmlElement(name = "ESNMetadata")
    protected List<ESNMetadataType> esnMetadata;
    @XmlElement(name = "TesterAccessInterface")
    protected NetworkInterfaceDetailType testerAccessInterface;
    @XmlAttribute(name = "specificationCategory")
    protected String specificationCategory;
    @XmlAttribute(name = "isFlashed")
    protected Boolean isFlashed;

    /**
     * Gets the value of the address property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress() {
        return address;
    }

    /**
     * Sets the value of the address property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress(String value) {
        this.address = value;
    }

    /**
     * Gets the value of the ecuAcronym property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the ecuAcronym property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getECUAcronym().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ECUAcronymType }
     * 
     * 
     */
    public List<ECUAcronymType> getECUAcronym() {
        if (ecuAcronym == null) {
            ecuAcronym = new ArrayList<ECUAcronymType>();
        }
        return this.ecuAcronym;
    }

    /**
     * Gets the value of the esnMetadata property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the esnMetadata property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getESNMetadata().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ESNMetadataType }
     * 
     * 
     */
    public List<ESNMetadataType> getESNMetadata() {
        if (esnMetadata == null) {
            esnMetadata = new ArrayList<ESNMetadataType>();
        }
        return this.esnMetadata;
    }

    /**
     * Gets the value of the testerAccessInterface property.
     * 
     * @return
     *     possible object is
     *     {@link NetworkInterfaceDetailType }
     *     
     */
    public NetworkInterfaceDetailType getTesterAccessInterface() {
        return testerAccessInterface;
    }

    /**
     * Sets the value of the testerAccessInterface property.
     * 
     * @param value
     *     allowed object is
     *     {@link NetworkInterfaceDetailType }
     *     
     */
    public void setTesterAccessInterface(NetworkInterfaceDetailType value) {
        this.testerAccessInterface = value;
    }

    /**
     * Gets the value of the specificationCategory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSpecificationCategory() {
        return specificationCategory;
    }

    /**
     * Sets the value of the specificationCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSpecificationCategory(String value) {
        this.specificationCategory = value;
    }

    /**
     * Gets the value of the isFlashed property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsFlashed() {
        return isFlashed;
    }

    /**
     * Sets the value of the isFlashed property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsFlashed(Boolean value) {
        this.isFlashed = value;
    }

}
