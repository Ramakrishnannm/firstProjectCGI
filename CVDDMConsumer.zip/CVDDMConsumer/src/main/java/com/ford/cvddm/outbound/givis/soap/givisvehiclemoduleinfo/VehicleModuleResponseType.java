
package com.ford.cvddm.outbound.givis.soap.givisvehiclemoduleinfo;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for VehicleModuleResponseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="VehicleModuleResponseType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn:ford/interface/Vehicle/Module/Information/v4.0}VehicleModuleInfoRequest"/>
 *         &lt;element name="DataAvailable" type="{urn:ford/Vehicle/Module/Information/v4.0}ISDataAvailableType" minOccurs="0"/>
 *         &lt;element name="Vehicle" type="{urn:ford/Vehicle/Module/Information/v4.0}VehicleDataType" minOccurs="0"/>
 *         &lt;element name="OptimizedDIDList" type="{urn:ford/Vehicle/Module/Information/v4.0}OptimizedDIDListType" minOccurs="0"/>
 *         &lt;element name="FlashActionList" type="{urn:ford/Vehicle/Module/Information/v4.0}FlashActionListType" minOccurs="0"/>
 *         &lt;element name="NetworkViewFiles" type="{urn:ford/Vehicle/Module/Information/v4.0}NetworkViewFilesType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="Warning" type="{urn:ford/Vehicle/Module/Information/v4.0}WarningType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="VehicleModelYear" type="{urn:ford/Vehicle/Module/Information/v4.0}VehicleModelYearType" minOccurs="0"/>
 *         &lt;element name="XMLFileId" type="{urn:ford/Vehicle/Module/Information/v4.0}XMLFileIdType" minOccurs="0"/>
 *         &lt;element name="AsBuiltData" type="{urn:ford/Vehicle/Module/Information/v4.0}AsBuiltDataType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "VehicleModuleResponseType", namespace = "urn:ford/interface/Vehicle/Module/Information/v4.0", propOrder = {
    "vehicleModuleInfoRequest",
    "dataAvailable",
    "vehicle",
    "optimizedDIDList",
    "flashActionList",
    "networkViewFiles",
    "warning",
    "vehicleModelYear",
    "xmlFileId",
    "asBuiltData"
})
public class VehicleModuleResponseType {

    @XmlElement(name = "VehicleModuleInfoRequest", required = true)
    protected VehicleModuleRequestType vehicleModuleInfoRequest;
    @XmlElement(name = "DataAvailable")
    protected ISDataAvailableType dataAvailable;
    @XmlElement(name = "Vehicle")
    protected VehicleDataType vehicle;
    @XmlElement(name = "OptimizedDIDList")
    protected OptimizedDIDListType optimizedDIDList;
    @XmlElement(name = "FlashActionList")
    protected FlashActionListType flashActionList;
    @XmlElement(name = "NetworkViewFiles")
    protected List<NetworkViewFilesType> networkViewFiles;
    @XmlElement(name = "Warning")
    protected List<WarningType> warning;
    @XmlElement(name = "VehicleModelYear")
    protected VehicleModelYearType vehicleModelYear;
    @XmlElement(name = "XMLFileId")
    protected String xmlFileId;
    @XmlElement(name = "AsBuiltData")
    protected AsBuiltDataType asBuiltData;

    /**
     * This represents request type that generated
     * 								this response.
     * 							
     * 
     * @return
     *     possible object is
     *     {@link VehicleModuleRequestType }
     *     
     */
    public VehicleModuleRequestType getVehicleModuleInfoRequest() {
        return vehicleModuleInfoRequest;
    }

    /**
     * Sets the value of the vehicleModuleInfoRequest property.
     * 
     * @param value
     *     allowed object is
     *     {@link VehicleModuleRequestType }
     *     
     */
    public void setVehicleModuleInfoRequest(VehicleModuleRequestType value) {
        this.vehicleModuleInfoRequest = value;
    }

    /**
     * Gets the value of the dataAvailable property.
     * 
     * @return
     *     possible object is
     *     {@link ISDataAvailableType }
     *     
     */
    public ISDataAvailableType getDataAvailable() {
        return dataAvailable;
    }

    /**
     * Sets the value of the dataAvailable property.
     * 
     * @param value
     *     allowed object is
     *     {@link ISDataAvailableType }
     *     
     */
    public void setDataAvailable(ISDataAvailableType value) {
        this.dataAvailable = value;
    }

    /**
     * Gets the value of the vehicle property.
     * 
     * @return
     *     possible object is
     *     {@link VehicleDataType }
     *     
     */
    public VehicleDataType getVehicle() {
        return vehicle;
    }

    /**
     * Sets the value of the vehicle property.
     * 
     * @param value
     *     allowed object is
     *     {@link VehicleDataType }
     *     
     */
    public void setVehicle(VehicleDataType value) {
        this.vehicle = value;
    }

    /**
     * Gets the value of the optimizedDIDList property.
     * 
     * @return
     *     possible object is
     *     {@link OptimizedDIDListType }
     *     
     */
    public OptimizedDIDListType getOptimizedDIDList() {
        return optimizedDIDList;
    }

    /**
     * Sets the value of the optimizedDIDList property.
     * 
     * @param value
     *     allowed object is
     *     {@link OptimizedDIDListType }
     *     
     */
    public void setOptimizedDIDList(OptimizedDIDListType value) {
        this.optimizedDIDList = value;
    }

    /**
     * Gets the value of the flashActionList property.
     * 
     * @return
     *     possible object is
     *     {@link FlashActionListType }
     *     
     */
    public FlashActionListType getFlashActionList() {
        return flashActionList;
    }

    /**
     * Sets the value of the flashActionList property.
     * 
     * @param value
     *     allowed object is
     *     {@link FlashActionListType }
     *     
     */
    public void setFlashActionList(FlashActionListType value) {
        this.flashActionList = value;
    }

    /**
     * Gets the value of the networkViewFiles property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the networkViewFiles property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNetworkViewFiles().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link NetworkViewFilesType }
     * 
     * 
     */
    public List<NetworkViewFilesType> getNetworkViewFiles() {
        if (networkViewFiles == null) {
            networkViewFiles = new ArrayList<NetworkViewFilesType>();
        }
        return this.networkViewFiles;
    }

    /**
     * Gets the value of the warning property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the warning property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getWarning().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link WarningType }
     * 
     * 
     */
    public List<WarningType> getWarning() {
        if (warning == null) {
            warning = new ArrayList<WarningType>();
        }
        return this.warning;
    }

    /**
     * Gets the value of the vehicleModelYear property.
     * 
     * @return
     *     possible object is
     *     {@link VehicleModelYearType }
     *     
     */
    public VehicleModelYearType getVehicleModelYear() {
        return vehicleModelYear;
    }

    /**
     * Sets the value of the vehicleModelYear property.
     * 
     * @param value
     *     allowed object is
     *     {@link VehicleModelYearType }
     *     
     */
    public void setVehicleModelYear(VehicleModelYearType value) {
        this.vehicleModelYear = value;
    }

    /**
     * Gets the value of the xmlFileId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getXMLFileId() {
        return xmlFileId;
    }

    /**
     * Sets the value of the xmlFileId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setXMLFileId(String value) {
        this.xmlFileId = value;
    }

    /**
     * Gets the value of the asBuiltData property.
     * 
     * @return
     *     possible object is
     *     {@link AsBuiltDataType }
     *     
     */
    public AsBuiltDataType getAsBuiltData() {
        return asBuiltData;
    }

    /**
     * Sets the value of the asBuiltData property.
     * 
     * @param value
     *     allowed object is
     *     {@link AsBuiltDataType }
     *     
     */
    public void setAsBuiltData(AsBuiltDataType value) {
        this.asBuiltData = value;
    }

}
