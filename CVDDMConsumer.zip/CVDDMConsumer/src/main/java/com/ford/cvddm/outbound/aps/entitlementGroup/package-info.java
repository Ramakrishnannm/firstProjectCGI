@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.sps.ford.com/EntitlementGroupService/data", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.ford.cvddm.outbound.aps.entitlementGroup;
